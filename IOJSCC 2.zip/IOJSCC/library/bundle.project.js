require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"EffectScript":[function(require,module,exports){
"use strict";
cc._RFpush(module, '09ed9DLIZ5IEYbO7o9HRA+I', 'EffectScript');
// Script/Gamescript/EffectScript.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // COCOS-CREATOR LA ENGINE KHON NAN NHAT, EFFECT RENDER STATIC THEO SCREEN :| BO TAY

    onLoad: function onLoad() {
        this.schudleFixPosition();
    },
    setFixedPosition: function setFixedPosition() {
        this.rX = this.node.parent.x;
        this.rY = this.node.parent.y;
    },
    schudleFixPosition: function schudleFixPosition() {
        this.schedule(function (dt) {
            //var dtx=this.node.parent.x-this.rX;
            //var dty=this.node.parent.y-this.rY;
            //this.rX=this.node.parent.x;
            //this.rY=this.node.parent.y;
            //
            //this.node.x=this.node.x+dtx/2;
            //this.node.y=this.node.y+dty/2;
        }, 0.002);
    }
});

cc._RFpop();
},{}],"GameMap":[function(require,module,exports){
"use strict";
cc._RFpush(module, '5b781n3CftGaqia/EnKu/Bf', 'GameMap');
// Script/Gamescript/GameMap.js

var Utils = require('../LIB/Utils');
cc.Class({
    "extends": cc.Component,

    properties: {
        t_prefab: {
            type: cc.Prefab,
            "default": null
        },
        obs_prefab: {
            type: cc.Prefab,
            "default": null
        },
        bullet_prefab: {
            type: cc.Prefab,
            "default": null
        },
        item_ammo_prefab: {
            type: cc.Prefab,
            "default": null
        },
        item_health_prefab: {
            type: cc.Prefab,
            "default": null
        },

        tankAtlas: cc.SpriteAtlas,
        flagsAlas: cc.SpriteAtlas,
        explosionAtlas: cc.SpriteAtlas,

        fire_audio: {
            "default": null,
            url: cc.AudioClip
        },
        hit2: {
            "default": null,
            url: cc.AudioClip
        },
        hit_tank: {
            "default": null,
            url: cc.AudioClip
        },
        tank_no: {
            "default": null,
            url: cc.AudioClip
        },

        eff_hit_wall: cc.Prefab,
        eff_hit_tank: cc.Prefab,
        eff_gun_fire: cc.Prefab,
        eff_tank_explosion: cc.Prefab
    },

    // use this for initialization
    onLoad: function onLoad() {
        // khai bao dang dictionary key-value, mục đích là chỉ chứa các script điều khiển việc hiển thị các đối tượng trong node mapgame
        this.dictObs = {}; // obj_type=1;
        this.dictTanks = {}; // obj_type=2;
        this.dictBullets = {}; // obj_type=3;
        this.dictItems = {}; // obj_type=3;

        this.MYPLAYER = null;
        this.t_add_tank = 0;
        this.t_add_bullet = 0;
        this.t_add_obs = 0;
        this.t_add_items = 0;
        this.t_add_explosion = 0;

        this.isOver = false;
        this.frame = 0;

        this.estimateMoveTank();
    },

    /**
     * trong hàm updateFrameStep thì đầu tiên gọi điến hàm beginUpdateFrame, kết thúc gọi đến hàm endUpdateFrame
     * Mục đích là để kiểm tra những đối tượng nào mà trên server không còn trả về nữa thì destroy nó đi như là 
     *  (ra ngoài view màn hình(tank,items,obs), bị nổ(tank) ,hoặc hết time-life (items,bullet) )
     * 
     * 
     * 
     * */

    updateFrameStep: function updateFrameStep(msgObj) {
        this.frame++;
        //----------TANK ----
        this.beginUpdate(this.dictTanks);
        var arr_tank = msgObj.t;
        this.managerTank(arr_tank);
        this.finishUpdate(this.dictTanks);

        this.updateMapPosition();

        //----------OBS ----

        var arr_obs = msgObj.o;
        if (!(typeof arr_obs === "undefined")) {
            this.beginUpdate(this.dictObs);
            this.managerObs(arr_obs);
            this.finishUpdate(this.dictObs);
        }

        //----------BULLET ----
        this.beginUpdate(this.dictBullets);
        var arr_bullet = msgObj.b;
        this.managerBullet(arr_bullet);
        this.finishUpdate(this.dictBullets);

        //----------ITEM ----

        var arr_items = msgObj.i;
        if (!(typeof arr_items === "undefined")) {
            this.beginUpdate(this.dictItems);
            this.managerItems(arr_items);
            this.finishUpdate(this.dictItems);
        }

        //----------Explorsion ----
        var arr_ex = msgObj.e;
        this.managerExplosion(arr_ex);

        this.loadMSGTest();
    },

    beginUpdate: function beginUpdate(dictUpdate) {
        for (var ikey in dictUpdate) {
            var tmp_script = dictUpdate[ikey];
            tmp_script.node.isActiveSC = false;
        }
    },

    finishUpdate: function finishUpdate(dictUpdate) {
        var arrDelete = [];
        for (var ikey in dictUpdate) {
            var tmp_script = dictUpdate[ikey];
            if (tmp_script.node.isActiveSC) {
                continue;
            }
            if (cc.isValid(tmp_script.node)) {
                arrDelete.push(tmp_script.node);
            }
        }

        for (var deleteid = 0, maxlengt = arrDelete.length; deleteid < maxlengt; deleteid++) {
            var node_tmp = arrDelete[deleteid];
            var type_of_dict = node_tmp.obj_type;

            if (type_of_dict == 1) {
                delete this.dictObs[node_tmp.gid];
            }
            if (type_of_dict == 2) {
                delete this.dictTanks[node_tmp.gid];
            }
            if (type_of_dict == 3) {
                // var script_bullet_delete=this.dictBullets[node_tmp.gid];
                // script_bullet_delete.clearBulletEffect();
                delete this.dictBullets[node_tmp.gid];
            }
            if (type_of_dict == 4) {
                var script_item_delete = this.dictItems[node_tmp.gid];
                script_item_delete.beginClean();
                delete this.dictItems[node_tmp.gid];
            }
            node_tmp.removeFromParent(true);
            //node_tmp.destroy();
        }
    },

    loadMSGTest: function loadMSGTest() {
        // doan nay chi de test object meomory
        this.c_tank_script = Object.keys(this.dictTanks).length;
        this.c_obs_script = Object.keys(this.dictObs).length;
        this.c_item_script = Object.keys(this.dictItems).length;
        this.c_bullet_script = Object.keys(this.dictBullets).length;
        var tong = this.c_tank_script + this.c_obs_script + this.c_item_script + this.c_bullet_script;
        this.c_all_node = this.node.children.length - 1; // tru di 1 lan tiledMapBG
        if (tong == this.c_all_node) {
            this.msglog = "count all object: " + tong;
        } else {
            this.msglog = "------>error: " + tong + "|" + this.c_all_node + "   info " + "t=" + this.c_tank_script + " obs=" + this.c_obs_script + " item=" + this.c_item_script + " bullet=" + this.c_bullet_script;
        }
    },

    managerExplosion: function managerExplosion(arr_Ex) {

        for (var i_e = 0, i_e_m = arr_Ex.length; i_e < i_e_m; i_e++) {
            var e_info = Utils.decodePackExplosion(arr_Ex[i_e]);
            var status = e_info.stt;
            status = status - 0;

            var x_p = Number(e_info.x);
            var y_p = Number(e_info.y);
            //Utils.log("status:"+status);
            this.t_add_explosion++;
            if (status == 1 || status == 2) {
                //dan ban trung tuong
                var tmpnode = null;
                if (status == 2) {
                    //dan va cham xe tank
                    tmpnode = cc.instantiate(this.eff_hit_tank); //hit2
                    if (!Utils.turnOffAudio) {
                        var vl = 0.8;
                        var pos1 = {};
                        pos1.x = this.MYPLAYER.x;
                        pos1.y = this.MYPLAYER.y;
                        var distance = Utils.distance2Pos(pos1, cc.p(x_p, y_p));
                        vl = 1.0 - distance / 450.0;

                        if (vl > 0.8) {
                            vl = 0.8;
                        }
                        if (vl < 0.1) {
                            vl = 0.1;
                        }
                        vl = vl * 0.3;

                        if (cc.sys.os == cc.sys.OS_IOS) {
                            jsb.reflection.callStaticMethod("BridgeIOS", "PlayEffect:volume:", "hittank.mp3", vl + "");
                        } else {
                            cc.audioEngine.playEffect(this.hit_tank, false, vl);
                        }
                    }
                } else {
                    tmpnode = cc.instantiate(this.eff_hit_wall); //hit_tank
                    if (!Utils.turnOffAudio) {
                        var vl = 0.8;
                        var pos1 = {};
                        pos1.x = this.MYPLAYER.x;
                        pos1.y = this.MYPLAYER.y;
                        var distance = Utils.distance2Pos(pos1, cc.p(x_p, y_p));
                        vl = (1.0 - distance / 300.0) * 0.9;
                        //NSLog(@"disance 11111: %f --- %f",disance,vl);
                        if (vl > 0.8) {
                            vl = 0.8;
                        }
                        if (vl < 0.1) {
                            vl = 0.1;
                        }
                        if (cc.sys.os == cc.sys.OS_IOS) {
                            jsb.reflection.callStaticMethod("BridgeIOS", "PlayEffect:volume:", "hit2.mp3", vl + "");
                        } else {
                            cc.audioEngine.playEffect(this.hit2, false, vl);
                        }
                    }
                }
                if (tmpnode == null) {
                    continue;
                }
                tmpnode.setPosition(cc.p(x_p, y_p));
                tmpnode.setLocalZOrder(8);
                var paricle = tmpnode.getComponent('cc.ParticleSystem');
                tmpnode.positionType = cc.ParticleSystem.PositionType.RELATIVE;
                paricle.positionType = cc.ParticleSystem.PositionType.RELATIVE;
                //var scriptEffect=tmpnode.getComponent("EffectScript");

                this.node.addChild(tmpnode);
                //scriptEffect.setFixedPosition();
            }

            if (status >= 3 && status <= 6) {
                //dan ban ra tu nong sung
                var tmp_effect_gun = cc.instantiate(this.eff_gun_fire);
                tmp_effect_gun.setPosition(cc.p(78, 2));
                tmp_effect_gun.scale = 2;
                tmp_effect_gun.setLocalZOrder(-3); // khong hieu sao -1,-2 lai khong duoc , bo tay
                var scriptnode = this.dictTanks[e_info.tid];
                if (typeof scriptnode === "undefined") {
                    continue;
                }
                if (typeof scriptnode.node === "undefined") {
                    continue;
                }
                var guntank = scriptnode.guntank;
                scriptnode.guntank.addChild(tmp_effect_gun);
                //console.log("scriptnode.guntank: %s",scriptnode.guntank.children.length);
                // effect audio
                if (!Utils.turnOffAudio) {
                    var vl = 0.8;
                    var pos1 = {};
                    pos1.x = this.MYPLAYER.x;
                    pos1.y = this.MYPLAYER.y;
                    var distance = Utils.distance2Pos(pos1, cc.p(x_p, y_p));

                    var vl = (1 - distance / 300.0) * 0.8;
                    //NSLog(@"disance 3----6: %f --- %f",disance,vl);
                    if (vl > 0.9) {
                        vl = 0.9;
                    }
                    if (vl < 0.1) {
                        vl = 0.1;
                    }

                    if (cc.sys.os == cc.sys.OS_IOS) {
                        jsb.reflection.callStaticMethod("BridgeIOS", "PlayEffect:volume:", "fire.mp3", vl + "");
                    } else {
                        cc.audioEngine.playEffect(this.fire_audio, false, vl);
                    }
                }
            }
            if (status === 0) {
                //xe tank no
                //if(this.isOver){
                //    return;
                //}
                var tid = parseInt(e_info.tid);
                tid = Math.abs(tid);
                tid = tid % 10;
                console.log("run explorsion: %s", tid);
                var tankNodeEff = cc.instantiate(this.eff_tank_explosion);
                var script_eff = tankNodeEff.getComponent("TankEffectScript");
                script_eff.runEffect(this.explosionAtlas, tid);
                tankNodeEff.setPosition(cc.p(x_p, y_p));
                tankNodeEff.scale = 0.5;
                this.node.addChild(tankNodeEff);
                console.log("status ==0" + " e_info.tid=" + e_info.tid);
                // audio effect
                if (!Utils.turnOffAudio) {
                    var volume = 0.8;
                    tid = parseInt(e_info.tid);
                    if (tid == this.TANKID) {
                        volume = 0.8;
                    } else {
                        var pos1 = {};
                        pos1.x = this.MYPLAYER.x;
                        pos1.y = this.MYPLAYER.y;
                        var distance = Utils.distance2Pos(pos1, cc.p(x_p, y_p));
                        volume = 1 - distance / 300.0;
                        if (volume > 0.6) {
                            volume = 0.6;
                        }
                        if (volume < 0.1) {
                            volume = 0.1;
                        }
                    }
                    volume = volume * 0.5;

                    if (cc.sys.os == cc.sys.OS_IOS) {
                        jsb.reflection.callStaticMethod("BridgeIOS", "PlayEffect:volume:", "tankno.mp3", volume + "");
                    } else {
                        cc.audioEngine.playEffect(this.tank_no, false, volume);
                    }
                }
            }
        }
    },

    managerTank: function managerTank(arr_tank) {
        for (var i_t = 0, i_t_m = arr_tank.length; i_t < i_t_m; i_t++) {
            var obj_info = Utils.decodePackTank(arr_tank[i_t]);
            var tank_script = this.dictTanks[obj_info.id];
            var tankNumberID = parseInt(obj_info.id);
            //Utils.log("--->tank_tmp:"+tank_tmp);
            if (typeof tank_script === "undefined") {
                // check bang null khong co tac dung :(
                //Utils.log("add new tank game");
                var tank_node = cc.instantiate(this.t_prefab);
                if (this.TANKID === tankNumberID) {
                    this.MYPLAYER = tank_node;
                }
                var colorID = Math.abs(tankNumberID % 10);
                if (colorID < 0) {
                    colorID = 6;
                } else if (colorID > 9) {
                    colorID = 7;
                }

                tank_node.obj_type = 2;
                tank_node.gid = obj_info.id;
                tank_node.scale = 0.25;
                tank_node.setLocalZOrder(5);

                tank_script = tank_node.getComponent("tankScript");
                tank_script.gid = obj_info.id;
                tank_script.colorID = colorID;
                tank_script.level = 0;
                tank_script.levelGun = 0;

                this.node.addChild(tank_node);
                this.dictTanks[tank_script.gid] = tank_script;

                this.t_add_tank++;
            }
            tank_script.updateFrame(obj_info);
            if (this.TANKID === tankNumberID) {
                this.MYPLAYER.activeInfo = obj_info;
            }
        }
        if (!this.MYPLAYER.isActiveSC) {
            this.isOver = true;
        }
    },

    managerObs: function managerObs(arr_obs) {
        for (var i_o = 0, j_o_m = arr_obs.length; i_o < j_o_m; i_o++) {
            var tmp_info = Utils.decodePackObs(arr_obs[i_o]);

            var obs_script = this.dictObs[tmp_info.id];
            if (typeof obs_script === "undefined") {
                // Utils.log("Add new Obstacles");
                var tmp_Obs = cc.instantiate(this.obs_prefab);
                tmp_Obs.obj_type = 1;
                tmp_Obs.gid = tmp_info.id;
                tmp_Obs.setLocalZOrder(2);

                obs_script = tmp_Obs.getComponent("obsScript");
                obs_script.gid = tmp_info.id;
                obs_script.initDisplay(tmp_info);
                this.node.addChild(tmp_Obs);

                this.dictObs[obs_script.gid] = obs_script;

                this.t_add_obs++;
            }
            obs_script.node.isActiveSC = true;
        }
    },

    managerBullet: function managerBullet(arr_bullet) {
        for (var i_b = 0, j_b_m = arr_bullet.length; i_b < j_b_m; i_b++) {
            var tmp_info = Utils.decodePackBullet(arr_bullet[i_b]);
            var bullet_script = this.dictBullets[tmp_info.id];
            if (typeof bullet_script === "undefined") {
                // Utils.log("Add new Bullet");
                this.t_add_bullet++;
                var tmp_Bullet = cc.instantiate(this.bullet_prefab);
                tmp_Bullet.obj_type = 3;
                tmp_Bullet.gid = tmp_info.id;
                tmp_Bullet.setLocalZOrder(1);

                bullet_script = tmp_Bullet.getComponent("bulletScript");
                bullet_script.gid = tmp_info.id;

                this.node.addChild(tmp_Bullet);

                this.dictBullets[bullet_script.gid] = bullet_script;
            }
            bullet_script.updateFrame(tmp_info);
        }
    },

    managerItems: function managerItems(arr_items) {
        for (var i_i = 0, j_i_m = arr_items.length; i_i < j_i_m; i_i++) {
            var tmp_info = Utils.decodePackItem(arr_items[i_i]);
            var item_script = this.dictItems[tmp_info.id];
            if (typeof item_script === "undefined") {
                //Utils.log("Add new item");
                var tmp_Item;
                if (tmp_info.type == 1) {
                    tmp_Item = cc.instantiate(this.item_ammo_prefab);
                } else {
                    tmp_Item = cc.instantiate(this.item_health_prefab);
                }
                tmp_Item.obj_type = 4;
                tmp_Item.gid = tmp_info.id;
                tmp_Item.setLocalZOrder(1);

                item_script = tmp_Item.getComponent("itemScript");
                item_script.gid = tmp_info.id;

                this.node.addChild(tmp_Item);

                this.dictItems[item_script.gid] = item_script;

                this.t_add_items++;
            }
            item_script.updateDisplay(tmp_info);
        }
    },

    updateMapPosition: function updateMapPosition() {
        if (this.isOver) {
            this.otherMSG = "this.isOver";
            return;
        }
        if (this.MYPLAYER === null) {
            this.otherMSG = "MYPLAYER===null";
            return;
        }
        if (this.TANKID == this.MYPLAYER.gid) {
            var x_pos = -this.MYPLAYER.x;
            var y_pos = -this.MYPLAYER.y;
            //this.node.setPosition(cc.p(x_pos,y_pos));
            this.node.x = x_pos * 2; // nhan 2 boi vi map game scale =2
            this.node.y = y_pos * 2;
            this.otherMSG = "";
        } else {
            this.otherMSG = "this.TANKID=" + this.TANKID + " | MYPLAYER.gid: " + MYPLAYER.gid;
        }
    },

    estimateMoveTank: function estimateMoveTank() {
        /**
        *server mac dinh luon push ve la 80/1000 
        * dt_move=speed*0.08
        * 
        */
        /**
         * GIẢI THÍCH :
         * Hàm này chỉ là làm mượt chuyển động của xe tank và giảm bớt việc ở backend cứ 40/1000s là 25 lần 1s thì giờ
         * chỉ cần là 1s push về 12 lần thôi , nếu comment lại hàm này và không chạy  cũng không sao như trông nó rất giật game
         *
         * 1.Cách cũ là livestream vị trí của các Object trong game
         *      Tức là ví dụ ở frame1 xe tank ở vị trí 1, sau đó ở frame2 lại set vị trí cho xe tank ở vị trí P2..
         *      Cách này realtime và luôn nhưng nhược điểm là cần từ backend push data về liên tục
         * 2.Cách mới là tính toán đường đi tương đối của xe tank và cứ 0.08s lại đồng bộ với server 1 lần
         *      Ví dụ ở frame1 xe tank đang ở vị trí là A1 và hướng đi của tank là đến vị trí A2 ở frame sau vậy mình tạo
         *      ra 1 chuyển động cứ 0.001s lại cho xe tank nhích 1 đoạn tới vị trí của A2( vận tốc đã biết rồi) , và đên
         *      frame2 bất kể xe tank đã nhích đến hay đi quá vị trí so với frame2 trả về thì cũng set position cho tank
         *      ở vị trí frame2 trả về anh xem ở hàm managerTank
         *
         *
         *      -Cách làm tương tự như vậy đối với viên đạn ,tuy nhiên với viên đạn sẽ có chút lỗi xảy ra là giữa đường
         *      viên đạn va vào chướng ngại vật hoặc va vào xe tank mà client vẫn chưa được cập nhật speed đạn là 400
         *      và time là 0.08 vậy sẽ có trường hợp đạn ở client vẫn cứ đi thẳng sai số với server là 400*0.08=32 px
         *      cái này client thấy rất rõ ràng
         *
         *      -Một lỗi nữa là trên trình duyệt web không hiểu sao lại lag , nếu không được thì backend chắc phải if ,else code
         *      để web vẫn push về là 0.04s 1 lần còn mobile là 0.08 và mobile sẽ giảm tải được dữ liệu đi về chỉ có 1kb/s
         *
               -còn một vấn đề ở backend là vì mỗi frame là mình check vị trí của viên đạn so với chướng ngại vật là theo
         *      mỗi frame , trước ít ảy ra sai số vì mỗi frame cách nhau 0.04s và đạn đi có 16px x, giờ time mỗi frame cách
         *      nhau lên đến 0.08 thì sai số tăng lên theo , nhưng cái này mình sửa được ở server và làm sau
         *
         *
         *
         */
        //      chú ý là nếu timeout quá lớn thì return ngay hoặc di chuyển quá vị trí tính toán thì stop lại
        //      1 : là vẫn nên làm chức năng tính toán va chạm ở client đối với đạn và tank
        var self = this;
        this.countStep = 0;
        var TIME_FRAME_SERVER = 0.08;
        this.schedule(function (dt) {
            var checkCollision = false;
            if (self.countStep == 0) {
                checkCollision = true;
            }
            //console.log("CCCCCC----------------------AAAA--------------------AAA");
            for (var keyobj in self.dictTanks) {
                var tankscript = self.dictTanks[keyobj];
                //console.log("tankscript.dirMv: "+tankscript.dirMv);
                var maxMove = tankscript.speedMove * TIME_FRAME_SERVER;
                if (tankscript.nextFrameMove >= maxMove) {
                    continue;
                }

                var dt_move = tankscript.speedMove * dt;
                tankscript.nextFrameMove = tankscript.nextFrameMove + dt_move;
                var tmp_tank = tankscript.node;
                if (tankscript.dirMv > 0 && tankscript.dirMv < 5) {
                    if (tankscript.dirMv == 1) {
                        tmp_tank.x = tmp_tank.x + dt_move;
                    } else if (tankscript.dirMv == 2) {
                        tmp_tank.y = tmp_tank.y + dt_move;
                    } else if (tankscript.dirMv == 3) {
                        tmp_tank.x = tmp_tank.x - dt_move;
                    } else if (tankscript.dirMv == 4) {
                        tmp_tank.y = tmp_tank.y - dt_move;
                    } else {
                        //console.log("AAAAAAA----------------------AAAA--------------------AAA");
                    }
                }
            }

            self.updateMapPosition();

            for (var key_b in self.dictBullets) {
                var bullet_script = self.dictBullets[key_b];
                var dtMv = 400 * dt;
                var maxMove = 400 * TIME_FRAME_SERVER;
                if (bullet_script.nextFrameMove >= maxMove) {
                    return;
                }

                bullet_script.nextFrameMove = bullet_script.nextFrameMove + dtMv;
                var convert_angle = bullet_script.angleMove * 3.14592 / 180;
                var tmpPos = cc.p(bullet_script.node.x + dtMv * Math.cos(convert_angle), bullet_script.node.y + dtMv * Math.sin(convert_angle));

                if (checkCollision) {
                    // neu co va cham xay ra thi , bullet co opacity=0 va limit position
                    if (this.checkCollisionWithObstacble(tmpPos)) {
                        bullet_script.node.opacity = 0;
                    }
                    if (this.checkCollisionWithTank(tmpPos)) {
                        bullet_script.node.opacity = 0;
                    }
                }

                bullet_script.node.x = tmpPos.x;
                bullet_script.node.y = tmpPos.y;
            }

            self.countStep = self.countStep + 1;
            if (self.countStep >= 3) {
                self.countStep = 0;
            }
        }, 0.001);
    },
    onDisable: function onDisable() {
        this.unscheduleAllCallbacks();
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },

    checkCollisionWithObstacble: function checkCollisionWithObstacble(obj_b) {
        var isC = false;
        for (var keyobj in this.dictObs) {
            var obs_sc = this.dictObs[keyobj];
            if (obj_b.x > obs_sc.min_x && obj_b.x < obs_sc.max_x && obj_b.y < obs_sc.max_y && obj_b.y > obs_sc.min_y) {
                isC = true;
                break;
            }
        }
        if (obj_b.x > 1475 || obj_b.x < -1475 || obj_b.y > 975 || obj_b.y < -975) {
            isC = true;
        }

        return isC;
    },
    checkCollisionWithTank: function checkCollisionWithTank(obj_b) {
        var isC = false;
        for (var keyobj in this.dictTanks) {
            var obs_sc = this.dictTanks[keyobj];
            if (obj_b.x > obs_sc.min_x && obj_b.x < obs_sc.max_x && obj_b.y < obs_sc.max_y && obj_b.y > obs_sc.min_y) {
                isC = true;
                break;
            }
        }
        return isC;
    }
});

cc._RFpop();
},{"../LIB/Utils":"Utils"}],"GamePlayScript":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'de6b5n59epGzaVpgGIRcJVi', 'GamePlayScript');
// Script/Gamescript/GamePlayScript.js


var Utils = require('../LIB/Utils');
cc.Class({
    "extends": cc.Component,

    properties: {
        hub_prefab: {
            type: cc.Prefab,
            "default": null
        },
        lbStatus: {
            type: cc.Label,
            "default": null
        },
        nodecontro: cc.Node,
        panelInfo: cc.Node,
        gameMap: {
            type: cc.Node,
            "default": null
        },
        arrowNode: cc.Node,
        tinyPlayer: cc.Node,
        lbscore: cc.Label,
        testnodxx: {
            type: cc.Prefab,
            "default": null
        },

        tinyMapGrapphic: cc.Graphics
    },
    actionBackHome: function actionBackHome() {
        this.socket.disconnect();
        cc.director.loadScene("HomeScene");
    },

    ListenNativeHidden: function ListenNativeHidden() {
        //game_on_hide
        if (cc.sys.isNative) {
            var self = this;
            this.lstnr = cc.EventListenerCustom.create("game_on_hide", function () {
                self.socket.disconnect();
                cc.director.loadScene("HomeScene");
            });
            cc.eventManager.addListener(this.lstnr, this);
        }
    },

    // use this for initialization
    onLoad: function onLoad() {
        /** 
         * Cơ bản trong Engine cocos: cấp cao nhất và chứa tất cả các đối tượng trong game là scene, trong scene chứa các child như là Canvas, Node, Sprite ,Label,button.... etc 
         * các child này sẽ có các thuộc tính cơ bản từ Node như position,scale,rotation,Anchor point ...
         * Lớp Node là lớp base chứa các đối tượng ,Sprite,Label,Button... đều là kế thừa từ Node và có các thuộc tính của node, ngoài ra với mỗi đối tượng có thêm thuộc tính riêng của mình
         *  -Sprite là đối tượng được dùng để thiển thị 1 bức ảnh cơ chế để load 1 bức ảnh image_file->texture->spriteframe----->Sprite 
         *          trong đó Sprite chỉ hiển thị spriteFrame, ví dụ mình có thể tạo 1 Sprite hiển thị trên màn hình là 1 ảnh hình tròn màu đỏ, khi touch vào thì load 1 spriteFrame màu xanh 
         *          ,release thì load lại spriteFrame màu đỏ 
         * 
         * Bất cứ đối tượng UI nào trong game đều có thể tạo 1 script đề điều khiển đối tượng đó, ví dụ có 1 đối tượng là xe tank thì trong xe tank có thể tạo 1 hoặc nhiều script để điều khiển 
         * xe tank, tuy nhiên tạo nhiều script sẽ dễ dẫn đến xung đột khó bắt lỗi 
         *     từ đối tượng UI muốn gọi ra script của xe tank thì gọi bằng cách 
         *          var scriptObj=UI_Object.getComponent("ScriptName");--> bở vì 1 node có thể chứa nhiều script nên phải gọi thế này
         *     ngược lại từ 1 script muốn gọi lại đối tượng UI_Object thì chỉ cần gọi 
         *          var ui_obj=script_obj.node;---> một đối tượng script chỉ có thể điều khiển duy nhất 1 node 
         *     ở dòng code trên ui_obj có thể là Label, Button, Sprite... tuy nhiên thì class Node là cha và đại diện chung cho tất cả các đối tượng trên 
         * */

        /**
         *  Hàm Onload được gọi đầu tiên trong game xem thêm ở url :http://cocos2d-x.org/docs/api-ref/creator/v1.1.2/classes/TiledLayer.html#method_onLoad
         * 
         * 
         * */
        if (cc.sys.isNative) {
            this.ListenNativeHidden();
        }

        var script_controller = this.nodecontro.getComponent("PadController");
        script_controller.mainscript = this;

        this.mapScript = this.gameMap.getComponent("GameMap"); // lấy ra script của đối tượng gamemap

        this.panelInfoScript = this.panelInfo.getComponent("PanelUserInfo");

        this.actionListenKeyPress(); //sử dụng cho việc nhấn phím để di chuyển xe tank web version

        //this.addTouchListenEvent();// sử dụng cho việc touch mobile version
        if (Utils.enableSwipe) {
            this.arrowNode.active = false;
            this.addTouchAndSwipeEvent();
        } else {
            this.arrowNode.destroy();
            this.addTouchListenEvent();
        }

        this.timelog = 0;
        this.actionLoadGameBegin(); // connect đến server

        //Utils.lastscore=103;
        this.AdsManager();

        this.testcountdraw = 0;
    },
    AdsManager: function AdsManager() {
        if (cc.sys.os == cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod("BridgeIOS", "HiddenAdsBanerWithAnimation");
        } else if (cc.sys.os == cc.sys.OS_ANDROID) {} else {// phien ban web

        }
    },

    runUpdateHighScore: function runUpdateHighScore() {},

    //called every frame, uncomment this function to activate update callback
    //update: function (dt) {
    //   this.timelog=this.timelog+dt;
    //   if(this.timelog>0.3){
    //       this.timelog=0;
    //       var logscreen="ID:"+this.mapScript.TANKID+" Tank:"+this.mapScript.t_add_tank+"  Obs:"+this.mapScript.t_add_obs+ "  Bullet:"+this.mapScript.t_add_bullet+ "  item:"+this.mapScript.t_add_items;
    //       logscreen=logscreen+" exp:"+this.mapScript.t_add_explosion;
    //       logscreen=logscreen+"\n"+this.mapScript.msglog+ "\n"+this.mapScript.otherMSG;
    //       this.lbStatus.string=logscreen;
    //   }
    //},

    onDisable: function onDisable() {
        var script_controller = this.nodecontro.getComponent("PadController");
        script_controller.mainscript = null;
        this.panelInfoScript = null;
        Utils.log("Game player is Unload");
        cc.eventManager.removeListener(this.touchListen);
        cc.eventManager.removeListener(this.keyEventListen);
        if (cc.sys.isNative) {
            cc.eventManager.removeListener(this.lstnr);
        }

        // cc.eventManager.removeAllListeners();
    },

    updateMoveController: function updateMoveController(dir_move) {
        cc.log("dir_move:%s", dir_move);
        var numberint = parseInt(dir_move);
        if (numberint >= 1 && numberint <= 4) {
            this.socket.emit("changeDir", numberint);
        }
    },

    addTouchListenEvent: function addTouchListenEvent() {

        this.touchListen = cc.eventManager.addListener({ event: cc.EventListener.TOUCH_ONE_BY_ONE, swallowTouches: true,
            onTouchBegan: (function (touch, event) {
                //cc.log("-----------asdasdasdasdkhkasjdbkajsdsakjdhaskdhaskjdhakjsdhask------------");

                //this.isFire=true;
                //this.beginPos = this.node.convertToNodeSpace(touch.getLocation());

                var pos = this.node.convertToNodeSpace(touch.getLocation());
                pos.x = pos.x - cc.winSize.width / 2;
                pos.y = pos.y - cc.winSize.height / 2;
                var vfire = cc.pNormalize(cc.v2(pos.x, pos.y));
                var angle = cc.pToAngle(vfire);
                angle = angle * 180 / 3.14;
                if (angle < 0) {
                    angle = 360 + angle;
                }
                if (angle > 360) {
                    // se khong bao gio xay ra truong hop nay vi cocos2d-js luon tra ve 1 goc tu -180,180
                    angle = angle - 360;
                }
                //this.lbStatus.string="GOC false AAA="+angle;
                this.socket.emit("fireTarget", angle);

                return true;
            }).bind(this)

        }, this.node);
    },

    addTouchAndSwipeEvent: function addTouchAndSwipeEvent() {

        this.touchListen = cc.eventManager.addListener({ event: cc.EventListener.TOUCH_ONE_BY_ONE, swallowTouches: true,
            onTouchBegan: (function (touch, event) {
                this.isFire = true;
                this.beginPos = this.node.convertToNodeSpace(touch.getLocation());
                return true;
            }).bind(this),

            onTouchMoved: (function (touch, event) {
                //this.lbStatus.string="touch onTouchMoved";
            }).bind(this),

            onTouchEnded: (function (touch, event) {

                var pos = this.node.convertToNodeSpace(touch.getLocation());
                var bukPos = this.beginPos;
                var distance = cc.pDistance(this.beginPos, pos);
                var stt_movedir = 0;
                //this.lbStatus.string="touch distance:"+distance;
                if (distance > 30) {
                    this.isFire = false;
                    var dtPos = cc.v2(pos.x - this.beginPos.x, pos.y - this.beginPos.y);

                    var anglemv = cc.pToAngle(dtPos);
                    anglemv = anglemv * 180 / 3.14;
                    if (anglemv < 0) {
                        anglemv = 360 + anglemv;
                    }
                    if (anglemv > 360) {
                        // se khong bao gio xay ra truong hop nay vi cocos2d-js luon tra ve 1 goc tu -180,180 , nhưng cứ thêm 1 câu if cho chắc ăn
                        anglemv = anglemv - 360;
                    }
                    if (anglemv < 45 || anglemv > 315) {
                        stt_movedir = 1;
                    }
                    if (anglemv > 45 && anglemv < 135) {
                        stt_movedir = 2;
                    }
                    if (anglemv > 135 && anglemv < 225) {
                        stt_movedir = 3;
                    }
                    if (anglemv < 315 && anglemv > 225) {
                        stt_movedir = 4;
                    }
                    //this.lbStatus.string="tank angle="+anglemv;
                }

                if (this.isFire) {
                    pos.x = pos.x - cc.winSize.width / 2;
                    pos.y = pos.y - cc.winSize.height / 2;
                    var vfire = cc.pNormalize(cc.v2(pos.x, pos.y));
                    var angle = cc.pToAngle(vfire);
                    angle = angle * 180 / 3.14;
                    if (angle < 0) {
                        angle = 360 + angle;
                    }
                    if (angle > 360) {
                        // se khong bao gio xay ra truong hop nay vi cocos2d-js luon tra ve 1 goc tu -180,180
                        angle = angle - 360;
                    }

                    //this.lbStatus.string="GOC false AAA="+angle;
                    this.socket.emit("fireTarget", angle);
                } else {
                    if (stt_movedir > 0 && stt_movedir < 5) {
                        pos.x = this.beginPos.x - cc.winSize.width / 2;
                        pos.y = this.beginPos.y - cc.winSize.height / 2;
                        this.arrowNode.active = true;
                        this.arrowNode.stopAllActions();
                        this.arrowNode.setPosition(pos);
                        this.arrowNode.scaleX = 0.4;
                        this.arrowNode.opacity = 120;
                        var actionSC = cc.scaleTo(0.3, 0.8, 0.7);

                        var xm = 0;
                        var ym = 0;
                        if (stt_movedir == 1) {
                            xm = 300;
                            this.arrowNode.rotation = 0;
                        }
                        if (stt_movedir == 3) {
                            xm = -300;
                            this.arrowNode.rotation = -180;
                        }
                        if (stt_movedir == 2) {
                            ym = 300;
                            this.arrowNode.rotation = -90;
                        }
                        if (stt_movedir == 4) {
                            ym = -300;
                            this.arrowNode.rotation = 90;
                        }
                        var actionMV = cc.moveBy(0.3, cc.p(xm, ym));
                        var actionop = cc.fadeTo(0.5, 0);
                        this.arrowNode.runAction(cc.spawn(actionSC, actionMV, actionop));

                        this.socket.emit("changeDir", stt_movedir);
                    }
                }
            }).bind(this)

        }, this.node);
    },

    actionListenKeyPress: function actionListenKeyPress() {
        var self = this;
        //add keyboard input listener to jump, turnLeft and turnRight
        this.keyEventListen = cc.eventManager.addListener({
            event: cc.EventListener.KEYBOARD,
            // set a flag when key pressed
            onKeyPressed: function onKeyPressed(keyCode, event) {
                var movestt = 0;
                if (keyCode == cc.KEY.d || keyCode == cc.KEY.right) {
                    movestt = 1;
                }
                if (keyCode == cc.KEY.w || keyCode == cc.KEY.up) {
                    movestt = 2;
                }
                if (keyCode == cc.KEY.a || keyCode == cc.KEY.left) {
                    movestt = 3;
                }
                if (keyCode == cc.KEY.s || keyCode == cc.KEY.down) {
                    movestt = 4;
                }

                // if(this.last_movestt==movestt){
                //     return;
                // }
                this.last_movestt = movestt;
                if (movestt > 0 && movestt < 5) {
                    self.socket.emit("changeDir", movestt);
                }
            }
        }, self.node);
    },

    actionLoadGameBegin: function actionLoadGameBegin() {

        this.hub = cc.instantiate(this.hub_prefab);
        this.node.addChild(this.hub);

        var self = this;
        require('socket.io');
        var urlconnect = Utils.getServer();
        var config = {
            'forceNew': true,
            'reconnection': false,
            'reconnectionDelay': 200,
            'reconnectionDelayMax': 1000,
            'reconnectionAttempts': 1
        };
        this.socket = io.connect(urlconnect, config); // phiên bản js này hỗ trợ trực tiếp ipv6, ipv4
        console.log("-----DD-->url connect: %s", urlconnect);
        this.socket.on('connect', function () {
            Utils.log("ket noi thanh cong");
            var str_info = Utils.loadUserInfo();
            self.socket.emit("MyInfo", str_info);
            if (self.hub == null) {
                return;
            }
            self.hub.destroy();
            self.hub = null;
        });

        this.socket.on('RequestValidate', function (message) {
            var msgReceive = message;
            if (typeof message == "string") {
                msgReceive = JSON.parse(message);
            }
            self.mapScript.TANKID = parseInt(msgReceive.id);
            var keydecode = Utils.deCode(msgReceive.key);
            self.socket.emit("MyValidate", keydecode);
            ///cham mau trang nhap nhay lien tuc
            //var actionRP=cc.repeatForever(cc.blink(2, 3));
            //self.tinyPlayer.stopAllActions();
            //self.tinyPlayer.runAction(actionRP);
        });
        this.socket.on('UpdatePosition', function (message) {
            var msgReceive = message;
            if (typeof message == "string") {
                msgReceive = JSON.parse(message);
            }
            self.mapScript.updateFrameStep(msgReceive);
            self.updateTinyMapGame();
        });

        this.socket.on('UpdateTankMap', function (message) {

            var msgReceive = message;
            if (typeof message == "string") {
                msgReceive = JSON.parse(message);
            }
            self.updateTinyMap(msgReceive);
        });

        this.socket.on('BestPlayers', function (message) {
            var msgReceive = message;
            if (typeof message == "string") {
                msgReceive = JSON.parse(message);
            }
            var l = msgReceive.length;
            var strHC = "";
            for (var i = 0; i < l; i++) {
                var objsc = msgReceive[i];
                var stt = i + 1;
                var linetmp = "#" + stt + "  " + objsc.n + "    " + objsc.s;
                if (i == 0) {
                    strHC = linetmp;
                } else {
                    strHC = strHC + "\n" + linetmp;
                }
            }
            self.lbStatus.string = strHC;
        });

        this.socket.on('error', function (message) {
            //cc.log("dddddddd----------eror:%s",message);
            Utils.messageconnect = message;
            cc.director.loadScene("HomeScene");
        });
        this.socket.on('disconnect', function (message) {
            cc.director.loadScene("HomeScene");
        });
    },

    updateTinyMap: function updateTinyMap(arrayTank) {
        //this.testcountdraw=this.testcountdraw+1;
        //if(this.testcountdraw>3){
        //
        //    this.tinyMapGrapphic.clear();
        //}else{
        //    this.tinyMapGrapphic.rect(20,20,111,111);
        //    this.tinyMapGrapphic.fillColor = cc.Color.GREEN;
        //    this.tinyMapGrapphic.fill();
        //}
        //if(this.testcountdraw>5){
        //    this.testcountdraw=0;
        //}
        //
        //return;

        this.tinyMapGrapphic.clear();
        var len = arrayTank.length;
        var mypos = {};
        mypos.x = this.mapScript.MYPLAYER.x;
        mypos.y = this.mapScript.MYPLAYER.y;

        for (var ax = 0; ax < len; ax++) {
            var pos = arrayTank[ax];

            var distanceMe = Utils.distance2Pos(mypos, pos);
            if (distanceMe > 15) {
                pos.x = 70 * (pos.x / 1500);
                pos.y = 50 * (pos.y / 1000);
                this.tinyMapGrapphic.rect(pos.x - 1.5, pos.y - 1.5, 3, 3);
                this.tinyMapGrapphic.fillColor = cc.Color.RED;
            }
        }
        this.tinyMapGrapphic.fill();

        mypos.x = 70 * (mypos.x / 1500);
        mypos.y = 50 * (mypos.y / 1000);
        this.tinyMapGrapphic.rect(mypos.x - 1.5, mypos.y - 1.5, 3, 3);
        this.tinyMapGrapphic.fillColor = cc.Color.GREEN;
        this.tinyMapGrapphic.fill();
    },

    updateTinyMapGame: function updateTinyMapGame() {
        if (this.mapScript.MYPLAYER.isActiveSC) {

            //var xpos=this.mapScript.MYPLAYER.x/1500;
            //var ypos=this.mapScript.MYPLAYER.y/1000;
            //this.tinyPlayer.x=xpos*70;
            //this.tinyPlayer.y=ypos*50;

            var obj_info = this.mapScript.MYPLAYER.activeInfo;

            var myLevel = obj_info.level;

            var myMaxAmmo = parseInt(140 + (myLevel - 1) * 20);
            var myMaxHealth = parseInt(80 + (myLevel - 1) * 15);

            var sc_ammo = parseInt(obj_info.ammo) / myMaxAmmo;
            if (sc_ammo > 1) {
                sc_ammo = 1;
            }
            var sc_hp = parseInt(obj_info.hp) / myMaxHealth;
            if (sc_hp > 1) {
                sc_hp = 1;
            }

            this.panelInfoScript.prAmmo.scaleX = sc_ammo;
            this.panelInfoScript.prHP.scaleX = sc_hp;

            this.panelInfoScript.lbCountAmmo.string = parseInt(obj_info.ammo) + "/" + myMaxAmmo;
            this.panelInfoScript.lbCountHp.string = parseInt(obj_info.hp) + "/" + myMaxHealth;
            this.panelInfoScript.lbLevel.string = "LEVEL:" + parseInt(myLevel);
            this.lbscore.string = obj_info.score;
            Utils.myscore = obj_info.score;
            this.panelInfoScript.lbSpeed.string = "Speed:" + Number(obj_info.sp).toFixed(1);
        }
    }

});

cc._RFpop();
},{"../LIB/Utils":"Utils","socket.io":"socket.io"}],"HomeScript":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'f1a18l9eclHML7T7jQnaiOz', 'HomeScript');
// Script/Gamescript/HomeScript.js

var Utils = require('../LIB/Utils');
cc.Class({
    "extends": cc.Component,

    properties: {
        nodeWeb: cc.Node,
        nodeMobile: cc.Node,
        txtUserName: cc.EditBox,
        hubloading: cc.Node,
        popSetting: cc.Prefab
    },

    loadFlagIpInfo: function loadFlagIpInfo() {
        if (this.IpInfo) {
            return;
        }
        this.IpInfo = true;
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status >= 200 && xhr.status < 400) {
                var response = xhr.responseText;

                var flag = JSON.parse(response).country;

                if (flag != null) {

                    if (flag.length > 1 || flag.length < 4) {
                        flag = flag.toLowerCase();
                        cc.sys.localStorage.setItem("country", flag);
                        console.log("ipinfo---->" + flag);
                    }
                }
            }
        };
        xhr.open("GET", "http://ipinfo.io/json", true);
        xhr.send();
    },

    loadFlagIpAPI: function loadFlagIpAPI() {
        var xhr = new XMLHttpRequest();
        var self = this;
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status >= 200 && xhr.status < 400) {
                var response = xhr.responseText;

                var flag = JSON.parse(response).countryCode;

                if (flag != null) {

                    if (flag.length > 1 || flag.length < 4) {
                        flag = flag.toLowerCase();
                        cc.sys.localStorage.setItem("country", flag);
                        console.log("IPAPI---->" + flag);
                    } else {
                        self.loadFlagIpInfo();
                    }
                } else {
                    self.loadFlagIpInfo();
                }
            } else {
                self.loadFlagIpInfo();
            }
        };
        xhr.onerror = function () {
            self.loadFlagIpInfo();
        };
        xhr.open("GET", "http://ip-api.com/json/", true);
        xhr.send();
    },

    // use this for initialization
    onLoad: function onLoad() {
        if (cc.sys.isNative) {
            // this.lbOS.string="isNative-iOS+Android:"+cc.sys.os;
            this.nodeWeb.active = false;
            this.nodeMobile.active = true;
        } else {
            this.nodeWeb.active = true;
            this.nodeMobile.active = false;
        }
        var strx = cc.sys.localStorage.getItem("usr");
        if (strx != null) {
            if (typeof strx === "undefined") {
                this.txtUserName.string = "";
            } else {
                this.txtUserName.string = strx;
            }
        }
        this.IpInfo = false;
        this.AdsManager();
        this.loadFlagIpAPI();

        if (typeof Utils.myscore != "undefined") {
            var intscore = parseInt(Utils.myscore);
            if (intscore > 0) {
                var strintscore = intscore + "";
                if (cc.sys.os == cc.sys.OS_IOS) {
                    jsb.reflection.callStaticMethod("BridgeIOS", "submitScoreGameCenter:leaderBoarID:", strintscore, "com.gameio.tankhighscore");
                }
            }
        }

        Utils.turnOffAudio = false;
    },

    AdsManager: function AdsManager() {
        if (cc.sys.os == cc.sys.OS_IOS) {
            // hien thi quang cao
            jsb.reflection.callStaticMethod("BridgeIOS", "ShowAdsBanerWithAdnimation");

            jsb.reflection.callStaticMethod("BridgeIOS", "ShowFullScreen");

            // hien thi loi thong bao khi khong ket not duoc mang
            if (typeof Utils.messageconnect != "undefined") {
                var msg = Utils.messageconnect + "";
                if (msg.length > 4) {
                    jsb.reflection.callStaticMethod("BridgeIOS", "callNativeUIWithTitle:andContent:", "Message", msg);
                    Utils.messageconnect = "";
                }
            }
        } else if (cc.sys.os == cc.sys.OS_ANDROID) {} else {// phien ban web

        }
    },

    acRate: function acRate() {
        /**
         *  NHỮNG API NÀY ĐƯỢC GỌI ĐI GỌI LẠI VÀ NÓ LÀ CƠ BẢN TẤT CẢ CÁC GAME ĐỀU CẦN CÓ NHƯ LÀ INAPP-PURCHASE,ADS,GAMECENTER,SHARE..., 
         *  NÊN SAU GAME NÀY MÌNH VIẾT NÓ THÀNH 1 CLASS RIÊNG ĐỂ DỄ TÁI SỬ DỤNG VÀ DỄ QUẢN LÝ, CÒN GIỜ CỨ VIẾT TẠM HẾT TRONG ĐÂY 
         * */
        var urlRateApp = "";
        if (cc.sys.os == cc.sys.OS_IOS) {
            urlRateApp = "itms-apps://itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?id=1142249508&onlyLatestVersion=true&pageNumber=0&sortOrdering=1&type=Purple+Software";
        } else {
            // la android
            urlRateApp = "https://play.google.com/store/apps/details?id=pack_name";
        }
        cc.sys.openURL(urlRateApp);
    },
    acHighScore: function acHighScore() {
        if (cc.sys.os == cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod("BridgeIOS", "showHighScore");
        }
    },
    acSetting: function acSetting() {
        var popsetting = cc.instantiate(this.popSetting);
        this.node.addChild(popsetting);
    },
    acShare: function acShare() {
        if (cc.sys.os == cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod("BridgeIOS", "shareAppNative:", "https://itunes.apple.com/app/id1142249508");
        }
    },

    actionOpenURL: function actionOpenURL() {
        cc.sys.openURL("http://tank.gameio.net");
    },

    actionWebLoadAppstore: function actionWebLoadAppstore() {
        cc.sys.openURL("https://itunes.apple.com/app/id1142249508");
    },
    actionWebLoadAppPlayStore: function actionWebLoadAppPlayStore() {
        cc.sys.openURL("https://itunes.apple.com/app/id1142249508");
    },

    acFacebookPage: function acFacebookPage() {
        cc.sys.openURL("https://www.facebook.com/gameio.live");
    },
    acTwitterPage: function acTwitterPage() {
        cc.sys.openURL("https://twitter.com/GameioL");
    },
    actionLoadGaamePlayer: function actionLoadGaamePlayer() {
        Utils.playerName = this.txtUserName.string.trim();
        cc.sys.localStorage.setItem("usr", Utils.playerName);
        this.loadConfigAudio();
        this.hubloading.opacity = 255;
        cc.director.loadScene("GamePlay");
    },

    loadConfigAudio: function loadConfigAudio() {
        var eff_disable = false;
        var disableSound = cc.sys.localStorage.getItem("disableEffect");
        if (disableSound != null) {
            if (typeof disableSound === "undefined") {
                console.log("AAAA begin eff");
                eff_disable = false;
            } else {

                eff_disable = JSON.parse(disableSound);
            }
        }
        Utils.turnOffAudio = eff_disable;

        var boole_swipe = false;
        var enable_swipe = cc.sys.localStorage.getItem("enable_swipe");
        if (enable_swipe != null) {
            if (typeof enable_swipe === "undefined") {
                enable_swipe = false;
            } else {
                boole_swipe = JSON.parse(enable_swipe);
            }
        }
        Utils.enableSwipe = !boole_swipe;
    }
});

cc._RFpop();
},{"../LIB/Utils":"Utils"}],"PadController":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'b7a59GsOBlEEID+Kx7MZBIu', 'PadController');
// Script/LIB/PadController.js

var Utils = require('../LIB/Utils');
cc.Class({
    "extends": cc.Component,

    properties: {
        hubcontrol: cc.Node,
        bt0: cc.Node,
        bt1: cc.Node,
        bt2: cc.Node,
        bt3: cc.Node,
        bt4: cc.Node

    },

    // use this for initialization
    onLoad: function onLoad() {
        //this.addTouchListenEvent();

        if (cc.sys.isBrowser || Utils.enableSwipe) {
            this.node.active = false;
        } else {
            var size = cc.director.getVisibleSize();

            var yclose = -225;
            var y_explain = -145;

            var xclose = -size.width / 2 + 113;
            var x_explain = -size.width / 2 + 200;

            this.closePos = cc.p(xclose, yclose);
            this.ex_pos = cc.p(x_explain, y_explain);

            this.PadDir = 1;

            this.closeAllButton();
            this.changeframe = true;
        }
    },
    onDisable: function onDisable() {
        this.mainscript = null;
    },
    updatePadDir: function updatePadDir() {

        var allchild = this.node.children;
        for (var ix = 0; ix < allchild.length; ix++) {
            var bt1 = allchild[ix];
            //bt1.setLocalZOrder(1);
        }
        if (this.PadDir == 1) {
            this.bt0.rotation = 180;
            // this.bt0=this.node.children[2];
            this.bt2.setLocalZOrder(3);
        }
        if (this.PadDir == 3) {
            this.bt0.rotation = 0;
            //this.bt0=this.node.children[3];
            this.bt3.setLocalZOrder(3);
        }
        if (this.PadDir == 4) {
            this.bt0.rotation = -90;
            //this.bt0=this.node.children[1];
            this.bt1.setLocalZOrder(3);
        }
        if (this.PadDir == 2) {
            this.bt0.rotation = 90;
            //this.bt0=this.node.children[4];
            this.bt4.setLocalZOrder(3);
        }
    },
    closeAllButton: function closeAllButton() {
        var allchild = this.node.children;
        for (var ix = 0; ix < allchild.length; ix++) {
            var bt1 = allchild[ix];
            bt1.x = 0;
            bt1.y = 0;
            if (ix == 0) {
                bt1.active = true;
            } else {
                bt1.active = false;
            }
        }

        this.node.setPosition(this.closePos);
        this.hubcontrol.active = true;
    },
    objectMovePos: function objectMovePos(obj_node, pos) {
        obj_node.stopAllActions();
        var actionmv = cc.moveTo(0.2, pos);
        obj_node.runAction(actionmv);
    },
    objectMoveCenter: function objectMoveCenter(obj_node, pos) {
        obj_node.stopAllActions();
        var actionmv = cc.moveTo(0.2, pos);
        obj_node.runAction(actionmv);
    },
    explainAllButton: function explainAllButton() {

        //var bt1=allchild[0];
        this.bt0.x = 0;
        this.bt0.y = 0;
        this.bt0.active = false;

        //bt1=allchild[1];
        this.bt1.active = true;
        this.objectMovePos(this.bt1, cc.p(0, -90));

        //bt1=allchild[2];
        this.bt2.active = true;
        this.objectMovePos(this.bt2, cc.p(90, 0));

        //bt1=allchild[3];
        this.bt3.active = true;
        this.objectMovePos(this.bt3, cc.p(-90, 0));

        //bt1=allchild[4];
        this.bt4.active = true;
        this.objectMovePos(this.bt4, cc.p(0, 90));

        this.node.stopAllActions();
        var actionmv = cc.moveTo(0.2, this.ex_pos);
        this.node.runAction(actionmv);
        //this.node.setPosition(this.ex_pos);
    },

    moveAndCloseAllButton: function moveAndCloseAllButton() {
        cc.log("asdas askkkkkkkkkkkdk");

        this.mainscript.updateMoveController(this.PadDir);
        var moveCenter = cc.callFunc(this.moveToCenter, this);
        var delaytime = cc.delayTime(0.15);
        var moveRootPos = cc.callFunc(this.moveToClosepos, this);
        var actionsc = cc.sequence(moveCenter, delaytime, moveRootPos);
        this.node.stopAllActions();
        this.node.runAction(actionsc);
    },
    moveToClosepos: function moveToClosepos(objsc) {
        var allchild = this.node.children;
        for (var ix = 0; ix < allchild.length; ix++) {
            var bt1 = allchild[ix];
            bt1.x = 0;
            bt1.y = 0;
            if (ix == 0) {
                bt1.active = true;
            } else {
                bt1.active = false;
            }
        }
        //this.bt0.active=true;
        //this.bt1.active=false;
        //this.bt2.active=false;
        //this.bt3.active=false;
        //this.bt4.active=false;
        // this.node.stopAllActions();
        var actionmv = cc.moveTo(0.18, this.closePos);
        this.node.runAction(actionmv);
    },
    moveToCenter: function moveToCenter(objsc) {
        cc.log("----------kkkkkk ");
        var allchild = this.node.children;

        // var bt1=allchild[0];
        // bt1.active = true;
        // bt1.opacity=0;
        this.updatePadDir();

        //var bt1=allchild[1];
        this.bt1.active = true;
        this.objectMoveCenter(this.bt1, cc.p(0, 0));

        //bt1=allchild[2];
        this.bt2.active = true;
        this.objectMoveCenter(this.bt2, cc.p(0, 0));

        //bt1=allchild[3];
        this.bt3.active = true;
        this.objectMoveCenter(this.bt3, cc.p(0, 0));

        //bt1=allchild[4];
        this.bt4.active = true;
        this.objectMoveCenter(this.bt4, cc.p(0, 0));
    },

    actionMoveUp: function actionMoveUp() {
        this.PadDir = 2;
        this.moveAndCloseAllButton();
        //this.closeAllButton();
    },
    actionMoveLeft: function actionMoveLeft() {
        this.PadDir = 3;
        this.moveAndCloseAllButton();
    },
    actionMoveRight: function actionMoveRight() {
        cc.log("move actionMoveRight");
        this.PadDir = 1;
        this.moveAndCloseAllButton();
    },
    actionMoveDown: function actionMoveDown() {
        cc.log("move actionMoveDown");
        this.PadDir = 4;
        this.moveAndCloseAllButton();
    },
    actionEX: function actionEX() {
        cc.log("move actionEX");
        var bt0 = this.node.children[0];
        if (this.changeframe) {
            this.changeframe = false;
            this.hubcontrol.removeFromParent(true);
            this.hubcontrol = null;
        }

        this.explainAllButton();
        //this.node.setPosition(this.ex_pos);
    }

});

cc._RFpop();
},{"../LIB/Utils":"Utils"}],"PanelUserInfo":[function(require,module,exports){
"use strict";
cc._RFpush(module, '270b1oXWlhLDLgiBzvW9bIb', 'PanelUserInfo');
// Script/Gamescript/PanelUserInfo.js

cc.Class({
    "extends": cc.Component,

    properties: {
        lbCountAmmo: cc.Label,
        lbCountHp: cc.Label,
        lbLevel: cc.Label,
        lbSpeed: cc.Label,
        prAmmo: cc.Node,
        prHP: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {}

});

cc._RFpop();
},{}],"SettingController":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'd8adajNK7BPWYhn3YeAQ2+z', 'SettingController');
// Script/LIB/SettingController.js

cc.Class({
    "extends": cc.Component,

    properties: {
        lb_button_control: cc.Label,
        lb_button_sound: cc.Label
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.addTouchListenEvent();
    },
    addTouchListenEvent: function addTouchListenEvent() {

        this.touchListen = cc.eventManager.addListener({ event: cc.EventListener.TOUCH_ONE_BY_ONE, swallowTouches: true,
            onTouchBegan: (function (touch, event) {
                console.log("alksdasdhaskd-----asd-s-s-s-s-s-s-s-s--s");
                return true;
            }).bind(this)

        }, this.node);

        this.loadLastSetting();
    },
    loadLastSetting: function loadLastSetting() {
        var eff_disable = false;
        var disableSound = cc.sys.localStorage.getItem("disableEffect");
        if (disableSound != null) {
            if (typeof disableSound === "undefined") {
                console.log("AAAA begin eff");
                eff_disable = false;
            } else {

                eff_disable = JSON.parse(disableSound);
            }
        }
        this.lb_button_sound.string = eff_disable ? "Off" : "On";

        var boole_swipe = false;
        var enable_swipe = cc.sys.localStorage.getItem("enable_swipe");
        if (enable_swipe != null) {
            if (typeof enable_swipe === "undefined") {
                enable_swipe = false;
            } else {
                boole_swipe = JSON.parse(enable_swipe);
            }
        }
        this.lb_button_control.string = !boole_swipe ? "Swipe" : "Button";
    },
    actionClose: function actionClose() {
        this.node.destroy();
    },
    actionChangeControl: function actionChangeControl() {
        var boole_swipe = false;
        var enable_swipe = cc.sys.localStorage.getItem("enable_swipe");
        if (enable_swipe != null) {
            if (typeof enable_swipe === "undefined") {
                enable_swipe = false;
            } else {
                boole_swipe = JSON.parse(enable_swipe);
            }
        }
        boole_swipe = !JSON.parse(boole_swipe);
        cc.sys.localStorage.setItem("enable_swipe", boole_swipe + "");
        this.lb_button_control.string = !boole_swipe ? "Swipe" : "Button";
    },

    actionOnOffAudio: function actionOnOffAudio() {
        var eff_disable = false;
        var disableSound = cc.sys.localStorage.getItem("disableEffect");
        cc.log("-------: ", disableSound);
        if (disableSound != null) {
            if (typeof disableSound === "undefined") {
                eff_disable = false;
            } else {
                eff_disable = JSON.parse(disableSound);
            }
        }
        eff_disable = !JSON.parse(eff_disable);
        cc.sys.localStorage.setItem("disableEffect", eff_disable + "");
        this.lb_button_sound.string = eff_disable ? "Off" : "On";
    }
});

cc._RFpop();
},{}],"TankEffectScript":[function(require,module,exports){
"use strict";
cc._RFpush(module, '9b8105Lin5PrKpFaLrYwowE', 'TankEffectScript');
// Script/Gamescript/TankEffectScript.js

cc.Class({
    "extends": cc.Component,

    properties: {
        spAtlas: cc.SpriteAtlas
    },

    // use this for initialization
    onLoad: function onLoad() {},
    runEffect: function runEffect(spAtlas, id) {

        var allchild = this.node.children;
        for (var ix = 0; ix <= 8; ix++) {
            var childNode = allchild[ix];
            var sp = childNode.getComponent("cc.Sprite");
            sp.spriteFrame = spAtlas.getSpriteFrame("Ptank-" + id + "_tex" + ix);
            var time1 = (0.3 + Math.random() * 0.7) * 1.2;
            var angle = 90 + Math.random() * 360;
            var rotateby = cc.rotateBy(time1, angle);

            var mvx = (0.5 - Math.random()) * 300;
            var mvy = (0.5 - Math.random()) * 300;

            var actionmove = cc.moveBy(time1, cc.p(mvx, mvy));
            var fade = cc.fadeTo(time1 * 0.3, 0);
            var delay = cc.delayTime(time1 + 0.6);
            var sqaction = cc.sequence(delay, fade);
            childNode.runAction(cc.spawn(rotateby, actionmove, sqaction));
        }
    },

    start: function start() {
        setTimeout((function () {
            this.node.destroy();
        }).bind(this), 1700);
    }

});

cc._RFpop();
},{}],"TestConnect":[function(require,module,exports){
"use strict";
cc._RFpush(module, '46277qbPR1ACI2Z3o4oUHBd', 'TestConnect');
// Script/TestScript/TestConnect.js

cc.Class({
    'extends': cc.Component,

    properties: {
        label_status: {
            type: cc.Label,
            'default': null
        }

    },

    // use this for initialization
    onLoad: function onLoad() {},

    actionConnect: function actionConnect() {
        var self = this;
        require('socket.io');
        this.socket = io.connect('localhost:2020');
        this.socket.on('connect', function (msgSend) {
            cc.log("connection------>");
            self.label_status.string = "ALKHKJHKD";
        });
    }

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{"socket.io":"socket.io"}],"TestEffect":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'ad9c3pgcn9OQrzRetEocmJc', 'TestEffect');
// Script/TestScript/TestEffect.js

cc.Class({
    "extends": cc.Component,

    properties: {
        spBullet: cc.Node,
        msTexture: cc.Texture2D,
        spX1: cc.Node,
        spX2: cc.Node,
        frameAlts: cc.SpriteAtlas,
        partTest: cc.ParticleSystem,
        tankEffect: cc.Prefab,
        homeMap: cc.Node
        //sp_particle:cc.Node
    },
    start: function start() {
        cc.log("node_add:start");
    },

    // use this for initialization
    onLoad: function onLoad() {
        var xcolcolor = new cc.Color(255, 255, 0);

        cc.log("node_add:onLoad");

        //this.spX1.setLocalZOrder(3);
        // this.spX2.setGlobalZOrder(2);

        // this.spX2.globalZOrder=-1;
        // this.spX2.color=new cc.Color(255,255,0);

        //var action1=cc.MoveBy(10,cc.p(500,0));
        //this.homeMap.runAction(action1);

        // cc.log("node_add:name= %s",node_add.name);

        // this.node_fire=new cc.Node("nodeParticleSystem");
        // this.ms=this.node_fire.addComponent(cc.ParticleSystem);
        // this.ms.file="";

        // this.node.addChild(this.node_fire);

        //cc.log("this.sp_particle.name: %s count allchild:",this.sp_particle.name,this.node.children.length);
        //cc.director.getScheduler().schedule(function() { this.testMovexx(); }, this, 0.1, !this._isRunning);
        // this.testMovexx();
    },

    testMovexx: function testMovexx(dt) {
        var tankNodeEff = cc.instantiate(this.tankEffect);
        tankNodeEff.x = 50;
        tankNodeEff.y = 180;

        var script_eff = tankNodeEff.getComponent("TankEffectScript");
        script_eff.runEffect(this.frameAlts, 3);
        this.node.addChild(tankNodeEff);

        //this.homeMap.addChild(tankNode);

        ////console.log("partTest: %s",this.partTest.group);
        //if (this.partTest.positionType==1){
        //    this.partTest.positionType=0;
        //}else{
        //    this.partTest.positionType=1;
        //}
        //
        //console.log("tankNode.children: "+this.homeMap.children.length);

        //var nodex=tankNode.children[9];
        //nodex.positionType=1;
        //nodex=tankNode.children[10];
        //nodex.positionType=1;
    },

    actionCheckEffect: function actionCheckEffect() {
        this.unscheduleAllCallbacks();
        // cc.log("this.node.children.length: %s",this.node.children.length);
        // cc.log("this.sp_particle.name: %s",this.sp_particle.name);
        // if (cc.isValid(sp_particle)) {
        //     cc.log("is activate");
        // }else{
        //     cc.log("is Remove ");
        // }
    },

    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {
        //this.homeMap.x=this.homeMap.x+2;

    }
});

cc._RFpop();
},{}],"TestParticleSystemPos":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'cf27a34VC5DU6079AfbfS0X', 'TestParticleSystemPos');
// Script/TestScript/TestParticleSystemPos.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.logMyPosition();
    },

    logMyPosition: function logMyPosition() {
        var self = this;
        this.countStep = 0;
        var TIME_FRAME_SERVER = 0.08;
        this.schedule(function (dt) {

            cc.log("-----------%s-----------Pos: %s %s", this.node.children.length, this.node.x, this.node.y);
        }, 0.001);
    }
});

cc._RFpop();
},{}],"Utils":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'ea1a5zc1kBBsJphlGGHjojW', 'Utils');
// Script/LIB/Utils.js

var CoutryServer = { IM: "tankeu", HR: "tankeu", GW: "tankeu", IN: "tankasia", KE: "tankeu", LA: "tankasia", IO: "tankasia", HT: "tank", GY: "tank", LB: "tankasia", KG: "tankasia", HU: "tankeu", LC: "tank", IQ: "tankasia", KH: "tankasia", JM: "tank", IR: "tankasia", KI: "tankasia", IS: "tankeu", MA: "tankeu", JO: "tankasia", IT: "tankeu", JP: "tankasia", MC: "tankeu", KM: "tankeu", MD: "tankeu", LI: "tankeu", KN: "tank", ME: "tankeu", NA: "tankeu", MF: "tank", LK: "tankasia", KP: "tankasia", MG: "tankeu", NC: "tankasia", MH: "tankasia", KR: "tankasia", NE: "tankeu", NF: "tankasia", MK: "tankeu", NG: "tankeu", ML: "tankeu", MM: "tankasia", LR: "tankeu", NI: "tank", KW: "tankasia", MN: "tankasia", LS: "tankeu", PA: "tank", MO: "tankasia", LT: "tankeu", KY: "tank", MP: "tankasia", LU: "tankeu", NL: "tankeu", KZ: "tankasia", MQ: "tank", LV: "tankeu", MR: "tankeu", PE: "tank", MS: "tank", QA: "tankasia", NO: "tankeu", PF: "tankasia", MT: "tankeu", LY: "tankeu", NP: "tankasia", PG: "tankasia", MU: "tankeu", PH: "tankasia", MV: "tankasia", OM: "tankasia", NR: "tankasia", MW: "tankeu", MX: "tank", PK: "tankasia", MY: "tankasia", NU: "tankasia", PL: "tankeu", MZ: "tankeu", PM: "tank", PN: "tankasia", RE: "tankeu", SA: "tankasia", SB: "tankasia", NZ: "tankasia", SC: "tankeu", SD: "tankeu", PR: "tank", SE: "tankeu", PS: "tankasia", PT: "tankeu", SG: "tankasia", TC: "tank", SH: "tankeu", TD: "tankeu", SI: "tankeu", PW: "tankasia", SJ: "tankeu", UA: "tankeu", RO: "tankeu", TF: "tankeu", SK: "tankeu", PY: "tank", TG: "tankeu", SL: "tankeu", TH: "tankasia", SM: "tankeu", SN: "tankeu", RS: "tankeu", TJ: "tankasia", VA: "tankeu", SO: "tankeu", TK: "tankasia", UG: "tankeu", RU: "tankeu", TL: "tankasia", VC: "tank", TM: "tankasia", SR: "tank", RW: "tankeu", TN: "tankeu", VE: "tank", SS: "tankeu", TO: "tankasia", ST: "tankeu", VG: "tank", SV: "tank", UM: "tankasia", TR: "tankasia", VI: "tank", SX: "tank", WF: "tankasia", TT: "tank", SY: "tankasia", SZ: "tankeu", TV: "tankasia", TW: "tankasia", VN: "tankasia", US: "tank", TZ: "tankeu", YE: "tankasia", ZA: "tankeu", XK: "tankeu", UY: "tank", VU: "tankasia", UZ: "tankasia", WS: "tankasia", ZM: "tankeu", AD: "tankeu", YT: "tankeu", AE: "tankasia", BA: "tankeu", AF: "tankasia", BB: "tank", AG: "tank", BD: "tankasia", AI: "tank", BE: "tankeu", CA: "tank", BF: "tankeu", BG: "tankeu", ZW: "tankeu", AL: "tankeu", CC: "tankasia", BH: "tankasia", AM: "tankasia", CD: "tankeu", BI: "tankeu", BJ: "tankeu", AO: "tankeu", CF: "tankeu", CG: "tankeu", BL: "tank", AQ: "tankeu", CH: "tankeu", BM: "tank", AR: "tank", CI: "tankeu", BN: "tankasia", DE: "tankeu", AS: "tankasia", BO: "tank", AT: "tankeu", CK: "tankasia", AU: "tankasia", CL: "tank", EC: "tank", BQ: "tank", CM: "tankeu", BR: "tank", AW: "tank", CN: "tankasia", EE: "tankeu", BS: "tank", DJ: "tankeu", AX: "tankeu", CO: "tank", BT: "tankasia", DK: "tankeu", EG: "tankeu", AZ: "tankasia", EH: "tankeu", BV: "tankeu", DM: "tank", CR: "tank", BW: "tankeu", GA: "tankeu", DO: "tank", BY: "tankeu", GB: "tankeu", CU: "tank", BZ: "tank", CV: "tankeu", GD: "tank", FI: "tankeu", CW: "tank", GE: "tankasia", FJ: "tankasia", CX: "tankasia", GF: "tank", FK: "tank", CY: "tankeu", GG: "tankeu", CZ: "tankeu", GH: "tankeu", FM: "tankasia", ER: "tankeu", GI: "tankeu", ES: "tankeu", FO: "tankeu", ET: "tankeu", GL: "tank", DZ: "tankeu", GM: "tankeu", ID: "tankasia", FR: "tankeu", GN: "tankeu", IE: "tankeu", HK: "tankasia", GP: "tank", GQ: "tankeu", HM: "tankeu", GR: "tankeu", HN: "tank", JE: "tankeu", GS: "tankeu", GT: "tank", GU: "tankasia", IL: "tankasia" };
var Utils = {
    log: function log(msgobject) {
        console.log("-GAMEIOLIVE-:%s", msgobject);
    },

    getServer: function getServer() {
        var contrycode = cc.sys.localStorage.getItem("country");

        if (typeof contrycode === "undefined") {
            contrycode = "US";
        }
        if (contrycode == null) {
            contrycode = "US";
        }
        if (contrycode.length != 2) {
            contrycode = "US";
        }
        contrycode = contrycode.toUpperCase();

        var subdomain = CoutryServer[contrycode];
        if (typeof subdomain === "undefined") {
            subdomain = "tank";
        }
        if (subdomain == null) {
            subdomain = "tank";
        }

        var domain = "http://" + subdomain + ".gameio.live:2020";
        console.log("contrycode: %s  / %s", contrycode, domain);
        return domain;
    },

    distance2Pos: function distance2Pos(p1, p2) {
        var dtx = p1.x - p2.x;
        var dty = p1.y - p2.y;
        return Math.sqrt(Math.pow(dtx, 2) + Math.pow(dty, 2));
    },
    loadUserInfo: function loadUserInfo() {
        var strRT = '{"platform":10,"version":1.1,"usr":"UserName","code":"vn"}'; // theo quy ước thì 9 là iOS,10 là web mobile, 11 là android

        var contrycode = cc.sys.localStorage.getItem("country");
        if (contrycode != null) {
            if (typeof contrycode === "undefined") {
                cc.log("error load contry code");
                strRT = strRT.replace("vn", "us");
            } else {
                strRT = strRT.replace("vn", contrycode);
            }
        }
        strRT = strRT.replace("UserName", Utils.playerName);
        cc.log("strRT: %s", strRT);
        return strRT;
    },
    deCode: function deCode(keyCode) {
        var end = keyCode.length * 0.6;
        var begin = keyCode.length * 0.1;
        var newkey = keyCode.substring(begin, end);
        return newkey;
    },

    decodePackTank: function decodePackTank(objectEndcode) {
        var psend = objectEndcode.p;
        var x_tmp = psend / 100000.0;
        var xp = x_tmp / 10.0;
        xp = xp - 2000;
        var y_tmp = psend % 100000;
        var yp = y_tmp / 10.0;
        yp = yp - 2000;

        var e_g_r_d = objectEndcode.r;
        var dir = 0;
        if (e_g_r_d >= 1000000) {
            dir = parseInt(e_g_r_d / 1000000);
            e_g_r_d = e_g_r_d - dir * 1000000;
        }
        var tank_angle = e_g_r_d / 1000;
        var gun_angle = e_g_r_d % 1000;

        var e_x = objectEndcode.e;
        var hp = parseInt(e_x / 10000.0);
        var ammo = e_x % 10000;

        var level_score = objectEndcode.s;
        var level_s = level_score / 1000000.0;
        var score_s = level_score % 1000000;

        var t_ID = objectEndcode.i;
        var spped = objectEndcode.m;

        var tankName = "";
        var nameserver = objectEndcode.n;
        if (typeof nameserver === "undefined") {
            tankName = "";
        } else {
            tankName = objectEndcode.n;
        }

        var ccode = objectEndcode.c;
        if (typeof ccode === "undefined") {
            ccode = "vn";
        } else {
            ccode = objectEndcode.c;
        }

        var objectDecode = {
            x: xp,
            y: yp,
            id: t_ID,
            r: tank_angle,
            level: level_s,
            score: score_s,
            hp: hp,
            dir: dir,
            ammo: ammo,
            sp: spped,
            name: tankName,
            gR: gun_angle,
            code: ccode
        };
        return objectDecode;
    },

    decodePackObs: function decodePackObs(objectEndcode) {
        var psend = objectEndcode.p;
        var x_tmp = psend / 100000.0;
        var xp = x_tmp / 10.0;
        xp = xp - 2000;
        var y_tmp = psend % 100000;
        var yp = y_tmp / 10.0;
        yp = yp - 2000;

        var numinfo = objectEndcode.o;
        var idObj = parseInt(numinfo / 1000000.0);

        var sodu = numinfo % 1000000;
        var wd = sodu / 1000;
        var hd = sodu % 1000;

        var objDecode = {
            x: xp,
            y: yp,
            w: wd,
            h: hd,
            id: idObj
        };
        return objDecode;
    },

    decodePackBullet: function decodePackBullet(objectEndcode) {
        var psend = objectEndcode.p;
        var x_tmp = psend / 100000.0;
        var xp = x_tmp / 10.0;
        xp = xp - 2000;
        var y_tmp = psend % 100000;
        var yp = y_tmp / 10.0;
        yp = yp - 2000;

        var number_info = objectEndcode.i;
        var bullet_angle = parseInt(number_info / 100000);
        var bullet_id = number_info % 100000;

        var objDecode = {
            x: xp,
            y: yp,
            ag: bullet_angle,
            id: bullet_id
        };
        return objDecode;
    },

    decodePackExplosion: function decodePackExplosion(objectEndcode) {
        var psend = objectEndcode.p;
        var x_tmp = psend / 100000.0;
        var xp = x_tmp / 10.0;
        xp = xp - 2000;
        var y_tmp = psend % 100000;
        var yp = y_tmp / 10.0;
        yp = yp - 2000;

        var tid = objectEndcode.t;

        var objDecode = {
            x: xp,
            y: yp,
            tid: tid,
            stt: objectEndcode.e,
            tank_angle: 0,
            gun_angle: 0
        };
        return objDecode;
    },

    decodePackItem: function decodePackItem(objectEndcode) {
        var psend = objectEndcode.p;
        var x_tmp = psend / 100000.0;
        var xp = x_tmp / 10.0;
        xp = xp - 2000;
        var y_tmp = psend % 100000;
        var yp = y_tmp / 10.0;
        yp = yp - 2000;

        var numberinfo = objectEndcode.i;
        var iditem = numberinfo % 100000;
        var typeitem = parseInt(numberinfo / 100000);
        var objDecode = {
            id: iditem,
            x: xp,
            y: yp,
            type: typeitem
        };
        return objDecode;
    }

};
module.exports = Utils;

cc._RFpop();
},{}],"bulletScript":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'c71e1vAlDFHkrt/N/U8jdgs', 'bulletScript');
// Script/Gamescript/bulletScript.js

cc.Class({
    "extends": cc.Component,

    properties: {
        msTexture: cc.Texture2D
    },

    // use this for initialization
    onLoad: function onLoad() {
        // this.node_add_efect=new cc.Node("effect");
        // var ms=this.node_add_efect.addComponent(cc.MotionStreak);
        // ms.fadeTime=0.08;
        // ms.minSeg=0.2;
        // ms.stroke=5;
        // ms.texture=this.msTexture;
        // this.node.parent.addChild(this.node_add_efect);
        // this.angleMove=0;

        this.nextFrameMove = 0;
        //this.effnode=this.node.children[0];
    },

    updateFrame: function updateFrame(tmp_info) {
        var x_p = Number(tmp_info.x);
        var y_p = Number(tmp_info.y);
        this.node.setPosition(cc.p(x_p, y_p));
        this.node.isActiveSC = true;

        this.angleMove = parseInt(tmp_info.ag);
        var t_r = this.angleMove;
        if (t_r > 180) {
            t_r = t_r - 360;
        }
        t_r = -t_r;
        this.nextFrameMove = 0;
        this.node.rotation = t_r;

        //this.updateEffectPosition();
    }

});

cc._RFpop();
},{}],"explosionScript":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'e5139Jon21IKYOc4KRV7pV7', 'explosionScript');
// Script/Gamescript/explosionScript.js

cc.Class({
    "extends": cc.Component,

    properties: {},

    onLoad: function onLoad() {
        cc.log("askdjakshdaksdhkasjdhakjsdhkajshdksajd0239182371892739172891");
    }

});

cc._RFpop();
},{}],"itemScript":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'a3930v3Gm1Du6LBz+Yn/6me', 'itemScript');
// Script/Gamescript/itemScript.js

cc.Class({
    "extends": cc.Component,

    properties: {},

    onLoad: function onLoad() {
        this.node.opacity = 190;
        var childx_effect = this.node.children[0];
        var ac1 = cc.fadeTo(cc.random0To1() * 3 + 0.5, 0); // tham so dau tien la duration , time so thu 2 la opacity
        var ac2 = cc.fadeTo(cc.random0To1() * 2 + 0.5, 255); // tham so dau tien la duration , time so thu 2 la opacity

        this.repeat = cc.repeatForever(cc.sequence(ac1, ac2));

        childx_effect.runAction(this.repeat);
    },
    beginClean: function beginClean() {
        var childx_effect = this.node.children[0];
        childx_effect.stopAllActions();
    },
    updateDisplay: function updateDisplay(tmp_info) {
        var x_p = Number(tmp_info.x);
        var y_p = Number(tmp_info.y);

        this.node.setPosition(cc.p(x_p, y_p));
        this.node.isActiveSC = true;
    }

});

cc._RFpop();
},{}],"obsScript":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'c3b1dKAqAdFBp0ilxwWwXxX', 'obsScript');
// Script/Gamescript/obsScript.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    initDisplay: function initDisplay(tmp_info) {
        var x_p = Number(tmp_info.x);
        var y_p = Number(tmp_info.y);
        this.node.setPosition(cc.p(x_p, y_p));
        var ww = Number(tmp_info.w);
        var hh = Number(tmp_info.h);
        this.node.scaleX = ww / 100;
        this.node.scaleY = hh / 100;

        this.Opos = cc.p(x_p, y_p);
        this.min_x = x_p - ww / 2;
        this.max_x = x_p + ww / 2;

        this.min_y = y_p - hh / 2;
        this.max_y = y_p + hh / 2;
    }

});

cc._RFpop();
},{}],"socket.io":[function(require,module,exports){
(function (global){
"use strict";
cc._RFpush(module, '553f6EpdwZG5LbBbiTVZDSa', 'socket.io');
// Script/LIB/socket.io.js

if (!cc.sys.isNative) {

  (function (f) {
    if (typeof exports === "object" && typeof module !== "undefined") {
      module.exports = f();
    } else if (typeof define === "function" && define.amd) {
      define([], f);
    } else {
      var g;if (typeof window !== "undefined") {
        g = window;
      } else if (typeof global !== "undefined") {
        g = global;
      } else if (typeof self !== "undefined") {
        g = self;
      } else {
        g = this;
      }g.io = f();
    }
  })(function () {
    var define, module, exports;return (function e(t, n, r) {
      function s(o, u) {
        if (!n[o]) {
          if (!t[o]) {
            var a = typeof require == "function" && require;if (!u && a) return a(o, !0);if (i) return i(o, !0);var f = new Error("Cannot find module '" + o + "'");throw (f.code = "MODULE_NOT_FOUND", f);
          }var l = n[o] = { exports: {} };t[o][0].call(l.exports, function (e) {
            var n = t[o][1][e];return s(n ? n : e);
          }, l, l.exports, e, t, n, r);
        }return n[o].exports;
      }var i = typeof require == "function" && require;for (var o = 0; o < r.length; o++) s(r[o]);return s;
    })({ 1: [function (_dereq_, module, exports) {

        module.exports = _dereq_('./lib/');
      }, { "./lib/": 2 }], 2: [function (_dereq_, module, exports) {

        module.exports = _dereq_('./socket');

        /**
         * Exports parser
         *
         * @api public
         *
         */
        module.exports.parser = _dereq_('engine.io-parser');
      }, { "./socket": 3, "engine.io-parser": 19 }], 3: [function (_dereq_, module, exports) {
        (function (global) {
          /**
           * Module dependencies.
           */

          var transports = _dereq_('./transports');
          var Emitter = _dereq_('component-emitter');
          var debug = _dereq_('debug')('engine.io-client:socket');
          var index = _dereq_('indexof');
          var parser = _dereq_('engine.io-parser');
          var parseuri = _dereq_('parseuri');
          var parsejson = _dereq_('parsejson');
          var parseqs = _dereq_('parseqs');

          /**
           * Module exports.
           */

          module.exports = Socket;

          /**
           * Noop function.
           *
           * @api private
           */

          function noop() {}

          /**
           * Socket constructor.
           *
           * @param {String|Object} uri or options
           * @param {Object} options
           * @api public
           */

          function Socket(uri, opts) {
            if (!(this instanceof Socket)) return new Socket(uri, opts);

            opts = opts || {};

            if (uri && 'object' == typeof uri) {
              opts = uri;
              uri = null;
            }

            if (uri) {
              uri = parseuri(uri);
              opts.hostname = uri.host;
              opts.secure = uri.protocol == 'https' || uri.protocol == 'wss';
              opts.port = uri.port;
              if (uri.query) opts.query = uri.query;
            } else if (opts.host) {
              opts.hostname = parseuri(opts.host).host;
            }

            this.secure = null != opts.secure ? opts.secure : global.location && 'https:' == location.protocol;

            if (opts.hostname && !opts.port) {
              // if no port is specified manually, use the protocol default
              opts.port = this.secure ? '443' : '80';
            }

            this.agent = opts.agent || false;
            this.hostname = opts.hostname || (global.location ? location.hostname : 'localhost');
            this.port = opts.port || (global.location && location.port ? location.port : this.secure ? 443 : 80);
            this.query = opts.query || {};
            if ('string' == typeof this.query) this.query = parseqs.decode(this.query);
            this.upgrade = false !== opts.upgrade;
            this.path = (opts.path || '/engine.io').replace(/\/$/, '') + '/';
            this.forceJSONP = !!opts.forceJSONP;
            this.jsonp = false !== opts.jsonp;
            this.forceBase64 = !!opts.forceBase64;
            this.enablesXDR = !!opts.enablesXDR;
            this.timestampParam = opts.timestampParam || 't';
            this.timestampRequests = opts.timestampRequests;
            this.transports = opts.transports || ['polling', 'websocket'];
            this.readyState = '';
            this.writeBuffer = [];
            this.policyPort = opts.policyPort || 843;
            this.rememberUpgrade = opts.rememberUpgrade || false;
            this.binaryType = null;
            this.onlyBinaryUpgrades = opts.onlyBinaryUpgrades;
            this.perMessageDeflate = false !== opts.perMessageDeflate ? opts.perMessageDeflate || {} : false;

            if (true === this.perMessageDeflate) this.perMessageDeflate = {};
            if (this.perMessageDeflate && null == this.perMessageDeflate.threshold) {
              this.perMessageDeflate.threshold = 1024;
            }

            // SSL options for Node.js client
            this.pfx = opts.pfx || null;
            this.key = opts.key || null;
            this.passphrase = opts.passphrase || null;
            this.cert = opts.cert || null;
            this.ca = opts.ca || null;
            this.ciphers = opts.ciphers || null;
            this.rejectUnauthorized = opts.rejectUnauthorized === undefined ? null : opts.rejectUnauthorized;

            // other options for Node.js client
            var freeGlobal = typeof global == 'object' && global;
            if (freeGlobal.global === freeGlobal) {
              if (opts.extraHeaders && Object.keys(opts.extraHeaders).length > 0) {
                this.extraHeaders = opts.extraHeaders;
              }
            }

            this.open();
          }

          Socket.priorWebsocketSuccess = false;

          /**
           * Mix in `Emitter`.
           */

          Emitter(Socket.prototype);

          /**
           * Protocol version.
           *
           * @api public
           */

          Socket.protocol = parser.protocol; // this is an int

          /**
           * Expose deps for legacy compatibility
           * and standalone browser access.
           */

          Socket.Socket = Socket;
          Socket.Transport = _dereq_('./transport');
          Socket.transports = _dereq_('./transports');
          Socket.parser = _dereq_('engine.io-parser');

          /**
           * Creates transport of the given type.
           *
           * @param {String} transport name
           * @return {Transport}
           * @api private
           */

          Socket.prototype.createTransport = function (name) {
            debug('creating transport "%s"', name);
            var query = clone(this.query);

            // append engine.io protocol identifier
            query.EIO = parser.protocol;

            // transport name
            query.transport = name;

            // session id if we already have one
            if (this.id) query.sid = this.id;

            var transport = new transports[name]({
              agent: this.agent,
              hostname: this.hostname,
              port: this.port,
              secure: this.secure,
              path: this.path,
              query: query,
              forceJSONP: this.forceJSONP,
              jsonp: this.jsonp,
              forceBase64: this.forceBase64,
              enablesXDR: this.enablesXDR,
              timestampRequests: this.timestampRequests,
              timestampParam: this.timestampParam,
              policyPort: this.policyPort,
              socket: this,
              pfx: this.pfx,
              key: this.key,
              passphrase: this.passphrase,
              cert: this.cert,
              ca: this.ca,
              ciphers: this.ciphers,
              rejectUnauthorized: this.rejectUnauthorized,
              perMessageDeflate: this.perMessageDeflate,
              extraHeaders: this.extraHeaders
            });

            return transport;
          };

          function clone(obj) {
            var o = {};
            for (var i in obj) {
              if (obj.hasOwnProperty(i)) {
                o[i] = obj[i];
              }
            }
            return o;
          }

          /**
           * Initializes transport to use and starts probe.
           *
           * @api private
           */
          Socket.prototype.open = function () {
            var transport;
            if (this.rememberUpgrade && Socket.priorWebsocketSuccess && this.transports.indexOf('websocket') != -1) {
              transport = 'websocket';
            } else if (0 === this.transports.length) {
              // Emit error on next tick so it can be listened to
              var self = this;
              setTimeout(function () {
                self.emit('error', 'No transports available');
              }, 0);
              return;
            } else {
              transport = this.transports[0];
            }
            this.readyState = 'opening';

            // Retry with the next transport if the transport is disabled (jsonp: false)
            try {
              transport = this.createTransport(transport);
            } catch (e) {
              this.transports.shift();
              this.open();
              return;
            }

            transport.open();
            this.setTransport(transport);
          };

          /**
           * Sets the current transport. Disables the existing one (if any).
           *
           * @api private
           */

          Socket.prototype.setTransport = function (transport) {
            debug('setting transport %s', transport.name);
            var self = this;

            if (this.transport) {
              debug('clearing existing transport %s', this.transport.name);
              this.transport.removeAllListeners();
            }

            // set up transport
            this.transport = transport;

            // set up transport listeners
            transport.on('drain', function () {
              self.onDrain();
            }).on('packet', function (packet) {
              self.onPacket(packet);
            }).on('error', function (e) {
              self.onError(e);
            }).on('close', function () {
              self.onClose('transport close');
            });
          };

          /**
           * Probes a transport.
           *
           * @param {String} transport name
           * @api private
           */

          Socket.prototype.probe = function (name) {
            debug('probing transport "%s"', name);
            var transport = this.createTransport(name, { probe: 1 }),
                failed = false,
                self = this;

            Socket.priorWebsocketSuccess = false;

            function onTransportOpen() {
              if (self.onlyBinaryUpgrades) {
                var upgradeLosesBinary = !this.supportsBinary && self.transport.supportsBinary;
                failed = failed || upgradeLosesBinary;
              }
              if (failed) return;

              debug('probe transport "%s" opened', name);
              transport.send([{ type: 'ping', data: 'probe' }]);
              transport.once('packet', function (msg) {
                if (failed) return;
                if ('pong' == msg.type && 'probe' == msg.data) {
                  debug('probe transport "%s" pong', name);
                  self.upgrading = true;
                  self.emit('upgrading', transport);
                  if (!transport) return;
                  Socket.priorWebsocketSuccess = 'websocket' == transport.name;

                  debug('pausing current transport "%s"', self.transport.name);
                  self.transport.pause(function () {
                    if (failed) return;
                    if ('closed' == self.readyState) return;
                    debug('changing transport and sending upgrade packet');

                    cleanup();

                    self.setTransport(transport);
                    transport.send([{ type: 'upgrade' }]);
                    self.emit('upgrade', transport);
                    transport = null;
                    self.upgrading = false;
                    self.flush();
                  });
                } else {
                  debug('probe transport "%s" failed', name);
                  var err = new Error('probe error');
                  err.transport = transport.name;
                  self.emit('upgradeError', err);
                }
              });
            }

            function freezeTransport() {
              if (failed) return;

              // Any callback called by transport should be ignored since now
              failed = true;

              cleanup();

              transport.close();
              transport = null;
            }

            //Handle any error that happens while probing
            function onerror(err) {
              var error = new Error('probe error: ' + err);
              error.transport = transport.name;

              freezeTransport();

              debug('probe transport "%s" failed because of error: %s', name, err);

              self.emit('upgradeError', error);
            }

            function onTransportClose() {
              onerror("transport closed");
            }

            //When the socket is closed while we're probing
            function onclose() {
              onerror("socket closed");
            }

            //When the socket is upgraded while we're probing
            function onupgrade(to) {
              if (transport && to.name != transport.name) {
                debug('"%s" works - aborting "%s"', to.name, transport.name);
                freezeTransport();
              }
            }

            //Remove all listeners on the transport and on self
            function cleanup() {
              transport.removeListener('open', onTransportOpen);
              transport.removeListener('error', onerror);
              transport.removeListener('close', onTransportClose);
              self.removeListener('close', onclose);
              self.removeListener('upgrading', onupgrade);
            }

            transport.once('open', onTransportOpen);
            transport.once('error', onerror);
            transport.once('close', onTransportClose);

            this.once('close', onclose);
            this.once('upgrading', onupgrade);

            transport.open();
          };

          /**
           * Called when connection is deemed open.
           *
           * @api public
           */

          Socket.prototype.onOpen = function () {
            debug('socket open');
            this.readyState = 'open';
            Socket.priorWebsocketSuccess = 'websocket' == this.transport.name;
            this.emit('open');
            this.flush();

            // we check for `readyState` in case an `open`
            // listener already closed the socket
            if ('open' == this.readyState && this.upgrade && this.transport.pause) {
              debug('starting upgrade probes');
              for (var i = 0, l = this.upgrades.length; i < l; i++) {
                this.probe(this.upgrades[i]);
              }
            }
          };

          /**
           * Handles a packet.
           *
           * @api private
           */

          Socket.prototype.onPacket = function (packet) {
            if ('opening' == this.readyState || 'open' == this.readyState) {
              debug('socket receive: type "%s", data "%s"', packet.type, packet.data);

              this.emit('packet', packet);

              // Socket is live - any packet counts
              this.emit('heartbeat');

              switch (packet.type) {
                case 'open':
                  this.onHandshake(parsejson(packet.data));
                  break;

                case 'pong':
                  this.setPing();
                  this.emit('pong');
                  break;

                case 'error':
                  var err = new Error('server error');
                  err.code = packet.data;
                  this.onError(err);
                  break;

                case 'message':
                  this.emit('data', packet.data);
                  this.emit('message', packet.data);
                  break;
              }
            } else {
              debug('packet received with socket readyState "%s"', this.readyState);
            }
          };

          /**
           * Called upon handshake completion.
           *
           * @param {Object} handshake obj
           * @api private
           */

          Socket.prototype.onHandshake = function (data) {
            this.emit('handshake', data);
            this.id = data.sid;
            this.transport.query.sid = data.sid;
            this.upgrades = this.filterUpgrades(data.upgrades);
            this.pingInterval = data.pingInterval;
            this.pingTimeout = data.pingTimeout;
            this.onOpen();
            // In case open handler closes socket
            if ('closed' == this.readyState) return;
            this.setPing();

            // Prolong liveness of socket on heartbeat
            this.removeListener('heartbeat', this.onHeartbeat);
            this.on('heartbeat', this.onHeartbeat);
          };

          /**
           * Resets ping timeout.
           *
           * @api private
           */

          Socket.prototype.onHeartbeat = function (timeout) {
            clearTimeout(this.pingTimeoutTimer);
            var self = this;
            self.pingTimeoutTimer = setTimeout(function () {
              if ('closed' == self.readyState) return;
              self.onClose('ping timeout');
            }, timeout || self.pingInterval + self.pingTimeout);
          };

          /**
           * Pings server every `this.pingInterval` and expects response
           * within `this.pingTimeout` or closes connection.
           *
           * @api private
           */

          Socket.prototype.setPing = function () {
            var self = this;
            clearTimeout(self.pingIntervalTimer);
            self.pingIntervalTimer = setTimeout(function () {
              debug('writing ping packet - expecting pong within %sms', self.pingTimeout);
              self.ping();
              self.onHeartbeat(self.pingTimeout);
            }, self.pingInterval);
          };

          /**
          * Sends a ping packet.
          *
          * @api private
          */

          Socket.prototype.ping = function () {
            var self = this;
            this.sendPacket('ping', function () {
              self.emit('ping');
            });
          };

          /**
           * Called on `drain` event
           *
           * @api private
           */

          Socket.prototype.onDrain = function () {
            this.writeBuffer.splice(0, this.prevBufferLen);

            // setting prevBufferLen = 0 is very important
            // for example, when upgrading, upgrade packet is sent over,
            // and a nonzero prevBufferLen could cause problems on `drain`
            this.prevBufferLen = 0;

            if (0 === this.writeBuffer.length) {
              this.emit('drain');
            } else {
              this.flush();
            }
          };

          /**
           * Flush write buffers.
           *
           * @api private
           */

          Socket.prototype.flush = function () {
            if ('closed' != this.readyState && this.transport.writable && !this.upgrading && this.writeBuffer.length) {
              debug('flushing %d packets in socket', this.writeBuffer.length);
              this.transport.send(this.writeBuffer);
              // keep track of current length of writeBuffer
              // splice writeBuffer and callbackBuffer on `drain`
              this.prevBufferLen = this.writeBuffer.length;
              this.emit('flush');
            }
          };

          /**
           * Sends a message.
           *
           * @param {String} message.
           * @param {Function} callback function.
           * @param {Object} options.
           * @return {Socket} for chaining.
           * @api public
           */

          Socket.prototype.write = Socket.prototype.send = function (msg, options, fn) {
            this.sendPacket('message', msg, options, fn);
            return this;
          };

          /**
           * Sends a packet.
           *
           * @param {String} packet type.
           * @param {String} data.
           * @param {Object} options.
           * @param {Function} callback function.
           * @api private
           */

          Socket.prototype.sendPacket = function (type, data, options, fn) {
            if ('function' == typeof data) {
              fn = data;
              data = undefined;
            }

            if ('function' == typeof options) {
              fn = options;
              options = null;
            }

            if ('closing' == this.readyState || 'closed' == this.readyState) {
              return;
            }

            options = options || {};
            options.compress = false !== options.compress;

            var packet = {
              type: type,
              data: data,
              options: options
            };
            this.emit('packetCreate', packet);
            this.writeBuffer.push(packet);
            if (fn) this.once('flush', fn);
            this.flush();
          };

          /**
           * Closes the connection.
           *
           * @api private
           */

          Socket.prototype.close = function () {
            if ('opening' == this.readyState || 'open' == this.readyState) {
              this.readyState = 'closing';

              var self = this;

              if (this.writeBuffer.length) {
                this.once('drain', function () {
                  if (this.upgrading) {
                    waitForUpgrade();
                  } else {
                    close();
                  }
                });
              } else if (this.upgrading) {
                waitForUpgrade();
              } else {
                close();
              }
            }

            function close() {
              self.onClose('forced close');
              debug('socket closing - telling transport to close');
              self.transport.close();
            }

            function cleanupAndClose() {
              self.removeListener('upgrade', cleanupAndClose);
              self.removeListener('upgradeError', cleanupAndClose);
              close();
            }

            function waitForUpgrade() {
              // wait for upgrade to finish since we can't send packets while pausing a transport
              self.once('upgrade', cleanupAndClose);
              self.once('upgradeError', cleanupAndClose);
            }

            return this;
          };

          /**
           * Called upon transport error
           *
           * @api private
           */

          Socket.prototype.onError = function (err) {
            debug('socket error %j', err);
            Socket.priorWebsocketSuccess = false;
            this.emit('error', err);
            this.onClose('transport error', err);
          };

          /**
           * Called upon transport close.
           *
           * @api private
           */

          Socket.prototype.onClose = function (reason, desc) {
            if ('opening' == this.readyState || 'open' == this.readyState || 'closing' == this.readyState) {
              debug('socket close with reason: "%s"', reason);
              var self = this;

              // clear timers
              clearTimeout(this.pingIntervalTimer);
              clearTimeout(this.pingTimeoutTimer);

              // stop event from firing again for transport
              this.transport.removeAllListeners('close');

              // ensure transport won't stay open
              this.transport.close();

              // ignore further transport communication
              this.transport.removeAllListeners();

              // set ready state
              this.readyState = 'closed';

              // clear session id
              this.id = null;

              // emit close event
              this.emit('close', reason, desc);

              // clean buffers after, so users can still
              // grab the buffers on `close` event
              self.writeBuffer = [];
              self.prevBufferLen = 0;
            }
          };

          /**
           * Filters upgrades, returning only those matching client transports.
           *
           * @param {Array} server upgrades
           * @api private
           *
           */

          Socket.prototype.filterUpgrades = function (upgrades) {
            var filteredUpgrades = [];
            for (var i = 0, j = upgrades.length; i < j; i++) {
              if (~index(this.transports, upgrades[i])) filteredUpgrades.push(upgrades[i]);
            }
            return filteredUpgrades;
          };
        }).call(this, typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
      }, { "./transport": 4, "./transports": 5, "component-emitter": 15, "debug": 17, "engine.io-parser": 19, "indexof": 23, "parsejson": 26, "parseqs": 27, "parseuri": 28 }], 4: [function (_dereq_, module, exports) {
        /**
         * Module dependencies.
         */

        var parser = _dereq_('engine.io-parser');
        var Emitter = _dereq_('component-emitter');

        /**
         * Module exports.
         */

        module.exports = Transport;

        /**
         * Transport abstract constructor.
         *
         * @param {Object} options.
         * @api private
         */

        function Transport(opts) {
          this.path = opts.path;
          this.hostname = opts.hostname;
          this.port = opts.port;
          this.secure = opts.secure;
          this.query = opts.query;
          this.timestampParam = opts.timestampParam;
          this.timestampRequests = opts.timestampRequests;
          this.readyState = '';
          this.agent = opts.agent || false;
          this.socket = opts.socket;
          this.enablesXDR = opts.enablesXDR;

          // SSL options for Node.js client
          this.pfx = opts.pfx;
          this.key = opts.key;
          this.passphrase = opts.passphrase;
          this.cert = opts.cert;
          this.ca = opts.ca;
          this.ciphers = opts.ciphers;
          this.rejectUnauthorized = opts.rejectUnauthorized;

          // other options for Node.js client
          this.extraHeaders = opts.extraHeaders;
        }

        /**
         * Mix in `Emitter`.
         */

        Emitter(Transport.prototype);

        /**
         * Emits an error.
         *
         * @param {String} str
         * @return {Transport} for chaining
         * @api public
         */

        Transport.prototype.onError = function (msg, desc) {
          var err = new Error(msg);
          err.type = 'TransportError';
          err.description = desc;
          this.emit('error', err);
          return this;
        };

        /**
         * Opens the transport.
         *
         * @api public
         */

        Transport.prototype.open = function () {
          if ('closed' == this.readyState || '' == this.readyState) {
            this.readyState = 'opening';
            this.doOpen();
          }

          return this;
        };

        /**
         * Closes the transport.
         *
         * @api private
         */

        Transport.prototype.close = function () {
          if ('opening' == this.readyState || 'open' == this.readyState) {
            this.doClose();
            this.onClose();
          }

          return this;
        };

        /**
         * Sends multiple packets.
         *
         * @param {Array} packets
         * @api private
         */

        Transport.prototype.send = function (packets) {
          if ('open' == this.readyState) {
            this.write(packets);
          } else {
            throw new Error('Transport not open');
          }
        };

        /**
         * Called upon open
         *
         * @api private
         */

        Transport.prototype.onOpen = function () {
          this.readyState = 'open';
          this.writable = true;
          this.emit('open');
        };

        /**
         * Called with data.
         *
         * @param {String} data
         * @api private
         */

        Transport.prototype.onData = function (data) {
          var packet = parser.decodePacket(data, this.socket.binaryType);
          this.onPacket(packet);
        };

        /**
         * Called with a decoded packet.
         */

        Transport.prototype.onPacket = function (packet) {
          this.emit('packet', packet);
        };

        /**
         * Called upon close.
         *
         * @api private
         */

        Transport.prototype.onClose = function () {
          this.readyState = 'closed';
          this.emit('close');
        };
      }, { "component-emitter": 15, "engine.io-parser": 19 }], 5: [function (_dereq_, module, exports) {
        (function (global) {
          /**
           * Module dependencies
           */

          var XMLHttpRequest = _dereq_('xmlhttprequest-ssl');
          var XHR = _dereq_('./polling-xhr');
          var JSONP = _dereq_('./polling-jsonp');
          var websocket = _dereq_('./websocket');

          /**
           * Export transports.
           */

          exports.polling = polling;
          exports.websocket = websocket;

          /**
           * Polling transport polymorphic constructor.
           * Decides on xhr vs jsonp based on feature detection.
           *
           * @api private
           */

          function polling(opts) {
            var xhr;
            var xd = false;
            var xs = false;
            var jsonp = false !== opts.jsonp;

            if (global.location) {
              var isSSL = 'https:' == location.protocol;
              var port = location.port;

              // some user agents have empty `location.port`
              if (!port) {
                port = isSSL ? 443 : 80;
              }

              xd = opts.hostname != location.hostname || port != opts.port;
              xs = opts.secure != isSSL;
            }

            opts.xdomain = xd;
            opts.xscheme = xs;
            xhr = new XMLHttpRequest(opts);

            if ('open' in xhr && !opts.forceJSONP) {
              return new XHR(opts);
            } else {
              if (!jsonp) throw new Error('JSONP disabled');
              return new JSONP(opts);
            }
          }
        }).call(this, typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
      }, { "./polling-jsonp": 6, "./polling-xhr": 7, "./websocket": 9, "xmlhttprequest-ssl": 10 }], 6: [function (_dereq_, module, exports) {
        (function (global) {

          /**
           * Module requirements.
           */

          var Polling = _dereq_('./polling');
          var inherit = _dereq_('component-inherit');

          /**
           * Module exports.
           */

          module.exports = JSONPPolling;

          /**
           * Cached regular expressions.
           */

          var rNewline = /\n/g;
          var rEscapedNewline = /\\n/g;

          /**
           * Global JSONP callbacks.
           */

          var callbacks;

          /**
           * Callbacks count.
           */

          var index = 0;

          /**
           * Noop.
           */

          function empty() {}

          /**
           * JSONP Polling constructor.
           *
           * @param {Object} opts.
           * @api public
           */

          function JSONPPolling(opts) {
            Polling.call(this, opts);

            this.query = this.query || {};

            // define global callbacks array if not present
            // we do this here (lazily) to avoid unneeded global pollution
            if (!callbacks) {
              // we need to consider multiple engines in the same page
              if (!global.___eio) global.___eio = [];
              callbacks = global.___eio;
            }

            // callback identifier
            this.index = callbacks.length;

            // add callback to jsonp global
            var self = this;
            callbacks.push(function (msg) {
              self.onData(msg);
            });

            // append to query string
            this.query.j = this.index;

            // prevent spurious errors from being emitted when the window is unloaded
            if (global.document && global.addEventListener) {
              global.addEventListener('beforeunload', function () {
                if (self.script) self.script.onerror = empty;
              }, false);
            }
          }

          /**
           * Inherits from Polling.
           */

          inherit(JSONPPolling, Polling);

          /*
           * JSONP only supports binary as base64 encoded strings
           */

          JSONPPolling.prototype.supportsBinary = false;

          /**
           * Closes the socket.
           *
           * @api private
           */

          JSONPPolling.prototype.doClose = function () {
            if (this.script) {
              this.script.parentNode.removeChild(this.script);
              this.script = null;
            }

            if (this.form) {
              this.form.parentNode.removeChild(this.form);
              this.form = null;
              this.iframe = null;
            }

            Polling.prototype.doClose.call(this);
          };

          /**
           * Starts a poll cycle.
           *
           * @api private
           */

          JSONPPolling.prototype.doPoll = function () {
            var self = this;
            var script = document.createElement('script');

            if (this.script) {
              this.script.parentNode.removeChild(this.script);
              this.script = null;
            }

            script.async = true;
            script.src = this.uri();
            script.onerror = function (e) {
              self.onError('jsonp poll error', e);
            };

            var insertAt = document.getElementsByTagName('script')[0];
            if (insertAt) {
              insertAt.parentNode.insertBefore(script, insertAt);
            } else {
              (document.head || document.body).appendChild(script);
            }
            this.script = script;

            var isUAgecko = 'undefined' != typeof navigator && /gecko/i.test(navigator.userAgent);

            if (isUAgecko) {
              setTimeout(function () {
                var iframe = document.createElement('iframe');
                document.body.appendChild(iframe);
                document.body.removeChild(iframe);
              }, 100);
            }
          };

          /**
           * Writes with a hidden iframe.
           *
           * @param {String} data to send
           * @param {Function} called upon flush.
           * @api private
           */

          JSONPPolling.prototype.doWrite = function (data, fn) {
            var self = this;

            if (!this.form) {
              var form = document.createElement('form');
              var area = document.createElement('textarea');
              var id = this.iframeId = 'eio_iframe_' + this.index;
              var iframe;

              form.className = 'socketio';
              form.style.position = 'absolute';
              form.style.top = '-1000px';
              form.style.left = '-1000px';
              form.target = id;
              form.method = 'POST';
              form.setAttribute('accept-charset', 'utf-8');
              area.name = 'd';
              form.appendChild(area);
              document.body.appendChild(form);

              this.form = form;
              this.area = area;
            }

            this.form.action = this.uri();

            function complete() {
              initIframe();
              fn();
            }

            function initIframe() {
              if (self.iframe) {
                try {
                  self.form.removeChild(self.iframe);
                } catch (e) {
                  self.onError('jsonp polling iframe removal error', e);
                }
              }

              try {
                // ie6 dynamic iframes with target="" support (thanks Chris Lambacher)
                var html = '<iframe src="javascript:0" name="' + self.iframeId + '">';
                iframe = document.createElement(html);
              } catch (e) {
                iframe = document.createElement('iframe');
                iframe.name = self.iframeId;
                iframe.src = 'javascript:0';
              }

              iframe.id = self.iframeId;

              self.form.appendChild(iframe);
              self.iframe = iframe;
            }

            initIframe();

            // escape \n to prevent it from being converted into \r\n by some UAs
            // double escaping is required for escaped new lines because unescaping of new lines can be done safely on server-side
            data = data.replace(rEscapedNewline, '\\\n');
            this.area.value = data.replace(rNewline, '\\n');

            try {
              this.form.submit();
            } catch (e) {}

            if (this.iframe.attachEvent) {
              this.iframe.onreadystatechange = function () {
                if (self.iframe.readyState == 'complete') {
                  complete();
                }
              };
            } else {
              this.iframe.onload = complete;
            }
          };
        }).call(this, typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
      }, { "./polling": 8, "component-inherit": 16 }], 7: [function (_dereq_, module, exports) {
        (function (global) {
          /**
           * Module requirements.
           */

          var XMLHttpRequest = _dereq_('xmlhttprequest-ssl');
          var Polling = _dereq_('./polling');
          var Emitter = _dereq_('component-emitter');
          var inherit = _dereq_('component-inherit');
          var debug = _dereq_('debug')('engine.io-client:polling-xhr');

          /**
           * Module exports.
           */

          module.exports = XHR;
          module.exports.Request = Request;

          /**
           * Empty function
           */

          function empty() {}

          /**
           * XHR Polling constructor.
           *
           * @param {Object} opts
           * @api public
           */

          function XHR(opts) {
            Polling.call(this, opts);

            if (global.location) {
              var isSSL = 'https:' == location.protocol;
              var port = location.port;

              // some user agents have empty `location.port`
              if (!port) {
                port = isSSL ? 443 : 80;
              }

              this.xd = opts.hostname != global.location.hostname || port != opts.port;
              this.xs = opts.secure != isSSL;
            } else {
              this.extraHeaders = opts.extraHeaders;
            }
          }

          /**
           * Inherits from Polling.
           */

          inherit(XHR, Polling);

          /**
           * XHR supports binary
           */

          XHR.prototype.supportsBinary = true;

          /**
           * Creates a request.
           *
           * @param {String} method
           * @api private
           */

          XHR.prototype.request = function (opts) {
            opts = opts || {};
            opts.uri = this.uri();
            opts.xd = this.xd;
            opts.xs = this.xs;
            opts.agent = this.agent || false;
            opts.supportsBinary = this.supportsBinary;
            opts.enablesXDR = this.enablesXDR;

            // SSL options for Node.js client
            opts.pfx = this.pfx;
            opts.key = this.key;
            opts.passphrase = this.passphrase;
            opts.cert = this.cert;
            opts.ca = this.ca;
            opts.ciphers = this.ciphers;
            opts.rejectUnauthorized = this.rejectUnauthorized;

            // other options for Node.js client
            opts.extraHeaders = this.extraHeaders;

            return new Request(opts);
          };

          /**
           * Sends data.
           *
           * @param {String} data to send.
           * @param {Function} called upon flush.
           * @api private
           */

          XHR.prototype.doWrite = function (data, fn) {
            var isBinary = typeof data !== 'string' && data !== undefined;
            var req = this.request({ method: 'POST', data: data, isBinary: isBinary });
            var self = this;
            req.on('success', fn);
            req.on('error', function (err) {
              self.onError('xhr post error', err);
            });
            this.sendXhr = req;
          };

          /**
           * Starts a poll cycle.
           *
           * @api private
           */

          XHR.prototype.doPoll = function () {
            debug('xhr poll');
            var req = this.request();
            var self = this;
            req.on('data', function (data) {
              self.onData(data);
            });
            req.on('error', function (err) {
              self.onError('xhr poll error', err);
            });
            this.pollXhr = req;
          };

          /**
           * Request constructor
           *
           * @param {Object} options
           * @api public
           */

          function Request(opts) {
            this.method = opts.method || 'GET';
            this.uri = opts.uri;
            this.xd = !!opts.xd;
            this.xs = !!opts.xs;
            this.async = false !== opts.async;
            this.data = undefined != opts.data ? opts.data : null;
            this.agent = opts.agent;
            this.isBinary = opts.isBinary;
            this.supportsBinary = opts.supportsBinary;
            this.enablesXDR = opts.enablesXDR;

            // SSL options for Node.js client
            this.pfx = opts.pfx;
            this.key = opts.key;
            this.passphrase = opts.passphrase;
            this.cert = opts.cert;
            this.ca = opts.ca;
            this.ciphers = opts.ciphers;
            this.rejectUnauthorized = opts.rejectUnauthorized;

            // other options for Node.js client
            this.extraHeaders = opts.extraHeaders;

            this.create();
          }

          /**
           * Mix in `Emitter`.
           */

          Emitter(Request.prototype);

          /**
           * Creates the XHR object and sends the request.
           *
           * @api private
           */

          Request.prototype.create = function () {
            var opts = { agent: this.agent, xdomain: this.xd, xscheme: this.xs, enablesXDR: this.enablesXDR };

            // SSL options for Node.js client
            opts.pfx = this.pfx;
            opts.key = this.key;
            opts.passphrase = this.passphrase;
            opts.cert = this.cert;
            opts.ca = this.ca;
            opts.ciphers = this.ciphers;
            opts.rejectUnauthorized = this.rejectUnauthorized;

            var xhr = this.xhr = new XMLHttpRequest(opts);
            var self = this;

            try {
              debug('xhr open %s: %s', this.method, this.uri);
              xhr.open(this.method, this.uri, this.async);
              try {
                if (this.extraHeaders) {
                  xhr.setDisableHeaderCheck(true);
                  for (var i in this.extraHeaders) {
                    if (this.extraHeaders.hasOwnProperty(i)) {
                      xhr.setRequestHeader(i, this.extraHeaders[i]);
                    }
                  }
                }
              } catch (e) {}
              if (this.supportsBinary) {
                // This has to be done after open because Firefox is stupid
                // http://stackoverflow.com/questions/13216903/get-binary-data-with-xmlhttprequest-in-a-firefox-extension
                xhr.responseType = 'arraybuffer';
              }

              if ('POST' == this.method) {
                try {
                  if (this.isBinary) {
                    xhr.setRequestHeader('Content-type', 'application/octet-stream');
                  } else {
                    xhr.setRequestHeader('Content-type', 'text/plain;charset=UTF-8');
                  }
                } catch (e) {}
              }

              // ie6 check
              if ('withCredentials' in xhr) {
                xhr.withCredentials = true;
              }

              if (this.hasXDR()) {
                xhr.onload = function () {
                  self.onLoad();
                };
                xhr.onerror = function () {
                  self.onError(xhr.responseText);
                };
              } else {
                xhr.onreadystatechange = function () {
                  if (4 != xhr.readyState) return;
                  if (200 == xhr.status || 1223 == xhr.status) {
                    self.onLoad();
                  } else {
                    // make sure the `error` event handler that's user-set
                    // does not throw in the same tick and gets caught here
                    setTimeout(function () {
                      self.onError(xhr.status);
                    }, 0);
                  }
                };
              }

              debug('xhr data %s', this.data);
              xhr.send(this.data);
            } catch (e) {
              // Need to defer since .create() is called directly fhrom the constructor
              // and thus the 'error' event can only be only bound *after* this exception
              // occurs.  Therefore, also, we cannot throw here at all.
              setTimeout(function () {
                self.onError(e);
              }, 0);
              return;
            }

            if (global.document) {
              this.index = Request.requestsCount++;
              Request.requests[this.index] = this;
            }
          };

          /**
           * Called upon successful response.
           *
           * @api private
           */

          Request.prototype.onSuccess = function () {
            this.emit('success');
            this.cleanup();
          };

          /**
           * Called if we have data.
           *
           * @api private
           */

          Request.prototype.onData = function (data) {
            this.emit('data', data);
            this.onSuccess();
          };

          /**
           * Called upon error.
           *
           * @api private
           */

          Request.prototype.onError = function (err) {
            this.emit('error', err);
            this.cleanup(true);
          };

          /**
           * Cleans up house.
           *
           * @api private
           */

          Request.prototype.cleanup = function (fromError) {
            if ('undefined' == typeof this.xhr || null === this.xhr) {
              return;
            }
            // xmlhttprequest
            if (this.hasXDR()) {
              this.xhr.onload = this.xhr.onerror = empty;
            } else {
              this.xhr.onreadystatechange = empty;
            }

            if (fromError) {
              try {
                this.xhr.abort();
              } catch (e) {}
            }

            if (global.document) {
              delete Request.requests[this.index];
            }

            this.xhr = null;
          };

          /**
           * Called upon load.
           *
           * @api private
           */

          Request.prototype.onLoad = function () {
            var data;
            try {
              var contentType;
              try {
                contentType = this.xhr.getResponseHeader('Content-Type').split(';')[0];
              } catch (e) {}
              if (contentType === 'application/octet-stream') {
                data = this.xhr.response;
              } else {
                if (!this.supportsBinary) {
                  data = this.xhr.responseText;
                } else {
                  try {
                    data = String.fromCharCode.apply(null, new Uint8Array(this.xhr.response));
                  } catch (e) {
                    var ui8Arr = new Uint8Array(this.xhr.response);
                    var dataArray = [];
                    for (var idx = 0, length = ui8Arr.length; idx < length; idx++) {
                      dataArray.push(ui8Arr[idx]);
                    }

                    data = String.fromCharCode.apply(null, dataArray);
                  }
                }
              }
            } catch (e) {
              this.onError(e);
            }
            if (null != data) {
              this.onData(data);
            }
          };

          /**
           * Check if it has XDomainRequest.
           *
           * @api private
           */

          Request.prototype.hasXDR = function () {
            return 'undefined' !== typeof global.XDomainRequest && !this.xs && this.enablesXDR;
          };

          /**
           * Aborts the request.
           *
           * @api public
           */

          Request.prototype.abort = function () {
            this.cleanup();
          };

          /**
           * Aborts pending requests when unloading the window. This is needed to prevent
           * memory leaks (e.g. when using IE) and to ensure that no spurious error is
           * emitted.
           */

          if (global.document) {
            Request.requestsCount = 0;
            Request.requests = {};
            if (global.attachEvent) {
              global.attachEvent('onunload', unloadHandler);
            } else if (global.addEventListener) {
              global.addEventListener('beforeunload', unloadHandler, false);
            }
          }

          function unloadHandler() {
            for (var i in Request.requests) {
              if (Request.requests.hasOwnProperty(i)) {
                Request.requests[i].abort();
              }
            }
          }
        }).call(this, typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
      }, { "./polling": 8, "component-emitter": 15, "component-inherit": 16, "debug": 17, "xmlhttprequest-ssl": 10 }], 8: [function (_dereq_, module, exports) {
        /**
         * Module dependencies.
         */

        var Transport = _dereq_('../transport');
        var parseqs = _dereq_('parseqs');
        var parser = _dereq_('engine.io-parser');
        var inherit = _dereq_('component-inherit');
        var yeast = _dereq_('yeast');
        var debug = _dereq_('debug')('engine.io-client:polling');

        /**
         * Module exports.
         */

        module.exports = Polling;

        /**
         * Is XHR2 supported?
         */

        var hasXHR2 = (function () {
          var XMLHttpRequest = _dereq_('xmlhttprequest-ssl');
          var xhr = new XMLHttpRequest({ xdomain: false });
          return null != xhr.responseType;
        })();

        /**
         * Polling interface.
         *
         * @param {Object} opts
         * @api private
         */

        function Polling(opts) {
          var forceBase64 = opts && opts.forceBase64;
          if (!hasXHR2 || forceBase64) {
            this.supportsBinary = false;
          }
          Transport.call(this, opts);
        }

        /**
         * Inherits from Transport.
         */

        inherit(Polling, Transport);

        /**
         * Transport name.
         */

        Polling.prototype.name = 'polling';

        /**
         * Opens the socket (triggers polling). We write a PING message to determine
         * when the transport is open.
         *
         * @api private
         */

        Polling.prototype.doOpen = function () {
          this.poll();
        };

        /**
         * Pauses polling.
         *
         * @param {Function} callback upon buffers are flushed and transport is paused
         * @api private
         */

        Polling.prototype.pause = function (onPause) {
          var pending = 0;
          var self = this;

          this.readyState = 'pausing';

          function pause() {
            debug('paused');
            self.readyState = 'paused';
            onPause();
          }

          if (this.polling || !this.writable) {
            var total = 0;

            if (this.polling) {
              debug('we are currently polling - waiting to pause');
              total++;
              this.once('pollComplete', function () {
                debug('pre-pause polling complete');
                --total || pause();
              });
            }

            if (!this.writable) {
              debug('we are currently writing - waiting to pause');
              total++;
              this.once('drain', function () {
                debug('pre-pause writing complete');
                --total || pause();
              });
            }
          } else {
            pause();
          }
        };

        /**
         * Starts polling cycle.
         *
         * @api public
         */

        Polling.prototype.poll = function () {
          debug('polling');
          this.polling = true;
          this.doPoll();
          this.emit('poll');
        };

        /**
         * Overloads onData to detect payloads.
         *
         * @api private
         */

        Polling.prototype.onData = function (data) {
          var self = this;
          debug('polling got data %s', data);
          var callback = function callback(packet, index, total) {
            // if its the first message we consider the transport open
            if ('opening' == self.readyState) {
              self.onOpen();
            }

            // if its a close packet, we close the ongoing requests
            if ('close' == packet.type) {
              self.onClose();
              return false;
            }

            // otherwise bypass onData and handle the message
            self.onPacket(packet);
          };

          // decode payload
          parser.decodePayload(data, this.socket.binaryType, callback);

          // if an event did not trigger closing
          if ('closed' != this.readyState) {
            // if we got data we're not polling
            this.polling = false;
            this.emit('pollComplete');

            if ('open' == this.readyState) {
              this.poll();
            } else {
              debug('ignoring poll - transport state "%s"', this.readyState);
            }
          }
        };

        /**
         * For polling, send a close packet.
         *
         * @api private
         */

        Polling.prototype.doClose = function () {
          var self = this;

          function close() {
            debug('writing close packet');
            self.write([{ type: 'close' }]);
          }

          if ('open' == this.readyState) {
            debug('transport open - closing');
            close();
          } else {
            // in case we're trying to close while
            // handshaking is in progress (GH-164)
            debug('transport not open - deferring close');
            this.once('open', close);
          }
        };

        /**
         * Writes a packets payload.
         *
         * @param {Array} data packets
         * @param {Function} drain callback
         * @api private
         */

        Polling.prototype.write = function (packets) {
          var self = this;
          this.writable = false;
          var callbackfn = function callbackfn() {
            self.writable = true;
            self.emit('drain');
          };

          var self = this;
          parser.encodePayload(packets, this.supportsBinary, function (data) {
            self.doWrite(data, callbackfn);
          });
        };

        /**
         * Generates uri for connection.
         *
         * @api private
         */

        Polling.prototype.uri = function () {
          var query = this.query || {};
          var schema = this.secure ? 'https' : 'http';
          var port = '';

          // cache busting is forced
          if (false !== this.timestampRequests) {
            query[this.timestampParam] = yeast();
          }

          if (!this.supportsBinary && !query.sid) {
            query.b64 = 1;
          }

          query = parseqs.encode(query);

          // avoid port if default for schema
          if (this.port && ('https' == schema && this.port != 443 || 'http' == schema && this.port != 80)) {
            port = ':' + this.port;
          }

          // prepend ? to query
          if (query.length) {
            query = '?' + query;
          }

          var ipv6 = this.hostname.indexOf(':') !== -1;
          return schema + '://' + (ipv6 ? '[' + this.hostname + ']' : this.hostname) + port + this.path + query;
        };
      }, { "../transport": 4, "component-inherit": 16, "debug": 17, "engine.io-parser": 19, "parseqs": 27, "xmlhttprequest-ssl": 10, "yeast": 30 }], 9: [function (_dereq_, module, exports) {
        (function (global) {
          /**
           * Module dependencies.
           */

          var Transport = _dereq_('../transport');
          var parser = _dereq_('engine.io-parser');
          var parseqs = _dereq_('parseqs');
          var inherit = _dereq_('component-inherit');
          var yeast = _dereq_('yeast');
          var debug = _dereq_('debug')('engine.io-client:websocket');
          var BrowserWebSocket = global.WebSocket || global.MozWebSocket;

          /**
           * Get either the `WebSocket` or `MozWebSocket` globals
           * in the browser or the WebSocket-compatible interface
           * exposed by `ws` for Node environment.
           */

          var WebSocket = BrowserWebSocket || (typeof window !== 'undefined' ? null : _dereq_('ws'));

          /**
           * Module exports.
           */

          module.exports = WS;

          /**
           * WebSocket transport constructor.
           *
           * @api {Object} connection options
           * @api public
           */

          function WS(opts) {
            var forceBase64 = opts && opts.forceBase64;
            if (forceBase64) {
              this.supportsBinary = false;
            }
            this.perMessageDeflate = opts.perMessageDeflate;
            Transport.call(this, opts);
          }

          /**
           * Inherits from Transport.
           */

          inherit(WS, Transport);

          /**
           * Transport name.
           *
           * @api public
           */

          WS.prototype.name = 'websocket';

          /*
           * WebSockets support binary
           */

          WS.prototype.supportsBinary = true;

          /**
           * Opens socket.
           *
           * @api private
           */

          WS.prototype.doOpen = function () {
            if (!this.check()) {
              // let probe timeout
              return;
            }

            var self = this;
            var uri = this.uri();
            var protocols = void 0;
            var opts = {
              agent: this.agent,
              perMessageDeflate: this.perMessageDeflate
            };

            // SSL options for Node.js client
            opts.pfx = this.pfx;
            opts.key = this.key;
            opts.passphrase = this.passphrase;
            opts.cert = this.cert;
            opts.ca = this.ca;
            opts.ciphers = this.ciphers;
            opts.rejectUnauthorized = this.rejectUnauthorized;
            if (this.extraHeaders) {
              opts.headers = this.extraHeaders;
            }

            this.ws = BrowserWebSocket ? new WebSocket(uri) : new WebSocket(uri, protocols, opts);

            if (this.ws.binaryType === undefined) {
              this.supportsBinary = false;
            }

            if (this.ws.supports && this.ws.supports.binary) {
              this.supportsBinary = true;
              this.ws.binaryType = 'buffer';
            } else {
              this.ws.binaryType = 'arraybuffer';
            }

            this.addEventListeners();
          };

          /**
           * Adds event listeners to the socket
           *
           * @api private
           */

          WS.prototype.addEventListeners = function () {
            var self = this;

            this.ws.onopen = function () {
              self.onOpen();
            };
            this.ws.onclose = function () {
              self.onClose();
            };
            this.ws.onmessage = function (ev) {
              self.onData(ev.data);
            };
            this.ws.onerror = function (e) {
              self.onError('websocket error', e);
            };
          };

          /**
           * Override `onData` to use a timer on iOS.
           * See: https://gist.github.com/mloughran/2052006
           *
           * @api private
           */

          if ('undefined' != typeof navigator && /iPad|iPhone|iPod/i.test(navigator.userAgent)) {
            WS.prototype.onData = function (data) {
              var self = this;
              setTimeout(function () {
                Transport.prototype.onData.call(self, data);
              }, 0);
            };
          }

          /**
           * Writes data to socket.
           *
           * @param {Array} array of packets.
           * @api private
           */

          WS.prototype.write = function (packets) {
            var self = this;
            this.writable = false;

            // encodePacket efficient as it uses WS framing
            // no need for encodePayload
            var total = packets.length;
            for (var i = 0, l = total; i < l; i++) {
              (function (packet) {
                parser.encodePacket(packet, self.supportsBinary, function (data) {
                  if (!BrowserWebSocket) {
                    // always create a new object (GH-437)
                    var opts = {};
                    if (packet.options) {
                      opts.compress = packet.options.compress;
                    }

                    if (self.perMessageDeflate) {
                      var len = 'string' == typeof data ? global.Buffer.byteLength(data) : data.length;
                      if (len < self.perMessageDeflate.threshold) {
                        opts.compress = false;
                      }
                    }
                  }

                  //Sometimes the websocket has already been closed but the browser didn't
                  //have a chance of informing us about it yet, in that case send will
                  //throw an error
                  try {
                    if (BrowserWebSocket) {
                      // TypeError is thrown when passing the second argument on Safari
                      self.ws.send(data);
                    } else {
                      self.ws.send(data, opts);
                    }
                  } catch (e) {
                    debug('websocket closed before onclose event');
                  }

                  --total || done();
                });
              })(packets[i]);
            }

            function done() {
              self.emit('flush');

              // fake drain
              // defer to next tick to allow Socket to clear writeBuffer
              setTimeout(function () {
                self.writable = true;
                self.emit('drain');
              }, 0);
            }
          };

          /**
           * Called upon close
           *
           * @api private
           */

          WS.prototype.onClose = function () {
            Transport.prototype.onClose.call(this);
          };

          /**
           * Closes socket.
           *
           * @api private
           */

          WS.prototype.doClose = function () {
            if (typeof this.ws !== 'undefined') {
              this.ws.close();
            }
          };

          /**
           * Generates uri for connection.
           *
           * @api private
           */

          WS.prototype.uri = function () {
            var query = this.query || {};
            var schema = this.secure ? 'wss' : 'ws';
            var port = '';

            // avoid port if default for schema
            if (this.port && ('wss' == schema && this.port != 443 || 'ws' == schema && this.port != 80)) {
              port = ':' + this.port;
            }

            // append timestamp to URI
            if (this.timestampRequests) {
              query[this.timestampParam] = yeast();
            }

            // communicate binary support capabilities
            if (!this.supportsBinary) {
              query.b64 = 1;
            }

            query = parseqs.encode(query);

            // prepend ? to query
            if (query.length) {
              query = '?' + query;
            }

            var ipv6 = this.hostname.indexOf(':') !== -1;
            return schema + '://' + (ipv6 ? '[' + this.hostname + ']' : this.hostname) + port + this.path + query;
          };

          /**
           * Feature detection for WebSocket.
           *
           * @return {Boolean} whether this transport is available.
           * @api public
           */

          WS.prototype.check = function () {
            return !!WebSocket && !('__initialize' in WebSocket && this.name === WS.prototype.name);
          };
        }).call(this, typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
      }, { "../transport": 4, "component-inherit": 16, "debug": 17, "engine.io-parser": 19, "parseqs": 27, "ws": undefined, "yeast": 30 }], 10: [function (_dereq_, module, exports) {
        // browser shim for xmlhttprequest module
        var hasCORS = _dereq_('has-cors');

        module.exports = function (opts) {
          var xdomain = opts.xdomain;

          // scheme must be same when usign XDomainRequest
          // http://blogs.msdn.com/b/ieinternals/archive/2010/05/13/xdomainrequest-restrictions-limitations-and-workarounds.aspx
          var xscheme = opts.xscheme;

          // XDomainRequest has a flow of not sending cookie, therefore it should be disabled as a default.
          // https://github.com/Automattic/engine.io-client/pull/217
          var enablesXDR = opts.enablesXDR;

          // XMLHttpRequest can be disabled on IE
          try {
            if ('undefined' != typeof XMLHttpRequest && (!xdomain || hasCORS)) {
              return new XMLHttpRequest();
            }
          } catch (e) {}

          // Use XDomainRequest for IE8 if enablesXDR is true
          // because loading bar keeps flashing when using jsonp-polling
          // https://github.com/yujiosaka/socke.io-ie8-loading-example
          try {
            if ('undefined' != typeof XDomainRequest && !xscheme && enablesXDR) {
              return new XDomainRequest();
            }
          } catch (e) {}

          if (!xdomain) {
            try {
              return new ActiveXObject('Microsoft.XMLHTTP');
            } catch (e) {}
          }
        };
      }, { "has-cors": 22 }], 11: [function (_dereq_, module, exports) {
        module.exports = after;

        function after(count, callback, err_cb) {
          var bail = false;
          err_cb = err_cb || noop;
          proxy.count = count;

          return count === 0 ? callback() : proxy;

          function proxy(err, result) {
            if (proxy.count <= 0) {
              throw new Error('after called too many times');
            }
            --proxy.count;

            // after first error, rest are passed to err_cb
            if (err) {
              bail = true;
              callback(err);
              // future error callbacks will go to error handler
              callback = err_cb;
            } else if (proxy.count === 0 && !bail) {
              callback(null, result);
            }
          }
        }

        function noop() {}
      }, {}], 12: [function (_dereq_, module, exports) {
        /**
         * An abstraction for slicing an arraybuffer even when
         * ArrayBuffer.prototype.slice is not supported
         *
         * @api public
         */

        module.exports = function (arraybuffer, start, end) {
          var bytes = arraybuffer.byteLength;
          start = start || 0;
          end = end || bytes;

          if (arraybuffer.slice) {
            return arraybuffer.slice(start, end);
          }

          if (start < 0) {
            start += bytes;
          }
          if (end < 0) {
            end += bytes;
          }
          if (end > bytes) {
            end = bytes;
          }

          if (start >= bytes || start >= end || bytes === 0) {
            return new ArrayBuffer(0);
          }

          var abv = new Uint8Array(arraybuffer);
          var result = new Uint8Array(end - start);
          for (var i = start, ii = 0; i < end; i++, ii++) {
            result[ii] = abv[i];
          }
          return result.buffer;
        };
      }, {}], 13: [function (_dereq_, module, exports) {
        /*
         * base64-arraybuffer
         * https://github.com/niklasvh/base64-arraybuffer
         *
         * Copyright (c) 2012 Niklas von Hertzen
         * Licensed under the MIT license.
         */
        (function (chars) {
          "use strict";

          exports.encode = function (arraybuffer) {
            var bytes = new Uint8Array(arraybuffer),
                i,
                len = bytes.length,
                base64 = "";

            for (i = 0; i < len; i += 3) {
              base64 += chars[bytes[i] >> 2];
              base64 += chars[(bytes[i] & 3) << 4 | bytes[i + 1] >> 4];
              base64 += chars[(bytes[i + 1] & 15) << 2 | bytes[i + 2] >> 6];
              base64 += chars[bytes[i + 2] & 63];
            }

            if (len % 3 === 2) {
              base64 = base64.substring(0, base64.length - 1) + "=";
            } else if (len % 3 === 1) {
              base64 = base64.substring(0, base64.length - 2) + "==";
            }

            return base64;
          };

          exports.decode = function (base64) {
            var bufferLength = base64.length * 0.75,
                len = base64.length,
                i,
                p = 0,
                encoded1,
                encoded2,
                encoded3,
                encoded4;

            if (base64[base64.length - 1] === "=") {
              bufferLength--;
              if (base64[base64.length - 2] === "=") {
                bufferLength--;
              }
            }

            var arraybuffer = new ArrayBuffer(bufferLength),
                bytes = new Uint8Array(arraybuffer);

            for (i = 0; i < len; i += 4) {
              encoded1 = chars.indexOf(base64[i]);
              encoded2 = chars.indexOf(base64[i + 1]);
              encoded3 = chars.indexOf(base64[i + 2]);
              encoded4 = chars.indexOf(base64[i + 3]);

              bytes[p++] = encoded1 << 2 | encoded2 >> 4;
              bytes[p++] = (encoded2 & 15) << 4 | encoded3 >> 2;
              bytes[p++] = (encoded3 & 3) << 6 | encoded4 & 63;
            }

            return arraybuffer;
          };
        })("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/");
      }, {}], 14: [function (_dereq_, module, exports) {
        (function (global) {
          /**
           * Create a blob builder even when vendor prefixes exist
           */

          var BlobBuilder = global.BlobBuilder || global.WebKitBlobBuilder || global.MSBlobBuilder || global.MozBlobBuilder;

          /**
           * Check if Blob constructor is supported
           */

          var blobSupported = (function () {
            try {
              var a = new Blob(['hi']);
              return a.size === 2;
            } catch (e) {
              return false;
            }
          })();

          /**
           * Check if Blob constructor supports ArrayBufferViews
           * Fails in Safari 6, so we need to map to ArrayBuffers there.
           */

          var blobSupportsArrayBufferView = blobSupported && (function () {
            try {
              var b = new Blob([new Uint8Array([1, 2])]);
              return b.size === 2;
            } catch (e) {
              return false;
            }
          })();

          /**
           * Check if BlobBuilder is supported
           */

          var blobBuilderSupported = BlobBuilder && BlobBuilder.prototype.append && BlobBuilder.prototype.getBlob;

          /**
           * Helper function that maps ArrayBufferViews to ArrayBuffers
           * Used by BlobBuilder constructor and old browsers that didn't
           * support it in the Blob constructor.
           */

          function mapArrayBufferViews(ary) {
            for (var i = 0; i < ary.length; i++) {
              var chunk = ary[i];
              if (chunk.buffer instanceof ArrayBuffer) {
                var buf = chunk.buffer;

                // if this is a subarray, make a copy so we only
                // include the subarray region from the underlying buffer
                if (chunk.byteLength !== buf.byteLength) {
                  var copy = new Uint8Array(chunk.byteLength);
                  copy.set(new Uint8Array(buf, chunk.byteOffset, chunk.byteLength));
                  buf = copy.buffer;
                }

                ary[i] = buf;
              }
            }
          }

          function BlobBuilderConstructor(ary, options) {
            options = options || {};

            var bb = new BlobBuilder();
            mapArrayBufferViews(ary);

            for (var i = 0; i < ary.length; i++) {
              bb.append(ary[i]);
            }

            return options.type ? bb.getBlob(options.type) : bb.getBlob();
          };

          function BlobConstructor(ary, options) {
            mapArrayBufferViews(ary);
            return new Blob(ary, options || {});
          };

          module.exports = (function () {
            if (blobSupported) {
              return blobSupportsArrayBufferView ? global.Blob : BlobConstructor;
            } else if (blobBuilderSupported) {
              return BlobBuilderConstructor;
            } else {
              return undefined;
            }
          })();
        }).call(this, typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
      }, {}], 15: [function (_dereq_, module, exports) {

        /**
         * Expose `Emitter`.
         */

        module.exports = Emitter;

        /**
         * Initialize a new `Emitter`.
         *
         * @api public
         */

        function Emitter(obj) {
          if (obj) return mixin(obj);
        };

        /**
         * Mixin the emitter properties.
         *
         * @param {Object} obj
         * @return {Object}
         * @api private
         */

        function mixin(obj) {
          for (var key in Emitter.prototype) {
            obj[key] = Emitter.prototype[key];
          }
          return obj;
        }

        /**
         * Listen on the given `event` with `fn`.
         *
         * @param {String} event
         * @param {Function} fn
         * @return {Emitter}
         * @api public
         */

        Emitter.prototype.on = Emitter.prototype.addEventListener = function (event, fn) {
          this._callbacks = this._callbacks || {};
          (this._callbacks[event] = this._callbacks[event] || []).push(fn);
          return this;
        };

        /**
         * Adds an `event` listener that will be invoked a single
         * time then automatically removed.
         *
         * @param {String} event
         * @param {Function} fn
         * @return {Emitter}
         * @api public
         */

        Emitter.prototype.once = function (event, fn) {
          var self = this;
          this._callbacks = this._callbacks || {};

          function on() {
            self.off(event, on);
            fn.apply(this, arguments);
          }

          on.fn = fn;
          this.on(event, on);
          return this;
        };

        /**
         * Remove the given callback for `event` or all
         * registered callbacks.
         *
         * @param {String} event
         * @param {Function} fn
         * @return {Emitter}
         * @api public
         */

        Emitter.prototype.off = Emitter.prototype.removeListener = Emitter.prototype.removeAllListeners = Emitter.prototype.removeEventListener = function (event, fn) {
          this._callbacks = this._callbacks || {};

          // all
          if (0 == arguments.length) {
            this._callbacks = {};
            return this;
          }

          // specific event
          var callbacks = this._callbacks[event];
          if (!callbacks) return this;

          // remove all handlers
          if (1 == arguments.length) {
            delete this._callbacks[event];
            return this;
          }

          // remove specific handler
          var cb;
          for (var i = 0; i < callbacks.length; i++) {
            cb = callbacks[i];
            if (cb === fn || cb.fn === fn) {
              callbacks.splice(i, 1);
              break;
            }
          }
          return this;
        };

        /**
         * Emit `event` with the given args.
         *
         * @param {String} event
         * @param {Mixed} ...
         * @return {Emitter}
         */

        Emitter.prototype.emit = function (event) {
          this._callbacks = this._callbacks || {};
          var args = [].slice.call(arguments, 1),
              callbacks = this._callbacks[event];

          if (callbacks) {
            callbacks = callbacks.slice(0);
            for (var i = 0, len = callbacks.length; i < len; ++i) {
              callbacks[i].apply(this, args);
            }
          }

          return this;
        };

        /**
         * Return array of callbacks for `event`.
         *
         * @param {String} event
         * @return {Array}
         * @api public
         */

        Emitter.prototype.listeners = function (event) {
          this._callbacks = this._callbacks || {};
          return this._callbacks[event] || [];
        };

        /**
         * Check if this emitter has `event` handlers.
         *
         * @param {String} event
         * @return {Boolean}
         * @api public
         */

        Emitter.prototype.hasListeners = function (event) {
          return !!this.listeners(event).length;
        };
      }, {}], 16: [function (_dereq_, module, exports) {

        module.exports = function (a, b) {
          var fn = function fn() {};
          fn.prototype = b.prototype;
          a.prototype = new fn();
          a.prototype.constructor = a;
        };
      }, {}], 17: [function (_dereq_, module, exports) {

        /**
         * This is the web browser implementation of `debug()`.
         *
         * Expose `debug()` as the module.
         */

        exports = module.exports = _dereq_('./debug');
        exports.log = log;
        exports.formatArgs = formatArgs;
        exports.save = save;
        exports.load = load;
        exports.useColors = useColors;
        exports.storage = 'undefined' != typeof chrome && 'undefined' != typeof chrome.storage ? chrome.storage.local : localstorage();

        /**
         * Colors.
         */

        exports.colors = ['lightseagreen', 'forestgreen', 'goldenrod', 'dodgerblue', 'darkorchid', 'crimson'];

        /**
         * Currently only WebKit-based Web Inspectors, Firefox >= v31,
         * and the Firebug extension (any Firefox version) are known
         * to support "%c" CSS customizations.
         *
         * TODO: add a `localStorage` variable to explicitly enable/disable colors
         */

        function useColors() {
          // is webkit? http://stackoverflow.com/a/16459606/376773
          return 'WebkitAppearance' in document.documentElement.style ||
          // is firebug? http://stackoverflow.com/a/398120/376773
          window.console && (console.firebug || console.exception && console.table) ||
          // is firefox >= v31?
          // https://developer.mozilla.org/en-US/docs/Tools/Web_Console#Styling_messages
          navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/) && parseInt(RegExp.$1, 10) >= 31;
        }

        /**
         * Map %j to `JSON.stringify()`, since no Web Inspectors do that by default.
         */

        exports.formatters.j = function (v) {
          return JSON.stringify(v);
        };

        /**
         * Colorize log arguments if enabled.
         *
         * @api public
         */

        function formatArgs() {
          var args = arguments;
          var useColors = this.useColors;

          args[0] = (useColors ? '%c' : '') + this.namespace + (useColors ? ' %c' : ' ') + args[0] + (useColors ? '%c ' : ' ') + '+' + exports.humanize(this.diff);

          if (!useColors) return args;

          var c = 'color: ' + this.color;
          args = [args[0], c, 'color: inherit'].concat(Array.prototype.slice.call(args, 1));

          // the final "%c" is somewhat tricky, because there could be other
          // arguments passed either before or after the %c, so we need to
          // figure out the correct index to insert the CSS into
          var index = 0;
          var lastC = 0;
          args[0].replace(/%[a-z%]/g, function (match) {
            if ('%%' === match) return;
            index++;
            if ('%c' === match) {
              // we only are interested in the *last* %c
              // (the user may have provided their own)
              lastC = index;
            }
          });

          args.splice(lastC, 0, c);
          return args;
        }

        /**
         * Invokes `console.log()` when available.
         * No-op when `console.log` is not a "function".
         *
         * @api public
         */

        function log() {
          // this hackery is required for IE8/9, where
          // the `console.log` function doesn't have 'apply'

          return 'object' === typeof console && console.log && Function.prototype.apply.call(console.log, console, arguments);
        }

        /**
         * Save `namespaces`.
         *
         * @param {String} namespaces
         * @api private
         */

        function save(namespaces) {
          try {
            if (null == namespaces) {
              exports.storage.removeItem('debug');
            } else {
              exports.storage.debug = namespaces;
            }
          } catch (e) {}
        }

        /**
         * Load `namespaces`.
         *
         * @return {String} returns the previously persisted debug modes
         * @api private
         */

        function load() {
          var r;
          try {
            r = exports.storage.debug;
          } catch (e) {}
          return r;
        }

        /**
         * Enable namespaces listed in `localStorage.debug` initially.
         */

        exports.enable(load());

        /**
         * Localstorage attempts to return the localstorage.
         *
         * This is necessary because safari throws
         * when a user disables cookies/localstorage
         * and you attempt to access it.
         *
         * @return {LocalStorage}
         * @api private
         */

        function localstorage() {
          try {
            return window.localStorage;
          } catch (e) {}
        }
      }, { "./debug": 18 }], 18: [function (_dereq_, module, exports) {

        /**
         * This is the common logic for both the Node.js and web browser
         * implementations of `debug()`.
         *
         * Expose `debug()` as the module.
         */

        exports = module.exports = debug;
        exports.coerce = coerce;
        exports.disable = disable;
        exports.enable = enable;
        exports.enabled = enabled;
        exports.humanize = _dereq_('ms');

        /**
         * The currently active debug mode names, and names to skip.
         */

        exports.names = [];
        exports.skips = [];

        /**
         * Map of special "%n" handling functions, for the debug "format" argument.
         *
         * Valid key names are a single, lowercased letter, i.e. "n".
         */

        exports.formatters = {};

        /**
         * Previously assigned color.
         */

        var prevColor = 0;

        /**
         * Previous log timestamp.
         */

        var prevTime;

        /**
         * Select a color.
         *
         * @return {Number}
         * @api private
         */

        function selectColor() {
          return exports.colors[prevColor++ % exports.colors.length];
        }

        /**
         * Create a debugger with the given `namespace`.
         *
         * @param {String} namespace
         * @return {Function}
         * @api public
         */

        function debug(namespace) {

          // define the `disabled` version
          function disabled() {}
          disabled.enabled = false;

          // define the `enabled` version
          function enabled() {

            var self = enabled;

            // set `diff` timestamp
            var curr = +new Date();
            var ms = curr - (prevTime || curr);
            self.diff = ms;
            self.prev = prevTime;
            self.curr = curr;
            prevTime = curr;

            // add the `color` if not set
            if (null == self.useColors) self.useColors = exports.useColors();
            if (null == self.color && self.useColors) self.color = selectColor();

            var args = Array.prototype.slice.call(arguments);

            args[0] = exports.coerce(args[0]);

            if ('string' !== typeof args[0]) {
              // anything else let's inspect with %o
              args = ['%o'].concat(args);
            }

            // apply any `formatters` transformations
            var index = 0;
            args[0] = args[0].replace(/%([a-z%])/g, function (match, format) {
              // if we encounter an escaped % then don't increase the array index
              if (match === '%%') return match;
              index++;
              var formatter = exports.formatters[format];
              if ('function' === typeof formatter) {
                var val = args[index];
                match = formatter.call(self, val);

                // now we need to remove `args[index]` since it's inlined in the `format`
                args.splice(index, 1);
                index--;
              }
              return match;
            });

            if ('function' === typeof exports.formatArgs) {
              args = exports.formatArgs.apply(self, args);
            }
            var logFn = enabled.log || exports.log || console.log.bind(console);
            logFn.apply(self, args);
          }
          enabled.enabled = true;

          var fn = exports.enabled(namespace) ? enabled : disabled;

          fn.namespace = namespace;

          return fn;
        }

        /**
         * Enables a debug mode by namespaces. This can include modes
         * separated by a colon and wildcards.
         *
         * @param {String} namespaces
         * @api public
         */

        function enable(namespaces) {
          exports.save(namespaces);

          var split = (namespaces || '').split(/[\s,]+/);
          var len = split.length;

          for (var i = 0; i < len; i++) {
            if (!split[i]) continue; // ignore empty strings
            namespaces = split[i].replace(/\*/g, '.*?');
            if (namespaces[0] === '-') {
              exports.skips.push(new RegExp('^' + namespaces.substr(1) + '$'));
            } else {
              exports.names.push(new RegExp('^' + namespaces + '$'));
            }
          }
        }

        /**
         * Disable debug output.
         *
         * @api public
         */

        function disable() {
          exports.enable('');
        }

        /**
         * Returns true if the given mode name is enabled, false otherwise.
         *
         * @param {String} name
         * @return {Boolean}
         * @api public
         */

        function enabled(name) {
          var i, len;
          for (i = 0, len = exports.skips.length; i < len; i++) {
            if (exports.skips[i].test(name)) {
              return false;
            }
          }
          for (i = 0, len = exports.names.length; i < len; i++) {
            if (exports.names[i].test(name)) {
              return true;
            }
          }
          return false;
        }

        /**
         * Coerce `val`.
         *
         * @param {Mixed} val
         * @return {Mixed}
         * @api private
         */

        function coerce(val) {
          if (val instanceof Error) return val.stack || val.message;
          return val;
        }
      }, { "ms": 25 }], 19: [function (_dereq_, module, exports) {
        (function (global) {
          /**
           * Module dependencies.
           */

          var keys = _dereq_('./keys');
          var hasBinary = _dereq_('has-binary');
          var sliceBuffer = _dereq_('arraybuffer.slice');
          var base64encoder = _dereq_('base64-arraybuffer');
          var after = _dereq_('after');
          var utf8 = _dereq_('utf8');

          /**
           * Check if we are running an android browser. That requires us to use
           * ArrayBuffer with polling transports...
           *
           * http://ghinda.net/jpeg-blob-ajax-android/
           */

          var isAndroid = navigator.userAgent.match(/Android/i);

          /**
           * Check if we are running in PhantomJS.
           * Uploading a Blob with PhantomJS does not work correctly, as reported here:
           * https://github.com/ariya/phantomjs/issues/11395
           * @type boolean
           */
          var isPhantomJS = /PhantomJS/i.test(navigator.userAgent);

          /**
           * When true, avoids using Blobs to encode payloads.
           * @type boolean
           */
          var dontSendBlobs = isAndroid || isPhantomJS;

          /**
           * Current protocol version.
           */

          exports.protocol = 3;

          /**
           * Packet types.
           */

          var packets = exports.packets = {
            open: 0, // non-ws
            close: 1, // non-ws
            ping: 2,
            pong: 3,
            message: 4,
            upgrade: 5,
            noop: 6
          };

          var packetslist = keys(packets);

          /**
           * Premade error packet.
           */

          var err = { type: 'error', data: 'parser error' };

          /**
           * Create a blob api even for blob builder when vendor prefixes exist
           */

          var Blob = _dereq_('blob');

          /**
           * Encodes a packet.
           *
           *     <packet type id> [ <data> ]
           *
           * Example:
           *
           *     5hello world
           *     3
           *     4
           *
           * Binary is encoded in an identical principle
           *
           * @api private
           */

          exports.encodePacket = function (packet, supportsBinary, utf8encode, callback) {
            if ('function' == typeof supportsBinary) {
              callback = supportsBinary;
              supportsBinary = false;
            }

            if ('function' == typeof utf8encode) {
              callback = utf8encode;
              utf8encode = null;
            }

            var data = packet.data === undefined ? undefined : packet.data.buffer || packet.data;

            if (global.ArrayBuffer && data instanceof ArrayBuffer) {
              return encodeArrayBuffer(packet, supportsBinary, callback);
            } else if (Blob && data instanceof global.Blob) {
              return encodeBlob(packet, supportsBinary, callback);
            }

            // might be an object with { base64: true, data: dataAsBase64String }
            if (data && data.base64) {
              return encodeBase64Object(packet, callback);
            }

            // Sending data as a utf-8 string
            var encoded = packets[packet.type];

            // data fragment is optional
            if (undefined !== packet.data) {
              encoded += utf8encode ? utf8.encode(String(packet.data)) : String(packet.data);
            }

            return callback('' + encoded);
          };

          function encodeBase64Object(packet, callback) {
            // packet data is an object { base64: true, data: dataAsBase64String }
            var message = 'b' + exports.packets[packet.type] + packet.data.data;
            return callback(message);
          }

          /**
           * Encode packet helpers for binary types
           */

          function encodeArrayBuffer(packet, supportsBinary, callback) {
            if (!supportsBinary) {
              return exports.encodeBase64Packet(packet, callback);
            }

            var data = packet.data;
            var contentArray = new Uint8Array(data);
            var resultBuffer = new Uint8Array(1 + data.byteLength);

            resultBuffer[0] = packets[packet.type];
            for (var i = 0; i < contentArray.length; i++) {
              resultBuffer[i + 1] = contentArray[i];
            }

            return callback(resultBuffer.buffer);
          }

          function encodeBlobAsArrayBuffer(packet, supportsBinary, callback) {
            if (!supportsBinary) {
              return exports.encodeBase64Packet(packet, callback);
            }

            var fr = new FileReader();
            fr.onload = function () {
              packet.data = fr.result;
              exports.encodePacket(packet, supportsBinary, true, callback);
            };
            return fr.readAsArrayBuffer(packet.data);
          }

          function encodeBlob(packet, supportsBinary, callback) {
            if (!supportsBinary) {
              return exports.encodeBase64Packet(packet, callback);
            }

            if (dontSendBlobs) {
              return encodeBlobAsArrayBuffer(packet, supportsBinary, callback);
            }

            var length = new Uint8Array(1);
            length[0] = packets[packet.type];
            var blob = new Blob([length.buffer, packet.data]);

            return callback(blob);
          }

          /**
           * Encodes a packet with binary data in a base64 string
           *
           * @param {Object} packet, has `type` and `data`
           * @return {String} base64 encoded message
           */

          exports.encodeBase64Packet = function (packet, callback) {
            var message = 'b' + exports.packets[packet.type];
            if (Blob && packet.data instanceof global.Blob) {
              var fr = new FileReader();
              fr.onload = function () {
                var b64 = fr.result.split(',')[1];
                callback(message + b64);
              };
              return fr.readAsDataURL(packet.data);
            }

            var b64data;
            try {
              b64data = String.fromCharCode.apply(null, new Uint8Array(packet.data));
            } catch (e) {
              // iPhone Safari doesn't let you apply with typed arrays
              var typed = new Uint8Array(packet.data);
              var basic = new Array(typed.length);
              for (var i = 0; i < typed.length; i++) {
                basic[i] = typed[i];
              }
              b64data = String.fromCharCode.apply(null, basic);
            }
            message += global.btoa(b64data);
            return callback(message);
          };

          /**
           * Decodes a packet. Changes format to Blob if requested.
           *
           * @return {Object} with `type` and `data` (if any)
           * @api private
           */

          exports.decodePacket = function (data, binaryType, utf8decode) {
            // String data
            if (typeof data == 'string' || data === undefined) {
              if (data.charAt(0) == 'b') {
                return exports.decodeBase64Packet(data.substr(1), binaryType);
              }

              if (utf8decode) {
                try {
                  data = utf8.decode(data);
                } catch (e) {
                  return err;
                }
              }
              var type = data.charAt(0);

              if (Number(type) != type || !packetslist[type]) {
                return err;
              }

              if (data.length > 1) {
                return { type: packetslist[type], data: data.substring(1) };
              } else {
                return { type: packetslist[type] };
              }
            }

            var asArray = new Uint8Array(data);
            var type = asArray[0];
            var rest = sliceBuffer(data, 1);
            if (Blob && binaryType === 'blob') {
              rest = new Blob([rest]);
            }
            return { type: packetslist[type], data: rest };
          };

          /**
           * Decodes a packet encoded in a base64 string
           *
           * @param {String} base64 encoded message
           * @return {Object} with `type` and `data` (if any)
           */

          exports.decodeBase64Packet = function (msg, binaryType) {
            var type = packetslist[msg.charAt(0)];
            if (!global.ArrayBuffer) {
              return { type: type, data: { base64: true, data: msg.substr(1) } };
            }

            var data = base64encoder.decode(msg.substr(1));

            if (binaryType === 'blob' && Blob) {
              data = new Blob([data]);
            }

            return { type: type, data: data };
          };

          /**
           * Encodes multiple messages (payload).
           *
           *     <length>:data
           *
           * Example:
           *
           *     11:hello world2:hi
           *
           * If any contents are binary, they will be encoded as base64 strings. Base64
           * encoded strings are marked with a b before the length specifier
           *
           * @param {Array} packets
           * @api private
           */

          exports.encodePayload = function (packets, supportsBinary, callback) {
            if (typeof supportsBinary == 'function') {
              callback = supportsBinary;
              supportsBinary = null;
            }

            var isBinary = hasBinary(packets);

            if (supportsBinary && isBinary) {
              if (Blob && !dontSendBlobs) {
                return exports.encodePayloadAsBlob(packets, callback);
              }

              return exports.encodePayloadAsArrayBuffer(packets, callback);
            }

            if (!packets.length) {
              return callback('0:');
            }

            function setLengthHeader(message) {
              return message.length + ':' + message;
            }

            function encodeOne(packet, doneCallback) {
              exports.encodePacket(packet, !isBinary ? false : supportsBinary, true, function (message) {
                doneCallback(null, setLengthHeader(message));
              });
            }

            map(packets, encodeOne, function (err, results) {
              return callback(results.join(''));
            });
          };

          /**
           * Async array map using after
           */

          function map(ary, each, done) {
            var result = new Array(ary.length);
            var next = after(ary.length, done);

            var eachWithIndex = function eachWithIndex(i, el, cb) {
              each(el, function (error, msg) {
                result[i] = msg;
                cb(error, result);
              });
            };

            for (var i = 0; i < ary.length; i++) {
              eachWithIndex(i, ary[i], next);
            }
          }

          /*
           * Decodes data when a payload is maybe expected. Possible binary contents are
           * decoded from their base64 representation
           *
           * @param {String} data, callback method
           * @api public
           */

          exports.decodePayload = function (data, binaryType, callback) {
            if (typeof data != 'string') {
              return exports.decodePayloadAsBinary(data, binaryType, callback);
            }

            if (typeof binaryType === 'function') {
              callback = binaryType;
              binaryType = null;
            }

            var packet;
            if (data == '') {
              // parser error - ignoring payload
              return callback(err, 0, 1);
            }

            var length = '',
                n,
                msg;

            for (var i = 0, l = data.length; i < l; i++) {
              var chr = data.charAt(i);

              if (':' != chr) {
                length += chr;
              } else {
                if ('' == length || length != (n = Number(length))) {
                  // parser error - ignoring payload
                  return callback(err, 0, 1);
                }

                msg = data.substr(i + 1, n);

                if (length != msg.length) {
                  // parser error - ignoring payload
                  return callback(err, 0, 1);
                }

                if (msg.length) {
                  packet = exports.decodePacket(msg, binaryType, true);

                  if (err.type == packet.type && err.data == packet.data) {
                    // parser error in individual packet - ignoring payload
                    return callback(err, 0, 1);
                  }

                  var ret = callback(packet, i + n, l);
                  if (false === ret) return;
                }

                // advance cursor
                i += n;
                length = '';
              }
            }

            if (length != '') {
              // parser error - ignoring payload
              return callback(err, 0, 1);
            }
          };

          /**
           * Encodes multiple messages (payload) as binary.
           *
           * <1 = binary, 0 = string><number from 0-9><number from 0-9>[...]<number
           * 255><data>
           *
           * Example:
           * 1 3 255 1 2 3, if the binary contents are interpreted as 8 bit integers
           *
           * @param {Array} packets
           * @return {ArrayBuffer} encoded payload
           * @api private
           */

          exports.encodePayloadAsArrayBuffer = function (packets, callback) {
            if (!packets.length) {
              return callback(new ArrayBuffer(0));
            }

            function encodeOne(packet, doneCallback) {
              exports.encodePacket(packet, true, true, function (data) {
                return doneCallback(null, data);
              });
            }

            map(packets, encodeOne, function (err, encodedPackets) {
              var totalLength = encodedPackets.reduce(function (acc, p) {
                var len;
                if (typeof p === 'string') {
                  len = p.length;
                } else {
                  len = p.byteLength;
                }
                return acc + len.toString().length + len + 2; // string/binary identifier + separator = 2
              }, 0);

              var resultArray = new Uint8Array(totalLength);

              var bufferIndex = 0;
              encodedPackets.forEach(function (p) {
                var isString = typeof p === 'string';
                var ab = p;
                if (isString) {
                  var view = new Uint8Array(p.length);
                  for (var i = 0; i < p.length; i++) {
                    view[i] = p.charCodeAt(i);
                  }
                  ab = view.buffer;
                }

                if (isString) {
                  // not true binary
                  resultArray[bufferIndex++] = 0;
                } else {
                  // true binary
                  resultArray[bufferIndex++] = 1;
                }

                var lenStr = ab.byteLength.toString();
                for (var i = 0; i < lenStr.length; i++) {
                  resultArray[bufferIndex++] = parseInt(lenStr[i]);
                }
                resultArray[bufferIndex++] = 255;

                var view = new Uint8Array(ab);
                for (var i = 0; i < view.length; i++) {
                  resultArray[bufferIndex++] = view[i];
                }
              });

              return callback(resultArray.buffer);
            });
          };

          /**
           * Encode as Blob
           */

          exports.encodePayloadAsBlob = function (packets, callback) {
            function encodeOne(packet, doneCallback) {
              exports.encodePacket(packet, true, true, function (encoded) {
                var binaryIdentifier = new Uint8Array(1);
                binaryIdentifier[0] = 1;
                if (typeof encoded === 'string') {
                  var view = new Uint8Array(encoded.length);
                  for (var i = 0; i < encoded.length; i++) {
                    view[i] = encoded.charCodeAt(i);
                  }
                  encoded = view.buffer;
                  binaryIdentifier[0] = 0;
                }

                var len = encoded instanceof ArrayBuffer ? encoded.byteLength : encoded.size;

                var lenStr = len.toString();
                var lengthAry = new Uint8Array(lenStr.length + 1);
                for (var i = 0; i < lenStr.length; i++) {
                  lengthAry[i] = parseInt(lenStr[i]);
                }
                lengthAry[lenStr.length] = 255;

                if (Blob) {
                  var blob = new Blob([binaryIdentifier.buffer, lengthAry.buffer, encoded]);
                  doneCallback(null, blob);
                }
              });
            }

            map(packets, encodeOne, function (err, results) {
              return callback(new Blob(results));
            });
          };

          /*
           * Decodes data when a payload is maybe expected. Strings are decoded by
           * interpreting each byte as a key code for entries marked to start with 0. See
           * description of encodePayloadAsBinary
           *
           * @param {ArrayBuffer} data, callback method
           * @api public
           */

          exports.decodePayloadAsBinary = function (data, binaryType, callback) {
            if (typeof binaryType === 'function') {
              callback = binaryType;
              binaryType = null;
            }

            var bufferTail = data;
            var buffers = [];

            var numberTooLong = false;
            while (bufferTail.byteLength > 0) {
              var tailArray = new Uint8Array(bufferTail);
              var isString = tailArray[0] === 0;
              var msgLength = '';

              for (var i = 1;; i++) {
                if (tailArray[i] == 255) break;

                if (msgLength.length > 310) {
                  numberTooLong = true;
                  break;
                }

                msgLength += tailArray[i];
              }

              if (numberTooLong) return callback(err, 0, 1);

              bufferTail = sliceBuffer(bufferTail, 2 + msgLength.length);
              msgLength = parseInt(msgLength);

              var msg = sliceBuffer(bufferTail, 0, msgLength);
              if (isString) {
                try {
                  msg = String.fromCharCode.apply(null, new Uint8Array(msg));
                } catch (e) {
                  // iPhone Safari doesn't let you apply to typed arrays
                  var typed = new Uint8Array(msg);
                  msg = '';
                  for (var i = 0; i < typed.length; i++) {
                    msg += String.fromCharCode(typed[i]);
                  }
                }
              }

              buffers.push(msg);
              bufferTail = sliceBuffer(bufferTail, msgLength);
            }

            var total = buffers.length;
            buffers.forEach(function (buffer, i) {
              callback(exports.decodePacket(buffer, binaryType, true), i, total);
            });
          };
        }).call(this, typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
      }, { "./keys": 20, "after": 11, "arraybuffer.slice": 12, "base64-arraybuffer": 13, "blob": 14, "has-binary": 21, "utf8": 29 }], 20: [function (_dereq_, module, exports) {

        /**
         * Gets the keys for an object.
         *
         * @return {Array} keys
         * @api private
         */

        module.exports = Object.keys || function keys(obj) {
          var arr = [];
          var has = Object.prototype.hasOwnProperty;

          for (var i in obj) {
            if (has.call(obj, i)) {
              arr.push(i);
            }
          }
          return arr;
        };
      }, {}], 21: [function (_dereq_, module, exports) {
        (function (global) {

          /*
           * Module requirements.
           */

          var isArray = _dereq_('isarray');

          /**
           * Module exports.
           */

          module.exports = hasBinary;

          /**
           * Checks for binary data.
           *
           * Right now only Buffer and ArrayBuffer are supported..
           *
           * @param {Object} anything
           * @api public
           */

          function hasBinary(data) {

            function _hasBinary(obj) {
              if (!obj) return false;

              if (global.Buffer && global.Buffer.isBuffer(obj) || global.ArrayBuffer && obj instanceof ArrayBuffer || global.Blob && obj instanceof Blob || global.File && obj instanceof File) {
                return true;
              }

              if (isArray(obj)) {
                for (var i = 0; i < obj.length; i++) {
                  if (_hasBinary(obj[i])) {
                    return true;
                  }
                }
              } else if (obj && 'object' == typeof obj) {
                if (obj.toJSON) {
                  obj = obj.toJSON();
                }

                for (var key in obj) {
                  if (Object.prototype.hasOwnProperty.call(obj, key) && _hasBinary(obj[key])) {
                    return true;
                  }
                }
              }

              return false;
            }

            return _hasBinary(data);
          }
        }).call(this, typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
      }, { "isarray": 24 }], 22: [function (_dereq_, module, exports) {

        /**
         * Module exports.
         *
         * Logic borrowed from Modernizr:
         *
         *   - https://github.com/Modernizr/Modernizr/blob/master/feature-detects/cors.js
         */

        try {
          module.exports = typeof XMLHttpRequest !== 'undefined' && 'withCredentials' in new XMLHttpRequest();
        } catch (err) {
          // if XMLHttp support is disabled in IE then it will throw
          // when trying to create
          module.exports = false;
        }
      }, {}], 23: [function (_dereq_, module, exports) {

        var indexOf = [].indexOf;

        module.exports = function (arr, obj) {
          if (indexOf) return arr.indexOf(obj);
          for (var i = 0; i < arr.length; ++i) {
            if (arr[i] === obj) return i;
          }
          return -1;
        };
      }, {}], 24: [function (_dereq_, module, exports) {
        module.exports = Array.isArray || function (arr) {
          return Object.prototype.toString.call(arr) == '[object Array]';
        };
      }, {}], 25: [function (_dereq_, module, exports) {
        /**
         * Helpers.
         */

        var s = 1000;
        var m = s * 60;
        var h = m * 60;
        var d = h * 24;
        var y = d * 365.25;

        /**
         * Parse or format the given `val`.
         *
         * Options:
         *
         *  - `long` verbose formatting [false]
         *
         * @param {String|Number} val
         * @param {Object} options
         * @return {String|Number}
         * @api public
         */

        module.exports = function (val, options) {
          options = options || {};
          if ('string' == typeof val) return parse(val);
          return options.long ? long(val) : short(val);
        };

        /**
         * Parse the given `str` and return milliseconds.
         *
         * @param {String} str
         * @return {Number}
         * @api private
         */

        function parse(str) {
          str = '' + str;
          if (str.length > 10000) return;
          var match = /^((?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|years?|yrs?|y)?$/i.exec(str);
          if (!match) return;
          var n = parseFloat(match[1]);
          var type = (match[2] || 'ms').toLowerCase();
          switch (type) {
            case 'years':
            case 'year':
            case 'yrs':
            case 'yr':
            case 'y':
              return n * y;
            case 'days':
            case 'day':
            case 'd':
              return n * d;
            case 'hours':
            case 'hour':
            case 'hrs':
            case 'hr':
            case 'h':
              return n * h;
            case 'minutes':
            case 'minute':
            case 'mins':
            case 'min':
            case 'm':
              return n * m;
            case 'seconds':
            case 'second':
            case 'secs':
            case 'sec':
            case 's':
              return n * s;
            case 'milliseconds':
            case 'millisecond':
            case 'msecs':
            case 'msec':
            case 'ms':
              return n;
          }
        }

        /**
         * Short format for `ms`.
         *
         * @param {Number} ms
         * @return {String}
         * @api private
         */

        function short(ms) {
          if (ms >= d) return Math.round(ms / d) + 'd';
          if (ms >= h) return Math.round(ms / h) + 'h';
          if (ms >= m) return Math.round(ms / m) + 'm';
          if (ms >= s) return Math.round(ms / s) + 's';
          return ms + 'ms';
        }

        /**
         * Long format for `ms`.
         *
         * @param {Number} ms
         * @return {String}
         * @api private
         */

        function long(ms) {
          return plural(ms, d, 'day') || plural(ms, h, 'hour') || plural(ms, m, 'minute') || plural(ms, s, 'second') || ms + ' ms';
        }

        /**
         * Pluralization helper.
         */

        function plural(ms, n, name) {
          if (ms < n) return;
          if (ms < n * 1.5) return Math.floor(ms / n) + ' ' + name;
          return Math.ceil(ms / n) + ' ' + name + 's';
        }
      }, {}], 26: [function (_dereq_, module, exports) {
        (function (global) {
          /**
           * JSON parse.
           *
           * @see Based on jQuery#parseJSON (MIT) and JSON2
           * @api private
           */

          var rvalidchars = /^[\],:{}\s]*$/;
          var rvalidescape = /\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g;
          var rvalidtokens = /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g;
          var rvalidbraces = /(?:^|:|,)(?:\s*\[)+/g;
          var rtrimLeft = /^\s+/;
          var rtrimRight = /\s+$/;

          module.exports = function parsejson(data) {
            if ('string' != typeof data || !data) {
              return null;
            }

            data = data.replace(rtrimLeft, '').replace(rtrimRight, '');

            // Attempt to parse using the native JSON parser first
            if (global.JSON && JSON.parse) {
              return JSON.parse(data);
            }

            if (rvalidchars.test(data.replace(rvalidescape, '@').replace(rvalidtokens, ']').replace(rvalidbraces, ''))) {
              return new Function('return ' + data)();
            }
          };
        }).call(this, typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
      }, {}], 27: [function (_dereq_, module, exports) {
        /**
         * Compiles a querystring
         * Returns string representation of the object
         *
         * @param {Object}
         * @api private
         */

        exports.encode = function (obj) {
          var str = '';

          for (var i in obj) {
            if (obj.hasOwnProperty(i)) {
              if (str.length) str += '&';
              str += encodeURIComponent(i) + '=' + encodeURIComponent(obj[i]);
            }
          }

          return str;
        };

        /**
         * Parses a simple querystring into an object
         *
         * @param {String} qs
         * @api private
         */

        exports.decode = function (qs) {
          var qry = {};
          var pairs = qs.split('&');
          for (var i = 0, l = pairs.length; i < l; i++) {
            var pair = pairs[i].split('=');
            qry[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1]);
          }
          return qry;
        };
      }, {}], 28: [function (_dereq_, module, exports) {
        /**
         * Parses an URI
         *
         * @author Steven Levithan <stevenlevithan.com> (MIT license)
         * @api private
         */

        var re = /^(?:(?![^:@]+:[^:@\/]*@)(http|https|ws|wss):\/\/)?((?:(([^:@]*)(?::([^:@]*))?)?@)?((?:[a-f0-9]{0,4}:){2,7}[a-f0-9]{0,4}|[^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/;

        var parts = ['source', 'protocol', 'authority', 'userInfo', 'user', 'password', 'host', 'port', 'relative', 'path', 'directory', 'file', 'query', 'anchor'];

        module.exports = function parseuri(str) {
          var src = str,
              b = str.indexOf('['),
              e = str.indexOf(']');

          if (b != -1 && e != -1) {
            str = str.substring(0, b) + str.substring(b, e).replace(/:/g, ';') + str.substring(e, str.length);
          }

          var m = re.exec(str || ''),
              uri = {},
              i = 14;

          while (i--) {
            uri[parts[i]] = m[i] || '';
          }

          if (b != -1 && e != -1) {
            uri.source = src;
            uri.host = uri.host.substring(1, uri.host.length - 1).replace(/;/g, ':');
            uri.authority = uri.authority.replace('[', '').replace(']', '').replace(/;/g, ':');
            uri.ipv6uri = true;
          }

          return uri;
        };
      }, {}], 29: [function (_dereq_, module, exports) {
        (function (global) {
          /*! https://mths.be/utf8js v2.0.0 by @mathias */
          ;(function (root) {

            // Detect free variables `exports`
            var freeExports = typeof exports == 'object' && exports;

            // Detect free variable `module`
            var freeModule = typeof module == 'object' && module && module.exports == freeExports && module;

            // Detect free variable `global`, from Node.js or Browserified code,
            // and use it as `root`
            var freeGlobal = typeof global == 'object' && global;
            if (freeGlobal.global === freeGlobal || freeGlobal.window === freeGlobal) {
              root = freeGlobal;
            }

            /*--------------------------------------------------------------------------*/

            var stringFromCharCode = String.fromCharCode;

            // Taken from https://mths.be/punycode
            function ucs2decode(string) {
              var output = [];
              var counter = 0;
              var length = string.length;
              var value;
              var extra;
              while (counter < length) {
                value = string.charCodeAt(counter++);
                if (value >= 0xD800 && value <= 0xDBFF && counter < length) {
                  // high surrogate, and there is a next character
                  extra = string.charCodeAt(counter++);
                  if ((extra & 0xFC00) == 0xDC00) {
                    // low surrogate
                    output.push(((value & 0x3FF) << 10) + (extra & 0x3FF) + 0x10000);
                  } else {
                    // unmatched surrogate; only append this code unit, in case the next
                    // code unit is the high surrogate of a surrogate pair
                    output.push(value);
                    counter--;
                  }
                } else {
                  output.push(value);
                }
              }
              return output;
            }

            // Taken from https://mths.be/punycode
            function ucs2encode(array) {
              var length = array.length;
              var index = -1;
              var value;
              var output = '';
              while (++index < length) {
                value = array[index];
                if (value > 0xFFFF) {
                  value -= 0x10000;
                  output += stringFromCharCode(value >>> 10 & 0x3FF | 0xD800);
                  value = 0xDC00 | value & 0x3FF;
                }
                output += stringFromCharCode(value);
              }
              return output;
            }

            function checkScalarValue(codePoint) {
              if (codePoint >= 0xD800 && codePoint <= 0xDFFF) {
                throw Error('Lone surrogate U+' + codePoint.toString(16).toUpperCase() + ' is not a scalar value');
              }
            }
            /*--------------------------------------------------------------------------*/

            function createByte(codePoint, shift) {
              return stringFromCharCode(codePoint >> shift & 0x3F | 0x80);
            }

            function encodeCodePoint(codePoint) {
              if ((codePoint & 0xFFFFFF80) == 0) {
                // 1-byte sequence
                return stringFromCharCode(codePoint);
              }
              var symbol = '';
              if ((codePoint & 0xFFFFF800) == 0) {
                // 2-byte sequence
                symbol = stringFromCharCode(codePoint >> 6 & 0x1F | 0xC0);
              } else if ((codePoint & 0xFFFF0000) == 0) {
                // 3-byte sequence
                checkScalarValue(codePoint);
                symbol = stringFromCharCode(codePoint >> 12 & 0x0F | 0xE0);
                symbol += createByte(codePoint, 6);
              } else if ((codePoint & 0xFFE00000) == 0) {
                // 4-byte sequence
                symbol = stringFromCharCode(codePoint >> 18 & 0x07 | 0xF0);
                symbol += createByte(codePoint, 12);
                symbol += createByte(codePoint, 6);
              }
              symbol += stringFromCharCode(codePoint & 0x3F | 0x80);
              return symbol;
            }

            function utf8encode(string) {
              var codePoints = ucs2decode(string);
              var length = codePoints.length;
              var index = -1;
              var codePoint;
              var byteString = '';
              while (++index < length) {
                codePoint = codePoints[index];
                byteString += encodeCodePoint(codePoint);
              }
              return byteString;
            }

            /*--------------------------------------------------------------------------*/

            function readContinuationByte() {
              if (byteIndex >= byteCount) {
                throw Error('Invalid byte index');
              }

              var continuationByte = byteArray[byteIndex] & 0xFF;
              byteIndex++;

              if ((continuationByte & 0xC0) == 0x80) {
                return continuationByte & 0x3F;
              }

              // If we end up here, it’s not a continuation byte
              throw Error('Invalid continuation byte');
            }

            function decodeSymbol() {
              var byte1;
              var byte2;
              var byte3;
              var byte4;
              var codePoint;

              if (byteIndex > byteCount) {
                throw Error('Invalid byte index');
              }

              if (byteIndex == byteCount) {
                return false;
              }

              // Read first byte
              byte1 = byteArray[byteIndex] & 0xFF;
              byteIndex++;

              // 1-byte sequence (no continuation bytes)
              if ((byte1 & 0x80) == 0) {
                return byte1;
              }

              // 2-byte sequence
              if ((byte1 & 0xE0) == 0xC0) {
                var byte2 = readContinuationByte();
                codePoint = (byte1 & 0x1F) << 6 | byte2;
                if (codePoint >= 0x80) {
                  return codePoint;
                } else {
                  throw Error('Invalid continuation byte');
                }
              }

              // 3-byte sequence (may include unpaired surrogates)
              if ((byte1 & 0xF0) == 0xE0) {
                byte2 = readContinuationByte();
                byte3 = readContinuationByte();
                codePoint = (byte1 & 0x0F) << 12 | byte2 << 6 | byte3;
                if (codePoint >= 0x0800) {
                  checkScalarValue(codePoint);
                  return codePoint;
                } else {
                  throw Error('Invalid continuation byte');
                }
              }

              // 4-byte sequence
              if ((byte1 & 0xF8) == 0xF0) {
                byte2 = readContinuationByte();
                byte3 = readContinuationByte();
                byte4 = readContinuationByte();
                codePoint = (byte1 & 0x0F) << 0x12 | byte2 << 0x0C | byte3 << 0x06 | byte4;
                if (codePoint >= 0x010000 && codePoint <= 0x10FFFF) {
                  return codePoint;
                }
              }

              throw Error('Invalid UTF-8 detected');
            }

            var byteArray;
            var byteCount;
            var byteIndex;
            function utf8decode(byteString) {
              byteArray = ucs2decode(byteString);
              byteCount = byteArray.length;
              byteIndex = 0;
              var codePoints = [];
              var tmp;
              while ((tmp = decodeSymbol()) !== false) {
                codePoints.push(tmp);
              }
              return ucs2encode(codePoints);
            }

            /*--------------------------------------------------------------------------*/

            var utf8 = {
              'version': '2.0.0',
              'encode': utf8encode,
              'decode': utf8decode
            };

            // Some AMD build optimizers, like r.js, check for specific condition patterns
            // like the following:
            if (typeof define == 'function' && typeof define.amd == 'object' && define.amd) {
              define(function () {
                return utf8;
              });
            } else if (freeExports && !freeExports.nodeType) {
              if (freeModule) {
                // in Node.js or RingoJS v0.8.0+
                freeModule.exports = utf8;
              } else {
                // in Narwhal or RingoJS v0.7.0-
                var object = {};
                var hasOwnProperty = object.hasOwnProperty;
                for (var key in utf8) {
                  hasOwnProperty.call(utf8, key) && (freeExports[key] = utf8[key]);
                }
              }
            } else {
              // in Rhino or a web browser
              root.utf8 = utf8;
            }
          })(this);
        }).call(this, typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
      }, {}], 30: [function (_dereq_, module, exports) {
        'use strict';

        var alphabet = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_'.split(''),
            length = 64,
            map = {},
            seed = 0,
            i = 0,
            prev;

        /**
         * Return a string representing the specified number.
         *
         * @param {Number} num The number to convert.
         * @returns {String} The string representation of the number.
         * @api public
         */
        function encode(num) {
          var encoded = '';

          do {
            encoded = alphabet[num % length] + encoded;
            num = Math.floor(num / length);
          } while (num > 0);

          return encoded;
        }

        /**
         * Return the integer value specified by the given string.
         *
         * @param {String} str The string to convert.
         * @returns {Number} The integer value represented by the string.
         * @api public
         */
        function decode(str) {
          var decoded = 0;

          for (i = 0; i < str.length; i++) {
            decoded = decoded * length + map[str.charAt(i)];
          }

          return decoded;
        }

        /**
         * Yeast: A tiny growing id generator.
         *
         * @returns {String} A unique id.
         * @api public
         */
        function yeast() {
          var now = encode(+new Date());

          if (now !== prev) return seed = 0, prev = now;
          return now + '.' + encode(seed++);
        }

        //
        // Map each character to its index.
        //
        for (; i < length; i++) map[alphabet[i]] = i;

        //
        // Expose the `yeast`, `encode` and `decode` functions.
        //
        yeast.encode = encode;
        yeast.decode = decode;
        module.exports = yeast;
      }, {}], 31: [function (_dereq_, module, exports) {

        /**
         * Module dependencies.
         */

        var url = _dereq_('./url');
        var parser = _dereq_('socket.io-parser');
        var Manager = _dereq_('./manager');
        var debug = _dereq_('debug')('socket.io-client');

        /**
         * Module exports.
         */

        module.exports = exports = lookup;

        /**
         * Managers cache.
         */

        var cache = exports.managers = {};

        /**
         * Looks up an existing `Manager` for multiplexing.
         * If the user summons:
         *
         *   `io('http://localhost/a');`
         *   `io('http://localhost/b');`
         *
         * We reuse the existing instance based on same scheme/port/host,
         * and we initialize sockets for each namespace.
         *
         * @api public
         */

        function lookup(uri, opts) {
          if (typeof uri == 'object') {
            opts = uri;
            uri = undefined;
          }

          opts = opts || {};

          var parsed = url(uri);
          var source = parsed.source;
          var id = parsed.id;
          var path = parsed.path;
          var sameNamespace = cache[id] && path in cache[id].nsps;
          var newConnection = opts.forceNew || opts['force new connection'] || false === opts.multiplex || sameNamespace;

          var io;

          if (newConnection) {
            debug('ignoring socket cache for %s', source);
            io = Manager(source, opts);
          } else {
            if (!cache[id]) {
              debug('new io instance for %s', source);
              cache[id] = Manager(source, opts);
            }
            io = cache[id];
          }

          return io.socket(parsed.path);
        }

        /**
         * Protocol version.
         *
         * @api public
         */

        exports.protocol = parser.protocol;

        /**
         * `connect`.
         *
         * @param {String} uri
         * @api public
         */

        exports.connect = lookup;

        /**
         * Expose constructors for standalone build.
         *
         * @api public
         */

        exports.Manager = _dereq_('./manager');
        exports.Socket = _dereq_('./socket');
      }, { "./manager": 32, "./socket": 34, "./url": 35, "debug": 39, "socket.io-parser": 47 }], 32: [function (_dereq_, module, exports) {

        /**
         * Module dependencies.
         */

        var eio = _dereq_('engine.io-client');
        var Socket = _dereq_('./socket');
        var Emitter = _dereq_('component-emitter');
        var parser = _dereq_('socket.io-parser');
        var on = _dereq_('./on');
        var bind = _dereq_('component-bind');
        var debug = _dereq_('debug')('socket.io-client:manager');
        var indexOf = _dereq_('indexof');
        var Backoff = _dereq_('backo2');

        /**
         * IE6+ hasOwnProperty
         */

        var has = Object.prototype.hasOwnProperty;

        /**
         * Module exports
         */

        module.exports = Manager;

        /**
         * `Manager` constructor.
         *
         * @param {String} engine instance or engine uri/opts
         * @param {Object} options
         * @api public
         */

        function Manager(uri, opts) {
          if (!(this instanceof Manager)) return new Manager(uri, opts);
          if (uri && 'object' == typeof uri) {
            opts = uri;
            uri = undefined;
          }
          opts = opts || {};

          opts.path = opts.path || '/socket.io';
          this.nsps = {};
          this.subs = [];
          this.opts = opts;
          this.reconnection(opts.reconnection !== false);
          this.reconnectionAttempts(opts.reconnectionAttempts || Infinity);
          this.reconnectionDelay(opts.reconnectionDelay || 1000);
          this.reconnectionDelayMax(opts.reconnectionDelayMax || 5000);
          this.randomizationFactor(opts.randomizationFactor || 0.5);
          this.backoff = new Backoff({
            min: this.reconnectionDelay(),
            max: this.reconnectionDelayMax(),
            jitter: this.randomizationFactor()
          });
          this.timeout(null == opts.timeout ? 20000 : opts.timeout);
          this.readyState = 'closed';
          this.uri = uri;
          this.connecting = [];
          this.lastPing = null;
          this.encoding = false;
          this.packetBuffer = [];
          this.encoder = new parser.Encoder();
          this.decoder = new parser.Decoder();
          this.autoConnect = opts.autoConnect !== false;
          if (this.autoConnect) this.open();
        }

        /**
         * Propagate given event to sockets and emit on `this`
         *
         * @api private
         */

        Manager.prototype.emitAll = function () {
          this.emit.apply(this, arguments);
          for (var nsp in this.nsps) {
            if (has.call(this.nsps, nsp)) {
              this.nsps[nsp].emit.apply(this.nsps[nsp], arguments);
            }
          }
        };

        /**
         * Update `socket.id` of all sockets
         *
         * @api private
         */

        Manager.prototype.updateSocketIds = function () {
          for (var nsp in this.nsps) {
            if (has.call(this.nsps, nsp)) {
              this.nsps[nsp].id = this.engine.id;
            }
          }
        };

        /**
         * Mix in `Emitter`.
         */

        Emitter(Manager.prototype);

        /**
         * Sets the `reconnection` config.
         *
         * @param {Boolean} true/false if it should automatically reconnect
         * @return {Manager} self or value
         * @api public
         */

        Manager.prototype.reconnection = function (v) {
          if (!arguments.length) return this._reconnection;
          this._reconnection = !!v;
          return this;
        };

        /**
         * Sets the reconnection attempts config.
         *
         * @param {Number} max reconnection attempts before giving up
         * @return {Manager} self or value
         * @api public
         */

        Manager.prototype.reconnectionAttempts = function (v) {
          if (!arguments.length) return this._reconnectionAttempts;
          this._reconnectionAttempts = v;
          return this;
        };

        /**
         * Sets the delay between reconnections.
         *
         * @param {Number} delay
         * @return {Manager} self or value
         * @api public
         */

        Manager.prototype.reconnectionDelay = function (v) {
          if (!arguments.length) return this._reconnectionDelay;
          this._reconnectionDelay = v;
          this.backoff && this.backoff.setMin(v);
          return this;
        };

        Manager.prototype.randomizationFactor = function (v) {
          if (!arguments.length) return this._randomizationFactor;
          this._randomizationFactor = v;
          this.backoff && this.backoff.setJitter(v);
          return this;
        };

        /**
         * Sets the maximum delay between reconnections.
         *
         * @param {Number} delay
         * @return {Manager} self or value
         * @api public
         */

        Manager.prototype.reconnectionDelayMax = function (v) {
          if (!arguments.length) return this._reconnectionDelayMax;
          this._reconnectionDelayMax = v;
          this.backoff && this.backoff.setMax(v);
          return this;
        };

        /**
         * Sets the connection timeout. `false` to disable
         *
         * @return {Manager} self or value
         * @api public
         */

        Manager.prototype.timeout = function (v) {
          if (!arguments.length) return this._timeout;
          this._timeout = v;
          return this;
        };

        /**
         * Starts trying to reconnect if reconnection is enabled and we have not
         * started reconnecting yet
         *
         * @api private
         */

        Manager.prototype.maybeReconnectOnOpen = function () {
          // Only try to reconnect if it's the first time we're connecting
          if (!this.reconnecting && this._reconnection && this.backoff.attempts === 0) {
            // keeps reconnection from firing twice for the same reconnection loop
            this.reconnect();
          }
        };

        /**
         * Sets the current transport `socket`.
         *
         * @param {Function} optional, callback
         * @return {Manager} self
         * @api public
         */

        Manager.prototype.open = Manager.prototype.connect = function (fn) {
          debug('readyState %s', this.readyState);
          if (~this.readyState.indexOf('open')) return this;

          debug('opening %s', this.uri);
          this.engine = eio(this.uri, this.opts);
          var socket = this.engine;
          var self = this;
          this.readyState = 'opening';
          this.skipReconnect = false;

          // emit `open`
          var openSub = on(socket, 'open', function () {
            self.onopen();
            fn && fn();
          });

          // emit `connect_error`
          var errorSub = on(socket, 'error', function (data) {
            debug('connect_error');
            self.cleanup();
            self.readyState = 'closed';
            self.emitAll('connect_error', data);
            if (fn) {
              var err = new Error('Connection error');
              err.data = data;
              fn(err);
            } else {
              // Only do this if there is no fn to handle the error
              self.maybeReconnectOnOpen();
            }
          });

          // emit `connect_timeout`
          if (false !== this._timeout) {
            var timeout = this._timeout;
            debug('connect attempt will timeout after %d', timeout);

            // set timer
            var timer = setTimeout(function () {
              debug('connect attempt timed out after %d', timeout);
              openSub.destroy();
              socket.close();
              socket.emit('error', 'timeout');
              self.emitAll('connect_timeout', timeout);
            }, timeout);

            this.subs.push({
              destroy: function destroy() {
                clearTimeout(timer);
              }
            });
          }

          this.subs.push(openSub);
          this.subs.push(errorSub);

          return this;
        };

        /**
         * Called upon transport open.
         *
         * @api private
         */

        Manager.prototype.onopen = function () {
          debug('open');

          // clear old subs
          this.cleanup();

          // mark as open
          this.readyState = 'open';
          this.emit('open');

          // add new subs
          var socket = this.engine;
          this.subs.push(on(socket, 'data', bind(this, 'ondata')));
          this.subs.push(on(socket, 'ping', bind(this, 'onping')));
          this.subs.push(on(socket, 'pong', bind(this, 'onpong')));
          this.subs.push(on(socket, 'error', bind(this, 'onerror')));
          this.subs.push(on(socket, 'close', bind(this, 'onclose')));
          this.subs.push(on(this.decoder, 'decoded', bind(this, 'ondecoded')));
        };

        /**
         * Called upon a ping.
         *
         * @api private
         */

        Manager.prototype.onping = function () {
          this.lastPing = new Date();
          this.emitAll('ping');
        };

        /**
         * Called upon a packet.
         *
         * @api private
         */

        Manager.prototype.onpong = function () {
          this.emitAll('pong', new Date() - this.lastPing);
        };

        /**
         * Called with data.
         *
         * @api private
         */

        Manager.prototype.ondata = function (data) {
          this.decoder.add(data);
        };

        /**
         * Called when parser fully decodes a packet.
         *
         * @api private
         */

        Manager.prototype.ondecoded = function (packet) {
          this.emit('packet', packet);
        };

        /**
         * Called upon socket error.
         *
         * @api private
         */

        Manager.prototype.onerror = function (err) {
          debug('error', err);
          this.emitAll('error', err);
        };

        /**
         * Creates a new socket for the given `nsp`.
         *
         * @return {Socket}
         * @api public
         */

        Manager.prototype.socket = function (nsp) {
          var socket = this.nsps[nsp];
          if (!socket) {
            socket = new Socket(this, nsp);
            this.nsps[nsp] = socket;
            var self = this;
            socket.on('connecting', onConnecting);
            socket.on('connect', function () {
              socket.id = self.engine.id;
            });

            if (this.autoConnect) {
              // manually call here since connecting evnet is fired before listening
              onConnecting();
            }
          }

          function onConnecting() {
            if (! ~indexOf(self.connecting, socket)) {
              self.connecting.push(socket);
            }
          }

          return socket;
        };

        /**
         * Called upon a socket close.
         *
         * @param {Socket} socket
         */

        Manager.prototype.destroy = function (socket) {
          var index = indexOf(this.connecting, socket);
          if (~index) this.connecting.splice(index, 1);
          if (this.connecting.length) return;

          this.close();
        };

        /**
         * Writes a packet.
         *
         * @param {Object} packet
         * @api private
         */

        Manager.prototype.packet = function (packet) {
          debug('writing packet %j', packet);
          var self = this;

          if (!self.encoding) {
            // encode, then write to engine with result
            self.encoding = true;
            this.encoder.encode(packet, function (encodedPackets) {
              for (var i = 0; i < encodedPackets.length; i++) {
                self.engine.write(encodedPackets[i], packet.options);
              }
              self.encoding = false;
              self.processPacketQueue();
            });
          } else {
            // add packet to the queue
            self.packetBuffer.push(packet);
          }
        };

        /**
         * If packet buffer is non-empty, begins encoding the
         * next packet in line.
         *
         * @api private
         */

        Manager.prototype.processPacketQueue = function () {
          if (this.packetBuffer.length > 0 && !this.encoding) {
            var pack = this.packetBuffer.shift();
            this.packet(pack);
          }
        };

        /**
         * Clean up transport subscriptions and packet buffer.
         *
         * @api private
         */

        Manager.prototype.cleanup = function () {
          debug('cleanup');

          var sub;
          while (sub = this.subs.shift()) sub.destroy();

          this.packetBuffer = [];
          this.encoding = false;
          this.lastPing = null;

          this.decoder.destroy();
        };

        /**
         * Close the current socket.
         *
         * @api private
         */

        Manager.prototype.close = Manager.prototype.disconnect = function () {
          debug('disconnect');
          this.skipReconnect = true;
          this.reconnecting = false;
          if ('opening' == this.readyState) {
            // `onclose` will not fire because
            // an open event never happened
            this.cleanup();
          }
          this.backoff.reset();
          this.readyState = 'closed';
          if (this.engine) this.engine.close();
        };

        /**
         * Called upon engine close.
         *
         * @api private
         */

        Manager.prototype.onclose = function (reason) {
          debug('onclose');

          this.cleanup();
          this.backoff.reset();
          this.readyState = 'closed';
          this.emit('close', reason);

          if (this._reconnection && !this.skipReconnect) {
            this.reconnect();
          }
        };

        /**
         * Attempt a reconnection.
         *
         * @api private
         */

        Manager.prototype.reconnect = function () {
          if (this.reconnecting || this.skipReconnect) return this;

          var self = this;

          if (this.backoff.attempts >= this._reconnectionAttempts) {
            debug('reconnect failed');
            this.backoff.reset();
            this.emitAll('reconnect_failed');
            this.reconnecting = false;
          } else {
            var delay = this.backoff.duration();
            debug('will wait %dms before reconnect attempt', delay);

            this.reconnecting = true;
            var timer = setTimeout(function () {
              if (self.skipReconnect) return;

              debug('attempting reconnect');
              self.emitAll('reconnect_attempt', self.backoff.attempts);
              self.emitAll('reconnecting', self.backoff.attempts);

              // check again for the case socket closed in above events
              if (self.skipReconnect) return;

              self.open(function (err) {
                if (err) {
                  debug('reconnect attempt error');
                  self.reconnecting = false;
                  self.reconnect();
                  self.emitAll('reconnect_error', err.data);
                } else {
                  debug('reconnect success');
                  self.onreconnect();
                }
              });
            }, delay);

            this.subs.push({
              destroy: function destroy() {
                clearTimeout(timer);
              }
            });
          }
        };

        /**
         * Called upon successful reconnect.
         *
         * @api private
         */

        Manager.prototype.onreconnect = function () {
          var attempt = this.backoff.attempts;
          this.reconnecting = false;
          this.backoff.reset();
          this.updateSocketIds();
          this.emitAll('reconnect', attempt);
        };
      }, { "./on": 33, "./socket": 34, "backo2": 36, "component-bind": 37, "component-emitter": 38, "debug": 39, "engine.io-client": 1, "indexof": 42, "socket.io-parser": 47 }], 33: [function (_dereq_, module, exports) {

        /**
         * Module exports.
         */

        module.exports = on;

        /**
         * Helper for subscriptions.
         *
         * @param {Object|EventEmitter} obj with `Emitter` mixin or `EventEmitter`
         * @param {String} event name
         * @param {Function} callback
         * @api public
         */

        function on(obj, ev, fn) {
          obj.on(ev, fn);
          return {
            destroy: function destroy() {
              obj.removeListener(ev, fn);
            }
          };
        }
      }, {}], 34: [function (_dereq_, module, exports) {

        /**
         * Module dependencies.
         */

        var parser = _dereq_('socket.io-parser');
        var Emitter = _dereq_('component-emitter');
        var toArray = _dereq_('to-array');
        var on = _dereq_('./on');
        var bind = _dereq_('component-bind');
        var debug = _dereq_('debug')('socket.io-client:socket');
        var hasBin = _dereq_('has-binary');

        /**
         * Module exports.
         */

        module.exports = exports = Socket;

        /**
         * Internal events (blacklisted).
         * These events can't be emitted by the user.
         *
         * @api private
         */

        var events = {
          connect: 1,
          connect_error: 1,
          connect_timeout: 1,
          connecting: 1,
          disconnect: 1,
          error: 1,
          reconnect: 1,
          reconnect_attempt: 1,
          reconnect_failed: 1,
          reconnect_error: 1,
          reconnecting: 1,
          ping: 1,
          pong: 1
        };

        /**
         * Shortcut to `Emitter#emit`.
         */

        var emit = Emitter.prototype.emit;

        /**
         * `Socket` constructor.
         *
         * @api public
         */

        function Socket(io, nsp) {
          this.io = io;
          this.nsp = nsp;
          this.json = this; // compat
          this.ids = 0;
          this.acks = {};
          this.receiveBuffer = [];
          this.sendBuffer = [];
          this.connected = false;
          this.disconnected = true;
          if (this.io.autoConnect) this.open();
        }

        /**
         * Mix in `Emitter`.
         */

        Emitter(Socket.prototype);

        /**
         * Subscribe to open, close and packet events
         *
         * @api private
         */

        Socket.prototype.subEvents = function () {
          if (this.subs) return;

          var io = this.io;
          this.subs = [on(io, 'open', bind(this, 'onopen')), on(io, 'packet', bind(this, 'onpacket')), on(io, 'close', bind(this, 'onclose'))];
        };

        /**
         * "Opens" the socket.
         *
         * @api public
         */

        Socket.prototype.open = Socket.prototype.connect = function () {
          if (this.connected) return this;

          this.subEvents();
          this.io.open(); // ensure open
          if ('open' == this.io.readyState) this.onopen();
          this.emit('connecting');
          return this;
        };

        /**
         * Sends a `message` event.
         *
         * @return {Socket} self
         * @api public
         */

        Socket.prototype.send = function () {
          var args = toArray(arguments);
          args.unshift('message');
          this.emit.apply(this, args);
          return this;
        };

        /**
         * Override `emit`.
         * If the event is in `events`, it's emitted normally.
         *
         * @param {String} event name
         * @return {Socket} self
         * @api public
         */

        Socket.prototype.emit = function (ev) {
          if (events.hasOwnProperty(ev)) {
            emit.apply(this, arguments);
            return this;
          }

          var args = toArray(arguments);
          var parserType = parser.EVENT; // default
          if (hasBin(args)) {
            parserType = parser.BINARY_EVENT;
          } // binary
          var packet = { type: parserType, data: args };

          packet.options = {};
          packet.options.compress = !this.flags || false !== this.flags.compress;

          // event ack callback
          if ('function' == typeof args[args.length - 1]) {
            debug('emitting packet with ack id %d', this.ids);
            this.acks[this.ids] = args.pop();
            packet.id = this.ids++;
          }

          if (this.connected) {
            this.packet(packet);
          } else {
            this.sendBuffer.push(packet);
          }

          delete this.flags;

          return this;
        };

        /**
         * Sends a packet.
         *
         * @param {Object} packet
         * @api private
         */

        Socket.prototype.packet = function (packet) {
          packet.nsp = this.nsp;
          this.io.packet(packet);
        };

        /**
         * Called upon engine `open`.
         *
         * @api private
         */

        Socket.prototype.onopen = function () {
          debug('transport is open - connecting');

          // write connect packet if necessary
          if ('/' != this.nsp) {
            this.packet({ type: parser.CONNECT });
          }
        };

        /**
         * Called upon engine `close`.
         *
         * @param {String} reason
         * @api private
         */

        Socket.prototype.onclose = function (reason) {
          debug('close (%s)', reason);
          this.connected = false;
          this.disconnected = true;
          delete this.id;
          this.emit('disconnect', reason);
        };

        /**
         * Called with socket packet.
         *
         * @param {Object} packet
         * @api private
         */

        Socket.prototype.onpacket = function (packet) {
          if (packet.nsp != this.nsp) return;

          switch (packet.type) {
            case parser.CONNECT:
              this.onconnect();
              break;

            case parser.EVENT:
              this.onevent(packet);
              break;

            case parser.BINARY_EVENT:
              this.onevent(packet);
              break;

            case parser.ACK:
              this.onack(packet);
              break;

            case parser.BINARY_ACK:
              this.onack(packet);
              break;

            case parser.DISCONNECT:
              this.ondisconnect();
              break;

            case parser.ERROR:
              this.emit('error', packet.data);
              break;
          }
        };

        /**
         * Called upon a server event.
         *
         * @param {Object} packet
         * @api private
         */

        Socket.prototype.onevent = function (packet) {
          var args = packet.data || [];
          debug('emitting event %j', args);

          if (null != packet.id) {
            debug('attaching ack callback to event');
            args.push(this.ack(packet.id));
          }

          if (this.connected) {
            emit.apply(this, args);
          } else {
            this.receiveBuffer.push(args);
          }
        };

        /**
         * Produces an ack callback to emit with an event.
         *
         * @api private
         */

        Socket.prototype.ack = function (id) {
          var self = this;
          var sent = false;
          return function () {
            // prevent double callbacks
            if (sent) return;
            sent = true;
            var args = toArray(arguments);
            debug('sending ack %j', args);

            var type = hasBin(args) ? parser.BINARY_ACK : parser.ACK;
            self.packet({
              type: type,
              id: id,
              data: args
            });
          };
        };

        /**
         * Called upon a server acknowlegement.
         *
         * @param {Object} packet
         * @api private
         */

        Socket.prototype.onack = function (packet) {
          var ack = this.acks[packet.id];
          if ('function' == typeof ack) {
            debug('calling ack %s with %j', packet.id, packet.data);
            ack.apply(this, packet.data);
            delete this.acks[packet.id];
          } else {
            debug('bad ack %s', packet.id);
          }
        };

        /**
         * Called upon server connect.
         *
         * @api private
         */

        Socket.prototype.onconnect = function () {
          this.connected = true;
          this.disconnected = false;
          this.emit('connect');
          this.emitBuffered();
        };

        /**
         * Emit buffered events (received and emitted).
         *
         * @api private
         */

        Socket.prototype.emitBuffered = function () {
          var i;
          for (i = 0; i < this.receiveBuffer.length; i++) {
            emit.apply(this, this.receiveBuffer[i]);
          }
          this.receiveBuffer = [];

          for (i = 0; i < this.sendBuffer.length; i++) {
            this.packet(this.sendBuffer[i]);
          }
          this.sendBuffer = [];
        };

        /**
         * Called upon server disconnect.
         *
         * @api private
         */

        Socket.prototype.ondisconnect = function () {
          debug('server disconnect (%s)', this.nsp);
          this.destroy();
          this.onclose('io server disconnect');
        };

        /**
         * Called upon forced client/server side disconnections,
         * this method ensures the manager stops tracking us and
         * that reconnections don't get triggered for this.
         *
         * @api private.
         */

        Socket.prototype.destroy = function () {
          if (this.subs) {
            // clean subscriptions to avoid reconnections
            for (var i = 0; i < this.subs.length; i++) {
              this.subs[i].destroy();
            }
            this.subs = null;
          }

          this.io.destroy(this);
        };

        /**
         * Disconnects the socket manually.
         *
         * @return {Socket} self
         * @api public
         */

        Socket.prototype.close = Socket.prototype.disconnect = function () {
          if (this.connected) {
            debug('performing disconnect (%s)', this.nsp);
            this.packet({ type: parser.DISCONNECT });
          }

          // remove socket from pool
          this.destroy();

          if (this.connected) {
            // fire events
            this.onclose('io client disconnect');
          }
          return this;
        };

        /**
         * Sets the compress flag.
         *
         * @param {Boolean} if `true`, compresses the sending data
         * @return {Socket} self
         * @api public
         */

        Socket.prototype.compress = function (compress) {
          this.flags = this.flags || {};
          this.flags.compress = compress;
          return this;
        };
      }, { "./on": 33, "component-bind": 37, "component-emitter": 38, "debug": 39, "has-binary": 41, "socket.io-parser": 47, "to-array": 51 }], 35: [function (_dereq_, module, exports) {
        (function (global) {

          /**
           * Module dependencies.
           */

          var parseuri = _dereq_('parseuri');
          var debug = _dereq_('debug')('socket.io-client:url');

          /**
           * Module exports.
           */

          module.exports = url;

          /**
           * URL parser.
           *
           * @param {String} url
           * @param {Object} An object meant to mimic window.location.
           *                 Defaults to window.location.
           * @api public
           */

          function url(uri, loc) {
            var obj = uri;

            // default to window.location
            var loc = loc || global.location;
            if (null == uri) uri = loc.protocol + '//' + loc.host;

            // relative path support
            if ('string' == typeof uri) {
              if ('/' == uri.charAt(0)) {
                if ('/' == uri.charAt(1)) {
                  uri = loc.protocol + uri;
                } else {
                  uri = loc.host + uri;
                }
              }

              if (!/^(https?|wss?):\/\//.test(uri)) {
                debug('protocol-less url %s', uri);
                if ('undefined' != typeof loc) {
                  uri = loc.protocol + '//' + uri;
                } else {
                  uri = 'https://' + uri;
                }
              }

              // parse
              debug('parse %s', uri);
              obj = parseuri(uri);
            }

            // make sure we treat `localhost:80` and `localhost` equally
            if (!obj.port) {
              if (/^(http|ws)$/.test(obj.protocol)) {
                obj.port = '80';
              } else if (/^(http|ws)s$/.test(obj.protocol)) {
                obj.port = '443';
              }
            }

            obj.path = obj.path || '/';

            var ipv6 = obj.host.indexOf(':') !== -1;
            var host = ipv6 ? '[' + obj.host + ']' : obj.host;

            // define unique id
            obj.id = obj.protocol + '://' + host + ':' + obj.port;
            // define href
            obj.href = obj.protocol + '://' + host + (loc && loc.port == obj.port ? '' : ':' + obj.port);

            return obj;
          }
        }).call(this, typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
      }, { "debug": 39, "parseuri": 45 }], 36: [function (_dereq_, module, exports) {

        /**
         * Expose `Backoff`.
         */

        module.exports = Backoff;

        /**
         * Initialize backoff timer with `opts`.
         *
         * - `min` initial timeout in milliseconds [100]
         * - `max` max timeout [10000]
         * - `jitter` [0]
         * - `factor` [2]
         *
         * @param {Object} opts
         * @api public
         */

        function Backoff(opts) {
          opts = opts || {};
          this.ms = opts.min || 100;
          this.max = opts.max || 10000;
          this.factor = opts.factor || 2;
          this.jitter = opts.jitter > 0 && opts.jitter <= 1 ? opts.jitter : 0;
          this.attempts = 0;
        }

        /**
         * Return the backoff duration.
         *
         * @return {Number}
         * @api public
         */

        Backoff.prototype.duration = function () {
          var ms = this.ms * Math.pow(this.factor, this.attempts++);
          if (this.jitter) {
            var rand = Math.random();
            var deviation = Math.floor(rand * this.jitter * ms);
            ms = (Math.floor(rand * 10) & 1) == 0 ? ms - deviation : ms + deviation;
          }
          return Math.min(ms, this.max) | 0;
        };

        /**
         * Reset the number of attempts.
         *
         * @api public
         */

        Backoff.prototype.reset = function () {
          this.attempts = 0;
        };

        /**
         * Set the minimum duration
         *
         * @api public
         */

        Backoff.prototype.setMin = function (min) {
          this.ms = min;
        };

        /**
         * Set the maximum duration
         *
         * @api public
         */

        Backoff.prototype.setMax = function (max) {
          this.max = max;
        };

        /**
         * Set the jitter
         *
         * @api public
         */

        Backoff.prototype.setJitter = function (jitter) {
          this.jitter = jitter;
        };
      }, {}], 37: [function (_dereq_, module, exports) {
        /**
         * Slice reference.
         */

        var slice = [].slice;

        /**
         * Bind `obj` to `fn`.
         *
         * @param {Object} obj
         * @param {Function|String} fn or string
         * @return {Function}
         * @api public
         */

        module.exports = function (obj, fn) {
          if ('string' == typeof fn) fn = obj[fn];
          if ('function' != typeof fn) throw new Error('bind() requires a function');
          var args = slice.call(arguments, 2);
          return function () {
            return fn.apply(obj, args.concat(slice.call(arguments)));
          };
        };
      }, {}], 38: [function (_dereq_, module, exports) {

        /**
         * Expose `Emitter`.
         */

        module.exports = Emitter;

        /**
         * Initialize a new `Emitter`.
         *
         * @api public
         */

        function Emitter(obj) {
          if (obj) return mixin(obj);
        };

        /**
         * Mixin the emitter properties.
         *
         * @param {Object} obj
         * @return {Object}
         * @api private
         */

        function mixin(obj) {
          for (var key in Emitter.prototype) {
            obj[key] = Emitter.prototype[key];
          }
          return obj;
        }

        /**
         * Listen on the given `event` with `fn`.
         *
         * @param {String} event
         * @param {Function} fn
         * @return {Emitter}
         * @api public
         */

        Emitter.prototype.on = Emitter.prototype.addEventListener = function (event, fn) {
          this._callbacks = this._callbacks || {};
          (this._callbacks['$' + event] = this._callbacks['$' + event] || []).push(fn);
          return this;
        };

        /**
         * Adds an `event` listener that will be invoked a single
         * time then automatically removed.
         *
         * @param {String} event
         * @param {Function} fn
         * @return {Emitter}
         * @api public
         */

        Emitter.prototype.once = function (event, fn) {
          function on() {
            this.off(event, on);
            fn.apply(this, arguments);
          }

          on.fn = fn;
          this.on(event, on);
          return this;
        };

        /**
         * Remove the given callback for `event` or all
         * registered callbacks.
         *
         * @param {String} event
         * @param {Function} fn
         * @return {Emitter}
         * @api public
         */

        Emitter.prototype.off = Emitter.prototype.removeListener = Emitter.prototype.removeAllListeners = Emitter.prototype.removeEventListener = function (event, fn) {
          this._callbacks = this._callbacks || {};

          // all
          if (0 == arguments.length) {
            this._callbacks = {};
            return this;
          }

          // specific event
          var callbacks = this._callbacks['$' + event];
          if (!callbacks) return this;

          // remove all handlers
          if (1 == arguments.length) {
            delete this._callbacks['$' + event];
            return this;
          }

          // remove specific handler
          var cb;
          for (var i = 0; i < callbacks.length; i++) {
            cb = callbacks[i];
            if (cb === fn || cb.fn === fn) {
              callbacks.splice(i, 1);
              break;
            }
          }
          return this;
        };

        /**
         * Emit `event` with the given args.
         *
         * @param {String} event
         * @param {Mixed} ...
         * @return {Emitter}
         */

        Emitter.prototype.emit = function (event) {
          this._callbacks = this._callbacks || {};
          var args = [].slice.call(arguments, 1),
              callbacks = this._callbacks['$' + event];

          if (callbacks) {
            callbacks = callbacks.slice(0);
            for (var i = 0, len = callbacks.length; i < len; ++i) {
              callbacks[i].apply(this, args);
            }
          }

          return this;
        };

        /**
         * Return array of callbacks for `event`.
         *
         * @param {String} event
         * @return {Array}
         * @api public
         */

        Emitter.prototype.listeners = function (event) {
          this._callbacks = this._callbacks || {};
          return this._callbacks['$' + event] || [];
        };

        /**
         * Check if this emitter has `event` handlers.
         *
         * @param {String} event
         * @return {Boolean}
         * @api public
         */

        Emitter.prototype.hasListeners = function (event) {
          return !!this.listeners(event).length;
        };
      }, {}], 39: [function (_dereq_, module, exports) {
        arguments[4][17][0].apply(exports, arguments);
      }, { "./debug": 40, "dup": 17 }], 40: [function (_dereq_, module, exports) {
        arguments[4][18][0].apply(exports, arguments);
      }, { "dup": 18, "ms": 44 }], 41: [function (_dereq_, module, exports) {
        (function (global) {

          /*
           * Module requirements.
           */

          var isArray = _dereq_('isarray');

          /**
           * Module exports.
           */

          module.exports = hasBinary;

          /**
           * Checks for binary data.
           *
           * Right now only Buffer and ArrayBuffer are supported..
           *
           * @param {Object} anything
           * @api public
           */

          function hasBinary(data) {

            function _hasBinary(obj) {
              if (!obj) return false;

              if (global.Buffer && global.Buffer.isBuffer && global.Buffer.isBuffer(obj) || global.ArrayBuffer && obj instanceof ArrayBuffer || global.Blob && obj instanceof Blob || global.File && obj instanceof File) {
                return true;
              }

              if (isArray(obj)) {
                for (var i = 0; i < obj.length; i++) {
                  if (_hasBinary(obj[i])) {
                    return true;
                  }
                }
              } else if (obj && 'object' == typeof obj) {
                // see: https://github.com/Automattic/has-binary/pull/4
                if (obj.toJSON && 'function' == typeof obj.toJSON) {
                  obj = obj.toJSON();
                }

                for (var key in obj) {
                  if (Object.prototype.hasOwnProperty.call(obj, key) && _hasBinary(obj[key])) {
                    return true;
                  }
                }
              }

              return false;
            }

            return _hasBinary(data);
          }
        }).call(this, typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
      }, { "isarray": 43 }], 42: [function (_dereq_, module, exports) {
        arguments[4][23][0].apply(exports, arguments);
      }, { "dup": 23 }], 43: [function (_dereq_, module, exports) {
        arguments[4][24][0].apply(exports, arguments);
      }, { "dup": 24 }], 44: [function (_dereq_, module, exports) {
        arguments[4][25][0].apply(exports, arguments);
      }, { "dup": 25 }], 45: [function (_dereq_, module, exports) {
        arguments[4][28][0].apply(exports, arguments);
      }, { "dup": 28 }], 46: [function (_dereq_, module, exports) {
        (function (global) {
          /*global Blob,File*/

          /**
           * Module requirements
           */

          var isArray = _dereq_('isarray');
          var isBuf = _dereq_('./is-buffer');

          /**
           * Replaces every Buffer | ArrayBuffer in packet with a numbered placeholder.
           * Anything with blobs or files should be fed through removeBlobs before coming
           * here.
           *
           * @param {Object} packet - socket.io event packet
           * @return {Object} with deconstructed packet and list of buffers
           * @api public
           */

          exports.deconstructPacket = function (packet) {
            var buffers = [];
            var packetData = packet.data;

            function _deconstructPacket(data) {
              if (!data) return data;

              if (isBuf(data)) {
                var placeholder = { _placeholder: true, num: buffers.length };
                buffers.push(data);
                return placeholder;
              } else if (isArray(data)) {
                var newData = new Array(data.length);
                for (var i = 0; i < data.length; i++) {
                  newData[i] = _deconstructPacket(data[i]);
                }
                return newData;
              } else if ('object' == typeof data && !(data instanceof Date)) {
                var newData = {};
                for (var key in data) {
                  newData[key] = _deconstructPacket(data[key]);
                }
                return newData;
              }
              return data;
            }

            var pack = packet;
            pack.data = _deconstructPacket(packetData);
            pack.attachments = buffers.length; // number of binary 'attachments'
            return { packet: pack, buffers: buffers };
          };

          /**
           * Reconstructs a binary packet from its placeholder packet and buffers
           *
           * @param {Object} packet - event packet with placeholders
           * @param {Array} buffers - binary buffers to put in placeholder positions
           * @return {Object} reconstructed packet
           * @api public
           */

          exports.reconstructPacket = function (packet, buffers) {
            var curPlaceHolder = 0;

            function _reconstructPacket(data) {
              if (data && data._placeholder) {
                var buf = buffers[data.num]; // appropriate buffer (should be natural order anyway)
                return buf;
              } else if (isArray(data)) {
                for (var i = 0; i < data.length; i++) {
                  data[i] = _reconstructPacket(data[i]);
                }
                return data;
              } else if (data && 'object' == typeof data) {
                for (var key in data) {
                  data[key] = _reconstructPacket(data[key]);
                }
                return data;
              }
              return data;
            }

            packet.data = _reconstructPacket(packet.data);
            packet.attachments = undefined; // no longer useful
            return packet;
          };

          /**
           * Asynchronously removes Blobs or Files from data via
           * FileReader's readAsArrayBuffer method. Used before encoding
           * data as msgpack. Calls callback with the blobless data.
           *
           * @param {Object} data
           * @param {Function} callback
           * @api private
           */

          exports.removeBlobs = function (data, callback) {
            function _removeBlobs(obj, curKey, containingObject) {
              if (!obj) return obj;

              // convert any blob
              if (global.Blob && obj instanceof Blob || global.File && obj instanceof File) {
                pendingBlobs++;

                // async filereader
                var fileReader = new FileReader();
                fileReader.onload = function () {
                  // this.result == arraybuffer
                  if (containingObject) {
                    containingObject[curKey] = this.result;
                  } else {
                    bloblessData = this.result;
                  }

                  // if nothing pending its callback time
                  if (! --pendingBlobs) {
                    callback(bloblessData);
                  }
                };

                fileReader.readAsArrayBuffer(obj); // blob -> arraybuffer
              } else if (isArray(obj)) {
                  // handle array
                  for (var i = 0; i < obj.length; i++) {
                    _removeBlobs(obj[i], i, obj);
                  }
                } else if (obj && 'object' == typeof obj && !isBuf(obj)) {
                  // and object
                  for (var key in obj) {
                    _removeBlobs(obj[key], key, obj);
                  }
                }
            }

            var pendingBlobs = 0;
            var bloblessData = data;
            _removeBlobs(bloblessData);
            if (!pendingBlobs) {
              callback(bloblessData);
            }
          };
        }).call(this, typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
      }, { "./is-buffer": 48, "isarray": 43 }], 47: [function (_dereq_, module, exports) {

        /**
         * Module dependencies.
         */

        var debug = _dereq_('debug')('socket.io-parser');
        var json = _dereq_('json3');
        var isArray = _dereq_('isarray');
        var Emitter = _dereq_('component-emitter');
        var binary = _dereq_('./binary');
        var isBuf = _dereq_('./is-buffer');

        /**
         * Protocol version.
         *
         * @api public
         */

        exports.protocol = 4;

        /**
         * Packet types.
         *
         * @api public
         */

        exports.types = ['CONNECT', 'DISCONNECT', 'EVENT', 'BINARY_EVENT', 'ACK', 'BINARY_ACK', 'ERROR'];

        /**
         * Packet type `connect`.
         *
         * @api public
         */

        exports.CONNECT = 0;

        /**
         * Packet type `disconnect`.
         *
         * @api public
         */

        exports.DISCONNECT = 1;

        /**
         * Packet type `event`.
         *
         * @api public
         */

        exports.EVENT = 2;

        /**
         * Packet type `ack`.
         *
         * @api public
         */

        exports.ACK = 3;

        /**
         * Packet type `error`.
         *
         * @api public
         */

        exports.ERROR = 4;

        /**
         * Packet type 'binary event'
         *
         * @api public
         */

        exports.BINARY_EVENT = 5;

        /**
         * Packet type `binary ack`. For acks with binary arguments.
         *
         * @api public
         */

        exports.BINARY_ACK = 6;

        /**
         * Encoder constructor.
         *
         * @api public
         */

        exports.Encoder = Encoder;

        /**
         * Decoder constructor.
         *
         * @api public
         */

        exports.Decoder = Decoder;

        /**
         * A socket.io Encoder instance
         *
         * @api public
         */

        function Encoder() {}

        /**
         * Encode a packet as a single string if non-binary, or as a
         * buffer sequence, depending on packet type.
         *
         * @param {Object} obj - packet object
         * @param {Function} callback - function to handle encodings (likely engine.write)
         * @return Calls callback with Array of encodings
         * @api public
         */

        Encoder.prototype.encode = function (obj, callback) {
          debug('encoding packet %j', obj);

          if (exports.BINARY_EVENT == obj.type || exports.BINARY_ACK == obj.type) {
            encodeAsBinary(obj, callback);
          } else {
            var encoding = encodeAsString(obj);
            callback([encoding]);
          }
        };

        /**
         * Encode packet as string.
         *
         * @param {Object} packet
         * @return {String} encoded
         * @api private
         */

        function encodeAsString(obj) {
          var str = '';
          var nsp = false;

          // first is type
          str += obj.type;

          // attachments if we have them
          if (exports.BINARY_EVENT == obj.type || exports.BINARY_ACK == obj.type) {
            str += obj.attachments;
            str += '-';
          }

          // if we have a namespace other than `/`
          // we append it followed by a comma `,`
          if (obj.nsp && '/' != obj.nsp) {
            nsp = true;
            str += obj.nsp;
          }

          // immediately followed by the id
          if (null != obj.id) {
            if (nsp) {
              str += ',';
              nsp = false;
            }
            str += obj.id;
          }

          // json data
          if (null != obj.data) {
            if (nsp) str += ',';
            str += json.stringify(obj.data);
          }

          debug('encoded %j as %s', obj, str);
          return str;
        }

        /**
         * Encode packet as 'buffer sequence' by removing blobs, and
         * deconstructing packet into object with placeholders and
         * a list of buffers.
         *
         * @param {Object} packet
         * @return {Buffer} encoded
         * @api private
         */

        function encodeAsBinary(obj, callback) {

          function writeEncoding(bloblessData) {
            var deconstruction = binary.deconstructPacket(bloblessData);
            var pack = encodeAsString(deconstruction.packet);
            var buffers = deconstruction.buffers;

            buffers.unshift(pack); // add packet info to beginning of data list
            callback(buffers); // write all the buffers
          }

          binary.removeBlobs(obj, writeEncoding);
        }

        /**
         * A socket.io Decoder instance
         *
         * @return {Object} decoder
         * @api public
         */

        function Decoder() {
          this.reconstructor = null;
        }

        /**
         * Mix in `Emitter` with Decoder.
         */

        Emitter(Decoder.prototype);

        /**
         * Decodes an ecoded packet string into packet JSON.
         *
         * @param {String} obj - encoded packet
         * @return {Object} packet
         * @api public
         */

        Decoder.prototype.add = function (obj) {
          var packet;
          if ('string' == typeof obj) {
            packet = decodeString(obj);
            if (exports.BINARY_EVENT == packet.type || exports.BINARY_ACK == packet.type) {
              // binary packet's json
              this.reconstructor = new BinaryReconstructor(packet);

              // no attachments, labeled binary but no binary data to follow
              if (this.reconstructor.reconPack.attachments === 0) {
                this.emit('decoded', packet);
              }
            } else {
              // non-binary full packet
              this.emit('decoded', packet);
            }
          } else if (isBuf(obj) || obj.base64) {
            // raw binary data
            if (!this.reconstructor) {
              throw new Error('got binary data when not reconstructing a packet');
            } else {
              packet = this.reconstructor.takeBinaryData(obj);
              if (packet) {
                // received final buffer
                this.reconstructor = null;
                this.emit('decoded', packet);
              }
            }
          } else {
            throw new Error('Unknown type: ' + obj);
          }
        };

        /**
         * Decode a packet String (JSON data)
         *
         * @param {String} str
         * @return {Object} packet
         * @api private
         */

        function decodeString(str) {
          var p = {};
          var i = 0;

          // look up type
          p.type = Number(str.charAt(0));
          if (null == exports.types[p.type]) return error();

          // look up attachments if type binary
          if (exports.BINARY_EVENT == p.type || exports.BINARY_ACK == p.type) {
            var buf = '';
            while (str.charAt(++i) != '-') {
              buf += str.charAt(i);
              if (i == str.length) break;
            }
            if (buf != Number(buf) || str.charAt(i) != '-') {
              throw new Error('Illegal attachments');
            }
            p.attachments = Number(buf);
          }

          // look up namespace (if any)
          if ('/' == str.charAt(i + 1)) {
            p.nsp = '';
            while (++i) {
              var c = str.charAt(i);
              if (',' == c) break;
              p.nsp += c;
              if (i == str.length) break;
            }
          } else {
            p.nsp = '/';
          }

          // look up id
          var next = str.charAt(i + 1);
          if ('' !== next && Number(next) == next) {
            p.id = '';
            while (++i) {
              var c = str.charAt(i);
              if (null == c || Number(c) != c) {
                --i;
                break;
              }
              p.id += str.charAt(i);
              if (i == str.length) break;
            }
            p.id = Number(p.id);
          }

          // look up json data
          if (str.charAt(++i)) {
            try {
              p.data = json.parse(str.substr(i));
            } catch (e) {
              return error();
            }
          }

          debug('decoded %s as %j', str, p);
          return p;
        }

        /**
         * Deallocates a parser's resources
         *
         * @api public
         */

        Decoder.prototype.destroy = function () {
          if (this.reconstructor) {
            this.reconstructor.finishedReconstruction();
          }
        };

        /**
         * A manager of a binary event's 'buffer sequence'. Should
         * be constructed whenever a packet of type BINARY_EVENT is
         * decoded.
         *
         * @param {Object} packet
         * @return {BinaryReconstructor} initialized reconstructor
         * @api private
         */

        function BinaryReconstructor(packet) {
          this.reconPack = packet;
          this.buffers = [];
        }

        /**
         * Method to be called when binary data received from connection
         * after a BINARY_EVENT packet.
         *
         * @param {Buffer | ArrayBuffer} binData - the raw binary data received
         * @return {null | Object} returns null if more binary data is expected or
         *   a reconstructed packet object if all buffers have been received.
         * @api private
         */

        BinaryReconstructor.prototype.takeBinaryData = function (binData) {
          this.buffers.push(binData);
          if (this.buffers.length == this.reconPack.attachments) {
            // done with buffer list
            var packet = binary.reconstructPacket(this.reconPack, this.buffers);
            this.finishedReconstruction();
            return packet;
          }
          return null;
        };

        /**
         * Cleans up binary packet reconstruction variables.
         *
         * @api private
         */

        BinaryReconstructor.prototype.finishedReconstruction = function () {
          this.reconPack = null;
          this.buffers = [];
        };

        function error(data) {
          return {
            type: exports.ERROR,
            data: 'parser error'
          };
        }
      }, { "./binary": 46, "./is-buffer": 48, "component-emitter": 49, "debug": 39, "isarray": 43, "json3": 50 }], 48: [function (_dereq_, module, exports) {
        (function (global) {

          module.exports = isBuf;

          /**
           * Returns true if obj is a buffer or an arraybuffer.
           *
           * @api private
           */

          function isBuf(obj) {
            return global.Buffer && global.Buffer.isBuffer(obj) || global.ArrayBuffer && obj instanceof ArrayBuffer;
          }
        }).call(this, typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
      }, {}], 49: [function (_dereq_, module, exports) {
        arguments[4][15][0].apply(exports, arguments);
      }, { "dup": 15 }], 50: [function (_dereq_, module, exports) {
        (function (global) {
          /*! JSON v3.3.2 | http://bestiejs.github.io/json3 | Copyright 2012-2014, Kit Cambridge | http://kit.mit-license.org */
          ;(function () {
            // Detect the `define` function exposed by asynchronous module loaders. The
            // strict `define` check is necessary for compatibility with `r.js`.
            var isLoader = typeof define === "function" && define.amd;

            // A set of types used to distinguish objects from primitives.
            var objectTypes = {
              "function": true,
              "object": true
            };

            // Detect the `exports` object exposed by CommonJS implementations.
            var freeExports = objectTypes[typeof exports] && exports && !exports.nodeType && exports;

            // Use the `global` object exposed by Node (including Browserify via
            // `insert-module-globals`), Narwhal, and Ringo as the default context,
            // and the `window` object in browsers. Rhino exports a `global` function
            // instead.
            var root = objectTypes[typeof window] && window || this,
                freeGlobal = freeExports && objectTypes[typeof module] && module && !module.nodeType && typeof global == "object" && global;

            if (freeGlobal && (freeGlobal["global"] === freeGlobal || freeGlobal["window"] === freeGlobal || freeGlobal["self"] === freeGlobal)) {
              root = freeGlobal;
            }

            // Public: Initializes JSON 3 using the given `context` object, attaching the
            // `stringify` and `parse` functions to the specified `exports` object.
            function runInContext(context, exports) {
              context || (context = root["Object"]());
              exports || (exports = root["Object"]());

              // Native constructor aliases.
              var Number = context["Number"] || root["Number"],
                  String = context["String"] || root["String"],
                  Object = context["Object"] || root["Object"],
                  Date = context["Date"] || root["Date"],
                  SyntaxError = context["SyntaxError"] || root["SyntaxError"],
                  TypeError = context["TypeError"] || root["TypeError"],
                  Math = context["Math"] || root["Math"],
                  nativeJSON = context["JSON"] || root["JSON"];

              // Delegate to the native `stringify` and `parse` implementations.
              if (typeof nativeJSON == "object" && nativeJSON) {
                exports.stringify = nativeJSON.stringify;
                exports.parse = nativeJSON.parse;
              }

              // Convenience aliases.
              var objectProto = Object.prototype,
                  getClass = objectProto.toString,
                  isProperty,
                  forEach,
                  undef;

              // Test the `Date#getUTC*` methods. Based on work by @Yaffle.
              var isExtended = new Date(-3509827334573292);
              try {
                // The `getUTCFullYear`, `Month`, and `Date` methods return nonsensical
                // results for certain dates in Opera >= 10.53.
                isExtended = isExtended.getUTCFullYear() == -109252 && isExtended.getUTCMonth() === 0 && isExtended.getUTCDate() === 1 &&
                // Safari < 2.0.2 stores the internal millisecond time value correctly,
                // but clips the values returned by the date methods to the range of
                // signed 32-bit integers ([-2 ** 31, 2 ** 31 - 1]).
                isExtended.getUTCHours() == 10 && isExtended.getUTCMinutes() == 37 && isExtended.getUTCSeconds() == 6 && isExtended.getUTCMilliseconds() == 708;
              } catch (exception) {}

              // Internal: Determines whether the native `JSON.stringify` and `parse`
              // implementations are spec-compliant. Based on work by Ken Snyder.
              function has(name) {
                if (has[name] !== undef) {
                  // Return cached feature test result.
                  return has[name];
                }
                var isSupported;
                if (name == "bug-string-char-index") {
                  // IE <= 7 doesn't support accessing string characters using square
                  // bracket notation. IE 8 only supports this for primitives.
                  isSupported = "a"[0] != "a";
                } else if (name == "json") {
                  // Indicates whether both `JSON.stringify` and `JSON.parse` are
                  // supported.
                  isSupported = has("json-stringify") && has("json-parse");
                } else {
                  var value,
                      serialized = "{\"a\":[1,true,false,null,\"\\u0000\\b\\n\\f\\r\\t\"]}";
                  // Test `JSON.stringify`.
                  if (name == "json-stringify") {
                    var stringify = exports.stringify,
                        stringifySupported = typeof stringify == "function" && isExtended;
                    if (stringifySupported) {
                      // A test function object with a custom `toJSON` method.
                      (value = function () {
                        return 1;
                      }).toJSON = value;
                      try {
                        stringifySupported =
                        // Firefox 3.1b1 and b2 serialize string, number, and boolean
                        // primitives as object literals.
                        stringify(0) === "0" &&
                        // FF 3.1b1, b2, and JSON 2 serialize wrapped primitives as object
                        // literals.
                        stringify(new Number()) === "0" && stringify(new String()) == '""' &&
                        // FF 3.1b1, 2 throw an error if the value is `null`, `undefined`, or
                        // does not define a canonical JSON representation (this applies to
                        // objects with `toJSON` properties as well, *unless* they are nested
                        // within an object or array).
                        stringify(getClass) === undef &&
                        // IE 8 serializes `undefined` as `"undefined"`. Safari <= 5.1.7 and
                        // FF 3.1b3 pass this test.
                        stringify(undef) === undef &&
                        // Safari <= 5.1.7 and FF 3.1b3 throw `Error`s and `TypeError`s,
                        // respectively, if the value is omitted entirely.
                        stringify() === undef &&
                        // FF 3.1b1, 2 throw an error if the given value is not a number,
                        // string, array, object, Boolean, or `null` literal. This applies to
                        // objects with custom `toJSON` methods as well, unless they are nested
                        // inside object or array literals. YUI 3.0.0b1 ignores custom `toJSON`
                        // methods entirely.
                        stringify(value) === "1" && stringify([value]) == "[1]" &&
                        // Prototype <= 1.6.1 serializes `[undefined]` as `"[]"` instead of
                        // `"[null]"`.
                        stringify([undef]) == "[null]" &&
                        // YUI 3.0.0b1 fails to serialize `null` literals.
                        stringify(null) == "null" &&
                        // FF 3.1b1, 2 halts serialization if an array contains a function:
                        // `[1, true, getClass, 1]` serializes as "[1,true,],". FF 3.1b3
                        // elides non-JSON values from objects and arrays, unless they
                        // define custom `toJSON` methods.
                        stringify([undef, getClass, null]) == "[null,null,null]" &&
                        // Simple serialization test. FF 3.1b1 uses Unicode escape sequences
                        // where character escape codes are expected (e.g., `\b` => `\u0008`).
                        stringify({ "a": [value, true, false, null, "\x00\b\n\f\r\t"] }) == serialized &&
                        // FF 3.1b1 and b2 ignore the `filter` and `width` arguments.
                        stringify(null, value) === "1" && stringify([1, 2], null, 1) == "[\n 1,\n 2\n]" &&
                        // JSON 2, Prototype <= 1.7, and older WebKit builds incorrectly
                        // serialize extended years.
                        stringify(new Date(-8.64e15)) == '"-271821-04-20T00:00:00.000Z"' &&
                        // The milliseconds are optional in ES 5, but required in 5.1.
                        stringify(new Date(8.64e15)) == '"+275760-09-13T00:00:00.000Z"' &&
                        // Firefox <= 11.0 incorrectly serializes years prior to 0 as negative
                        // four-digit years instead of six-digit years. Credits: @Yaffle.
                        stringify(new Date(-621987552e5)) == '"-000001-01-01T00:00:00.000Z"' &&
                        // Safari <= 5.1.5 and Opera >= 10.53 incorrectly serialize millisecond
                        // values less than 1000. Credits: @Yaffle.
                        stringify(new Date(-1)) == '"1969-12-31T23:59:59.999Z"';
                      } catch (exception) {
                        stringifySupported = false;
                      }
                    }
                    isSupported = stringifySupported;
                  }
                  // Test `JSON.parse`.
                  if (name == "json-parse") {
                    var parse = exports.parse;
                    if (typeof parse == "function") {
                      try {
                        // FF 3.1b1, b2 will throw an exception if a bare literal is provided.
                        // Conforming implementations should also coerce the initial argument to
                        // a string prior to parsing.
                        if (parse("0") === 0 && !parse(false)) {
                          // Simple parsing test.
                          value = parse(serialized);
                          var parseSupported = value["a"].length == 5 && value["a"][0] === 1;
                          if (parseSupported) {
                            try {
                              // Safari <= 5.1.2 and FF 3.1b1 allow unescaped tabs in strings.
                              parseSupported = !parse('"\t"');
                            } catch (exception) {}
                            if (parseSupported) {
                              try {
                                // FF 4.0 and 4.0.1 allow leading `+` signs and leading
                                // decimal points. FF 4.0, 4.0.1, and IE 9-10 also allow
                                // certain octal literals.
                                parseSupported = parse("01") !== 1;
                              } catch (exception) {}
                            }
                            if (parseSupported) {
                              try {
                                // FF 4.0, 4.0.1, and Rhino 1.7R3-R4 allow trailing decimal
                                // points. These environments, along with FF 3.1b1 and 2,
                                // also allow trailing commas in JSON objects and arrays.
                                parseSupported = parse("1.") !== 1;
                              } catch (exception) {}
                            }
                          }
                        }
                      } catch (exception) {
                        parseSupported = false;
                      }
                    }
                    isSupported = parseSupported;
                  }
                }
                return has[name] = !!isSupported;
              }

              if (!has("json")) {
                // Common `[[Class]]` name aliases.
                var functionClass = "[object Function]",
                    dateClass = "[object Date]",
                    numberClass = "[object Number]",
                    stringClass = "[object String]",
                    arrayClass = "[object Array]",
                    booleanClass = "[object Boolean]";

                // Detect incomplete support for accessing string characters by index.
                var charIndexBuggy = has("bug-string-char-index");

                // Define additional utility methods if the `Date` methods are buggy.
                if (!isExtended) {
                  var floor = Math.floor;
                  // A mapping between the months of the year and the number of days between
                  // January 1st and the first of the respective month.
                  var Months = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
                  // Internal: Calculates the number of days between the Unix epoch and the
                  // first day of the given month.
                  var getDay = function getDay(year, month) {
                    return Months[month] + 365 * (year - 1970) + floor((year - 1969 + (month = +(month > 1))) / 4) - floor((year - 1901 + month) / 100) + floor((year - 1601 + month) / 400);
                  };
                }

                // Internal: Determines if a property is a direct property of the given
                // object. Delegates to the native `Object#hasOwnProperty` method.
                if (!(isProperty = objectProto.hasOwnProperty)) {
                  isProperty = function (property) {
                    var members = {},
                        constructor;
                    if ((members.__proto__ = null, members.__proto__ = {
                      // The *proto* property cannot be set multiple times in recent
                      // versions of Firefox and SeaMonkey.
                      "toString": 1
                    }, members).toString != getClass) {
                      // Safari <= 2.0.3 doesn't implement `Object#hasOwnProperty`, but
                      // supports the mutable *proto* property.
                      isProperty = function (property) {
                        // Capture and break the object's prototype chain (see section 8.6.2
                        // of the ES 5.1 spec). The parenthesized expression prevents an
                        // unsafe transformation by the Closure Compiler.
                        var original = this.__proto__,
                            result = (property in (this.__proto__ = null, this));
                        // Restore the original prototype chain.
                        this.__proto__ = original;
                        return result;
                      };
                    } else {
                      // Capture a reference to the top-level `Object` constructor.
                      constructor = members.constructor;
                      // Use the `constructor` property to simulate `Object#hasOwnProperty` in
                      // other environments.
                      isProperty = function (property) {
                        var parent = (this.constructor || constructor).prototype;
                        return property in this && !(property in parent && this[property] === parent[property]);
                      };
                    }
                    members = null;
                    return isProperty.call(this, property);
                  };
                }

                // Internal: Normalizes the `for...in` iteration algorithm across
                // environments. Each enumerated key is yielded to a `callback` function.
                forEach = function (object, callback) {
                  var size = 0,
                      Properties,
                      members,
                      property;

                  // Tests for bugs in the current environment's `for...in` algorithm. The
                  // `valueOf` property inherits the non-enumerable flag from
                  // `Object.prototype` in older versions of IE, Netscape, and Mozilla.
                  (Properties = function () {
                    this.valueOf = 0;
                  }).prototype.valueOf = 0;

                  // Iterate over a new instance of the `Properties` class.
                  members = new Properties();
                  for (property in members) {
                    // Ignore all properties inherited from `Object.prototype`.
                    if (isProperty.call(members, property)) {
                      size++;
                    }
                  }
                  Properties = members = null;

                  // Normalize the iteration algorithm.
                  if (!size) {
                    // A list of non-enumerable properties inherited from `Object.prototype`.
                    members = ["valueOf", "toString", "toLocaleString", "propertyIsEnumerable", "isPrototypeOf", "hasOwnProperty", "constructor"];
                    // IE <= 8, Mozilla 1.0, and Netscape 6.2 ignore shadowed non-enumerable
                    // properties.
                    forEach = function (object, callback) {
                      var isFunction = getClass.call(object) == functionClass,
                          property,
                          length;
                      var hasProperty = !isFunction && typeof object.constructor != "function" && objectTypes[typeof object.hasOwnProperty] && object.hasOwnProperty || isProperty;
                      for (property in object) {
                        // Gecko <= 1.0 enumerates the `prototype` property of functions under
                        // certain conditions; IE does not.
                        if (!(isFunction && property == "prototype") && hasProperty.call(object, property)) {
                          callback(property);
                        }
                      }
                      // Manually invoke the callback for each non-enumerable property.
                      for (length = members.length; property = members[--length]; hasProperty.call(object, property) && callback(property));
                    };
                  } else if (size == 2) {
                    // Safari <= 2.0.4 enumerates shadowed properties twice.
                    forEach = function (object, callback) {
                      // Create a set of iterated properties.
                      var members = {},
                          isFunction = getClass.call(object) == functionClass,
                          property;
                      for (property in object) {
                        // Store each property name to prevent double enumeration. The
                        // `prototype` property of functions is not enumerated due to cross-
                        // environment inconsistencies.
                        if (!(isFunction && property == "prototype") && !isProperty.call(members, property) && (members[property] = 1) && isProperty.call(object, property)) {
                          callback(property);
                        }
                      }
                    };
                  } else {
                    // No bugs detected; use the standard `for...in` algorithm.
                    forEach = function (object, callback) {
                      var isFunction = getClass.call(object) == functionClass,
                          property,
                          isConstructor;
                      for (property in object) {
                        if (!(isFunction && property == "prototype") && isProperty.call(object, property) && !(isConstructor = property === "constructor")) {
                          callback(property);
                        }
                      }
                      // Manually invoke the callback for the `constructor` property due to
                      // cross-environment inconsistencies.
                      if (isConstructor || isProperty.call(object, property = "constructor")) {
                        callback(property);
                      }
                    };
                  }
                  return forEach(object, callback);
                };

                // Public: Serializes a JavaScript `value` as a JSON string. The optional
                // `filter` argument may specify either a function that alters how object and
                // array members are serialized, or an array of strings and numbers that
                // indicates which properties should be serialized. The optional `width`
                // argument may be either a string or number that specifies the indentation
                // level of the output.
                if (!has("json-stringify")) {
                  // Internal: A map of control characters and their escaped equivalents.
                  var Escapes = {
                    92: "\\\\",
                    34: '\\"',
                    8: "\\b",
                    12: "\\f",
                    10: "\\n",
                    13: "\\r",
                    9: "\\t"
                  };

                  // Internal: Converts `value` into a zero-padded string such that its
                  // length is at least equal to `width`. The `width` must be <= 6.
                  var leadingZeroes = "000000";
                  var toPaddedString = function toPaddedString(width, value) {
                    // The `|| 0` expression is necessary to work around a bug in
                    // Opera <= 7.54u2 where `0 == -0`, but `String(-0) !== "0"`.
                    return (leadingZeroes + (value || 0)).slice(-width);
                  };

                  // Internal: Double-quotes a string `value`, replacing all ASCII control
                  // characters (characters with code unit values between 0 and 31) with
                  // their escaped equivalents. This is an implementation of the
                  // `Quote(value)` operation defined in ES 5.1 section 15.12.3.
                  var unicodePrefix = "\\u00";
                  var quote = function quote(value) {
                    var result = '"',
                        index = 0,
                        length = value.length,
                        useCharIndex = !charIndexBuggy || length > 10;
                    var symbols = useCharIndex && (charIndexBuggy ? value.split("") : value);
                    for (; index < length; index++) {
                      var charCode = value.charCodeAt(index);
                      // If the character is a control character, append its Unicode or
                      // shorthand escape sequence; otherwise, append the character as-is.
                      switch (charCode) {
                        case 8:case 9:case 10:case 12:case 13:case 34:case 92:
                          result += Escapes[charCode];
                          break;
                        default:
                          if (charCode < 32) {
                            result += unicodePrefix + toPaddedString(2, charCode.toString(16));
                            break;
                          }
                          result += useCharIndex ? symbols[index] : value.charAt(index);
                      }
                    }
                    return result + '"';
                  };

                  // Internal: Recursively serializes an object. Implements the
                  // `Str(key, holder)`, `JO(value)`, and `JA(value)` operations.
                  var serialize = function serialize(property, object, callback, properties, whitespace, indentation, stack) {
                    var value, className, year, month, date, time, hours, minutes, seconds, milliseconds, results, element, index, length, prefix, result;
                    try {
                      // Necessary for host object support.
                      value = object[property];
                    } catch (exception) {}
                    if (typeof value == "object" && value) {
                      className = getClass.call(value);
                      if (className == dateClass && !isProperty.call(value, "toJSON")) {
                        if (value > -1 / 0 && value < 1 / 0) {
                          // Dates are serialized according to the `Date#toJSON` method
                          // specified in ES 5.1 section 15.9.5.44. See section 15.9.1.15
                          // for the ISO 8601 date time string format.
                          if (getDay) {
                            // Manually compute the year, month, date, hours, minutes,
                            // seconds, and milliseconds if the `getUTC*` methods are
                            // buggy. Adapted from @Yaffle's `date-shim` project.
                            date = floor(value / 864e5);
                            for (year = floor(date / 365.2425) + 1970 - 1; getDay(year + 1, 0) <= date; year++);
                            for (month = floor((date - getDay(year, 0)) / 30.42); getDay(year, month + 1) <= date; month++);
                            date = 1 + date - getDay(year, month);
                            // The `time` value specifies the time within the day (see ES
                            // 5.1 section 15.9.1.2). The formula `(A % B + B) % B` is used
                            // to compute `A modulo B`, as the `%` operator does not
                            // correspond to the `modulo` operation for negative numbers.
                            time = (value % 864e5 + 864e5) % 864e5;
                            // The hours, minutes, seconds, and milliseconds are obtained by
                            // decomposing the time within the day. See section 15.9.1.10.
                            hours = floor(time / 36e5) % 24;
                            minutes = floor(time / 6e4) % 60;
                            seconds = floor(time / 1e3) % 60;
                            milliseconds = time % 1e3;
                          } else {
                            year = value.getUTCFullYear();
                            month = value.getUTCMonth();
                            date = value.getUTCDate();
                            hours = value.getUTCHours();
                            minutes = value.getUTCMinutes();
                            seconds = value.getUTCSeconds();
                            milliseconds = value.getUTCMilliseconds();
                          }
                          // Serialize extended years correctly.
                          value = (year <= 0 || year >= 1e4 ? (year < 0 ? "-" : "+") + toPaddedString(6, year < 0 ? -year : year) : toPaddedString(4, year)) + "-" + toPaddedString(2, month + 1) + "-" + toPaddedString(2, date) +
                          // Months, dates, hours, minutes, and seconds should have two
                          // digits; milliseconds should have three.
                          "T" + toPaddedString(2, hours) + ":" + toPaddedString(2, minutes) + ":" + toPaddedString(2, seconds) +
                          // Milliseconds are optional in ES 5.0, but required in 5.1.
                          "." + toPaddedString(3, milliseconds) + "Z";
                        } else {
                          value = null;
                        }
                      } else if (typeof value.toJSON == "function" && (className != numberClass && className != stringClass && className != arrayClass || isProperty.call(value, "toJSON"))) {
                        // Prototype <= 1.6.1 adds non-standard `toJSON` methods to the
                        // `Number`, `String`, `Date`, and `Array` prototypes. JSON 3
                        // ignores all `toJSON` methods on these objects unless they are
                        // defined directly on an instance.
                        value = value.toJSON(property);
                      }
                    }
                    if (callback) {
                      // If a replacement function was provided, call it to obtain the value
                      // for serialization.
                      value = callback.call(object, property, value);
                    }
                    if (value === null) {
                      return "null";
                    }
                    className = getClass.call(value);
                    if (className == booleanClass) {
                      // Booleans are represented literally.
                      return "" + value;
                    } else if (className == numberClass) {
                      // JSON numbers must be finite. `Infinity` and `NaN` are serialized as
                      // `"null"`.
                      return value > -1 / 0 && value < 1 / 0 ? "" + value : "null";
                    } else if (className == stringClass) {
                      // Strings are double-quoted and escaped.
                      return quote("" + value);
                    }
                    // Recursively serialize objects and arrays.
                    if (typeof value == "object") {
                      // Check for cyclic structures. This is a linear search; performance
                      // is inversely proportional to the number of unique nested objects.
                      for (length = stack.length; length--;) {
                        if (stack[length] === value) {
                          // Cyclic structures cannot be serialized by `JSON.stringify`.
                          throw TypeError();
                        }
                      }
                      // Add the object to the stack of traversed objects.
                      stack.push(value);
                      results = [];
                      // Save the current indentation level and indent one additional level.
                      prefix = indentation;
                      indentation += whitespace;
                      if (className == arrayClass) {
                        // Recursively serialize array elements.
                        for (index = 0, length = value.length; index < length; index++) {
                          element = serialize(index, value, callback, properties, whitespace, indentation, stack);
                          results.push(element === undef ? "null" : element);
                        }
                        result = results.length ? whitespace ? "[\n" + indentation + results.join(",\n" + indentation) + "\n" + prefix + "]" : "[" + results.join(",") + "]" : "[]";
                      } else {
                        // Recursively serialize object members. Members are selected from
                        // either a user-specified list of property names, or the object
                        // itself.
                        forEach(properties || value, function (property) {
                          var element = serialize(property, value, callback, properties, whitespace, indentation, stack);
                          if (element !== undef) {
                            // According to ES 5.1 section 15.12.3: "If `gap` {whitespace}
                            // is not the empty string, let `member` {quote(property) + ":"}
                            // be the concatenation of `member` and the `space` character."
                            // The "`space` character" refers to the literal space
                            // character, not the `space` {width} argument provided to
                            // `JSON.stringify`.
                            results.push(quote(property) + ":" + (whitespace ? " " : "") + element);
                          }
                        });
                        result = results.length ? whitespace ? "{\n" + indentation + results.join(",\n" + indentation) + "\n" + prefix + "}" : "{" + results.join(",") + "}" : "{}";
                      }
                      // Remove the object from the traversed object stack.
                      stack.pop();
                      return result;
                    }
                  };

                  // Public: `JSON.stringify`. See ES 5.1 section 15.12.3.
                  exports.stringify = function (source, filter, width) {
                    var whitespace, callback, properties, className;
                    if (objectTypes[typeof filter] && filter) {
                      if ((className = getClass.call(filter)) == functionClass) {
                        callback = filter;
                      } else if (className == arrayClass) {
                        // Convert the property names array into a makeshift set.
                        properties = {};
                        for (var index = 0, length = filter.length, value; index < length; value = filter[index++], (className = getClass.call(value), className == stringClass || className == numberClass) && (properties[value] = 1));
                      }
                    }
                    if (width) {
                      if ((className = getClass.call(width)) == numberClass) {
                        // Convert the `width` to an integer and create a string containing
                        // `width` number of space characters.
                        if ((width -= width % 1) > 0) {
                          for (whitespace = "", width > 10 && (width = 10); whitespace.length < width; whitespace += " ");
                        }
                      } else if (className == stringClass) {
                        whitespace = width.length <= 10 ? width : width.slice(0, 10);
                      }
                    }
                    // Opera <= 7.54u2 discards the values associated with empty string keys
                    // (`""`) only if they are used directly within an object member list
                    // (e.g., `!("" in { "": 1})`).
                    return serialize("", (value = {}, value[""] = source, value), callback, properties, whitespace, "", []);
                  };
                }

                // Public: Parses a JSON source string.
                if (!has("json-parse")) {
                  var fromCharCode = String.fromCharCode;

                  // Internal: A map of escaped control characters and their unescaped
                  // equivalents.
                  var Unescapes = {
                    92: "\\",
                    34: '"',
                    47: "/",
                    98: "\b",
                    116: "\t",
                    110: "\n",
                    102: "\f",
                    114: "\r"
                  };

                  // Internal: Stores the parser state.
                  var Index, Source;

                  // Internal: Resets the parser state and throws a `SyntaxError`.
                  var abort = function abort() {
                    Index = Source = null;
                    throw SyntaxError();
                  };

                  // Internal: Returns the next token, or `"$"` if the parser has reached
                  // the end of the source string. A token may be a string, number, `null`
                  // literal, or Boolean literal.
                  var lex = function lex() {
                    var source = Source,
                        length = source.length,
                        value,
                        begin,
                        position,
                        isSigned,
                        charCode;
                    while (Index < length) {
                      charCode = source.charCodeAt(Index);
                      switch (charCode) {
                        case 9:case 10:case 13:case 32:
                          // Skip whitespace tokens, including tabs, carriage returns, line
                          // feeds, and space characters.
                          Index++;
                          break;
                        case 123:case 125:case 91:case 93:case 58:case 44:
                          // Parse a punctuator token (`{`, `}`, `[`, `]`, `:`, or `,`) at
                          // the current position.
                          value = charIndexBuggy ? source.charAt(Index) : source[Index];
                          Index++;
                          return value;
                        case 34:
                          // `"` delimits a JSON string; advance to the next character and
                          // begin parsing the string. String tokens are prefixed with the
                          // sentinel `@` character to distinguish them from punctuators and
                          // end-of-string tokens.
                          for (value = "@", Index++; Index < length;) {
                            charCode = source.charCodeAt(Index);
                            if (charCode < 32) {
                              // Unescaped ASCII control characters (those with a code unit
                              // less than the space character) are not permitted.
                              abort();
                            } else if (charCode == 92) {
                              // A reverse solidus (`\`) marks the beginning of an escaped
                              // control character (including `"`, `\`, and `/`) or Unicode
                              // escape sequence.
                              charCode = source.charCodeAt(++Index);
                              switch (charCode) {
                                case 92:case 34:case 47:case 98:case 116:case 110:case 102:case 114:
                                  // Revive escaped control characters.
                                  value += Unescapes[charCode];
                                  Index++;
                                  break;
                                case 117:
                                  // `\u` marks the beginning of a Unicode escape sequence.
                                  // Advance to the first character and validate the
                                  // four-digit code point.
                                  begin = ++Index;
                                  for (position = Index + 4; Index < position; Index++) {
                                    charCode = source.charCodeAt(Index);
                                    // A valid sequence comprises four hexdigits (case-
                                    // insensitive) that form a single hexadecimal value.
                                    if (!(charCode >= 48 && charCode <= 57 || charCode >= 97 && charCode <= 102 || charCode >= 65 && charCode <= 70)) {
                                      // Invalid Unicode escape sequence.
                                      abort();
                                    }
                                  }
                                  // Revive the escaped character.
                                  value += fromCharCode("0x" + source.slice(begin, Index));
                                  break;
                                default:
                                  // Invalid escape sequence.
                                  abort();
                              }
                            } else {
                              if (charCode == 34) {
                                // An unescaped double-quote character marks the end of the
                                // string.
                                break;
                              }
                              charCode = source.charCodeAt(Index);
                              begin = Index;
                              // Optimize for the common case where a string is valid.
                              while (charCode >= 32 && charCode != 92 && charCode != 34) {
                                charCode = source.charCodeAt(++Index);
                              }
                              // Append the string as-is.
                              value += source.slice(begin, Index);
                            }
                          }
                          if (source.charCodeAt(Index) == 34) {
                            // Advance to the next character and return the revived string.
                            Index++;
                            return value;
                          }
                          // Unterminated string.
                          abort();
                        default:
                          // Parse numbers and literals.
                          begin = Index;
                          // Advance past the negative sign, if one is specified.
                          if (charCode == 45) {
                            isSigned = true;
                            charCode = source.charCodeAt(++Index);
                          }
                          // Parse an integer or floating-point value.
                          if (charCode >= 48 && charCode <= 57) {
                            // Leading zeroes are interpreted as octal literals.
                            if (charCode == 48 && (charCode = source.charCodeAt(Index + 1), charCode >= 48 && charCode <= 57)) {
                              // Illegal octal literal.
                              abort();
                            }
                            isSigned = false;
                            // Parse the integer component.
                            for (; Index < length && (charCode = source.charCodeAt(Index), charCode >= 48 && charCode <= 57); Index++);
                            // Floats cannot contain a leading decimal point; however, this
                            // case is already accounted for by the parser.
                            if (source.charCodeAt(Index) == 46) {
                              position = ++Index;
                              // Parse the decimal component.
                              for (; position < length && (charCode = source.charCodeAt(position), charCode >= 48 && charCode <= 57); position++);
                              if (position == Index) {
                                // Illegal trailing decimal.
                                abort();
                              }
                              Index = position;
                            }
                            // Parse exponents. The `e` denoting the exponent is
                            // case-insensitive.
                            charCode = source.charCodeAt(Index);
                            if (charCode == 101 || charCode == 69) {
                              charCode = source.charCodeAt(++Index);
                              // Skip past the sign following the exponent, if one is
                              // specified.
                              if (charCode == 43 || charCode == 45) {
                                Index++;
                              }
                              // Parse the exponential component.
                              for (position = Index; position < length && (charCode = source.charCodeAt(position), charCode >= 48 && charCode <= 57); position++);
                              if (position == Index) {
                                // Illegal empty exponent.
                                abort();
                              }
                              Index = position;
                            }
                            // Coerce the parsed value to a JavaScript number.
                            return +source.slice(begin, Index);
                          }
                          // A negative sign may only precede numbers.
                          if (isSigned) {
                            abort();
                          }
                          // `true`, `false`, and `null` literals.
                          if (source.slice(Index, Index + 4) == "true") {
                            Index += 4;
                            return true;
                          } else if (source.slice(Index, Index + 5) == "false") {
                            Index += 5;
                            return false;
                          } else if (source.slice(Index, Index + 4) == "null") {
                            Index += 4;
                            return null;
                          }
                          // Unrecognized token.
                          abort();
                      }
                    }
                    // Return the sentinel `$` character if the parser has reached the end
                    // of the source string.
                    return "$";
                  };

                  // Internal: Parses a JSON `value` token.
                  var get = function get(value) {
                    var results, hasMembers;
                    if (value == "$") {
                      // Unexpected end of input.
                      abort();
                    }
                    if (typeof value == "string") {
                      if ((charIndexBuggy ? value.charAt(0) : value[0]) == "@") {
                        // Remove the sentinel `@` character.
                        return value.slice(1);
                      }
                      // Parse object and array literals.
                      if (value == "[") {
                        // Parses a JSON array, returning a new JavaScript array.
                        results = [];
                        for (;; hasMembers || (hasMembers = true)) {
                          value = lex();
                          // A closing square bracket marks the end of the array literal.
                          if (value == "]") {
                            break;
                          }
                          // If the array literal contains elements, the current token
                          // should be a comma separating the previous element from the
                          // next.
                          if (hasMembers) {
                            if (value == ",") {
                              value = lex();
                              if (value == "]") {
                                // Unexpected trailing `,` in array literal.
                                abort();
                              }
                            } else {
                              // A `,` must separate each array element.
                              abort();
                            }
                          }
                          // Elisions and leading commas are not permitted.
                          if (value == ",") {
                            abort();
                          }
                          results.push(get(value));
                        }
                        return results;
                      } else if (value == "{") {
                        // Parses a JSON object, returning a new JavaScript object.
                        results = {};
                        for (;; hasMembers || (hasMembers = true)) {
                          value = lex();
                          // A closing curly brace marks the end of the object literal.
                          if (value == "}") {
                            break;
                          }
                          // If the object literal contains members, the current token
                          // should be a comma separator.
                          if (hasMembers) {
                            if (value == ",") {
                              value = lex();
                              if (value == "}") {
                                // Unexpected trailing `,` in object literal.
                                abort();
                              }
                            } else {
                              // A `,` must separate each object member.
                              abort();
                            }
                          }
                          // Leading commas are not permitted, object property names must be
                          // double-quoted strings, and a `:` must separate each property
                          // name and value.
                          if (value == "," || typeof value != "string" || (charIndexBuggy ? value.charAt(0) : value[0]) != "@" || lex() != ":") {
                            abort();
                          }
                          results[value.slice(1)] = get(lex());
                        }
                        return results;
                      }
                      // Unexpected token encountered.
                      abort();
                    }
                    return value;
                  };

                  // Internal: Updates a traversed object member.
                  var update = function update(source, property, callback) {
                    var element = walk(source, property, callback);
                    if (element === undef) {
                      delete source[property];
                    } else {
                      source[property] = element;
                    }
                  };

                  // Internal: Recursively traverses a parsed JSON object, invoking the
                  // `callback` function for each value. This is an implementation of the
                  // `Walk(holder, name)` operation defined in ES 5.1 section 15.12.2.
                  var walk = function walk(source, property, callback) {
                    var value = source[property],
                        length;
                    if (typeof value == "object" && value) {
                      // `forEach` can't be used to traverse an array in Opera <= 8.54
                      // because its `Object#hasOwnProperty` implementation returns `false`
                      // for array indices (e.g., `![1, 2, 3].hasOwnProperty("0")`).
                      if (getClass.call(value) == arrayClass) {
                        for (length = value.length; length--;) {
                          update(value, length, callback);
                        }
                      } else {
                        forEach(value, function (property) {
                          update(value, property, callback);
                        });
                      }
                    }
                    return callback.call(source, property, value);
                  };

                  // Public: `JSON.parse`. See ES 5.1 section 15.12.2.
                  exports.parse = function (source, callback) {
                    var result, value;
                    Index = 0;
                    Source = "" + source;
                    result = get(lex());
                    // If a JSON string contains multiple tokens, it is invalid.
                    if (lex() != "$") {
                      abort();
                    }
                    // Reset the parser state.
                    Index = Source = null;
                    return callback && getClass.call(callback) == functionClass ? walk((value = {}, value[""] = result, value), "", callback) : result;
                  };
                }
              }

              exports["runInContext"] = runInContext;
              return exports;
            }

            if (freeExports && !isLoader) {
              // Export for CommonJS environments.
              runInContext(root, freeExports);
            } else {
              // Export for web browsers and JavaScript engines.
              var nativeJSON = root.JSON,
                  previousJSON = root["JSON3"],
                  isRestored = false;

              var JSON3 = runInContext(root, root["JSON3"] = {
                // Public: Restores the original value of the global `JSON` object and
                // returns a reference to the `JSON3` object.
                "noConflict": function noConflict() {
                  if (!isRestored) {
                    isRestored = true;
                    root.JSON = nativeJSON;
                    root["JSON3"] = previousJSON;
                    nativeJSON = previousJSON = null;
                  }
                  return JSON3;
                }
              });

              root.JSON = {
                "parse": JSON3.parse,
                "stringify": JSON3.stringify
              };
            }

            // Export for asynchronous module loaders.
            if (isLoader) {
              define(function () {
                return JSON3;
              });
            }
          }).call(this);
        }).call(this, typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
      }, {}], 51: [function (_dereq_, module, exports) {
        module.exports = toArray;

        function toArray(list, index) {
          var array = [];

          index = index || 0;

          for (var i = index || 0; i < list.length; i++) {
            array[i - index] = list[i];
          }

          return array;
        }
      }, {}] }, {}, [31])(31);
  });
}

cc._RFpop();
}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{}],"tankScript":[function(require,module,exports){
"use strict";
cc._RFpush(module, '64207bwT5lKDa3HBoPU6Hz0', 'tankScript');
// Script/Gamescript/tankScript.js

cc.Class({
    "extends": cc.Component,

    properties: {
        lbname: {
            type: cc.Label,
            "default": null
        },
        bodytank: {
            type: cc.Node,
            "default": null
        },
        guntank: {
            type: cc.Node,
            "default": null
        },

        lbscore: {
            type: cc.Label,
            "default": null
        }
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.lbname.string = "";
        this.dirMv = 0;
        this.speedMove = 0;
        this.nextFrameMove = 0;

        this.ammo = 0;
        this.hp = 0;
        this.level = 0;

        this.count_updateRun = 0;

        this.needUpdateName = true;

        var flagNode = this.node.children[1];
        flagNode.active = false;
        //var sp_body=this.node.children[0];
        //var sprite_body=sp_body.getComponent("cc.Sprite");
        //sprite_body.spriteFrame=this.spAllCharacter.getSpriteFrame("TankColor-t5_b");
    },
    //[{"x":"-61.50","y":"-52.00","id":"48","r":"0.00","level":"1","score":"0","hp":"80","ammo":"140","sp":"50","gR":"180"}],"e":[]}

    updateFrame: function updateFrame(obj_info) {
        var x_p = Number(obj_info.x);
        var y_p = Number(obj_info.y);
        this.node.isActiveSC = true;
        this.node.setPosition(cc.p(x_p, y_p));

        this.bodytank.rotation = Number(obj_info.r);

        var gunR = Number(obj_info.gR);
        if (gunR > 180) {
            gunR = gunR - 360;
        }
        gunR = -gunR;
        //console.log("obj_info.dirMV: %s",obj_info.dir);
        this.dirMv = parseInt(obj_info.dir);
        this.speedMove = parseInt(obj_info.sp);

        this.nextFrameMove = 0;

        this.Opos = cc.p(x_p, y_p);
        this.min_x = x_p - 12;
        this.max_x = x_p + 12;
        this.min_y = y_p - 12;
        this.max_y = y_p + 12;

        //this.score=obj_info.score;
        //this.ammo=parseInt(obj_info.ammo);
        //this.hp=parseInt(obj_info.hp);

        var tmpLevel = parseInt(obj_info.level);
        if (tmpLevel != this.level) {
            this.level = tmpLevel;
            var parrentNode = this.node.parent;
            var mapScript = parrentNode.getComponent("GameMap");

            var sp_body = this.node.children[0];
            var sprite_body = sp_body.getComponent("cc.Sprite");
            sprite_body.spriteFrame = mapScript.tankAtlas.getSpriteFrame("TankColor-t" + this.colorID + "_b");
            //this.count_updateRun++;
            var tml_lv_gun = 1;
            if (this.level >= 10 && this.level < 35) {
                tml_lv_gun = 2;
            } else if (this.level >= 35 && this.level < 79) {
                tml_lv_gun = 3;
            } else if (this.level >= 79) {
                tml_lv_gun = 4;
            }
            if (this.levelGun != tml_lv_gun) {
                this.levelGun = tml_lv_gun;
                var sp_gun = this.node.children[3];
                var sprite_gun = sp_gun.getComponent("cc.Sprite");
                //this.count_updateRun++;
                sprite_gun.spriteFrame = mapScript.tankAtlas.getSpriteFrame("TankColor-t" + this.colorID + "_l" + this.levelGun);
            }
        }

        var tmp_hp = parseInt(obj_info.hp);
        if (tmp_hp != this.hp) {
            this.hp = tmp_hp;
            var nodepr = this.node.children[2];
            var nodeprsc = nodepr.children[0];
            var maxHP = 80 + (this.level - 1) * 15;
            var Xsc = this.hp / maxHP;
            if (Xsc > 1) {
                Xsc = 1;
            } else if (Xsc < 0) {
                Xsc = 0;
            }
            nodeprsc.scaleX = Xsc;
            //this.count_updateRun++;
        }

        var name = obj_info.name;
        if (name.length >= 1 && this.needUpdateName) {
            this.count_updateRun++;

            this.needUpdateName = false;

            var nodescore = this.node.children[5];
            var lbscore = nodescore.getComponent("cc.Label");
            lbscore.string = name;

            var ccode = obj_info.code;
            if (ccode.length == 2 || true) {
                var flagNode = this.node.children[1];
                flagNode.active = true;
                var flagSprite = flagNode.getComponent("cc.Sprite");
                var parrentNode = this.node.parent;
                var mapScript = parrentNode.getComponent("GameMap");
                flagSprite.spriteFrame = mapScript.flagsAlas.getSpriteFrame("flag-" + ccode);
            }
        }

        var nodename = this.node.children[4];
        var lbRed = nodename.getComponent("cc.Label");
        lbRed.string = obj_info.score;
        //var nodescore=this.node.children[5];
        //var lbscore=nodescore.getComponent("cc.Label");
        //lbscore.string=

        this.guntank.rotation = gunR;
        //this.lbname.string="GuestXXXX";
    }

});

cc._RFpop();
},{}]},{},["EffectScript","PanelUserInfo","TestConnect","socket.io","GameMap","tankScript","TankEffectScript","itemScript","TestEffect","PadController","obsScript","bulletScript","TestParticleSystemPos","SettingController","GamePlayScript","explosionScript","Utils","HomeScript"])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL0FwcGxpY2F0aW9ucy9Db2Nvc0NyZWF0b3IuYXBwL0NvbnRlbnRzL1Jlc291cmNlcy9hcHAuYXNhci9ub2RlX21vZHVsZXMvYnJvd3Nlci1wYWNrL19wcmVsdWRlLmpzIiwiYXNzZXRzL1NjcmlwdC9HYW1lc2NyaXB0L0VmZmVjdFNjcmlwdC5qcyIsImFzc2V0cy9TY3JpcHQvR2FtZXNjcmlwdC9HYW1lTWFwLmpzIiwiYXNzZXRzL1NjcmlwdC9HYW1lc2NyaXB0L0dhbWVQbGF5U2NyaXB0LmpzIiwiYXNzZXRzL1NjcmlwdC9HYW1lc2NyaXB0L0hvbWVTY3JpcHQuanMiLCJhc3NldHMvU2NyaXB0L0xJQi9QYWRDb250cm9sbGVyLmpzIiwiYXNzZXRzL1NjcmlwdC9HYW1lc2NyaXB0L1BhbmVsVXNlckluZm8uanMiLCJhc3NldHMvU2NyaXB0L0xJQi9TZXR0aW5nQ29udHJvbGxlci5qcyIsImFzc2V0cy9TY3JpcHQvR2FtZXNjcmlwdC9UYW5rRWZmZWN0U2NyaXB0LmpzIiwiYXNzZXRzL1NjcmlwdC9UZXN0U2NyaXB0L1Rlc3RDb25uZWN0LmpzIiwiYXNzZXRzL1NjcmlwdC9UZXN0U2NyaXB0L1Rlc3RFZmZlY3QuanMiLCJhc3NldHMvU2NyaXB0L1Rlc3RTY3JpcHQvVGVzdFBhcnRpY2xlU3lzdGVtUG9zLmpzIiwiYXNzZXRzL1NjcmlwdC9MSUIvVXRpbHMuanMiLCJhc3NldHMvU2NyaXB0L0dhbWVzY3JpcHQvYnVsbGV0U2NyaXB0LmpzIiwiYXNzZXRzL1NjcmlwdC9HYW1lc2NyaXB0L2V4cGxvc2lvblNjcmlwdC5qcyIsImFzc2V0cy9TY3JpcHQvR2FtZXNjcmlwdC9pdGVtU2NyaXB0LmpzIiwiYXNzZXRzL1NjcmlwdC9HYW1lc2NyaXB0L29ic1NjcmlwdC5qcyIsImFzc2V0cy9TY3JpcHQvTElCL3NvY2tldC5pby5qcyIsImFzc2V0cy9TY3JpcHQvR2FtZXNjcmlwdC90YW5rU2NyaXB0LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3pDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDOW5CQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN0ZUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbE5BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDNU5BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3JCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3hGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzNDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2xDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzlGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbkNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM3TkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM5Q0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDZkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDakNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FDdENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7OztBQ25oT0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dmFyIGY9bmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKTt0aHJvdyBmLmNvZGU9XCJNT0RVTEVfTk9UX0ZPVU5EXCIsZn12YXIgbD1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwobC5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxsLGwuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzA5ZWQ5RExJWjVJRVliTzdvOUhSQStJJywgJ0VmZmVjdFNjcmlwdCcpO1xuLy8gU2NyaXB0L0dhbWVzY3JpcHQvRWZmZWN0U2NyaXB0LmpzXG5cbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCxcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICB9LFxuXG4gICAgLy8gQ09DT1MtQ1JFQVRPUiBMQSBFTkdJTkUgS0hPTiBOQU4gTkhBVCwgRUZGRUNUIFJFTkRFUiBTVEFUSUMgVEhFTyBTQ1JFRU4gOnwgQk8gVEFZXG5cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy5zY2h1ZGxlRml4UG9zaXRpb24oKTtcbiAgICB9LFxuICAgIHNldEZpeGVkUG9zaXRpb246IGZ1bmN0aW9uIHNldEZpeGVkUG9zaXRpb24oKSB7XG4gICAgICAgIHRoaXMuclggPSB0aGlzLm5vZGUucGFyZW50Lng7XG4gICAgICAgIHRoaXMuclkgPSB0aGlzLm5vZGUucGFyZW50Lnk7XG4gICAgfSxcbiAgICBzY2h1ZGxlRml4UG9zaXRpb246IGZ1bmN0aW9uIHNjaHVkbGVGaXhQb3NpdGlvbigpIHtcbiAgICAgICAgdGhpcy5zY2hlZHVsZShmdW5jdGlvbiAoZHQpIHtcbiAgICAgICAgICAgIC8vdmFyIGR0eD10aGlzLm5vZGUucGFyZW50LngtdGhpcy5yWDtcbiAgICAgICAgICAgIC8vdmFyIGR0eT10aGlzLm5vZGUucGFyZW50LnktdGhpcy5yWTtcbiAgICAgICAgICAgIC8vdGhpcy5yWD10aGlzLm5vZGUucGFyZW50Lng7XG4gICAgICAgICAgICAvL3RoaXMuclk9dGhpcy5ub2RlLnBhcmVudC55O1xuICAgICAgICAgICAgLy9cbiAgICAgICAgICAgIC8vdGhpcy5ub2RlLng9dGhpcy5ub2RlLngrZHR4LzI7XG4gICAgICAgICAgICAvL3RoaXMubm9kZS55PXRoaXMubm9kZS55K2R0eS8yO1xuICAgICAgICB9LCAwLjAwMik7XG4gICAgfVxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICc1Yjc4MW4zQ2Z0R2FxaWEvRW5LdS9CZicsICdHYW1lTWFwJyk7XG4vLyBTY3JpcHQvR2FtZXNjcmlwdC9HYW1lTWFwLmpzXG5cbnZhciBVdGlscyA9IHJlcXVpcmUoJy4uL0xJQi9VdGlscycpO1xuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIHRfcHJlZmFiOiB7XG4gICAgICAgICAgICB0eXBlOiBjYy5QcmVmYWIsXG4gICAgICAgICAgICBcImRlZmF1bHRcIjogbnVsbFxuICAgICAgICB9LFxuICAgICAgICBvYnNfcHJlZmFiOiB7XG4gICAgICAgICAgICB0eXBlOiBjYy5QcmVmYWIsXG4gICAgICAgICAgICBcImRlZmF1bHRcIjogbnVsbFxuICAgICAgICB9LFxuICAgICAgICBidWxsZXRfcHJlZmFiOiB7XG4gICAgICAgICAgICB0eXBlOiBjYy5QcmVmYWIsXG4gICAgICAgICAgICBcImRlZmF1bHRcIjogbnVsbFxuICAgICAgICB9LFxuICAgICAgICBpdGVtX2FtbW9fcHJlZmFiOiB7XG4gICAgICAgICAgICB0eXBlOiBjYy5QcmVmYWIsXG4gICAgICAgICAgICBcImRlZmF1bHRcIjogbnVsbFxuICAgICAgICB9LFxuICAgICAgICBpdGVtX2hlYWx0aF9wcmVmYWI6IHtcbiAgICAgICAgICAgIHR5cGU6IGNjLlByZWZhYixcbiAgICAgICAgICAgIFwiZGVmYXVsdFwiOiBudWxsXG4gICAgICAgIH0sXG5cbiAgICAgICAgdGFua0F0bGFzOiBjYy5TcHJpdGVBdGxhcyxcbiAgICAgICAgZmxhZ3NBbGFzOiBjYy5TcHJpdGVBdGxhcyxcbiAgICAgICAgZXhwbG9zaW9uQXRsYXM6IGNjLlNwcml0ZUF0bGFzLFxuXG4gICAgICAgIGZpcmVfYXVkaW86IHtcbiAgICAgICAgICAgIFwiZGVmYXVsdFwiOiBudWxsLFxuICAgICAgICAgICAgdXJsOiBjYy5BdWRpb0NsaXBcbiAgICAgICAgfSxcbiAgICAgICAgaGl0Mjoge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB1cmw6IGNjLkF1ZGlvQ2xpcFxuICAgICAgICB9LFxuICAgICAgICBoaXRfdGFuazoge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB1cmw6IGNjLkF1ZGlvQ2xpcFxuICAgICAgICB9LFxuICAgICAgICB0YW5rX25vOiB7XG4gICAgICAgICAgICBcImRlZmF1bHRcIjogbnVsbCxcbiAgICAgICAgICAgIHVybDogY2MuQXVkaW9DbGlwXG4gICAgICAgIH0sXG5cbiAgICAgICAgZWZmX2hpdF93YWxsOiBjYy5QcmVmYWIsXG4gICAgICAgIGVmZl9oaXRfdGFuazogY2MuUHJlZmFiLFxuICAgICAgICBlZmZfZ3VuX2ZpcmU6IGNjLlByZWZhYixcbiAgICAgICAgZWZmX3RhbmtfZXhwbG9zaW9uOiBjYy5QcmVmYWJcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIC8vIGtoYWkgYmFvIGRhbmcgZGljdGlvbmFyeSBrZXktdmFsdWUsIG3hu6VjIMSRw61jaCBsw6AgY2jhu4kgY2jhu6lhIGPDoWMgc2NyaXB0IMSRaeG7gXUga2hp4buDbiB2aeG7h2MgaGnhu4NuIHRo4buLIGPDoWMgxJHhu5FpIHTGsOG7o25nIHRyb25nIG5vZGUgbWFwZ2FtZVxuICAgICAgICB0aGlzLmRpY3RPYnMgPSB7fTsgLy8gb2JqX3R5cGU9MTtcbiAgICAgICAgdGhpcy5kaWN0VGFua3MgPSB7fTsgLy8gb2JqX3R5cGU9MjtcbiAgICAgICAgdGhpcy5kaWN0QnVsbGV0cyA9IHt9OyAvLyBvYmpfdHlwZT0zO1xuICAgICAgICB0aGlzLmRpY3RJdGVtcyA9IHt9OyAvLyBvYmpfdHlwZT0zO1xuXG4gICAgICAgIHRoaXMuTVlQTEFZRVIgPSBudWxsO1xuICAgICAgICB0aGlzLnRfYWRkX3RhbmsgPSAwO1xuICAgICAgICB0aGlzLnRfYWRkX2J1bGxldCA9IDA7XG4gICAgICAgIHRoaXMudF9hZGRfb2JzID0gMDtcbiAgICAgICAgdGhpcy50X2FkZF9pdGVtcyA9IDA7XG4gICAgICAgIHRoaXMudF9hZGRfZXhwbG9zaW9uID0gMDtcblxuICAgICAgICB0aGlzLmlzT3ZlciA9IGZhbHNlO1xuICAgICAgICB0aGlzLmZyYW1lID0gMDtcblxuICAgICAgICB0aGlzLmVzdGltYXRlTW92ZVRhbmsoKTtcbiAgICB9LFxuXG4gICAgLyoqXG4gICAgICogdHJvbmcgaMOgbSB1cGRhdGVGcmFtZVN0ZXAgdGjDrCDEkeG6p3UgdGnDqm4gZ+G7jWkgxJFp4bq/biBow6BtIGJlZ2luVXBkYXRlRnJhbWUsIGvhur90IHRow7pjIGfhu41pIMSR4bq/biBow6BtIGVuZFVwZGF0ZUZyYW1lXG4gICAgICogTeG7pWMgxJHDrWNoIGzDoCDEkeG7gyBraeG7g20gdHJhIG5o4buvbmcgxJHhu5FpIHTGsOG7o25nIG7DoG8gbcOgIHRyw6puIHNlcnZlciBraMO0bmcgY8OybiB0cuG6oyB24buBIG7hu69hIHRow6wgZGVzdHJveSBuw7MgxJFpIG5oxrAgbMOgIFxuICAgICAqICAocmEgbmdvw6BpIHZpZXcgbcOgbiBow6xuaCh0YW5rLGl0ZW1zLG9icyksIGLhu4sgbuG7lSh0YW5rKSAsaG/hurdjIGjhur90IHRpbWUtbGlmZSAoaXRlbXMsYnVsbGV0KSApXG4gICAgICogXG4gICAgICogXG4gICAgICogXG4gICAgICogKi9cblxuICAgIHVwZGF0ZUZyYW1lU3RlcDogZnVuY3Rpb24gdXBkYXRlRnJhbWVTdGVwKG1zZ09iaikge1xuICAgICAgICB0aGlzLmZyYW1lKys7XG4gICAgICAgIC8vLS0tLS0tLS0tLVRBTksgLS0tLVxuICAgICAgICB0aGlzLmJlZ2luVXBkYXRlKHRoaXMuZGljdFRhbmtzKTtcbiAgICAgICAgdmFyIGFycl90YW5rID0gbXNnT2JqLnQ7XG4gICAgICAgIHRoaXMubWFuYWdlclRhbmsoYXJyX3RhbmspO1xuICAgICAgICB0aGlzLmZpbmlzaFVwZGF0ZSh0aGlzLmRpY3RUYW5rcyk7XG5cbiAgICAgICAgdGhpcy51cGRhdGVNYXBQb3NpdGlvbigpO1xuXG4gICAgICAgIC8vLS0tLS0tLS0tLU9CUyAtLS0tXG5cbiAgICAgICAgdmFyIGFycl9vYnMgPSBtc2dPYmoubztcbiAgICAgICAgaWYgKCEodHlwZW9mIGFycl9vYnMgPT09IFwidW5kZWZpbmVkXCIpKSB7XG4gICAgICAgICAgICB0aGlzLmJlZ2luVXBkYXRlKHRoaXMuZGljdE9icyk7XG4gICAgICAgICAgICB0aGlzLm1hbmFnZXJPYnMoYXJyX29icyk7XG4gICAgICAgICAgICB0aGlzLmZpbmlzaFVwZGF0ZSh0aGlzLmRpY3RPYnMpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8tLS0tLS0tLS0tQlVMTEVUIC0tLS1cbiAgICAgICAgdGhpcy5iZWdpblVwZGF0ZSh0aGlzLmRpY3RCdWxsZXRzKTtcbiAgICAgICAgdmFyIGFycl9idWxsZXQgPSBtc2dPYmouYjtcbiAgICAgICAgdGhpcy5tYW5hZ2VyQnVsbGV0KGFycl9idWxsZXQpO1xuICAgICAgICB0aGlzLmZpbmlzaFVwZGF0ZSh0aGlzLmRpY3RCdWxsZXRzKTtcblxuICAgICAgICAvLy0tLS0tLS0tLS1JVEVNIC0tLS1cblxuICAgICAgICB2YXIgYXJyX2l0ZW1zID0gbXNnT2JqLmk7XG4gICAgICAgIGlmICghKHR5cGVvZiBhcnJfaXRlbXMgPT09IFwidW5kZWZpbmVkXCIpKSB7XG4gICAgICAgICAgICB0aGlzLmJlZ2luVXBkYXRlKHRoaXMuZGljdEl0ZW1zKTtcbiAgICAgICAgICAgIHRoaXMubWFuYWdlckl0ZW1zKGFycl9pdGVtcyk7XG4gICAgICAgICAgICB0aGlzLmZpbmlzaFVwZGF0ZSh0aGlzLmRpY3RJdGVtcyk7XG4gICAgICAgIH1cblxuICAgICAgICAvLy0tLS0tLS0tLS1FeHBsb3JzaW9uIC0tLS1cbiAgICAgICAgdmFyIGFycl9leCA9IG1zZ09iai5lO1xuICAgICAgICB0aGlzLm1hbmFnZXJFeHBsb3Npb24oYXJyX2V4KTtcblxuICAgICAgICB0aGlzLmxvYWRNU0dUZXN0KCk7XG4gICAgfSxcblxuICAgIGJlZ2luVXBkYXRlOiBmdW5jdGlvbiBiZWdpblVwZGF0ZShkaWN0VXBkYXRlKSB7XG4gICAgICAgIGZvciAodmFyIGlrZXkgaW4gZGljdFVwZGF0ZSkge1xuICAgICAgICAgICAgdmFyIHRtcF9zY3JpcHQgPSBkaWN0VXBkYXRlW2lrZXldO1xuICAgICAgICAgICAgdG1wX3NjcmlwdC5ub2RlLmlzQWN0aXZlU0MgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBmaW5pc2hVcGRhdGU6IGZ1bmN0aW9uIGZpbmlzaFVwZGF0ZShkaWN0VXBkYXRlKSB7XG4gICAgICAgIHZhciBhcnJEZWxldGUgPSBbXTtcbiAgICAgICAgZm9yICh2YXIgaWtleSBpbiBkaWN0VXBkYXRlKSB7XG4gICAgICAgICAgICB2YXIgdG1wX3NjcmlwdCA9IGRpY3RVcGRhdGVbaWtleV07XG4gICAgICAgICAgICBpZiAodG1wX3NjcmlwdC5ub2RlLmlzQWN0aXZlU0MpIHtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChjYy5pc1ZhbGlkKHRtcF9zY3JpcHQubm9kZSkpIHtcbiAgICAgICAgICAgICAgICBhcnJEZWxldGUucHVzaCh0bXBfc2NyaXB0Lm5vZGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgZm9yICh2YXIgZGVsZXRlaWQgPSAwLCBtYXhsZW5ndCA9IGFyckRlbGV0ZS5sZW5ndGg7IGRlbGV0ZWlkIDwgbWF4bGVuZ3Q7IGRlbGV0ZWlkKyspIHtcbiAgICAgICAgICAgIHZhciBub2RlX3RtcCA9IGFyckRlbGV0ZVtkZWxldGVpZF07XG4gICAgICAgICAgICB2YXIgdHlwZV9vZl9kaWN0ID0gbm9kZV90bXAub2JqX3R5cGU7XG5cbiAgICAgICAgICAgIGlmICh0eXBlX29mX2RpY3QgPT0gMSkge1xuICAgICAgICAgICAgICAgIGRlbGV0ZSB0aGlzLmRpY3RPYnNbbm9kZV90bXAuZ2lkXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh0eXBlX29mX2RpY3QgPT0gMikge1xuICAgICAgICAgICAgICAgIGRlbGV0ZSB0aGlzLmRpY3RUYW5rc1tub2RlX3RtcC5naWRdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHR5cGVfb2ZfZGljdCA9PSAzKSB7XG4gICAgICAgICAgICAgICAgLy8gdmFyIHNjcmlwdF9idWxsZXRfZGVsZXRlPXRoaXMuZGljdEJ1bGxldHNbbm9kZV90bXAuZ2lkXTtcbiAgICAgICAgICAgICAgICAvLyBzY3JpcHRfYnVsbGV0X2RlbGV0ZS5jbGVhckJ1bGxldEVmZmVjdCgpO1xuICAgICAgICAgICAgICAgIGRlbGV0ZSB0aGlzLmRpY3RCdWxsZXRzW25vZGVfdG1wLmdpZF07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodHlwZV9vZl9kaWN0ID09IDQpIHtcbiAgICAgICAgICAgICAgICB2YXIgc2NyaXB0X2l0ZW1fZGVsZXRlID0gdGhpcy5kaWN0SXRlbXNbbm9kZV90bXAuZ2lkXTtcbiAgICAgICAgICAgICAgICBzY3JpcHRfaXRlbV9kZWxldGUuYmVnaW5DbGVhbigpO1xuICAgICAgICAgICAgICAgIGRlbGV0ZSB0aGlzLmRpY3RJdGVtc1tub2RlX3RtcC5naWRdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbm9kZV90bXAucmVtb3ZlRnJvbVBhcmVudCh0cnVlKTtcbiAgICAgICAgICAgIC8vbm9kZV90bXAuZGVzdHJveSgpO1xuICAgICAgICB9XG4gICAgfSxcblxuICAgIGxvYWRNU0dUZXN0OiBmdW5jdGlvbiBsb2FkTVNHVGVzdCgpIHtcbiAgICAgICAgLy8gZG9hbiBuYXkgY2hpIGRlIHRlc3Qgb2JqZWN0IG1lb21vcnlcbiAgICAgICAgdGhpcy5jX3Rhbmtfc2NyaXB0ID0gT2JqZWN0LmtleXModGhpcy5kaWN0VGFua3MpLmxlbmd0aDtcbiAgICAgICAgdGhpcy5jX29ic19zY3JpcHQgPSBPYmplY3Qua2V5cyh0aGlzLmRpY3RPYnMpLmxlbmd0aDtcbiAgICAgICAgdGhpcy5jX2l0ZW1fc2NyaXB0ID0gT2JqZWN0LmtleXModGhpcy5kaWN0SXRlbXMpLmxlbmd0aDtcbiAgICAgICAgdGhpcy5jX2J1bGxldF9zY3JpcHQgPSBPYmplY3Qua2V5cyh0aGlzLmRpY3RCdWxsZXRzKS5sZW5ndGg7XG4gICAgICAgIHZhciB0b25nID0gdGhpcy5jX3Rhbmtfc2NyaXB0ICsgdGhpcy5jX29ic19zY3JpcHQgKyB0aGlzLmNfaXRlbV9zY3JpcHQgKyB0aGlzLmNfYnVsbGV0X3NjcmlwdDtcbiAgICAgICAgdGhpcy5jX2FsbF9ub2RlID0gdGhpcy5ub2RlLmNoaWxkcmVuLmxlbmd0aCAtIDE7IC8vIHRydSBkaSAxIGxhbiB0aWxlZE1hcEJHXG4gICAgICAgIGlmICh0b25nID09IHRoaXMuY19hbGxfbm9kZSkge1xuICAgICAgICAgICAgdGhpcy5tc2dsb2cgPSBcImNvdW50IGFsbCBvYmplY3Q6IFwiICsgdG9uZztcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMubXNnbG9nID0gXCItLS0tLS0+ZXJyb3I6IFwiICsgdG9uZyArIFwifFwiICsgdGhpcy5jX2FsbF9ub2RlICsgXCIgICBpbmZvIFwiICsgXCJ0PVwiICsgdGhpcy5jX3Rhbmtfc2NyaXB0ICsgXCIgb2JzPVwiICsgdGhpcy5jX29ic19zY3JpcHQgKyBcIiBpdGVtPVwiICsgdGhpcy5jX2l0ZW1fc2NyaXB0ICsgXCIgYnVsbGV0PVwiICsgdGhpcy5jX2J1bGxldF9zY3JpcHQ7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgbWFuYWdlckV4cGxvc2lvbjogZnVuY3Rpb24gbWFuYWdlckV4cGxvc2lvbihhcnJfRXgpIHtcblxuICAgICAgICBmb3IgKHZhciBpX2UgPSAwLCBpX2VfbSA9IGFycl9FeC5sZW5ndGg7IGlfZSA8IGlfZV9tOyBpX2UrKykge1xuICAgICAgICAgICAgdmFyIGVfaW5mbyA9IFV0aWxzLmRlY29kZVBhY2tFeHBsb3Npb24oYXJyX0V4W2lfZV0pO1xuICAgICAgICAgICAgdmFyIHN0YXR1cyA9IGVfaW5mby5zdHQ7XG4gICAgICAgICAgICBzdGF0dXMgPSBzdGF0dXMgLSAwO1xuXG4gICAgICAgICAgICB2YXIgeF9wID0gTnVtYmVyKGVfaW5mby54KTtcbiAgICAgICAgICAgIHZhciB5X3AgPSBOdW1iZXIoZV9pbmZvLnkpO1xuICAgICAgICAgICAgLy9VdGlscy5sb2coXCJzdGF0dXM6XCIrc3RhdHVzKTtcbiAgICAgICAgICAgIHRoaXMudF9hZGRfZXhwbG9zaW9uKys7XG4gICAgICAgICAgICBpZiAoc3RhdHVzID09IDEgfHwgc3RhdHVzID09IDIpIHtcbiAgICAgICAgICAgICAgICAvL2RhbiBiYW4gdHJ1bmcgdHVvbmdcbiAgICAgICAgICAgICAgICB2YXIgdG1wbm9kZSA9IG51bGw7XG4gICAgICAgICAgICAgICAgaWYgKHN0YXR1cyA9PSAyKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vZGFuIHZhIGNoYW0geGUgdGFua1xuICAgICAgICAgICAgICAgICAgICB0bXBub2RlID0gY2MuaW5zdGFudGlhdGUodGhpcy5lZmZfaGl0X3RhbmspOyAvL2hpdDJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFVdGlscy50dXJuT2ZmQXVkaW8pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciB2bCA9IDAuODtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwb3MxID0ge307XG4gICAgICAgICAgICAgICAgICAgICAgICBwb3MxLnggPSB0aGlzLk1ZUExBWUVSLng7XG4gICAgICAgICAgICAgICAgICAgICAgICBwb3MxLnkgPSB0aGlzLk1ZUExBWUVSLnk7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgZGlzdGFuY2UgPSBVdGlscy5kaXN0YW5jZTJQb3MocG9zMSwgY2MucCh4X3AsIHlfcCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmwgPSAxLjAgLSBkaXN0YW5jZSAvIDQ1MC4wO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodmwgPiAwLjgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2bCA9IDAuODtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2bCA8IDAuMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZsID0gMC4xO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgdmwgPSB2bCAqIDAuMztcblxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNjLnN5cy5vcyA9PSBjYy5zeXMuT1NfSU9TKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAganNiLnJlZmxlY3Rpb24uY2FsbFN0YXRpY01ldGhvZChcIkJyaWRnZUlPU1wiLCBcIlBsYXlFZmZlY3Q6dm9sdW1lOlwiLCBcImhpdHRhbmsubXAzXCIsIHZsICsgXCJcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXlFZmZlY3QodGhpcy5oaXRfdGFuaywgZmFsc2UsIHZsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHRtcG5vZGUgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmVmZl9oaXRfd2FsbCk7IC8vaGl0X3RhbmtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFVdGlscy50dXJuT2ZmQXVkaW8pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciB2bCA9IDAuODtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwb3MxID0ge307XG4gICAgICAgICAgICAgICAgICAgICAgICBwb3MxLnggPSB0aGlzLk1ZUExBWUVSLng7XG4gICAgICAgICAgICAgICAgICAgICAgICBwb3MxLnkgPSB0aGlzLk1ZUExBWUVSLnk7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgZGlzdGFuY2UgPSBVdGlscy5kaXN0YW5jZTJQb3MocG9zMSwgY2MucCh4X3AsIHlfcCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmwgPSAoMS4wIC0gZGlzdGFuY2UgLyAzMDAuMCkgKiAwLjk7XG4gICAgICAgICAgICAgICAgICAgICAgICAvL05TTG9nKEBcImRpc2FuY2UgMTExMTE6ICVmIC0tLSAlZlwiLGRpc2FuY2UsdmwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZsID4gMC44KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmwgPSAwLjg7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodmwgPCAwLjEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2bCA9IDAuMTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjYy5zeXMub3MgPT0gY2Muc3lzLk9TX0lPUykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGpzYi5yZWZsZWN0aW9uLmNhbGxTdGF0aWNNZXRob2QoXCJCcmlkZ2VJT1NcIiwgXCJQbGF5RWZmZWN0OnZvbHVtZTpcIiwgXCJoaXQyLm1wM1wiLCB2bCArIFwiXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHRoaXMuaGl0MiwgZmFsc2UsIHZsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAodG1wbm9kZSA9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB0bXBub2RlLnNldFBvc2l0aW9uKGNjLnAoeF9wLCB5X3ApKTtcbiAgICAgICAgICAgICAgICB0bXBub2RlLnNldExvY2FsWk9yZGVyKDgpO1xuICAgICAgICAgICAgICAgIHZhciBwYXJpY2xlID0gdG1wbm9kZS5nZXRDb21wb25lbnQoJ2NjLlBhcnRpY2xlU3lzdGVtJyk7XG4gICAgICAgICAgICAgICAgdG1wbm9kZS5wb3NpdGlvblR5cGUgPSBjYy5QYXJ0aWNsZVN5c3RlbS5Qb3NpdGlvblR5cGUuUkVMQVRJVkU7XG4gICAgICAgICAgICAgICAgcGFyaWNsZS5wb3NpdGlvblR5cGUgPSBjYy5QYXJ0aWNsZVN5c3RlbS5Qb3NpdGlvblR5cGUuUkVMQVRJVkU7XG4gICAgICAgICAgICAgICAgLy92YXIgc2NyaXB0RWZmZWN0PXRtcG5vZGUuZ2V0Q29tcG9uZW50KFwiRWZmZWN0U2NyaXB0XCIpO1xuXG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLmFkZENoaWxkKHRtcG5vZGUpO1xuICAgICAgICAgICAgICAgIC8vc2NyaXB0RWZmZWN0LnNldEZpeGVkUG9zaXRpb24oKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKHN0YXR1cyA+PSAzICYmIHN0YXR1cyA8PSA2KSB7XG4gICAgICAgICAgICAgICAgLy9kYW4gYmFuIHJhIHR1IG5vbmcgc3VuZ1xuICAgICAgICAgICAgICAgIHZhciB0bXBfZWZmZWN0X2d1biA9IGNjLmluc3RhbnRpYXRlKHRoaXMuZWZmX2d1bl9maXJlKTtcbiAgICAgICAgICAgICAgICB0bXBfZWZmZWN0X2d1bi5zZXRQb3NpdGlvbihjYy5wKDc4LCAyKSk7XG4gICAgICAgICAgICAgICAgdG1wX2VmZmVjdF9ndW4uc2NhbGUgPSAyO1xuICAgICAgICAgICAgICAgIHRtcF9lZmZlY3RfZ3VuLnNldExvY2FsWk9yZGVyKC0zKTsgLy8ga2hvbmcgaGlldSBzYW8gLTEsLTIgbGFpIGtob25nIGR1b2MgLCBibyB0YXlcbiAgICAgICAgICAgICAgICB2YXIgc2NyaXB0bm9kZSA9IHRoaXMuZGljdFRhbmtzW2VfaW5mby50aWRdO1xuICAgICAgICAgICAgICAgIGlmICh0eXBlb2Ygc2NyaXB0bm9kZSA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBzY3JpcHRub2RlLm5vZGUgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHZhciBndW50YW5rID0gc2NyaXB0bm9kZS5ndW50YW5rO1xuICAgICAgICAgICAgICAgIHNjcmlwdG5vZGUuZ3VudGFuay5hZGRDaGlsZCh0bXBfZWZmZWN0X2d1bik7XG4gICAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcInNjcmlwdG5vZGUuZ3VudGFuazogJXNcIixzY3JpcHRub2RlLmd1bnRhbmsuY2hpbGRyZW4ubGVuZ3RoKTtcbiAgICAgICAgICAgICAgICAvLyBlZmZlY3QgYXVkaW9cbiAgICAgICAgICAgICAgICBpZiAoIVV0aWxzLnR1cm5PZmZBdWRpbykge1xuICAgICAgICAgICAgICAgICAgICB2YXIgdmwgPSAwLjg7XG4gICAgICAgICAgICAgICAgICAgIHZhciBwb3MxID0ge307XG4gICAgICAgICAgICAgICAgICAgIHBvczEueCA9IHRoaXMuTVlQTEFZRVIueDtcbiAgICAgICAgICAgICAgICAgICAgcG9zMS55ID0gdGhpcy5NWVBMQVlFUi55O1xuICAgICAgICAgICAgICAgICAgICB2YXIgZGlzdGFuY2UgPSBVdGlscy5kaXN0YW5jZTJQb3MocG9zMSwgY2MucCh4X3AsIHlfcCkpO1xuXG4gICAgICAgICAgICAgICAgICAgIHZhciB2bCA9ICgxIC0gZGlzdGFuY2UgLyAzMDAuMCkgKiAwLjg7XG4gICAgICAgICAgICAgICAgICAgIC8vTlNMb2coQFwiZGlzYW5jZSAzLS0tLTY6ICVmIC0tLSAlZlwiLGRpc2FuY2UsdmwpO1xuICAgICAgICAgICAgICAgICAgICBpZiAodmwgPiAwLjkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZsID0gMC45O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmICh2bCA8IDAuMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmwgPSAwLjE7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBpZiAoY2Muc3lzLm9zID09IGNjLnN5cy5PU19JT1MpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGpzYi5yZWZsZWN0aW9uLmNhbGxTdGF0aWNNZXRob2QoXCJCcmlkZ2VJT1NcIiwgXCJQbGF5RWZmZWN0OnZvbHVtZTpcIiwgXCJmaXJlLm1wM1wiLCB2bCArIFwiXCIpO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheUVmZmVjdCh0aGlzLmZpcmVfYXVkaW8sIGZhbHNlLCB2bCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoc3RhdHVzID09PSAwKSB7XG4gICAgICAgICAgICAgICAgLy94ZSB0YW5rIG5vXG4gICAgICAgICAgICAgICAgLy9pZih0aGlzLmlzT3Zlcil7XG4gICAgICAgICAgICAgICAgLy8gICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIC8vfVxuICAgICAgICAgICAgICAgIHZhciB0aWQgPSBwYXJzZUludChlX2luZm8udGlkKTtcbiAgICAgICAgICAgICAgICB0aWQgPSBNYXRoLmFicyh0aWQpO1xuICAgICAgICAgICAgICAgIHRpZCA9IHRpZCAlIDEwO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwicnVuIGV4cGxvcnNpb246ICVzXCIsIHRpZCk7XG4gICAgICAgICAgICAgICAgdmFyIHRhbmtOb2RlRWZmID0gY2MuaW5zdGFudGlhdGUodGhpcy5lZmZfdGFua19leHBsb3Npb24pO1xuICAgICAgICAgICAgICAgIHZhciBzY3JpcHRfZWZmID0gdGFua05vZGVFZmYuZ2V0Q29tcG9uZW50KFwiVGFua0VmZmVjdFNjcmlwdFwiKTtcbiAgICAgICAgICAgICAgICBzY3JpcHRfZWZmLnJ1bkVmZmVjdCh0aGlzLmV4cGxvc2lvbkF0bGFzLCB0aWQpO1xuICAgICAgICAgICAgICAgIHRhbmtOb2RlRWZmLnNldFBvc2l0aW9uKGNjLnAoeF9wLCB5X3ApKTtcbiAgICAgICAgICAgICAgICB0YW5rTm9kZUVmZi5zY2FsZSA9IDAuNTtcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUuYWRkQ2hpbGQodGFua05vZGVFZmYpO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwic3RhdHVzID09MFwiICsgXCIgZV9pbmZvLnRpZD1cIiArIGVfaW5mby50aWQpO1xuICAgICAgICAgICAgICAgIC8vIGF1ZGlvIGVmZmVjdFxuICAgICAgICAgICAgICAgIGlmICghVXRpbHMudHVybk9mZkF1ZGlvKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciB2b2x1bWUgPSAwLjg7XG4gICAgICAgICAgICAgICAgICAgIHRpZCA9IHBhcnNlSW50KGVfaW5mby50aWQpO1xuICAgICAgICAgICAgICAgICAgICBpZiAodGlkID09IHRoaXMuVEFOS0lEKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2b2x1bWUgPSAwLjg7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcG9zMSA9IHt9O1xuICAgICAgICAgICAgICAgICAgICAgICAgcG9zMS54ID0gdGhpcy5NWVBMQVlFUi54O1xuICAgICAgICAgICAgICAgICAgICAgICAgcG9zMS55ID0gdGhpcy5NWVBMQVlFUi55O1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGRpc3RhbmNlID0gVXRpbHMuZGlzdGFuY2UyUG9zKHBvczEsIGNjLnAoeF9wLCB5X3ApKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZvbHVtZSA9IDEgLSBkaXN0YW5jZSAvIDMwMC4wO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZvbHVtZSA+IDAuNikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvbHVtZSA9IDAuNjtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2b2x1bWUgPCAwLjEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b2x1bWUgPSAwLjE7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdm9sdW1lID0gdm9sdW1lICogMC41O1xuXG4gICAgICAgICAgICAgICAgICAgIGlmIChjYy5zeXMub3MgPT0gY2Muc3lzLk9TX0lPUykge1xuICAgICAgICAgICAgICAgICAgICAgICAganNiLnJlZmxlY3Rpb24uY2FsbFN0YXRpY01ldGhvZChcIkJyaWRnZUlPU1wiLCBcIlBsYXlFZmZlY3Q6dm9sdW1lOlwiLCBcInRhbmtuby5tcDNcIiwgdm9sdW1lICsgXCJcIik7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHRoaXMudGFua19ubywgZmFsc2UsIHZvbHVtZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgbWFuYWdlclRhbms6IGZ1bmN0aW9uIG1hbmFnZXJUYW5rKGFycl90YW5rKSB7XG4gICAgICAgIGZvciAodmFyIGlfdCA9IDAsIGlfdF9tID0gYXJyX3RhbmsubGVuZ3RoOyBpX3QgPCBpX3RfbTsgaV90KyspIHtcbiAgICAgICAgICAgIHZhciBvYmpfaW5mbyA9IFV0aWxzLmRlY29kZVBhY2tUYW5rKGFycl90YW5rW2lfdF0pO1xuICAgICAgICAgICAgdmFyIHRhbmtfc2NyaXB0ID0gdGhpcy5kaWN0VGFua3Nbb2JqX2luZm8uaWRdO1xuICAgICAgICAgICAgdmFyIHRhbmtOdW1iZXJJRCA9IHBhcnNlSW50KG9ial9pbmZvLmlkKTtcbiAgICAgICAgICAgIC8vVXRpbHMubG9nKFwiLS0tPnRhbmtfdG1wOlwiK3RhbmtfdG1wKTtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGFua19zY3JpcHQgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgICAgICAgICAvLyBjaGVjayBiYW5nIG51bGwga2hvbmcgY28gdGFjIGR1bmcgOihcbiAgICAgICAgICAgICAgICAvL1V0aWxzLmxvZyhcImFkZCBuZXcgdGFuayBnYW1lXCIpO1xuICAgICAgICAgICAgICAgIHZhciB0YW5rX25vZGUgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLnRfcHJlZmFiKTtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5UQU5LSUQgPT09IHRhbmtOdW1iZXJJRCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLk1ZUExBWUVSID0gdGFua19ub2RlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB2YXIgY29sb3JJRCA9IE1hdGguYWJzKHRhbmtOdW1iZXJJRCAlIDEwKTtcbiAgICAgICAgICAgICAgICBpZiAoY29sb3JJRCA8IDApIHtcbiAgICAgICAgICAgICAgICAgICAgY29sb3JJRCA9IDY7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChjb2xvcklEID4gOSkge1xuICAgICAgICAgICAgICAgICAgICBjb2xvcklEID0gNztcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB0YW5rX25vZGUub2JqX3R5cGUgPSAyO1xuICAgICAgICAgICAgICAgIHRhbmtfbm9kZS5naWQgPSBvYmpfaW5mby5pZDtcbiAgICAgICAgICAgICAgICB0YW5rX25vZGUuc2NhbGUgPSAwLjI1O1xuICAgICAgICAgICAgICAgIHRhbmtfbm9kZS5zZXRMb2NhbFpPcmRlcig1KTtcblxuICAgICAgICAgICAgICAgIHRhbmtfc2NyaXB0ID0gdGFua19ub2RlLmdldENvbXBvbmVudChcInRhbmtTY3JpcHRcIik7XG4gICAgICAgICAgICAgICAgdGFua19zY3JpcHQuZ2lkID0gb2JqX2luZm8uaWQ7XG4gICAgICAgICAgICAgICAgdGFua19zY3JpcHQuY29sb3JJRCA9IGNvbG9ySUQ7XG4gICAgICAgICAgICAgICAgdGFua19zY3JpcHQubGV2ZWwgPSAwO1xuICAgICAgICAgICAgICAgIHRhbmtfc2NyaXB0LmxldmVsR3VuID0gMDtcblxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5hZGRDaGlsZCh0YW5rX25vZGUpO1xuICAgICAgICAgICAgICAgIHRoaXMuZGljdFRhbmtzW3Rhbmtfc2NyaXB0LmdpZF0gPSB0YW5rX3NjcmlwdDtcblxuICAgICAgICAgICAgICAgIHRoaXMudF9hZGRfdGFuaysrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGFua19zY3JpcHQudXBkYXRlRnJhbWUob2JqX2luZm8pO1xuICAgICAgICAgICAgaWYgKHRoaXMuVEFOS0lEID09PSB0YW5rTnVtYmVySUQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLk1ZUExBWUVSLmFjdGl2ZUluZm8gPSBvYmpfaW5mbztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoIXRoaXMuTVlQTEFZRVIuaXNBY3RpdmVTQykge1xuICAgICAgICAgICAgdGhpcy5pc092ZXIgPSB0cnVlO1xuICAgICAgICB9XG4gICAgfSxcblxuICAgIG1hbmFnZXJPYnM6IGZ1bmN0aW9uIG1hbmFnZXJPYnMoYXJyX29icykge1xuICAgICAgICBmb3IgKHZhciBpX28gPSAwLCBqX29fbSA9IGFycl9vYnMubGVuZ3RoOyBpX28gPCBqX29fbTsgaV9vKyspIHtcbiAgICAgICAgICAgIHZhciB0bXBfaW5mbyA9IFV0aWxzLmRlY29kZVBhY2tPYnMoYXJyX29ic1tpX29dKTtcblxuICAgICAgICAgICAgdmFyIG9ic19zY3JpcHQgPSB0aGlzLmRpY3RPYnNbdG1wX2luZm8uaWRdO1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBvYnNfc2NyaXB0ID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgICAgICAgICAgLy8gVXRpbHMubG9nKFwiQWRkIG5ldyBPYnN0YWNsZXNcIik7XG4gICAgICAgICAgICAgICAgdmFyIHRtcF9PYnMgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLm9ic19wcmVmYWIpO1xuICAgICAgICAgICAgICAgIHRtcF9PYnMub2JqX3R5cGUgPSAxO1xuICAgICAgICAgICAgICAgIHRtcF9PYnMuZ2lkID0gdG1wX2luZm8uaWQ7XG4gICAgICAgICAgICAgICAgdG1wX09icy5zZXRMb2NhbFpPcmRlcigyKTtcblxuICAgICAgICAgICAgICAgIG9ic19zY3JpcHQgPSB0bXBfT2JzLmdldENvbXBvbmVudChcIm9ic1NjcmlwdFwiKTtcbiAgICAgICAgICAgICAgICBvYnNfc2NyaXB0LmdpZCA9IHRtcF9pbmZvLmlkO1xuICAgICAgICAgICAgICAgIG9ic19zY3JpcHQuaW5pdERpc3BsYXkodG1wX2luZm8pO1xuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5hZGRDaGlsZCh0bXBfT2JzKTtcblxuICAgICAgICAgICAgICAgIHRoaXMuZGljdE9ic1tvYnNfc2NyaXB0LmdpZF0gPSBvYnNfc2NyaXB0O1xuXG4gICAgICAgICAgICAgICAgdGhpcy50X2FkZF9vYnMrKztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG9ic19zY3JpcHQubm9kZS5pc0FjdGl2ZVNDID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBtYW5hZ2VyQnVsbGV0OiBmdW5jdGlvbiBtYW5hZ2VyQnVsbGV0KGFycl9idWxsZXQpIHtcbiAgICAgICAgZm9yICh2YXIgaV9iID0gMCwgal9iX20gPSBhcnJfYnVsbGV0Lmxlbmd0aDsgaV9iIDwgal9iX207IGlfYisrKSB7XG4gICAgICAgICAgICB2YXIgdG1wX2luZm8gPSBVdGlscy5kZWNvZGVQYWNrQnVsbGV0KGFycl9idWxsZXRbaV9iXSk7XG4gICAgICAgICAgICB2YXIgYnVsbGV0X3NjcmlwdCA9IHRoaXMuZGljdEJ1bGxldHNbdG1wX2luZm8uaWRdO1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBidWxsZXRfc2NyaXB0ID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgICAgICAgICAgLy8gVXRpbHMubG9nKFwiQWRkIG5ldyBCdWxsZXRcIik7XG4gICAgICAgICAgICAgICAgdGhpcy50X2FkZF9idWxsZXQrKztcbiAgICAgICAgICAgICAgICB2YXIgdG1wX0J1bGxldCA9IGNjLmluc3RhbnRpYXRlKHRoaXMuYnVsbGV0X3ByZWZhYik7XG4gICAgICAgICAgICAgICAgdG1wX0J1bGxldC5vYmpfdHlwZSA9IDM7XG4gICAgICAgICAgICAgICAgdG1wX0J1bGxldC5naWQgPSB0bXBfaW5mby5pZDtcbiAgICAgICAgICAgICAgICB0bXBfQnVsbGV0LnNldExvY2FsWk9yZGVyKDEpO1xuXG4gICAgICAgICAgICAgICAgYnVsbGV0X3NjcmlwdCA9IHRtcF9CdWxsZXQuZ2V0Q29tcG9uZW50KFwiYnVsbGV0U2NyaXB0XCIpO1xuICAgICAgICAgICAgICAgIGJ1bGxldF9zY3JpcHQuZ2lkID0gdG1wX2luZm8uaWQ7XG5cbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUuYWRkQ2hpbGQodG1wX0J1bGxldCk7XG5cbiAgICAgICAgICAgICAgICB0aGlzLmRpY3RCdWxsZXRzW2J1bGxldF9zY3JpcHQuZ2lkXSA9IGJ1bGxldF9zY3JpcHQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBidWxsZXRfc2NyaXB0LnVwZGF0ZUZyYW1lKHRtcF9pbmZvKTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBtYW5hZ2VySXRlbXM6IGZ1bmN0aW9uIG1hbmFnZXJJdGVtcyhhcnJfaXRlbXMpIHtcbiAgICAgICAgZm9yICh2YXIgaV9pID0gMCwgal9pX20gPSBhcnJfaXRlbXMubGVuZ3RoOyBpX2kgPCBqX2lfbTsgaV9pKyspIHtcbiAgICAgICAgICAgIHZhciB0bXBfaW5mbyA9IFV0aWxzLmRlY29kZVBhY2tJdGVtKGFycl9pdGVtc1tpX2ldKTtcbiAgICAgICAgICAgIHZhciBpdGVtX3NjcmlwdCA9IHRoaXMuZGljdEl0ZW1zW3RtcF9pbmZvLmlkXTtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgaXRlbV9zY3JpcHQgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgICAgICAgICAvL1V0aWxzLmxvZyhcIkFkZCBuZXcgaXRlbVwiKTtcbiAgICAgICAgICAgICAgICB2YXIgdG1wX0l0ZW07XG4gICAgICAgICAgICAgICAgaWYgKHRtcF9pbmZvLnR5cGUgPT0gMSkge1xuICAgICAgICAgICAgICAgICAgICB0bXBfSXRlbSA9IGNjLmluc3RhbnRpYXRlKHRoaXMuaXRlbV9hbW1vX3ByZWZhYik7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdG1wX0l0ZW0gPSBjYy5pbnN0YW50aWF0ZSh0aGlzLml0ZW1faGVhbHRoX3ByZWZhYik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRtcF9JdGVtLm9ial90eXBlID0gNDtcbiAgICAgICAgICAgICAgICB0bXBfSXRlbS5naWQgPSB0bXBfaW5mby5pZDtcbiAgICAgICAgICAgICAgICB0bXBfSXRlbS5zZXRMb2NhbFpPcmRlcigxKTtcblxuICAgICAgICAgICAgICAgIGl0ZW1fc2NyaXB0ID0gdG1wX0l0ZW0uZ2V0Q29tcG9uZW50KFwiaXRlbVNjcmlwdFwiKTtcbiAgICAgICAgICAgICAgICBpdGVtX3NjcmlwdC5naWQgPSB0bXBfaW5mby5pZDtcblxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5hZGRDaGlsZCh0bXBfSXRlbSk7XG5cbiAgICAgICAgICAgICAgICB0aGlzLmRpY3RJdGVtc1tpdGVtX3NjcmlwdC5naWRdID0gaXRlbV9zY3JpcHQ7XG5cbiAgICAgICAgICAgICAgICB0aGlzLnRfYWRkX2l0ZW1zKys7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpdGVtX3NjcmlwdC51cGRhdGVEaXNwbGF5KHRtcF9pbmZvKTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICB1cGRhdGVNYXBQb3NpdGlvbjogZnVuY3Rpb24gdXBkYXRlTWFwUG9zaXRpb24oKSB7XG4gICAgICAgIGlmICh0aGlzLmlzT3Zlcikge1xuICAgICAgICAgICAgdGhpcy5vdGhlck1TRyA9IFwidGhpcy5pc092ZXJcIjtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5NWVBMQVlFUiA9PT0gbnVsbCkge1xuICAgICAgICAgICAgdGhpcy5vdGhlck1TRyA9IFwiTVlQTEFZRVI9PT1udWxsXCI7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuVEFOS0lEID09IHRoaXMuTVlQTEFZRVIuZ2lkKSB7XG4gICAgICAgICAgICB2YXIgeF9wb3MgPSAtdGhpcy5NWVBMQVlFUi54O1xuICAgICAgICAgICAgdmFyIHlfcG9zID0gLXRoaXMuTVlQTEFZRVIueTtcbiAgICAgICAgICAgIC8vdGhpcy5ub2RlLnNldFBvc2l0aW9uKGNjLnAoeF9wb3MseV9wb3MpKTtcbiAgICAgICAgICAgIHRoaXMubm9kZS54ID0geF9wb3MgKiAyOyAvLyBuaGFuIDIgYm9pIHZpIG1hcCBnYW1lIHNjYWxlID0yXG4gICAgICAgICAgICB0aGlzLm5vZGUueSA9IHlfcG9zICogMjtcbiAgICAgICAgICAgIHRoaXMub3RoZXJNU0cgPSBcIlwiO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5vdGhlck1TRyA9IFwidGhpcy5UQU5LSUQ9XCIgKyB0aGlzLlRBTktJRCArIFwiIHwgTVlQTEFZRVIuZ2lkOiBcIiArIE1ZUExBWUVSLmdpZDtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBlc3RpbWF0ZU1vdmVUYW5rOiBmdW5jdGlvbiBlc3RpbWF0ZU1vdmVUYW5rKCkge1xuICAgICAgICAvKipcbiAgICAgICAgKnNlcnZlciBtYWMgZGluaCBsdW9uIHB1c2ggdmUgbGEgODAvMTAwMCBcbiAgICAgICAgKiBkdF9tb3ZlPXNwZWVkKjAuMDhcbiAgICAgICAgKiBcbiAgICAgICAgKi9cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEdJ4bqiSSBUSMONQ0ggOlxuICAgICAgICAgKiBIw6BtIG7DoHkgY2jhu4kgbMOgIGzDoG0gbcaw4bujdCBjaHV54buDbiDEkeG7mW5nIGPhu6dhIHhlIHRhbmsgdsOgIGdp4bqjbSBi4bubdCB2aeG7h2Mg4bufIGJhY2tlbmQgY+G7qSA0MC8xMDAwcyBsw6AgMjUgbOG6p24gMXMgdGjDrCBnaeG7nVxuICAgICAgICAgKiBjaOG7iSBj4bqnbiBsw6AgMXMgcHVzaCB24buBIDEyIGzhuqduIHRow7RpICwgbuG6v3UgY29tbWVudCBs4bqhaSBow6BtIG7DoHkgdsOgIGtow7RuZyBjaOG6oXkgIGPFqW5nIGtow7RuZyBzYW8gbmjGsCB0csO0bmcgbsOzIHLhuqV0IGdp4bqtdCBnYW1lXG4gICAgICAgICAqXG4gICAgICAgICAqIDEuQ8OhY2ggY8WpIGzDoCBsaXZlc3RyZWFtIHbhu4sgdHLDrSBj4bunYSBjw6FjIE9iamVjdCB0cm9uZyBnYW1lXG4gICAgICAgICAqICAgICAgVOG7qWMgbMOgIHbDrSBk4bulIOG7nyBmcmFtZTEgeGUgdGFuayDhu58gduG7iyB0csOtIDEsIHNhdSDEkcOzIOG7nyBmcmFtZTIgbOG6oWkgc2V0IHbhu4sgdHLDrSBjaG8geGUgdGFuayDhu58gduG7iyB0csOtIFAyLi5cbiAgICAgICAgICogICAgICBDw6FjaCBuw6B5IHJlYWx0aW1lIHbDoCBsdcO0biBuaMawbmcgbmjGsOG7o2MgxJFp4buDbSBsw6AgY+G6p24gdOG7qyBiYWNrZW5kIHB1c2ggZGF0YSB24buBIGxpw6puIHThu6VjXG4gICAgICAgICAqIDIuQ8OhY2ggbeG7m2kgbMOgIHTDrW5oIHRvw6FuIMSRxrDhu51uZyDEkWkgdMawxqFuZyDEkeG7kWkgY+G7p2EgeGUgdGFuayB2w6AgY+G7qSAwLjA4cyBs4bqhaSDEkeG7k25nIGLhu5kgduG7m2kgc2VydmVyIDEgbOG6p25cbiAgICAgICAgICogICAgICBWw60gZOG7pSDhu58gZnJhbWUxIHhlIHRhbmsgxJFhbmcg4bufIHbhu4sgdHLDrSBsw6AgQTEgdsOgIGjGsOG7m25nIMSRaSBj4bunYSB0YW5rIGzDoCDEkeG6v24gduG7iyB0csOtIEEyIOG7nyBmcmFtZSBzYXUgduG6rXkgbcOsbmggdOG6oW9cbiAgICAgICAgICogICAgICByYSAxIGNodXnhu4NuIMSR4buZbmcgY+G7qSAwLjAwMXMgbOG6oWkgY2hvIHhlIHRhbmsgbmjDrWNoIDEgxJFv4bqhbiB04bubaSB24buLIHRyw60gY+G7p2EgQTIoIHbhuq1uIHThu5FjIMSRw6MgYmnhur90IHLhu5NpKSAsIHbDoCDEkcOqblxuICAgICAgICAgKiAgICAgIGZyYW1lMiBi4bqldCBr4buDIHhlIHRhbmsgxJHDoyBuaMOtY2ggxJHhur9uIGhheSDEkWkgcXXDoSB24buLIHRyw60gc28gduG7m2kgZnJhbWUyIHRy4bqjIHbhu4EgdGjDrCBjxaluZyBzZXQgcG9zaXRpb24gY2hvIHRhbmtcbiAgICAgICAgICogICAgICDhu58gduG7iyB0csOtIGZyYW1lMiB0cuG6oyB24buBIGFuaCB4ZW0g4bufIGjDoG0gbWFuYWdlclRhbmtcbiAgICAgICAgICpcbiAgICAgICAgICpcbiAgICAgICAgICogICAgICAtQ8OhY2ggbMOgbSB0xrDGoW5nIHThu7EgbmjGsCB24bqteSDEkeG7kWkgduG7m2kgdmnDqm4gxJHhuqFuICx0dXkgbmhpw6puIHbhu5tpIHZpw6puIMSR4bqhbiBz4bq9IGPDsyBjaMO6dCBs4buXaSB44bqjeSByYSBsw6AgZ2nhu69hIMSRxrDhu51uZ1xuICAgICAgICAgKiAgICAgIHZpw6puIMSR4bqhbiB2YSB2w6BvIGNoxrDhu5tuZyBuZ+G6oWkgduG6rXQgaG/hurdjIHZhIHbDoG8geGUgdGFuayBtw6AgY2xpZW50IHbhuqtuIGNoxrBhIMSRxrDhu6NjIGPhuq1wIG5o4bqtdCBzcGVlZCDEkeG6oW4gbMOgIDQwMFxuICAgICAgICAgKiAgICAgIHbDoCB0aW1lIGzDoCAwLjA4IHbhuq15IHPhur0gY8OzIHRyxrDhu51uZyBo4bujcCDEkeG6oW4g4bufIGNsaWVudCB24bqrbiBj4bupIMSRaSB0aOG6s25nIHNhaSBz4buRIHbhu5tpIHNlcnZlciBsw6AgNDAwKjAuMDg9MzIgcHhcbiAgICAgICAgICogICAgICBjw6FpIG7DoHkgY2xpZW50IHRo4bqleSBy4bqldCByw7UgcsOgbmdcbiAgICAgICAgICpcbiAgICAgICAgICogICAgICAtTeG7mXQgbOG7l2kgbuG7r2EgbMOgIHRyw6puIHRyw6xuaCBkdXnhu4d0IHdlYiBraMO0bmcgaGnhu4N1IHNhbyBs4bqhaSBsYWcgLCBu4bq/dSBraMO0bmcgxJHGsOG7o2MgdGjDrCBiYWNrZW5kIGNo4bqvYyBwaOG6o2kgaWYgLGVsc2UgY29kZVxuICAgICAgICAgKiAgICAgIMSR4buDIHdlYiB24bqrbiBwdXNoIHbhu4EgbMOgIDAuMDRzIDEgbOG6p24gY8OybiBtb2JpbGUgbMOgIDAuMDggdsOgIG1vYmlsZSBz4bq9IGdp4bqjbSB04bqjaSDEkcaw4bujYyBk4buvIGxp4buHdSDEkWkgduG7gSBjaOG7iSBjw7MgMWtiL3NcbiAgICAgICAgICpcbiAgICAgICAgICAgICAgIC1jw7JuIG3hu5l0IHbhuqVuIMSR4buBIOG7nyBiYWNrZW5kIGzDoCB2w6wgbeG7l2kgZnJhbWUgbMOgIG3DrG5oIGNoZWNrIHbhu4sgdHLDrSBj4bunYSB2acOqbiDEkeG6oW4gc28gduG7m2kgY2jGsOG7m25nIG5n4bqhaSB24bqtdCBsw6AgdGhlb1xuICAgICAgICAgKiAgICAgIG3hu5dpIGZyYW1lICwgdHLGsOG7m2Mgw610IOG6o3kgcmEgc2FpIHPhu5EgdsOsIG3hu5dpIGZyYW1lIGPDoWNoIG5oYXUgMC4wNHMgdsOgIMSR4bqhbiDEkWkgY8OzIDE2cHggeCwgZ2nhu50gdGltZSBt4buXaSBmcmFtZSBjw6FjaFxuICAgICAgICAgKiAgICAgIG5oYXUgbMOqbiDEkeG6v24gMC4wOCB0aMOsIHNhaSBz4buRIHTEg25nIGzDqm4gdGhlbyAsIG5oxrBuZyBjw6FpIG7DoHkgbcOsbmggc+G7rWEgxJHGsOG7o2Mg4bufIHNlcnZlciB2w6AgbMOgbSBzYXVcbiAgICAgICAgICpcbiAgICAgICAgICpcbiAgICAgICAgICpcbiAgICAgICAgICovXG4gICAgICAgIC8vICAgICAgY2jDuiDDvSBsw6AgbuG6v3UgdGltZW91dCBxdcOhIGzhu5tuIHRow6wgcmV0dXJuIG5nYXkgaG/hurdjIGRpIGNodXnhu4NuIHF1w6EgduG7iyB0csOtIHTDrW5oIHRvw6FuIHRow6wgc3RvcCBs4bqhaVxuICAgICAgICAvLyAgICAgIDEgOiBsw6AgduG6q24gbsOqbiBsw6BtIGNo4bupYyBuxINuZyB0w61uaCB0b8OhbiB2YSBjaOG6oW0g4bufIGNsaWVudCDEkeG7kWkgduG7m2kgxJHhuqFuIHbDoCB0YW5rXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgdGhpcy5jb3VudFN0ZXAgPSAwO1xuICAgICAgICB2YXIgVElNRV9GUkFNRV9TRVJWRVIgPSAwLjA4O1xuICAgICAgICB0aGlzLnNjaGVkdWxlKGZ1bmN0aW9uIChkdCkge1xuICAgICAgICAgICAgdmFyIGNoZWNrQ29sbGlzaW9uID0gZmFsc2U7XG4gICAgICAgICAgICBpZiAoc2VsZi5jb3VudFN0ZXAgPT0gMCkge1xuICAgICAgICAgICAgICAgIGNoZWNrQ29sbGlzaW9uID0gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJDQ0NDQ0MtLS0tLS0tLS0tLS0tLS0tLS0tLS0tQUFBQS0tLS0tLS0tLS0tLS0tLS0tLS0tQUFBXCIpO1xuICAgICAgICAgICAgZm9yICh2YXIga2V5b2JqIGluIHNlbGYuZGljdFRhbmtzKSB7XG4gICAgICAgICAgICAgICAgdmFyIHRhbmtzY3JpcHQgPSBzZWxmLmRpY3RUYW5rc1trZXlvYmpdO1xuICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJ0YW5rc2NyaXB0LmRpck12OiBcIit0YW5rc2NyaXB0LmRpck12KTtcbiAgICAgICAgICAgICAgICB2YXIgbWF4TW92ZSA9IHRhbmtzY3JpcHQuc3BlZWRNb3ZlICogVElNRV9GUkFNRV9TRVJWRVI7XG4gICAgICAgICAgICAgICAgaWYgKHRhbmtzY3JpcHQubmV4dEZyYW1lTW92ZSA+PSBtYXhNb3ZlKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHZhciBkdF9tb3ZlID0gdGFua3NjcmlwdC5zcGVlZE1vdmUgKiBkdDtcbiAgICAgICAgICAgICAgICB0YW5rc2NyaXB0Lm5leHRGcmFtZU1vdmUgPSB0YW5rc2NyaXB0Lm5leHRGcmFtZU1vdmUgKyBkdF9tb3ZlO1xuICAgICAgICAgICAgICAgIHZhciB0bXBfdGFuayA9IHRhbmtzY3JpcHQubm9kZTtcbiAgICAgICAgICAgICAgICBpZiAodGFua3NjcmlwdC5kaXJNdiA+IDAgJiYgdGFua3NjcmlwdC5kaXJNdiA8IDUpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRhbmtzY3JpcHQuZGlyTXYgPT0gMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdG1wX3RhbmsueCA9IHRtcF90YW5rLnggKyBkdF9tb3ZlO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHRhbmtzY3JpcHQuZGlyTXYgPT0gMikge1xuICAgICAgICAgICAgICAgICAgICAgICAgdG1wX3RhbmsueSA9IHRtcF90YW5rLnkgKyBkdF9tb3ZlO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHRhbmtzY3JpcHQuZGlyTXYgPT0gMykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdG1wX3RhbmsueCA9IHRtcF90YW5rLnggLSBkdF9tb3ZlO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHRhbmtzY3JpcHQuZGlyTXYgPT0gNCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdG1wX3RhbmsueSA9IHRtcF90YW5rLnkgLSBkdF9tb3ZlO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcIkFBQUFBQUEtLS0tLS0tLS0tLS0tLS0tLS0tLS0tQUFBQS0tLS0tLS0tLS0tLS0tLS0tLS0tQUFBXCIpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBzZWxmLnVwZGF0ZU1hcFBvc2l0aW9uKCk7XG5cbiAgICAgICAgICAgIGZvciAodmFyIGtleV9iIGluIHNlbGYuZGljdEJ1bGxldHMpIHtcbiAgICAgICAgICAgICAgICB2YXIgYnVsbGV0X3NjcmlwdCA9IHNlbGYuZGljdEJ1bGxldHNba2V5X2JdO1xuICAgICAgICAgICAgICAgIHZhciBkdE12ID0gNDAwICogZHQ7XG4gICAgICAgICAgICAgICAgdmFyIG1heE1vdmUgPSA0MDAgKiBUSU1FX0ZSQU1FX1NFUlZFUjtcbiAgICAgICAgICAgICAgICBpZiAoYnVsbGV0X3NjcmlwdC5uZXh0RnJhbWVNb3ZlID49IG1heE1vdmUpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGJ1bGxldF9zY3JpcHQubmV4dEZyYW1lTW92ZSA9IGJ1bGxldF9zY3JpcHQubmV4dEZyYW1lTW92ZSArIGR0TXY7XG4gICAgICAgICAgICAgICAgdmFyIGNvbnZlcnRfYW5nbGUgPSBidWxsZXRfc2NyaXB0LmFuZ2xlTW92ZSAqIDMuMTQ1OTIgLyAxODA7XG4gICAgICAgICAgICAgICAgdmFyIHRtcFBvcyA9IGNjLnAoYnVsbGV0X3NjcmlwdC5ub2RlLnggKyBkdE12ICogTWF0aC5jb3MoY29udmVydF9hbmdsZSksIGJ1bGxldF9zY3JpcHQubm9kZS55ICsgZHRNdiAqIE1hdGguc2luKGNvbnZlcnRfYW5nbGUpKTtcblxuICAgICAgICAgICAgICAgIGlmIChjaGVja0NvbGxpc2lvbikge1xuICAgICAgICAgICAgICAgICAgICAvLyBuZXUgY28gdmEgY2hhbSB4YXkgcmEgdGhpICwgYnVsbGV0IGNvIG9wYWNpdHk9MCB2YSBsaW1pdCBwb3NpdGlvblxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5jaGVja0NvbGxpc2lvbldpdGhPYnN0YWNibGUodG1wUG9zKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYnVsbGV0X3NjcmlwdC5ub2RlLm9wYWNpdHkgPSAwO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoZWNrQ29sbGlzaW9uV2l0aFRhbmsodG1wUG9zKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYnVsbGV0X3NjcmlwdC5ub2RlLm9wYWNpdHkgPSAwO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgYnVsbGV0X3NjcmlwdC5ub2RlLnggPSB0bXBQb3MueDtcbiAgICAgICAgICAgICAgICBidWxsZXRfc2NyaXB0Lm5vZGUueSA9IHRtcFBvcy55O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBzZWxmLmNvdW50U3RlcCA9IHNlbGYuY291bnRTdGVwICsgMTtcbiAgICAgICAgICAgIGlmIChzZWxmLmNvdW50U3RlcCA+PSAzKSB7XG4gICAgICAgICAgICAgICAgc2VsZi5jb3VudFN0ZXAgPSAwO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LCAwLjAwMSk7XG4gICAgfSxcbiAgICBvbkRpc2FibGU6IGZ1bmN0aW9uIG9uRGlzYWJsZSgpIHtcbiAgICAgICAgdGhpcy51bnNjaGVkdWxlQWxsQ2FsbGJhY2tzKCk7XG4gICAgfSxcblxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuICAgIC8vIH0sXG5cbiAgICBjaGVja0NvbGxpc2lvbldpdGhPYnN0YWNibGU6IGZ1bmN0aW9uIGNoZWNrQ29sbGlzaW9uV2l0aE9ic3RhY2JsZShvYmpfYikge1xuICAgICAgICB2YXIgaXNDID0gZmFsc2U7XG4gICAgICAgIGZvciAodmFyIGtleW9iaiBpbiB0aGlzLmRpY3RPYnMpIHtcbiAgICAgICAgICAgIHZhciBvYnNfc2MgPSB0aGlzLmRpY3RPYnNba2V5b2JqXTtcbiAgICAgICAgICAgIGlmIChvYmpfYi54ID4gb2JzX3NjLm1pbl94ICYmIG9ial9iLnggPCBvYnNfc2MubWF4X3ggJiYgb2JqX2IueSA8IG9ic19zYy5tYXhfeSAmJiBvYmpfYi55ID4gb2JzX3NjLm1pbl95KSB7XG4gICAgICAgICAgICAgICAgaXNDID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAob2JqX2IueCA+IDE0NzUgfHwgb2JqX2IueCA8IC0xNDc1IHx8IG9ial9iLnkgPiA5NzUgfHwgb2JqX2IueSA8IC05NzUpIHtcbiAgICAgICAgICAgIGlzQyA9IHRydWU7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gaXNDO1xuICAgIH0sXG4gICAgY2hlY2tDb2xsaXNpb25XaXRoVGFuazogZnVuY3Rpb24gY2hlY2tDb2xsaXNpb25XaXRoVGFuayhvYmpfYikge1xuICAgICAgICB2YXIgaXNDID0gZmFsc2U7XG4gICAgICAgIGZvciAodmFyIGtleW9iaiBpbiB0aGlzLmRpY3RUYW5rcykge1xuICAgICAgICAgICAgdmFyIG9ic19zYyA9IHRoaXMuZGljdFRhbmtzW2tleW9ial07XG4gICAgICAgICAgICBpZiAob2JqX2IueCA+IG9ic19zYy5taW5feCAmJiBvYmpfYi54IDwgb2JzX3NjLm1heF94ICYmIG9ial9iLnkgPCBvYnNfc2MubWF4X3kgJiYgb2JqX2IueSA+IG9ic19zYy5taW5feSkge1xuICAgICAgICAgICAgICAgIGlzQyA9IHRydWU7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGlzQztcbiAgICB9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2RlNmI1bjU5ZXBHemFWcGdHSVJjSlZpJywgJ0dhbWVQbGF5U2NyaXB0Jyk7XG4vLyBTY3JpcHQvR2FtZXNjcmlwdC9HYW1lUGxheVNjcmlwdC5qc1xuXG5cbnZhciBVdGlscyA9IHJlcXVpcmUoJy4uL0xJQi9VdGlscycpO1xuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIGh1Yl9wcmVmYWI6IHtcbiAgICAgICAgICAgIHR5cGU6IGNjLlByZWZhYixcbiAgICAgICAgICAgIFwiZGVmYXVsdFwiOiBudWxsXG4gICAgICAgIH0sXG4gICAgICAgIGxiU3RhdHVzOiB7XG4gICAgICAgICAgICB0eXBlOiBjYy5MYWJlbCxcbiAgICAgICAgICAgIFwiZGVmYXVsdFwiOiBudWxsXG4gICAgICAgIH0sXG4gICAgICAgIG5vZGVjb250cm86IGNjLk5vZGUsXG4gICAgICAgIHBhbmVsSW5mbzogY2MuTm9kZSxcbiAgICAgICAgZ2FtZU1hcDoge1xuICAgICAgICAgICAgdHlwZTogY2MuTm9kZSxcbiAgICAgICAgICAgIFwiZGVmYXVsdFwiOiBudWxsXG4gICAgICAgIH0sXG4gICAgICAgIGFycm93Tm9kZTogY2MuTm9kZSxcbiAgICAgICAgdGlueVBsYXllcjogY2MuTm9kZSxcbiAgICAgICAgbGJzY29yZTogY2MuTGFiZWwsXG4gICAgICAgIHRlc3Rub2R4eDoge1xuICAgICAgICAgICAgdHlwZTogY2MuUHJlZmFiLFxuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGxcbiAgICAgICAgfSxcblxuICAgICAgICB0aW55TWFwR3JhcHBoaWM6IGNjLkdyYXBoaWNzXG4gICAgfSxcbiAgICBhY3Rpb25CYWNrSG9tZTogZnVuY3Rpb24gYWN0aW9uQmFja0hvbWUoKSB7XG4gICAgICAgIHRoaXMuc29ja2V0LmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiSG9tZVNjZW5lXCIpO1xuICAgIH0sXG5cbiAgICBMaXN0ZW5OYXRpdmVIaWRkZW46IGZ1bmN0aW9uIExpc3Rlbk5hdGl2ZUhpZGRlbigpIHtcbiAgICAgICAgLy9nYW1lX29uX2hpZGVcbiAgICAgICAgaWYgKGNjLnN5cy5pc05hdGl2ZSkge1xuICAgICAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICAgICAgdGhpcy5sc3RuciA9IGNjLkV2ZW50TGlzdGVuZXJDdXN0b20uY3JlYXRlKFwiZ2FtZV9vbl9oaWRlXCIsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBzZWxmLnNvY2tldC5kaXNjb25uZWN0KCk7XG4gICAgICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiSG9tZVNjZW5lXCIpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBjYy5ldmVudE1hbmFnZXIuYWRkTGlzdGVuZXIodGhpcy5sc3RuciwgdGhpcyk7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIC8qKiBcbiAgICAgICAgICogQ8ahIGLhuqNuIHRyb25nIEVuZ2luZSBjb2NvczogY+G6pXAgY2FvIG5o4bqldCB2w6AgY2jhu6lhIHThuqV0IGPhuqMgY8OhYyDEkeG7kWkgdMaw4bujbmcgdHJvbmcgZ2FtZSBsw6Agc2NlbmUsIHRyb25nIHNjZW5lIGNo4bupYSBjw6FjIGNoaWxkIG5oxrAgbMOgIENhbnZhcywgTm9kZSwgU3ByaXRlICxMYWJlbCxidXR0b24uLi4uIGV0YyBcbiAgICAgICAgICogY8OhYyBjaGlsZCBuw6B5IHPhur0gY8OzIGPDoWMgdGh14buZYyB0w61uaCBjxqEgYuG6o24gdOG7qyBOb2RlIG5oxrAgcG9zaXRpb24sc2NhbGUscm90YXRpb24sQW5jaG9yIHBvaW50IC4uLlxuICAgICAgICAgKiBM4bubcCBOb2RlIGzDoCBs4bubcCBiYXNlIGNo4bupYSBjw6FjIMSR4buRaSB0xrDhu6NuZyAsU3ByaXRlLExhYmVsLEJ1dHRvbi4uLiDEkeG7gXUgbMOgIGvhur8gdGjhu6thIHThu6sgTm9kZSB2w6AgY8OzIGPDoWMgdGh14buZYyB0w61uaCBj4bunYSBub2RlLCBuZ2/DoGkgcmEgduG7m2kgbeG7l2kgxJHhu5FpIHTGsOG7o25nIGPDsyB0aMOqbSB0aHXhu5ljIHTDrW5oIHJpw6puZyBj4bunYSBtw6xuaFxuICAgICAgICAgKiAgLVNwcml0ZSBsw6AgxJHhu5FpIHTGsOG7o25nIMSRxrDhu6NjIGTDuW5nIMSR4buDIHRoaeG7g24gdGjhu4sgMSBi4bupYyDhuqNuaCBjxqEgY2jhur8gxJHhu4MgbG9hZCAxIGLhu6ljIOG6o25oIGltYWdlX2ZpbGUtPnRleHR1cmUtPnNwcml0ZWZyYW1lLS0tLS0+U3ByaXRlIFxuICAgICAgICAgKiAgICAgICAgICB0cm9uZyDEkcOzIFNwcml0ZSBjaOG7iSBoaeG7g24gdGjhu4sgc3ByaXRlRnJhbWUsIHbDrSBk4bulIG3DrG5oIGPDsyB0aOG7gyB04bqhbyAxIFNwcml0ZSBoaeG7g24gdGjhu4sgdHLDqm4gbcOgbiBow6xuaCBsw6AgMSDhuqNuaCBow6xuaCB0csOybiBtw6B1IMSR4buPLCBraGkgdG91Y2ggdsOgbyB0aMOsIGxvYWQgMSBzcHJpdGVGcmFtZSBtw6B1IHhhbmggXG4gICAgICAgICAqICAgICAgICAgICxyZWxlYXNlIHRow6wgbG9hZCBs4bqhaSBzcHJpdGVGcmFtZSBtw6B1IMSR4buPIFxuICAgICAgICAgKiBcbiAgICAgICAgICogQuG6pXQgY+G7qSDEkeG7kWkgdMaw4bujbmcgVUkgbsOgbyB0cm9uZyBnYW1lIMSR4buBdSBjw7MgdGjhu4MgdOG6oW8gMSBzY3JpcHQgxJHhu4EgxJFp4buBdSBraGnhu4NuIMSR4buRaSB0xrDhu6NuZyDEkcOzLCB2w60gZOG7pSBjw7MgMSDEkeG7kWkgdMaw4bujbmcgbMOgIHhlIHRhbmsgdGjDrCB0cm9uZyB4ZSB0YW5rIGPDsyB0aOG7gyB04bqhbyAxIGhv4bq3YyBuaGnhu4F1IHNjcmlwdCDEkeG7gyDEkWnhu4F1IGtoaeG7g24gXG4gICAgICAgICAqIHhlIHRhbmssIHR1eSBuaGnDqm4gdOG6oW8gbmhp4buBdSBzY3JpcHQgc+G6vSBk4buFIGThuqtuIMSR4bq/biB4dW5nIMSR4buZdCBraMOzIGLhuq90IGzhu5dpIFxuICAgICAgICAgKiAgICAgdOG7qyDEkeG7kWkgdMaw4bujbmcgVUkgbXXhu5FuIGfhu41pIHJhIHNjcmlwdCBj4bunYSB4ZSB0YW5rIHRow6wgZ+G7jWkgYuG6sW5nIGPDoWNoIFxuICAgICAgICAgKiAgICAgICAgICB2YXIgc2NyaXB0T2JqPVVJX09iamVjdC5nZXRDb21wb25lbnQoXCJTY3JpcHROYW1lXCIpOy0tPiBi4bufIHbDrCAxIG5vZGUgY8OzIHRo4buDIGNo4bupYSBuaGnhu4F1IHNjcmlwdCBuw6puIHBo4bqjaSBn4buNaSB0aOG6vyBuw6B5XG4gICAgICAgICAqICAgICBuZ8aw4bujYyBs4bqhaSB04burIDEgc2NyaXB0IG114buRbiBn4buNaSBs4bqhaSDEkeG7kWkgdMaw4bujbmcgVUlfT2JqZWN0IHRow6wgY2jhu4kgY+G6p24gZ+G7jWkgXG4gICAgICAgICAqICAgICAgICAgIHZhciB1aV9vYmo9c2NyaXB0X29iai5ub2RlOy0tLT4gbeG7mXQgxJHhu5FpIHTGsOG7o25nIHNjcmlwdCBjaOG7iSBjw7MgdGjhu4MgxJFp4buBdSBraGnhu4NuIGR1eSBuaOG6pXQgMSBub2RlIFxuICAgICAgICAgKiAgICAg4bufIGTDsm5nIGNvZGUgdHLDqm4gdWlfb2JqIGPDsyB0aOG7gyBsw6AgTGFiZWwsIEJ1dHRvbiwgU3ByaXRlLi4uIHR1eSBuaGnDqm4gdGjDrCBjbGFzcyBOb2RlIGzDoCBjaGEgdsOgIMSR4bqhaSBkaeG7h24gY2h1bmcgY2hvIHThuqV0IGPhuqMgY8OhYyDEkeG7kWkgdMaw4bujbmcgdHLDqm4gXG4gICAgICAgICAqICovXG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqICBIw6BtIE9ubG9hZCDEkcaw4bujYyBn4buNaSDEkeG6p3UgdGnDqm4gdHJvbmcgZ2FtZSB4ZW0gdGjDqm0g4bufIHVybCA6aHR0cDovL2NvY29zMmQteC5vcmcvZG9jcy9hcGktcmVmL2NyZWF0b3IvdjEuMS4yL2NsYXNzZXMvVGlsZWRMYXllci5odG1sI21ldGhvZF9vbkxvYWRcbiAgICAgICAgICogXG4gICAgICAgICAqIFxuICAgICAgICAgKiAqL1xuICAgICAgICBpZiAoY2Muc3lzLmlzTmF0aXZlKSB7XG4gICAgICAgICAgICB0aGlzLkxpc3Rlbk5hdGl2ZUhpZGRlbigpO1xuICAgICAgICB9XG5cbiAgICAgICAgdmFyIHNjcmlwdF9jb250cm9sbGVyID0gdGhpcy5ub2RlY29udHJvLmdldENvbXBvbmVudChcIlBhZENvbnRyb2xsZXJcIik7XG4gICAgICAgIHNjcmlwdF9jb250cm9sbGVyLm1haW5zY3JpcHQgPSB0aGlzO1xuXG4gICAgICAgIHRoaXMubWFwU2NyaXB0ID0gdGhpcy5nYW1lTWFwLmdldENvbXBvbmVudChcIkdhbWVNYXBcIik7IC8vIGzhuqV5IHJhIHNjcmlwdCBj4bunYSDEkeG7kWkgdMaw4bujbmcgZ2FtZW1hcFxuXG4gICAgICAgIHRoaXMucGFuZWxJbmZvU2NyaXB0ID0gdGhpcy5wYW5lbEluZm8uZ2V0Q29tcG9uZW50KFwiUGFuZWxVc2VySW5mb1wiKTtcblxuICAgICAgICB0aGlzLmFjdGlvbkxpc3RlbktleVByZXNzKCk7IC8vc+G7rSBk4bulbmcgY2hvIHZp4buHYyBuaOG6pW4gcGjDrW0gxJHhu4MgZGkgY2h1eeG7g24geGUgdGFuayB3ZWIgdmVyc2lvblxuXG4gICAgICAgIC8vdGhpcy5hZGRUb3VjaExpc3RlbkV2ZW50KCk7Ly8gc+G7rSBk4bulbmcgY2hvIHZp4buHYyB0b3VjaCBtb2JpbGUgdmVyc2lvblxuICAgICAgICBpZiAoVXRpbHMuZW5hYmxlU3dpcGUpIHtcbiAgICAgICAgICAgIHRoaXMuYXJyb3dOb2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAgICAgdGhpcy5hZGRUb3VjaEFuZFN3aXBlRXZlbnQoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuYXJyb3dOb2RlLmRlc3Ryb3koKTtcbiAgICAgICAgICAgIHRoaXMuYWRkVG91Y2hMaXN0ZW5FdmVudCgpO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy50aW1lbG9nID0gMDtcbiAgICAgICAgdGhpcy5hY3Rpb25Mb2FkR2FtZUJlZ2luKCk7IC8vIGNvbm5lY3QgxJHhur9uIHNlcnZlclxuXG4gICAgICAgIC8vVXRpbHMubGFzdHNjb3JlPTEwMztcbiAgICAgICAgdGhpcy5BZHNNYW5hZ2VyKCk7XG5cbiAgICAgICAgdGhpcy50ZXN0Y291bnRkcmF3ID0gMDtcbiAgICB9LFxuICAgIEFkc01hbmFnZXI6IGZ1bmN0aW9uIEFkc01hbmFnZXIoKSB7XG4gICAgICAgIGlmIChjYy5zeXMub3MgPT0gY2Muc3lzLk9TX0lPUykge1xuICAgICAgICAgICAganNiLnJlZmxlY3Rpb24uY2FsbFN0YXRpY01ldGhvZChcIkJyaWRnZUlPU1wiLCBcIkhpZGRlbkFkc0JhbmVyV2l0aEFuaW1hdGlvblwiKTtcbiAgICAgICAgfSBlbHNlIGlmIChjYy5zeXMub3MgPT0gY2Muc3lzLk9TX0FORFJPSUQpIHt9IGVsc2Ugey8vIHBoaWVuIGJhbiB3ZWJcblxuICAgICAgICB9XG4gICAgfSxcblxuICAgIHJ1blVwZGF0ZUhpZ2hTY29yZTogZnVuY3Rpb24gcnVuVXBkYXRlSGlnaFNjb3JlKCkge30sXG5cbiAgICAvL2NhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgLy91cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuICAgIC8vICAgdGhpcy50aW1lbG9nPXRoaXMudGltZWxvZytkdDtcbiAgICAvLyAgIGlmKHRoaXMudGltZWxvZz4wLjMpe1xuICAgIC8vICAgICAgIHRoaXMudGltZWxvZz0wO1xuICAgIC8vICAgICAgIHZhciBsb2dzY3JlZW49XCJJRDpcIit0aGlzLm1hcFNjcmlwdC5UQU5LSUQrXCIgVGFuazpcIit0aGlzLm1hcFNjcmlwdC50X2FkZF90YW5rK1wiICBPYnM6XCIrdGhpcy5tYXBTY3JpcHQudF9hZGRfb2JzKyBcIiAgQnVsbGV0OlwiK3RoaXMubWFwU2NyaXB0LnRfYWRkX2J1bGxldCsgXCIgIGl0ZW06XCIrdGhpcy5tYXBTY3JpcHQudF9hZGRfaXRlbXM7XG4gICAgLy8gICAgICAgbG9nc2NyZWVuPWxvZ3NjcmVlbitcIiBleHA6XCIrdGhpcy5tYXBTY3JpcHQudF9hZGRfZXhwbG9zaW9uO1xuICAgIC8vICAgICAgIGxvZ3NjcmVlbj1sb2dzY3JlZW4rXCJcXG5cIit0aGlzLm1hcFNjcmlwdC5tc2dsb2crIFwiXFxuXCIrdGhpcy5tYXBTY3JpcHQub3RoZXJNU0c7XG4gICAgLy8gICAgICAgdGhpcy5sYlN0YXR1cy5zdHJpbmc9bG9nc2NyZWVuO1xuICAgIC8vICAgfVxuICAgIC8vfSxcblxuICAgIG9uRGlzYWJsZTogZnVuY3Rpb24gb25EaXNhYmxlKCkge1xuICAgICAgICB2YXIgc2NyaXB0X2NvbnRyb2xsZXIgPSB0aGlzLm5vZGVjb250cm8uZ2V0Q29tcG9uZW50KFwiUGFkQ29udHJvbGxlclwiKTtcbiAgICAgICAgc2NyaXB0X2NvbnRyb2xsZXIubWFpbnNjcmlwdCA9IG51bGw7XG4gICAgICAgIHRoaXMucGFuZWxJbmZvU2NyaXB0ID0gbnVsbDtcbiAgICAgICAgVXRpbHMubG9nKFwiR2FtZSBwbGF5ZXIgaXMgVW5sb2FkXCIpO1xuICAgICAgICBjYy5ldmVudE1hbmFnZXIucmVtb3ZlTGlzdGVuZXIodGhpcy50b3VjaExpc3Rlbik7XG4gICAgICAgIGNjLmV2ZW50TWFuYWdlci5yZW1vdmVMaXN0ZW5lcih0aGlzLmtleUV2ZW50TGlzdGVuKTtcbiAgICAgICAgaWYgKGNjLnN5cy5pc05hdGl2ZSkge1xuICAgICAgICAgICAgY2MuZXZlbnRNYW5hZ2VyLnJlbW92ZUxpc3RlbmVyKHRoaXMubHN0bnIpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gY2MuZXZlbnRNYW5hZ2VyLnJlbW92ZUFsbExpc3RlbmVycygpO1xuICAgIH0sXG5cbiAgICB1cGRhdGVNb3ZlQ29udHJvbGxlcjogZnVuY3Rpb24gdXBkYXRlTW92ZUNvbnRyb2xsZXIoZGlyX21vdmUpIHtcbiAgICAgICAgY2MubG9nKFwiZGlyX21vdmU6JXNcIiwgZGlyX21vdmUpO1xuICAgICAgICB2YXIgbnVtYmVyaW50ID0gcGFyc2VJbnQoZGlyX21vdmUpO1xuICAgICAgICBpZiAobnVtYmVyaW50ID49IDEgJiYgbnVtYmVyaW50IDw9IDQpIHtcbiAgICAgICAgICAgIHRoaXMuc29ja2V0LmVtaXQoXCJjaGFuZ2VEaXJcIiwgbnVtYmVyaW50KTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBhZGRUb3VjaExpc3RlbkV2ZW50OiBmdW5jdGlvbiBhZGRUb3VjaExpc3RlbkV2ZW50KCkge1xuXG4gICAgICAgIHRoaXMudG91Y2hMaXN0ZW4gPSBjYy5ldmVudE1hbmFnZXIuYWRkTGlzdGVuZXIoeyBldmVudDogY2MuRXZlbnRMaXN0ZW5lci5UT1VDSF9PTkVfQllfT05FLCBzd2FsbG93VG91Y2hlczogdHJ1ZSxcbiAgICAgICAgICAgIG9uVG91Y2hCZWdhbjogKGZ1bmN0aW9uICh0b3VjaCwgZXZlbnQpIHtcbiAgICAgICAgICAgICAgICAvL2NjLmxvZyhcIi0tLS0tLS0tLS0tYXNkYXNkYXNkYXNka2hrYXNqZGJrYWpzZHNha2pkaGFza2RoYXNramRoYWtqc2RoYXNrLS0tLS0tLS0tLS0tXCIpO1xuXG4gICAgICAgICAgICAgICAgLy90aGlzLmlzRmlyZT10cnVlO1xuICAgICAgICAgICAgICAgIC8vdGhpcy5iZWdpblBvcyA9IHRoaXMubm9kZS5jb252ZXJ0VG9Ob2RlU3BhY2UodG91Y2guZ2V0TG9jYXRpb24oKSk7XG5cbiAgICAgICAgICAgICAgICB2YXIgcG9zID0gdGhpcy5ub2RlLmNvbnZlcnRUb05vZGVTcGFjZSh0b3VjaC5nZXRMb2NhdGlvbigpKTtcbiAgICAgICAgICAgICAgICBwb3MueCA9IHBvcy54IC0gY2Mud2luU2l6ZS53aWR0aCAvIDI7XG4gICAgICAgICAgICAgICAgcG9zLnkgPSBwb3MueSAtIGNjLndpblNpemUuaGVpZ2h0IC8gMjtcbiAgICAgICAgICAgICAgICB2YXIgdmZpcmUgPSBjYy5wTm9ybWFsaXplKGNjLnYyKHBvcy54LCBwb3MueSkpO1xuICAgICAgICAgICAgICAgIHZhciBhbmdsZSA9IGNjLnBUb0FuZ2xlKHZmaXJlKTtcbiAgICAgICAgICAgICAgICBhbmdsZSA9IGFuZ2xlICogMTgwIC8gMy4xNDtcbiAgICAgICAgICAgICAgICBpZiAoYW5nbGUgPCAwKSB7XG4gICAgICAgICAgICAgICAgICAgIGFuZ2xlID0gMzYwICsgYW5nbGU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChhbmdsZSA+IDM2MCkge1xuICAgICAgICAgICAgICAgICAgICAvLyBzZSBraG9uZyBiYW8gZ2lvIHhheSByYSB0cnVvbmcgaG9wIG5heSB2aSBjb2NvczJkLWpzIGx1b24gdHJhIHZlIDEgZ29jIHR1IC0xODAsMTgwXG4gICAgICAgICAgICAgICAgICAgIGFuZ2xlID0gYW5nbGUgLSAzNjA7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8vdGhpcy5sYlN0YXR1cy5zdHJpbmc9XCJHT0MgZmFsc2UgQUFBPVwiK2FuZ2xlO1xuICAgICAgICAgICAgICAgIHRoaXMuc29ja2V0LmVtaXQoXCJmaXJlVGFyZ2V0XCIsIGFuZ2xlKTtcblxuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfSkuYmluZCh0aGlzKVxuXG4gICAgICAgIH0sIHRoaXMubm9kZSk7XG4gICAgfSxcblxuICAgIGFkZFRvdWNoQW5kU3dpcGVFdmVudDogZnVuY3Rpb24gYWRkVG91Y2hBbmRTd2lwZUV2ZW50KCkge1xuXG4gICAgICAgIHRoaXMudG91Y2hMaXN0ZW4gPSBjYy5ldmVudE1hbmFnZXIuYWRkTGlzdGVuZXIoeyBldmVudDogY2MuRXZlbnRMaXN0ZW5lci5UT1VDSF9PTkVfQllfT05FLCBzd2FsbG93VG91Y2hlczogdHJ1ZSxcbiAgICAgICAgICAgIG9uVG91Y2hCZWdhbjogKGZ1bmN0aW9uICh0b3VjaCwgZXZlbnQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmlzRmlyZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgdGhpcy5iZWdpblBvcyA9IHRoaXMubm9kZS5jb252ZXJ0VG9Ob2RlU3BhY2UodG91Y2guZ2V0TG9jYXRpb24oKSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9KS5iaW5kKHRoaXMpLFxuXG4gICAgICAgICAgICBvblRvdWNoTW92ZWQ6IChmdW5jdGlvbiAodG91Y2gsIGV2ZW50KSB7XG4gICAgICAgICAgICAgICAgLy90aGlzLmxiU3RhdHVzLnN0cmluZz1cInRvdWNoIG9uVG91Y2hNb3ZlZFwiO1xuICAgICAgICAgICAgfSkuYmluZCh0aGlzKSxcblxuICAgICAgICAgICAgb25Ub3VjaEVuZGVkOiAoZnVuY3Rpb24gKHRvdWNoLCBldmVudCkge1xuXG4gICAgICAgICAgICAgICAgdmFyIHBvcyA9IHRoaXMubm9kZS5jb252ZXJ0VG9Ob2RlU3BhY2UodG91Y2guZ2V0TG9jYXRpb24oKSk7XG4gICAgICAgICAgICAgICAgdmFyIGJ1a1BvcyA9IHRoaXMuYmVnaW5Qb3M7XG4gICAgICAgICAgICAgICAgdmFyIGRpc3RhbmNlID0gY2MucERpc3RhbmNlKHRoaXMuYmVnaW5Qb3MsIHBvcyk7XG4gICAgICAgICAgICAgICAgdmFyIHN0dF9tb3ZlZGlyID0gMDtcbiAgICAgICAgICAgICAgICAvL3RoaXMubGJTdGF0dXMuc3RyaW5nPVwidG91Y2ggZGlzdGFuY2U6XCIrZGlzdGFuY2U7XG4gICAgICAgICAgICAgICAgaWYgKGRpc3RhbmNlID4gMzApIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pc0ZpcmUgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGR0UG9zID0gY2MudjIocG9zLnggLSB0aGlzLmJlZ2luUG9zLngsIHBvcy55IC0gdGhpcy5iZWdpblBvcy55KTtcblxuICAgICAgICAgICAgICAgICAgICB2YXIgYW5nbGVtdiA9IGNjLnBUb0FuZ2xlKGR0UG9zKTtcbiAgICAgICAgICAgICAgICAgICAgYW5nbGVtdiA9IGFuZ2xlbXYgKiAxODAgLyAzLjE0O1xuICAgICAgICAgICAgICAgICAgICBpZiAoYW5nbGVtdiA8IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFuZ2xlbXYgPSAzNjAgKyBhbmdsZW12O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChhbmdsZW12ID4gMzYwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBzZSBraG9uZyBiYW8gZ2lvIHhheSByYSB0cnVvbmcgaG9wIG5heSB2aSBjb2NvczJkLWpzIGx1b24gdHJhIHZlIDEgZ29jIHR1IC0xODAsMTgwICwgbmjGsG5nIGPhu6kgdGjDqm0gMSBjw6J1IGlmIGNobyBjaOG6r2MgxINuXG4gICAgICAgICAgICAgICAgICAgICAgICBhbmdsZW12ID0gYW5nbGVtdiAtIDM2MDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAoYW5nbGVtdiA8IDQ1IHx8IGFuZ2xlbXYgPiAzMTUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0dF9tb3ZlZGlyID0gMTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAoYW5nbGVtdiA+IDQ1ICYmIGFuZ2xlbXYgPCAxMzUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0dF9tb3ZlZGlyID0gMjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAoYW5nbGVtdiA+IDEzNSAmJiBhbmdsZW12IDwgMjI1KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzdHRfbW92ZWRpciA9IDM7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKGFuZ2xlbXYgPCAzMTUgJiYgYW5nbGVtdiA+IDIyNSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc3R0X21vdmVkaXIgPSA0O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIC8vdGhpcy5sYlN0YXR1cy5zdHJpbmc9XCJ0YW5rIGFuZ2xlPVwiK2FuZ2xlbXY7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuaXNGaXJlKSB7XG4gICAgICAgICAgICAgICAgICAgIHBvcy54ID0gcG9zLnggLSBjYy53aW5TaXplLndpZHRoIC8gMjtcbiAgICAgICAgICAgICAgICAgICAgcG9zLnkgPSBwb3MueSAtIGNjLndpblNpemUuaGVpZ2h0IC8gMjtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHZmaXJlID0gY2MucE5vcm1hbGl6ZShjYy52Mihwb3MueCwgcG9zLnkpKTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGFuZ2xlID0gY2MucFRvQW5nbGUodmZpcmUpO1xuICAgICAgICAgICAgICAgICAgICBhbmdsZSA9IGFuZ2xlICogMTgwIC8gMy4xNDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGFuZ2xlIDwgMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYW5nbGUgPSAzNjAgKyBhbmdsZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAoYW5nbGUgPiAzNjApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHNlIGtob25nIGJhbyBnaW8geGF5IHJhIHRydW9uZyBob3AgbmF5IHZpIGNvY29zMmQtanMgbHVvbiB0cmEgdmUgMSBnb2MgdHUgLTE4MCwxODBcbiAgICAgICAgICAgICAgICAgICAgICAgIGFuZ2xlID0gYW5nbGUgLSAzNjA7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMubGJTdGF0dXMuc3RyaW5nPVwiR09DIGZhbHNlIEFBQT1cIithbmdsZTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zb2NrZXQuZW1pdChcImZpcmVUYXJnZXRcIiwgYW5nbGUpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChzdHRfbW92ZWRpciA+IDAgJiYgc3R0X21vdmVkaXIgPCA1KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBwb3MueCA9IHRoaXMuYmVnaW5Qb3MueCAtIGNjLndpblNpemUud2lkdGggLyAyO1xuICAgICAgICAgICAgICAgICAgICAgICAgcG9zLnkgPSB0aGlzLmJlZ2luUG9zLnkgLSBjYy53aW5TaXplLmhlaWdodCAvIDI7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFycm93Tm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hcnJvd05vZGUuc3RvcEFsbEFjdGlvbnMoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYXJyb3dOb2RlLnNldFBvc2l0aW9uKHBvcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFycm93Tm9kZS5zY2FsZVggPSAwLjQ7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFycm93Tm9kZS5vcGFjaXR5ID0gMTIwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGFjdGlvblNDID0gY2Muc2NhbGVUbygwLjMsIDAuOCwgMC43KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHhtID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciB5bSA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoc3R0X21vdmVkaXIgPT0gMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHhtID0gMzAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYXJyb3dOb2RlLnJvdGF0aW9uID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzdHRfbW92ZWRpciA9PSAzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeG0gPSAtMzAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYXJyb3dOb2RlLnJvdGF0aW9uID0gLTE4MDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzdHRfbW92ZWRpciA9PSAyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeW0gPSAzMDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hcnJvd05vZGUucm90YXRpb24gPSAtOTA7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoc3R0X21vdmVkaXIgPT0gNCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHltID0gLTMwMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFycm93Tm9kZS5yb3RhdGlvbiA9IDkwO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGFjdGlvbk1WID0gY2MubW92ZUJ5KDAuMywgY2MucCh4bSwgeW0pKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBhY3Rpb25vcCA9IGNjLmZhZGVUbygwLjUsIDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hcnJvd05vZGUucnVuQWN0aW9uKGNjLnNwYXduKGFjdGlvblNDLCBhY3Rpb25NViwgYWN0aW9ub3ApKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zb2NrZXQuZW1pdChcImNoYW5nZURpclwiLCBzdHRfbW92ZWRpcik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KS5iaW5kKHRoaXMpXG5cbiAgICAgICAgfSwgdGhpcy5ub2RlKTtcbiAgICB9LFxuXG4gICAgYWN0aW9uTGlzdGVuS2V5UHJlc3M6IGZ1bmN0aW9uIGFjdGlvbkxpc3RlbktleVByZXNzKCkge1xuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICAgIC8vYWRkIGtleWJvYXJkIGlucHV0IGxpc3RlbmVyIHRvIGp1bXAsIHR1cm5MZWZ0IGFuZCB0dXJuUmlnaHRcbiAgICAgICAgdGhpcy5rZXlFdmVudExpc3RlbiA9IGNjLmV2ZW50TWFuYWdlci5hZGRMaXN0ZW5lcih7XG4gICAgICAgICAgICBldmVudDogY2MuRXZlbnRMaXN0ZW5lci5LRVlCT0FSRCxcbiAgICAgICAgICAgIC8vIHNldCBhIGZsYWcgd2hlbiBrZXkgcHJlc3NlZFxuICAgICAgICAgICAgb25LZXlQcmVzc2VkOiBmdW5jdGlvbiBvbktleVByZXNzZWQoa2V5Q29kZSwgZXZlbnQpIHtcbiAgICAgICAgICAgICAgICB2YXIgbW92ZXN0dCA9IDA7XG4gICAgICAgICAgICAgICAgaWYgKGtleUNvZGUgPT0gY2MuS0VZLmQgfHwga2V5Q29kZSA9PSBjYy5LRVkucmlnaHQpIHtcbiAgICAgICAgICAgICAgICAgICAgbW92ZXN0dCA9IDE7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChrZXlDb2RlID09IGNjLktFWS53IHx8IGtleUNvZGUgPT0gY2MuS0VZLnVwKSB7XG4gICAgICAgICAgICAgICAgICAgIG1vdmVzdHQgPSAyO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoa2V5Q29kZSA9PSBjYy5LRVkuYSB8fCBrZXlDb2RlID09IGNjLktFWS5sZWZ0KSB7XG4gICAgICAgICAgICAgICAgICAgIG1vdmVzdHQgPSAzO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoa2V5Q29kZSA9PSBjYy5LRVkucyB8fCBrZXlDb2RlID09IGNjLktFWS5kb3duKSB7XG4gICAgICAgICAgICAgICAgICAgIG1vdmVzdHQgPSA0O1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vIGlmKHRoaXMubGFzdF9tb3Zlc3R0PT1tb3Zlc3R0KXtcbiAgICAgICAgICAgICAgICAvLyAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIC8vIH1cbiAgICAgICAgICAgICAgICB0aGlzLmxhc3RfbW92ZXN0dCA9IG1vdmVzdHQ7XG4gICAgICAgICAgICAgICAgaWYgKG1vdmVzdHQgPiAwICYmIG1vdmVzdHQgPCA1KSB7XG4gICAgICAgICAgICAgICAgICAgIHNlbGYuc29ja2V0LmVtaXQoXCJjaGFuZ2VEaXJcIiwgbW92ZXN0dCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9LCBzZWxmLm5vZGUpO1xuICAgIH0sXG5cbiAgICBhY3Rpb25Mb2FkR2FtZUJlZ2luOiBmdW5jdGlvbiBhY3Rpb25Mb2FkR2FtZUJlZ2luKCkge1xuXG4gICAgICAgIHRoaXMuaHViID0gY2MuaW5zdGFudGlhdGUodGhpcy5odWJfcHJlZmFiKTtcbiAgICAgICAgdGhpcy5ub2RlLmFkZENoaWxkKHRoaXMuaHViKTtcblxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICAgIHJlcXVpcmUoJ3NvY2tldC5pbycpO1xuICAgICAgICB2YXIgdXJsY29ubmVjdCA9IFV0aWxzLmdldFNlcnZlcigpO1xuICAgICAgICB2YXIgY29uZmlnID0ge1xuICAgICAgICAgICAgJ2ZvcmNlTmV3JzogdHJ1ZSxcbiAgICAgICAgICAgICdyZWNvbm5lY3Rpb24nOiBmYWxzZSxcbiAgICAgICAgICAgICdyZWNvbm5lY3Rpb25EZWxheSc6IDIwMCxcbiAgICAgICAgICAgICdyZWNvbm5lY3Rpb25EZWxheU1heCc6IDEwMDAsXG4gICAgICAgICAgICAncmVjb25uZWN0aW9uQXR0ZW1wdHMnOiAxXG4gICAgICAgIH07XG4gICAgICAgIHRoaXMuc29ja2V0ID0gaW8uY29ubmVjdCh1cmxjb25uZWN0LCBjb25maWcpOyAvLyBwaGnDqm4gYuG6o24ganMgbsOgeSBo4buXIHRy4bujIHRy4buxYyB0aeG6v3AgaXB2NiwgaXB2NFxuICAgICAgICBjb25zb2xlLmxvZyhcIi0tLS0tREQtLT51cmwgY29ubmVjdDogJXNcIiwgdXJsY29ubmVjdCk7XG4gICAgICAgIHRoaXMuc29ja2V0Lm9uKCdjb25uZWN0JywgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgVXRpbHMubG9nKFwia2V0IG5vaSB0aGFuaCBjb25nXCIpO1xuICAgICAgICAgICAgdmFyIHN0cl9pbmZvID0gVXRpbHMubG9hZFVzZXJJbmZvKCk7XG4gICAgICAgICAgICBzZWxmLnNvY2tldC5lbWl0KFwiTXlJbmZvXCIsIHN0cl9pbmZvKTtcbiAgICAgICAgICAgIGlmIChzZWxmLmh1YiA9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2VsZi5odWIuZGVzdHJveSgpO1xuICAgICAgICAgICAgc2VsZi5odWIgPSBudWxsO1xuICAgICAgICB9KTtcblxuICAgICAgICB0aGlzLnNvY2tldC5vbignUmVxdWVzdFZhbGlkYXRlJywgZnVuY3Rpb24gKG1lc3NhZ2UpIHtcbiAgICAgICAgICAgIHZhciBtc2dSZWNlaXZlID0gbWVzc2FnZTtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZSA9PSBcInN0cmluZ1wiKSB7XG4gICAgICAgICAgICAgICAgbXNnUmVjZWl2ZSA9IEpTT04ucGFyc2UobWVzc2FnZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzZWxmLm1hcFNjcmlwdC5UQU5LSUQgPSBwYXJzZUludChtc2dSZWNlaXZlLmlkKTtcbiAgICAgICAgICAgIHZhciBrZXlkZWNvZGUgPSBVdGlscy5kZUNvZGUobXNnUmVjZWl2ZS5rZXkpO1xuICAgICAgICAgICAgc2VsZi5zb2NrZXQuZW1pdChcIk15VmFsaWRhdGVcIiwga2V5ZGVjb2RlKTtcbiAgICAgICAgICAgIC8vL2NoYW0gbWF1IHRyYW5nIG5oYXAgbmhheSBsaWVuIHR1Y1xuICAgICAgICAgICAgLy92YXIgYWN0aW9uUlA9Y2MucmVwZWF0Rm9yZXZlcihjYy5ibGluaygyLCAzKSk7XG4gICAgICAgICAgICAvL3NlbGYudGlueVBsYXllci5zdG9wQWxsQWN0aW9ucygpO1xuICAgICAgICAgICAgLy9zZWxmLnRpbnlQbGF5ZXIucnVuQWN0aW9uKGFjdGlvblJQKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuc29ja2V0Lm9uKCdVcGRhdGVQb3NpdGlvbicsIGZ1bmN0aW9uIChtZXNzYWdlKSB7XG4gICAgICAgICAgICB2YXIgbXNnUmVjZWl2ZSA9IG1lc3NhZ2U7XG4gICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UgPT0gXCJzdHJpbmdcIikge1xuICAgICAgICAgICAgICAgIG1zZ1JlY2VpdmUgPSBKU09OLnBhcnNlKG1lc3NhZ2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2VsZi5tYXBTY3JpcHQudXBkYXRlRnJhbWVTdGVwKG1zZ1JlY2VpdmUpO1xuICAgICAgICAgICAgc2VsZi51cGRhdGVUaW55TWFwR2FtZSgpO1xuICAgICAgICB9KTtcblxuICAgICAgICB0aGlzLnNvY2tldC5vbignVXBkYXRlVGFua01hcCcsIGZ1bmN0aW9uIChtZXNzYWdlKSB7XG5cbiAgICAgICAgICAgIHZhciBtc2dSZWNlaXZlID0gbWVzc2FnZTtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZSA9PSBcInN0cmluZ1wiKSB7XG4gICAgICAgICAgICAgICAgbXNnUmVjZWl2ZSA9IEpTT04ucGFyc2UobWVzc2FnZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzZWxmLnVwZGF0ZVRpbnlNYXAobXNnUmVjZWl2ZSk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHRoaXMuc29ja2V0Lm9uKCdCZXN0UGxheWVycycsIGZ1bmN0aW9uIChtZXNzYWdlKSB7XG4gICAgICAgICAgICB2YXIgbXNnUmVjZWl2ZSA9IG1lc3NhZ2U7XG4gICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UgPT0gXCJzdHJpbmdcIikge1xuICAgICAgICAgICAgICAgIG1zZ1JlY2VpdmUgPSBKU09OLnBhcnNlKG1lc3NhZ2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdmFyIGwgPSBtc2dSZWNlaXZlLmxlbmd0aDtcbiAgICAgICAgICAgIHZhciBzdHJIQyA9IFwiXCI7XG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGw7IGkrKykge1xuICAgICAgICAgICAgICAgIHZhciBvYmpzYyA9IG1zZ1JlY2VpdmVbaV07XG4gICAgICAgICAgICAgICAgdmFyIHN0dCA9IGkgKyAxO1xuICAgICAgICAgICAgICAgIHZhciBsaW5ldG1wID0gXCIjXCIgKyBzdHQgKyBcIiAgXCIgKyBvYmpzYy5uICsgXCIgICAgXCIgKyBvYmpzYy5zO1xuICAgICAgICAgICAgICAgIGlmIChpID09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgc3RySEMgPSBsaW5ldG1wO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHN0ckhDID0gc3RySEMgKyBcIlxcblwiICsgbGluZXRtcDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzZWxmLmxiU3RhdHVzLnN0cmluZyA9IHN0ckhDO1xuICAgICAgICB9KTtcblxuICAgICAgICB0aGlzLnNvY2tldC5vbignZXJyb3InLCBmdW5jdGlvbiAobWVzc2FnZSkge1xuICAgICAgICAgICAgLy9jYy5sb2coXCJkZGRkZGRkZC0tLS0tLS0tLS1lcm9yOiVzXCIsbWVzc2FnZSk7XG4gICAgICAgICAgICBVdGlscy5tZXNzYWdlY29ubmVjdCA9IG1lc3NhZ2U7XG4gICAgICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJIb21lU2NlbmVcIik7XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLnNvY2tldC5vbignZGlzY29ubmVjdCcsIGZ1bmN0aW9uIChtZXNzYWdlKSB7XG4gICAgICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJIb21lU2NlbmVcIik7XG4gICAgICAgIH0pO1xuICAgIH0sXG5cbiAgICB1cGRhdGVUaW55TWFwOiBmdW5jdGlvbiB1cGRhdGVUaW55TWFwKGFycmF5VGFuaykge1xuICAgICAgICAvL3RoaXMudGVzdGNvdW50ZHJhdz10aGlzLnRlc3Rjb3VudGRyYXcrMTtcbiAgICAgICAgLy9pZih0aGlzLnRlc3Rjb3VudGRyYXc+Myl7XG4gICAgICAgIC8vXG4gICAgICAgIC8vICAgIHRoaXMudGlueU1hcEdyYXBwaGljLmNsZWFyKCk7XG4gICAgICAgIC8vfWVsc2V7XG4gICAgICAgIC8vICAgIHRoaXMudGlueU1hcEdyYXBwaGljLnJlY3QoMjAsMjAsMTExLDExMSk7XG4gICAgICAgIC8vICAgIHRoaXMudGlueU1hcEdyYXBwaGljLmZpbGxDb2xvciA9IGNjLkNvbG9yLkdSRUVOO1xuICAgICAgICAvLyAgICB0aGlzLnRpbnlNYXBHcmFwcGhpYy5maWxsKCk7XG4gICAgICAgIC8vfVxuICAgICAgICAvL2lmKHRoaXMudGVzdGNvdW50ZHJhdz41KXtcbiAgICAgICAgLy8gICAgdGhpcy50ZXN0Y291bnRkcmF3PTA7XG4gICAgICAgIC8vfVxuICAgICAgICAvL1xuICAgICAgICAvL3JldHVybjtcblxuICAgICAgICB0aGlzLnRpbnlNYXBHcmFwcGhpYy5jbGVhcigpO1xuICAgICAgICB2YXIgbGVuID0gYXJyYXlUYW5rLmxlbmd0aDtcbiAgICAgICAgdmFyIG15cG9zID0ge307XG4gICAgICAgIG15cG9zLnggPSB0aGlzLm1hcFNjcmlwdC5NWVBMQVlFUi54O1xuICAgICAgICBteXBvcy55ID0gdGhpcy5tYXBTY3JpcHQuTVlQTEFZRVIueTtcblxuICAgICAgICBmb3IgKHZhciBheCA9IDA7IGF4IDwgbGVuOyBheCsrKSB7XG4gICAgICAgICAgICB2YXIgcG9zID0gYXJyYXlUYW5rW2F4XTtcblxuICAgICAgICAgICAgdmFyIGRpc3RhbmNlTWUgPSBVdGlscy5kaXN0YW5jZTJQb3MobXlwb3MsIHBvcyk7XG4gICAgICAgICAgICBpZiAoZGlzdGFuY2VNZSA+IDE1KSB7XG4gICAgICAgICAgICAgICAgcG9zLnggPSA3MCAqIChwb3MueCAvIDE1MDApO1xuICAgICAgICAgICAgICAgIHBvcy55ID0gNTAgKiAocG9zLnkgLyAxMDAwKTtcbiAgICAgICAgICAgICAgICB0aGlzLnRpbnlNYXBHcmFwcGhpYy5yZWN0KHBvcy54IC0gMS41LCBwb3MueSAtIDEuNSwgMywgMyk7XG4gICAgICAgICAgICAgICAgdGhpcy50aW55TWFwR3JhcHBoaWMuZmlsbENvbG9yID0gY2MuQ29sb3IuUkVEO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHRoaXMudGlueU1hcEdyYXBwaGljLmZpbGwoKTtcblxuICAgICAgICBteXBvcy54ID0gNzAgKiAobXlwb3MueCAvIDE1MDApO1xuICAgICAgICBteXBvcy55ID0gNTAgKiAobXlwb3MueSAvIDEwMDApO1xuICAgICAgICB0aGlzLnRpbnlNYXBHcmFwcGhpYy5yZWN0KG15cG9zLnggLSAxLjUsIG15cG9zLnkgLSAxLjUsIDMsIDMpO1xuICAgICAgICB0aGlzLnRpbnlNYXBHcmFwcGhpYy5maWxsQ29sb3IgPSBjYy5Db2xvci5HUkVFTjtcbiAgICAgICAgdGhpcy50aW55TWFwR3JhcHBoaWMuZmlsbCgpO1xuICAgIH0sXG5cbiAgICB1cGRhdGVUaW55TWFwR2FtZTogZnVuY3Rpb24gdXBkYXRlVGlueU1hcEdhbWUoKSB7XG4gICAgICAgIGlmICh0aGlzLm1hcFNjcmlwdC5NWVBMQVlFUi5pc0FjdGl2ZVNDKSB7XG5cbiAgICAgICAgICAgIC8vdmFyIHhwb3M9dGhpcy5tYXBTY3JpcHQuTVlQTEFZRVIueC8xNTAwO1xuICAgICAgICAgICAgLy92YXIgeXBvcz10aGlzLm1hcFNjcmlwdC5NWVBMQVlFUi55LzEwMDA7XG4gICAgICAgICAgICAvL3RoaXMudGlueVBsYXllci54PXhwb3MqNzA7XG4gICAgICAgICAgICAvL3RoaXMudGlueVBsYXllci55PXlwb3MqNTA7XG5cbiAgICAgICAgICAgIHZhciBvYmpfaW5mbyA9IHRoaXMubWFwU2NyaXB0Lk1ZUExBWUVSLmFjdGl2ZUluZm87XG5cbiAgICAgICAgICAgIHZhciBteUxldmVsID0gb2JqX2luZm8ubGV2ZWw7XG5cbiAgICAgICAgICAgIHZhciBteU1heEFtbW8gPSBwYXJzZUludCgxNDAgKyAobXlMZXZlbCAtIDEpICogMjApO1xuICAgICAgICAgICAgdmFyIG15TWF4SGVhbHRoID0gcGFyc2VJbnQoODAgKyAobXlMZXZlbCAtIDEpICogMTUpO1xuXG4gICAgICAgICAgICB2YXIgc2NfYW1tbyA9IHBhcnNlSW50KG9ial9pbmZvLmFtbW8pIC8gbXlNYXhBbW1vO1xuICAgICAgICAgICAgaWYgKHNjX2FtbW8gPiAxKSB7XG4gICAgICAgICAgICAgICAgc2NfYW1tbyA9IDE7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgc2NfaHAgPSBwYXJzZUludChvYmpfaW5mby5ocCkgLyBteU1heEhlYWx0aDtcbiAgICAgICAgICAgIGlmIChzY19ocCA+IDEpIHtcbiAgICAgICAgICAgICAgICBzY19ocCA9IDE7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRoaXMucGFuZWxJbmZvU2NyaXB0LnByQW1tby5zY2FsZVggPSBzY19hbW1vO1xuICAgICAgICAgICAgdGhpcy5wYW5lbEluZm9TY3JpcHQucHJIUC5zY2FsZVggPSBzY19ocDtcblxuICAgICAgICAgICAgdGhpcy5wYW5lbEluZm9TY3JpcHQubGJDb3VudEFtbW8uc3RyaW5nID0gcGFyc2VJbnQob2JqX2luZm8uYW1tbykgKyBcIi9cIiArIG15TWF4QW1tbztcbiAgICAgICAgICAgIHRoaXMucGFuZWxJbmZvU2NyaXB0LmxiQ291bnRIcC5zdHJpbmcgPSBwYXJzZUludChvYmpfaW5mby5ocCkgKyBcIi9cIiArIG15TWF4SGVhbHRoO1xuICAgICAgICAgICAgdGhpcy5wYW5lbEluZm9TY3JpcHQubGJMZXZlbC5zdHJpbmcgPSBcIkxFVkVMOlwiICsgcGFyc2VJbnQobXlMZXZlbCk7XG4gICAgICAgICAgICB0aGlzLmxic2NvcmUuc3RyaW5nID0gb2JqX2luZm8uc2NvcmU7XG4gICAgICAgICAgICBVdGlscy5teXNjb3JlID0gb2JqX2luZm8uc2NvcmU7XG4gICAgICAgICAgICB0aGlzLnBhbmVsSW5mb1NjcmlwdC5sYlNwZWVkLnN0cmluZyA9IFwiU3BlZWQ6XCIgKyBOdW1iZXIob2JqX2luZm8uc3ApLnRvRml4ZWQoMSk7XG4gICAgICAgIH1cbiAgICB9XG5cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnZjFhMThsOWVjbEhNTDdUN2pRbmFpT3onLCAnSG9tZVNjcmlwdCcpO1xuLy8gU2NyaXB0L0dhbWVzY3JpcHQvSG9tZVNjcmlwdC5qc1xuXG52YXIgVXRpbHMgPSByZXF1aXJlKCcuLi9MSUIvVXRpbHMnKTtcbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBub2RlV2ViOiBjYy5Ob2RlLFxuICAgICAgICBub2RlTW9iaWxlOiBjYy5Ob2RlLFxuICAgICAgICB0eHRVc2VyTmFtZTogY2MuRWRpdEJveCxcbiAgICAgICAgaHVibG9hZGluZzogY2MuTm9kZSxcbiAgICAgICAgcG9wU2V0dGluZzogY2MuUHJlZmFiXG4gICAgfSxcblxuICAgIGxvYWRGbGFnSXBJbmZvOiBmdW5jdGlvbiBsb2FkRmxhZ0lwSW5mbygpIHtcbiAgICAgICAgaWYgKHRoaXMuSXBJbmZvKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5JcEluZm8gPSB0cnVlO1xuICAgICAgICB2YXIgeGhyID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG4gICAgICAgIHhoci5vbnJlYWR5c3RhdGVjaGFuZ2UgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAoeGhyLnJlYWR5U3RhdGUgPT0gNCAmJiB4aHIuc3RhdHVzID49IDIwMCAmJiB4aHIuc3RhdHVzIDwgNDAwKSB7XG4gICAgICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0geGhyLnJlc3BvbnNlVGV4dDtcblxuICAgICAgICAgICAgICAgIHZhciBmbGFnID0gSlNPTi5wYXJzZShyZXNwb25zZSkuY291bnRyeTtcblxuICAgICAgICAgICAgICAgIGlmIChmbGFnICE9IG51bGwpIHtcblxuICAgICAgICAgICAgICAgICAgICBpZiAoZmxhZy5sZW5ndGggPiAxIHx8IGZsYWcubGVuZ3RoIDwgNCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmxhZyA9IGZsYWcudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImNvdW50cnlcIiwgZmxhZyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImlwaW5mby0tLS0+XCIgKyBmbGFnKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgeGhyLm9wZW4oXCJHRVRcIiwgXCJodHRwOi8vaXBpbmZvLmlvL2pzb25cIiwgdHJ1ZSk7XG4gICAgICAgIHhoci5zZW5kKCk7XG4gICAgfSxcblxuICAgIGxvYWRGbGFnSXBBUEk6IGZ1bmN0aW9uIGxvYWRGbGFnSXBBUEkoKSB7XG4gICAgICAgIHZhciB4aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICB4aHIub25yZWFkeXN0YXRlY2hhbmdlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaWYgKHhoci5yZWFkeVN0YXRlID09IDQgJiYgeGhyLnN0YXR1cyA+PSAyMDAgJiYgeGhyLnN0YXR1cyA8IDQwMCkge1xuICAgICAgICAgICAgICAgIHZhciByZXNwb25zZSA9IHhoci5yZXNwb25zZVRleHQ7XG5cbiAgICAgICAgICAgICAgICB2YXIgZmxhZyA9IEpTT04ucGFyc2UocmVzcG9uc2UpLmNvdW50cnlDb2RlO1xuXG4gICAgICAgICAgICAgICAgaWYgKGZsYWcgIT0gbnVsbCkge1xuXG4gICAgICAgICAgICAgICAgICAgIGlmIChmbGFnLmxlbmd0aCA+IDEgfHwgZmxhZy5sZW5ndGggPCA0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmbGFnID0gZmxhZy50b0xvd2VyQ2FzZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiY291bnRyeVwiLCBmbGFnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiSVBBUEktLS0tPlwiICsgZmxhZyk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxmLmxvYWRGbGFnSXBJbmZvKCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBzZWxmLmxvYWRGbGFnSXBJbmZvKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBzZWxmLmxvYWRGbGFnSXBJbmZvKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIHhoci5vbmVycm9yID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgc2VsZi5sb2FkRmxhZ0lwSW5mbygpO1xuICAgICAgICB9O1xuICAgICAgICB4aHIub3BlbihcIkdFVFwiLCBcImh0dHA6Ly9pcC1hcGkuY29tL2pzb24vXCIsIHRydWUpO1xuICAgICAgICB4aHIuc2VuZCgpO1xuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgaWYgKGNjLnN5cy5pc05hdGl2ZSkge1xuICAgICAgICAgICAgLy8gdGhpcy5sYk9TLnN0cmluZz1cImlzTmF0aXZlLWlPUytBbmRyb2lkOlwiK2NjLnN5cy5vcztcbiAgICAgICAgICAgIHRoaXMubm9kZVdlYi5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgICAgIHRoaXMubm9kZU1vYmlsZS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5ub2RlV2ViLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgICAgICB0aGlzLm5vZGVNb2JpbGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHN0cnggPSBjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c3JcIik7XG4gICAgICAgIGlmIChzdHJ4ICE9IG51bGwpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2Ygc3RyeCA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICAgICAgICAgIHRoaXMudHh0VXNlck5hbWUuc3RyaW5nID0gXCJcIjtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy50eHRVc2VyTmFtZS5zdHJpbmcgPSBzdHJ4O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHRoaXMuSXBJbmZvID0gZmFsc2U7XG4gICAgICAgIHRoaXMuQWRzTWFuYWdlcigpO1xuICAgICAgICB0aGlzLmxvYWRGbGFnSXBBUEkoKTtcblxuICAgICAgICBpZiAodHlwZW9mIFV0aWxzLm15c2NvcmUgIT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICAgICAgdmFyIGludHNjb3JlID0gcGFyc2VJbnQoVXRpbHMubXlzY29yZSk7XG4gICAgICAgICAgICBpZiAoaW50c2NvcmUgPiAwKSB7XG4gICAgICAgICAgICAgICAgdmFyIHN0cmludHNjb3JlID0gaW50c2NvcmUgKyBcIlwiO1xuICAgICAgICAgICAgICAgIGlmIChjYy5zeXMub3MgPT0gY2Muc3lzLk9TX0lPUykge1xuICAgICAgICAgICAgICAgICAgICBqc2IucmVmbGVjdGlvbi5jYWxsU3RhdGljTWV0aG9kKFwiQnJpZGdlSU9TXCIsIFwic3VibWl0U2NvcmVHYW1lQ2VudGVyOmxlYWRlckJvYXJJRDpcIiwgc3RyaW50c2NvcmUsIFwiY29tLmdhbWVpby50YW5raGlnaHNjb3JlXCIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIFV0aWxzLnR1cm5PZmZBdWRpbyA9IGZhbHNlO1xuICAgIH0sXG5cbiAgICBBZHNNYW5hZ2VyOiBmdW5jdGlvbiBBZHNNYW5hZ2VyKCkge1xuICAgICAgICBpZiAoY2Muc3lzLm9zID09IGNjLnN5cy5PU19JT1MpIHtcbiAgICAgICAgICAgIC8vIGhpZW4gdGhpIHF1YW5nIGNhb1xuICAgICAgICAgICAganNiLnJlZmxlY3Rpb24uY2FsbFN0YXRpY01ldGhvZChcIkJyaWRnZUlPU1wiLCBcIlNob3dBZHNCYW5lcldpdGhBZG5pbWF0aW9uXCIpO1xuXG4gICAgICAgICAgICBqc2IucmVmbGVjdGlvbi5jYWxsU3RhdGljTWV0aG9kKFwiQnJpZGdlSU9TXCIsIFwiU2hvd0Z1bGxTY3JlZW5cIik7XG5cbiAgICAgICAgICAgIC8vIGhpZW4gdGhpIGxvaSB0aG9uZyBiYW8ga2hpIGtob25nIGtldCBub3QgZHVvYyBtYW5nXG4gICAgICAgICAgICBpZiAodHlwZW9mIFV0aWxzLm1lc3NhZ2Vjb25uZWN0ICE9IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgICAgICAgICB2YXIgbXNnID0gVXRpbHMubWVzc2FnZWNvbm5lY3QgKyBcIlwiO1xuICAgICAgICAgICAgICAgIGlmIChtc2cubGVuZ3RoID4gNCkge1xuICAgICAgICAgICAgICAgICAgICBqc2IucmVmbGVjdGlvbi5jYWxsU3RhdGljTWV0aG9kKFwiQnJpZGdlSU9TXCIsIFwiY2FsbE5hdGl2ZVVJV2l0aFRpdGxlOmFuZENvbnRlbnQ6XCIsIFwiTWVzc2FnZVwiLCBtc2cpO1xuICAgICAgICAgICAgICAgICAgICBVdGlscy5tZXNzYWdlY29ubmVjdCA9IFwiXCI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKGNjLnN5cy5vcyA9PSBjYy5zeXMuT1NfQU5EUk9JRCkge30gZWxzZSB7Ly8gcGhpZW4gYmFuIHdlYlxuXG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgYWNSYXRlOiBmdW5jdGlvbiBhY1JhdGUoKSB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiAgTkjhu65ORyBBUEkgTsOAWSDEkMav4buiQyBH4buMSSDEkEkgR+G7jEkgTOG6oEkgVsOAIE7DkyBMw4AgQ8agIELhuqJOIFThuqRUIEPhuqIgQ8OBQyBHQU1FIMSQ4buAVSBD4bqmTiBDw5MgTkjGryBMw4AgSU5BUFAtUFVSQ0hBU0UsQURTLEdBTUVDRU5URVIsU0hBUkUuLi4sIFxuICAgICAgICAgKiAgTsOKTiBTQVUgR0FNRSBOw4BZIE3DjE5IIFZJ4bq+VCBOw5MgVEjDgE5IIDEgQ0xBU1MgUknDik5HIMSQ4buCIEThu4QgVMOBSSBT4busIEThu6RORyBWw4AgROG7hCBRVeG6ok4gTMOdLCBDw5JOIEdJ4bucIEPhu6ggVknhur5UIFThuqBNIEjhur5UIFRST05HIMSQw4JZIFxuICAgICAgICAgKiAqL1xuICAgICAgICB2YXIgdXJsUmF0ZUFwcCA9IFwiXCI7XG4gICAgICAgIGlmIChjYy5zeXMub3MgPT0gY2Muc3lzLk9TX0lPUykge1xuICAgICAgICAgICAgdXJsUmF0ZUFwcCA9IFwiaXRtcy1hcHBzOi8vaXR1bmVzLmFwcGxlLmNvbS9XZWJPYmplY3RzL01aU3RvcmUud29hL3dhL3ZpZXdDb250ZW50c1VzZXJSZXZpZXdzP2lkPTExNDIyNDk1MDgmb25seUxhdGVzdFZlcnNpb249dHJ1ZSZwYWdlTnVtYmVyPTAmc29ydE9yZGVyaW5nPTEmdHlwZT1QdXJwbGUrU29mdHdhcmVcIjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIGxhIGFuZHJvaWRcbiAgICAgICAgICAgIHVybFJhdGVBcHAgPSBcImh0dHBzOi8vcGxheS5nb29nbGUuY29tL3N0b3JlL2FwcHMvZGV0YWlscz9pZD1wYWNrX25hbWVcIjtcbiAgICAgICAgfVxuICAgICAgICBjYy5zeXMub3BlblVSTCh1cmxSYXRlQXBwKTtcbiAgICB9LFxuICAgIGFjSGlnaFNjb3JlOiBmdW5jdGlvbiBhY0hpZ2hTY29yZSgpIHtcbiAgICAgICAgaWYgKGNjLnN5cy5vcyA9PSBjYy5zeXMuT1NfSU9TKSB7XG4gICAgICAgICAgICBqc2IucmVmbGVjdGlvbi5jYWxsU3RhdGljTWV0aG9kKFwiQnJpZGdlSU9TXCIsIFwic2hvd0hpZ2hTY29yZVwiKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgYWNTZXR0aW5nOiBmdW5jdGlvbiBhY1NldHRpbmcoKSB7XG4gICAgICAgIHZhciBwb3BzZXR0aW5nID0gY2MuaW5zdGFudGlhdGUodGhpcy5wb3BTZXR0aW5nKTtcbiAgICAgICAgdGhpcy5ub2RlLmFkZENoaWxkKHBvcHNldHRpbmcpO1xuICAgIH0sXG4gICAgYWNTaGFyZTogZnVuY3Rpb24gYWNTaGFyZSgpIHtcbiAgICAgICAgaWYgKGNjLnN5cy5vcyA9PSBjYy5zeXMuT1NfSU9TKSB7XG4gICAgICAgICAgICBqc2IucmVmbGVjdGlvbi5jYWxsU3RhdGljTWV0aG9kKFwiQnJpZGdlSU9TXCIsIFwic2hhcmVBcHBOYXRpdmU6XCIsIFwiaHR0cHM6Ly9pdHVuZXMuYXBwbGUuY29tL2FwcC9pZDExNDIyNDk1MDhcIik7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgYWN0aW9uT3BlblVSTDogZnVuY3Rpb24gYWN0aW9uT3BlblVSTCgpIHtcbiAgICAgICAgY2Muc3lzLm9wZW5VUkwoXCJodHRwOi8vdGFuay5nYW1laW8ubmV0XCIpO1xuICAgIH0sXG5cbiAgICBhY3Rpb25XZWJMb2FkQXBwc3RvcmU6IGZ1bmN0aW9uIGFjdGlvbldlYkxvYWRBcHBzdG9yZSgpIHtcbiAgICAgICAgY2Muc3lzLm9wZW5VUkwoXCJodHRwczovL2l0dW5lcy5hcHBsZS5jb20vYXBwL2lkMTE0MjI0OTUwOFwiKTtcbiAgICB9LFxuICAgIGFjdGlvbldlYkxvYWRBcHBQbGF5U3RvcmU6IGZ1bmN0aW9uIGFjdGlvbldlYkxvYWRBcHBQbGF5U3RvcmUoKSB7XG4gICAgICAgIGNjLnN5cy5vcGVuVVJMKFwiaHR0cHM6Ly9pdHVuZXMuYXBwbGUuY29tL2FwcC9pZDExNDIyNDk1MDhcIik7XG4gICAgfSxcblxuICAgIGFjRmFjZWJvb2tQYWdlOiBmdW5jdGlvbiBhY0ZhY2Vib29rUGFnZSgpIHtcbiAgICAgICAgY2Muc3lzLm9wZW5VUkwoXCJodHRwczovL3d3dy5mYWNlYm9vay5jb20vZ2FtZWlvLmxpdmVcIik7XG4gICAgfSxcbiAgICBhY1R3aXR0ZXJQYWdlOiBmdW5jdGlvbiBhY1R3aXR0ZXJQYWdlKCkge1xuICAgICAgICBjYy5zeXMub3BlblVSTChcImh0dHBzOi8vdHdpdHRlci5jb20vR2FtZWlvTFwiKTtcbiAgICB9LFxuICAgIGFjdGlvbkxvYWRHYWFtZVBsYXllcjogZnVuY3Rpb24gYWN0aW9uTG9hZEdhYW1lUGxheWVyKCkge1xuICAgICAgICBVdGlscy5wbGF5ZXJOYW1lID0gdGhpcy50eHRVc2VyTmFtZS5zdHJpbmcudHJpbSgpO1xuICAgICAgICBjYy5zeXMubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJ1c3JcIiwgVXRpbHMucGxheWVyTmFtZSk7XG4gICAgICAgIHRoaXMubG9hZENvbmZpZ0F1ZGlvKCk7XG4gICAgICAgIHRoaXMuaHVibG9hZGluZy5vcGFjaXR5ID0gMjU1O1xuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJHYW1lUGxheVwiKTtcbiAgICB9LFxuXG4gICAgbG9hZENvbmZpZ0F1ZGlvOiBmdW5jdGlvbiBsb2FkQ29uZmlnQXVkaW8oKSB7XG4gICAgICAgIHZhciBlZmZfZGlzYWJsZSA9IGZhbHNlO1xuICAgICAgICB2YXIgZGlzYWJsZVNvdW5kID0gY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZGlzYWJsZUVmZmVjdFwiKTtcbiAgICAgICAgaWYgKGRpc2FibGVTb3VuZCAhPSBudWxsKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIGRpc2FibGVTb3VuZCA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQUFBQSBiZWdpbiBlZmZcIik7XG4gICAgICAgICAgICAgICAgZWZmX2Rpc2FibGUgPSBmYWxzZTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG5cbiAgICAgICAgICAgICAgICBlZmZfZGlzYWJsZSA9IEpTT04ucGFyc2UoZGlzYWJsZVNvdW5kKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBVdGlscy50dXJuT2ZmQXVkaW8gPSBlZmZfZGlzYWJsZTtcblxuICAgICAgICB2YXIgYm9vbGVfc3dpcGUgPSBmYWxzZTtcbiAgICAgICAgdmFyIGVuYWJsZV9zd2lwZSA9IGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImVuYWJsZV9zd2lwZVwiKTtcbiAgICAgICAgaWYgKGVuYWJsZV9zd2lwZSAhPSBudWxsKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIGVuYWJsZV9zd2lwZSA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICAgICAgICAgIGVuYWJsZV9zd2lwZSA9IGZhbHNlO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBib29sZV9zd2lwZSA9IEpTT04ucGFyc2UoZW5hYmxlX3N3aXBlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBVdGlscy5lbmFibGVTd2lwZSA9ICFib29sZV9zd2lwZTtcbiAgICB9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2I3YTU5R3NPQmxFRUlEK0t4N01aQkl1JywgJ1BhZENvbnRyb2xsZXInKTtcbi8vIFNjcmlwdC9MSUIvUGFkQ29udHJvbGxlci5qc1xuXG52YXIgVXRpbHMgPSByZXF1aXJlKCcuLi9MSUIvVXRpbHMnKTtcbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBodWJjb250cm9sOiBjYy5Ob2RlLFxuICAgICAgICBidDA6IGNjLk5vZGUsXG4gICAgICAgIGJ0MTogY2MuTm9kZSxcbiAgICAgICAgYnQyOiBjYy5Ob2RlLFxuICAgICAgICBidDM6IGNjLk5vZGUsXG4gICAgICAgIGJ0NDogY2MuTm9kZVxuXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICAvL3RoaXMuYWRkVG91Y2hMaXN0ZW5FdmVudCgpO1xuXG4gICAgICAgIGlmIChjYy5zeXMuaXNCcm93c2VyIHx8IFV0aWxzLmVuYWJsZVN3aXBlKSB7XG4gICAgICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB2YXIgc2l6ZSA9IGNjLmRpcmVjdG9yLmdldFZpc2libGVTaXplKCk7XG5cbiAgICAgICAgICAgIHZhciB5Y2xvc2UgPSAtMjI1O1xuICAgICAgICAgICAgdmFyIHlfZXhwbGFpbiA9IC0xNDU7XG5cbiAgICAgICAgICAgIHZhciB4Y2xvc2UgPSAtc2l6ZS53aWR0aCAvIDIgKyAxMTM7XG4gICAgICAgICAgICB2YXIgeF9leHBsYWluID0gLXNpemUud2lkdGggLyAyICsgMjAwO1xuXG4gICAgICAgICAgICB0aGlzLmNsb3NlUG9zID0gY2MucCh4Y2xvc2UsIHljbG9zZSk7XG4gICAgICAgICAgICB0aGlzLmV4X3BvcyA9IGNjLnAoeF9leHBsYWluLCB5X2V4cGxhaW4pO1xuXG4gICAgICAgICAgICB0aGlzLlBhZERpciA9IDE7XG5cbiAgICAgICAgICAgIHRoaXMuY2xvc2VBbGxCdXR0b24oKTtcbiAgICAgICAgICAgIHRoaXMuY2hhbmdlZnJhbWUgPSB0cnVlO1xuICAgICAgICB9XG4gICAgfSxcbiAgICBvbkRpc2FibGU6IGZ1bmN0aW9uIG9uRGlzYWJsZSgpIHtcbiAgICAgICAgdGhpcy5tYWluc2NyaXB0ID0gbnVsbDtcbiAgICB9LFxuICAgIHVwZGF0ZVBhZERpcjogZnVuY3Rpb24gdXBkYXRlUGFkRGlyKCkge1xuXG4gICAgICAgIHZhciBhbGxjaGlsZCA9IHRoaXMubm9kZS5jaGlsZHJlbjtcbiAgICAgICAgZm9yICh2YXIgaXggPSAwOyBpeCA8IGFsbGNoaWxkLmxlbmd0aDsgaXgrKykge1xuICAgICAgICAgICAgdmFyIGJ0MSA9IGFsbGNoaWxkW2l4XTtcbiAgICAgICAgICAgIC8vYnQxLnNldExvY2FsWk9yZGVyKDEpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLlBhZERpciA9PSAxKSB7XG4gICAgICAgICAgICB0aGlzLmJ0MC5yb3RhdGlvbiA9IDE4MDtcbiAgICAgICAgICAgIC8vIHRoaXMuYnQwPXRoaXMubm9kZS5jaGlsZHJlblsyXTtcbiAgICAgICAgICAgIHRoaXMuYnQyLnNldExvY2FsWk9yZGVyKDMpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLlBhZERpciA9PSAzKSB7XG4gICAgICAgICAgICB0aGlzLmJ0MC5yb3RhdGlvbiA9IDA7XG4gICAgICAgICAgICAvL3RoaXMuYnQwPXRoaXMubm9kZS5jaGlsZHJlblszXTtcbiAgICAgICAgICAgIHRoaXMuYnQzLnNldExvY2FsWk9yZGVyKDMpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLlBhZERpciA9PSA0KSB7XG4gICAgICAgICAgICB0aGlzLmJ0MC5yb3RhdGlvbiA9IC05MDtcbiAgICAgICAgICAgIC8vdGhpcy5idDA9dGhpcy5ub2RlLmNoaWxkcmVuWzFdO1xuICAgICAgICAgICAgdGhpcy5idDEuc2V0TG9jYWxaT3JkZXIoMyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuUGFkRGlyID09IDIpIHtcbiAgICAgICAgICAgIHRoaXMuYnQwLnJvdGF0aW9uID0gOTA7XG4gICAgICAgICAgICAvL3RoaXMuYnQwPXRoaXMubm9kZS5jaGlsZHJlbls0XTtcbiAgICAgICAgICAgIHRoaXMuYnQ0LnNldExvY2FsWk9yZGVyKDMpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICBjbG9zZUFsbEJ1dHRvbjogZnVuY3Rpb24gY2xvc2VBbGxCdXR0b24oKSB7XG4gICAgICAgIHZhciBhbGxjaGlsZCA9IHRoaXMubm9kZS5jaGlsZHJlbjtcbiAgICAgICAgZm9yICh2YXIgaXggPSAwOyBpeCA8IGFsbGNoaWxkLmxlbmd0aDsgaXgrKykge1xuICAgICAgICAgICAgdmFyIGJ0MSA9IGFsbGNoaWxkW2l4XTtcbiAgICAgICAgICAgIGJ0MS54ID0gMDtcbiAgICAgICAgICAgIGJ0MS55ID0gMDtcbiAgICAgICAgICAgIGlmIChpeCA9PSAwKSB7XG4gICAgICAgICAgICAgICAgYnQxLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGJ0MS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMubm9kZS5zZXRQb3NpdGlvbih0aGlzLmNsb3NlUG9zKTtcbiAgICAgICAgdGhpcy5odWJjb250cm9sLmFjdGl2ZSA9IHRydWU7XG4gICAgfSxcbiAgICBvYmplY3RNb3ZlUG9zOiBmdW5jdGlvbiBvYmplY3RNb3ZlUG9zKG9ial9ub2RlLCBwb3MpIHtcbiAgICAgICAgb2JqX25vZGUuc3RvcEFsbEFjdGlvbnMoKTtcbiAgICAgICAgdmFyIGFjdGlvbm12ID0gY2MubW92ZVRvKDAuMiwgcG9zKTtcbiAgICAgICAgb2JqX25vZGUucnVuQWN0aW9uKGFjdGlvbm12KTtcbiAgICB9LFxuICAgIG9iamVjdE1vdmVDZW50ZXI6IGZ1bmN0aW9uIG9iamVjdE1vdmVDZW50ZXIob2JqX25vZGUsIHBvcykge1xuICAgICAgICBvYmpfbm9kZS5zdG9wQWxsQWN0aW9ucygpO1xuICAgICAgICB2YXIgYWN0aW9ubXYgPSBjYy5tb3ZlVG8oMC4yLCBwb3MpO1xuICAgICAgICBvYmpfbm9kZS5ydW5BY3Rpb24oYWN0aW9ubXYpO1xuICAgIH0sXG4gICAgZXhwbGFpbkFsbEJ1dHRvbjogZnVuY3Rpb24gZXhwbGFpbkFsbEJ1dHRvbigpIHtcblxuICAgICAgICAvL3ZhciBidDE9YWxsY2hpbGRbMF07XG4gICAgICAgIHRoaXMuYnQwLnggPSAwO1xuICAgICAgICB0aGlzLmJ0MC55ID0gMDtcbiAgICAgICAgdGhpcy5idDAuYWN0aXZlID0gZmFsc2U7XG5cbiAgICAgICAgLy9idDE9YWxsY2hpbGRbMV07XG4gICAgICAgIHRoaXMuYnQxLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIHRoaXMub2JqZWN0TW92ZVBvcyh0aGlzLmJ0MSwgY2MucCgwLCAtOTApKTtcblxuICAgICAgICAvL2J0MT1hbGxjaGlsZFsyXTtcbiAgICAgICAgdGhpcy5idDIuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5vYmplY3RNb3ZlUG9zKHRoaXMuYnQyLCBjYy5wKDkwLCAwKSk7XG5cbiAgICAgICAgLy9idDE9YWxsY2hpbGRbM107XG4gICAgICAgIHRoaXMuYnQzLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIHRoaXMub2JqZWN0TW92ZVBvcyh0aGlzLmJ0MywgY2MucCgtOTAsIDApKTtcblxuICAgICAgICAvL2J0MT1hbGxjaGlsZFs0XTtcbiAgICAgICAgdGhpcy5idDQuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5vYmplY3RNb3ZlUG9zKHRoaXMuYnQ0LCBjYy5wKDAsIDkwKSk7XG5cbiAgICAgICAgdGhpcy5ub2RlLnN0b3BBbGxBY3Rpb25zKCk7XG4gICAgICAgIHZhciBhY3Rpb25tdiA9IGNjLm1vdmVUbygwLjIsIHRoaXMuZXhfcG9zKTtcbiAgICAgICAgdGhpcy5ub2RlLnJ1bkFjdGlvbihhY3Rpb25tdik7XG4gICAgICAgIC8vdGhpcy5ub2RlLnNldFBvc2l0aW9uKHRoaXMuZXhfcG9zKTtcbiAgICB9LFxuXG4gICAgbW92ZUFuZENsb3NlQWxsQnV0dG9uOiBmdW5jdGlvbiBtb3ZlQW5kQ2xvc2VBbGxCdXR0b24oKSB7XG4gICAgICAgIGNjLmxvZyhcImFzZGFzIGFza2tra2tra2tra2tka1wiKTtcblxuICAgICAgICB0aGlzLm1haW5zY3JpcHQudXBkYXRlTW92ZUNvbnRyb2xsZXIodGhpcy5QYWREaXIpO1xuICAgICAgICB2YXIgbW92ZUNlbnRlciA9IGNjLmNhbGxGdW5jKHRoaXMubW92ZVRvQ2VudGVyLCB0aGlzKTtcbiAgICAgICAgdmFyIGRlbGF5dGltZSA9IGNjLmRlbGF5VGltZSgwLjE1KTtcbiAgICAgICAgdmFyIG1vdmVSb290UG9zID0gY2MuY2FsbEZ1bmModGhpcy5tb3ZlVG9DbG9zZXBvcywgdGhpcyk7XG4gICAgICAgIHZhciBhY3Rpb25zYyA9IGNjLnNlcXVlbmNlKG1vdmVDZW50ZXIsIGRlbGF5dGltZSwgbW92ZVJvb3RQb3MpO1xuICAgICAgICB0aGlzLm5vZGUuc3RvcEFsbEFjdGlvbnMoKTtcbiAgICAgICAgdGhpcy5ub2RlLnJ1bkFjdGlvbihhY3Rpb25zYyk7XG4gICAgfSxcbiAgICBtb3ZlVG9DbG9zZXBvczogZnVuY3Rpb24gbW92ZVRvQ2xvc2Vwb3Mob2Jqc2MpIHtcbiAgICAgICAgdmFyIGFsbGNoaWxkID0gdGhpcy5ub2RlLmNoaWxkcmVuO1xuICAgICAgICBmb3IgKHZhciBpeCA9IDA7IGl4IDwgYWxsY2hpbGQubGVuZ3RoOyBpeCsrKSB7XG4gICAgICAgICAgICB2YXIgYnQxID0gYWxsY2hpbGRbaXhdO1xuICAgICAgICAgICAgYnQxLnggPSAwO1xuICAgICAgICAgICAgYnQxLnkgPSAwO1xuICAgICAgICAgICAgaWYgKGl4ID09IDApIHtcbiAgICAgICAgICAgICAgICBidDEuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgYnQxLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vdGhpcy5idDAuYWN0aXZlPXRydWU7XG4gICAgICAgIC8vdGhpcy5idDEuYWN0aXZlPWZhbHNlO1xuICAgICAgICAvL3RoaXMuYnQyLmFjdGl2ZT1mYWxzZTtcbiAgICAgICAgLy90aGlzLmJ0My5hY3RpdmU9ZmFsc2U7XG4gICAgICAgIC8vdGhpcy5idDQuYWN0aXZlPWZhbHNlO1xuICAgICAgICAvLyB0aGlzLm5vZGUuc3RvcEFsbEFjdGlvbnMoKTtcbiAgICAgICAgdmFyIGFjdGlvbm12ID0gY2MubW92ZVRvKDAuMTgsIHRoaXMuY2xvc2VQb3MpO1xuICAgICAgICB0aGlzLm5vZGUucnVuQWN0aW9uKGFjdGlvbm12KTtcbiAgICB9LFxuICAgIG1vdmVUb0NlbnRlcjogZnVuY3Rpb24gbW92ZVRvQ2VudGVyKG9ianNjKSB7XG4gICAgICAgIGNjLmxvZyhcIi0tLS0tLS0tLS1ra2tra2sgXCIpO1xuICAgICAgICB2YXIgYWxsY2hpbGQgPSB0aGlzLm5vZGUuY2hpbGRyZW47XG5cbiAgICAgICAgLy8gdmFyIGJ0MT1hbGxjaGlsZFswXTtcbiAgICAgICAgLy8gYnQxLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIC8vIGJ0MS5vcGFjaXR5PTA7XG4gICAgICAgIHRoaXMudXBkYXRlUGFkRGlyKCk7XG5cbiAgICAgICAgLy92YXIgYnQxPWFsbGNoaWxkWzFdO1xuICAgICAgICB0aGlzLmJ0MS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICB0aGlzLm9iamVjdE1vdmVDZW50ZXIodGhpcy5idDEsIGNjLnAoMCwgMCkpO1xuXG4gICAgICAgIC8vYnQxPWFsbGNoaWxkWzJdO1xuICAgICAgICB0aGlzLmJ0Mi5hY3RpdmUgPSB0cnVlO1xuICAgICAgICB0aGlzLm9iamVjdE1vdmVDZW50ZXIodGhpcy5idDIsIGNjLnAoMCwgMCkpO1xuXG4gICAgICAgIC8vYnQxPWFsbGNoaWxkWzNdO1xuICAgICAgICB0aGlzLmJ0My5hY3RpdmUgPSB0cnVlO1xuICAgICAgICB0aGlzLm9iamVjdE1vdmVDZW50ZXIodGhpcy5idDMsIGNjLnAoMCwgMCkpO1xuXG4gICAgICAgIC8vYnQxPWFsbGNoaWxkWzRdO1xuICAgICAgICB0aGlzLmJ0NC5hY3RpdmUgPSB0cnVlO1xuICAgICAgICB0aGlzLm9iamVjdE1vdmVDZW50ZXIodGhpcy5idDQsIGNjLnAoMCwgMCkpO1xuICAgIH0sXG5cbiAgICBhY3Rpb25Nb3ZlVXA6IGZ1bmN0aW9uIGFjdGlvbk1vdmVVcCgpIHtcbiAgICAgICAgdGhpcy5QYWREaXIgPSAyO1xuICAgICAgICB0aGlzLm1vdmVBbmRDbG9zZUFsbEJ1dHRvbigpO1xuICAgICAgICAvL3RoaXMuY2xvc2VBbGxCdXR0b24oKTtcbiAgICB9LFxuICAgIGFjdGlvbk1vdmVMZWZ0OiBmdW5jdGlvbiBhY3Rpb25Nb3ZlTGVmdCgpIHtcbiAgICAgICAgdGhpcy5QYWREaXIgPSAzO1xuICAgICAgICB0aGlzLm1vdmVBbmRDbG9zZUFsbEJ1dHRvbigpO1xuICAgIH0sXG4gICAgYWN0aW9uTW92ZVJpZ2h0OiBmdW5jdGlvbiBhY3Rpb25Nb3ZlUmlnaHQoKSB7XG4gICAgICAgIGNjLmxvZyhcIm1vdmUgYWN0aW9uTW92ZVJpZ2h0XCIpO1xuICAgICAgICB0aGlzLlBhZERpciA9IDE7XG4gICAgICAgIHRoaXMubW92ZUFuZENsb3NlQWxsQnV0dG9uKCk7XG4gICAgfSxcbiAgICBhY3Rpb25Nb3ZlRG93bjogZnVuY3Rpb24gYWN0aW9uTW92ZURvd24oKSB7XG4gICAgICAgIGNjLmxvZyhcIm1vdmUgYWN0aW9uTW92ZURvd25cIik7XG4gICAgICAgIHRoaXMuUGFkRGlyID0gNDtcbiAgICAgICAgdGhpcy5tb3ZlQW5kQ2xvc2VBbGxCdXR0b24oKTtcbiAgICB9LFxuICAgIGFjdGlvbkVYOiBmdW5jdGlvbiBhY3Rpb25FWCgpIHtcbiAgICAgICAgY2MubG9nKFwibW92ZSBhY3Rpb25FWFwiKTtcbiAgICAgICAgdmFyIGJ0MCA9IHRoaXMubm9kZS5jaGlsZHJlblswXTtcbiAgICAgICAgaWYgKHRoaXMuY2hhbmdlZnJhbWUpIHtcbiAgICAgICAgICAgIHRoaXMuY2hhbmdlZnJhbWUgPSBmYWxzZTtcbiAgICAgICAgICAgIHRoaXMuaHViY29udHJvbC5yZW1vdmVGcm9tUGFyZW50KHRydWUpO1xuICAgICAgICAgICAgdGhpcy5odWJjb250cm9sID0gbnVsbDtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuZXhwbGFpbkFsbEJ1dHRvbigpO1xuICAgICAgICAvL3RoaXMubm9kZS5zZXRQb3NpdGlvbih0aGlzLmV4X3Bvcyk7XG4gICAgfVxuXG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzI3MGIxb1hXbGhMRExnaUJ6dlc5YkliJywgJ1BhbmVsVXNlckluZm8nKTtcbi8vIFNjcmlwdC9HYW1lc2NyaXB0L1BhbmVsVXNlckluZm8uanNcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIGxiQ291bnRBbW1vOiBjYy5MYWJlbCxcbiAgICAgICAgbGJDb3VudEhwOiBjYy5MYWJlbCxcbiAgICAgICAgbGJMZXZlbDogY2MuTGFiZWwsXG4gICAgICAgIGxiU3BlZWQ6IGNjLkxhYmVsLFxuICAgICAgICBwckFtbW86IGNjLk5vZGUsXG4gICAgICAgIHBySFA6IGNjLk5vZGVcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7fVxuXG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2Q4YWRhak5LN0JQV1lobjNZZUFRMit6JywgJ1NldHRpbmdDb250cm9sbGVyJyk7XG4vLyBTY3JpcHQvTElCL1NldHRpbmdDb250cm9sbGVyLmpzXG5cbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBsYl9idXR0b25fY29udHJvbDogY2MuTGFiZWwsXG4gICAgICAgIGxiX2J1dHRvbl9zb3VuZDogY2MuTGFiZWxcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIHRoaXMuYWRkVG91Y2hMaXN0ZW5FdmVudCgpO1xuICAgIH0sXG4gICAgYWRkVG91Y2hMaXN0ZW5FdmVudDogZnVuY3Rpb24gYWRkVG91Y2hMaXN0ZW5FdmVudCgpIHtcblxuICAgICAgICB0aGlzLnRvdWNoTGlzdGVuID0gY2MuZXZlbnRNYW5hZ2VyLmFkZExpc3RlbmVyKHsgZXZlbnQ6IGNjLkV2ZW50TGlzdGVuZXIuVE9VQ0hfT05FX0JZX09ORSwgc3dhbGxvd1RvdWNoZXM6IHRydWUsXG4gICAgICAgICAgICBvblRvdWNoQmVnYW46IChmdW5jdGlvbiAodG91Y2gsIGV2ZW50KSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJhbGtzZGFzZGhhc2tkLS0tLS1hc2Qtcy1zLXMtcy1zLXMtcy1zLS1zXCIpO1xuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfSkuYmluZCh0aGlzKVxuXG4gICAgICAgIH0sIHRoaXMubm9kZSk7XG5cbiAgICAgICAgdGhpcy5sb2FkTGFzdFNldHRpbmcoKTtcbiAgICB9LFxuICAgIGxvYWRMYXN0U2V0dGluZzogZnVuY3Rpb24gbG9hZExhc3RTZXR0aW5nKCkge1xuICAgICAgICB2YXIgZWZmX2Rpc2FibGUgPSBmYWxzZTtcbiAgICAgICAgdmFyIGRpc2FibGVTb3VuZCA9IGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImRpc2FibGVFZmZlY3RcIik7XG4gICAgICAgIGlmIChkaXNhYmxlU291bmQgIT0gbnVsbCkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBkaXNhYmxlU291bmQgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkFBQUEgYmVnaW4gZWZmXCIpO1xuICAgICAgICAgICAgICAgIGVmZl9kaXNhYmxlID0gZmFsc2U7XG4gICAgICAgICAgICB9IGVsc2Uge1xuXG4gICAgICAgICAgICAgICAgZWZmX2Rpc2FibGUgPSBKU09OLnBhcnNlKGRpc2FibGVTb3VuZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5sYl9idXR0b25fc291bmQuc3RyaW5nID0gZWZmX2Rpc2FibGUgPyBcIk9mZlwiIDogXCJPblwiO1xuXG4gICAgICAgIHZhciBib29sZV9zd2lwZSA9IGZhbHNlO1xuICAgICAgICB2YXIgZW5hYmxlX3N3aXBlID0gY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZW5hYmxlX3N3aXBlXCIpO1xuICAgICAgICBpZiAoZW5hYmxlX3N3aXBlICE9IG51bGwpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgZW5hYmxlX3N3aXBlID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgICAgICAgICAgZW5hYmxlX3N3aXBlID0gZmFsc2U7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGJvb2xlX3N3aXBlID0gSlNPTi5wYXJzZShlbmFibGVfc3dpcGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHRoaXMubGJfYnV0dG9uX2NvbnRyb2wuc3RyaW5nID0gIWJvb2xlX3N3aXBlID8gXCJTd2lwZVwiIDogXCJCdXR0b25cIjtcbiAgICB9LFxuICAgIGFjdGlvbkNsb3NlOiBmdW5jdGlvbiBhY3Rpb25DbG9zZSgpIHtcbiAgICAgICAgdGhpcy5ub2RlLmRlc3Ryb3koKTtcbiAgICB9LFxuICAgIGFjdGlvbkNoYW5nZUNvbnRyb2w6IGZ1bmN0aW9uIGFjdGlvbkNoYW5nZUNvbnRyb2woKSB7XG4gICAgICAgIHZhciBib29sZV9zd2lwZSA9IGZhbHNlO1xuICAgICAgICB2YXIgZW5hYmxlX3N3aXBlID0gY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZW5hYmxlX3N3aXBlXCIpO1xuICAgICAgICBpZiAoZW5hYmxlX3N3aXBlICE9IG51bGwpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgZW5hYmxlX3N3aXBlID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgICAgICAgICAgZW5hYmxlX3N3aXBlID0gZmFsc2U7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGJvb2xlX3N3aXBlID0gSlNPTi5wYXJzZShlbmFibGVfc3dpcGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGJvb2xlX3N3aXBlID0gIUpTT04ucGFyc2UoYm9vbGVfc3dpcGUpO1xuICAgICAgICBjYy5zeXMubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJlbmFibGVfc3dpcGVcIiwgYm9vbGVfc3dpcGUgKyBcIlwiKTtcbiAgICAgICAgdGhpcy5sYl9idXR0b25fY29udHJvbC5zdHJpbmcgPSAhYm9vbGVfc3dpcGUgPyBcIlN3aXBlXCIgOiBcIkJ1dHRvblwiO1xuICAgIH0sXG5cbiAgICBhY3Rpb25Pbk9mZkF1ZGlvOiBmdW5jdGlvbiBhY3Rpb25Pbk9mZkF1ZGlvKCkge1xuICAgICAgICB2YXIgZWZmX2Rpc2FibGUgPSBmYWxzZTtcbiAgICAgICAgdmFyIGRpc2FibGVTb3VuZCA9IGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImRpc2FibGVFZmZlY3RcIik7XG4gICAgICAgIGNjLmxvZyhcIi0tLS0tLS06IFwiLCBkaXNhYmxlU291bmQpO1xuICAgICAgICBpZiAoZGlzYWJsZVNvdW5kICE9IG51bGwpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgZGlzYWJsZVNvdW5kID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgICAgICAgICAgZWZmX2Rpc2FibGUgPSBmYWxzZTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgZWZmX2Rpc2FibGUgPSBKU09OLnBhcnNlKGRpc2FibGVTb3VuZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWZmX2Rpc2FibGUgPSAhSlNPTi5wYXJzZShlZmZfZGlzYWJsZSk7XG4gICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImRpc2FibGVFZmZlY3RcIiwgZWZmX2Rpc2FibGUgKyBcIlwiKTtcbiAgICAgICAgdGhpcy5sYl9idXR0b25fc291bmQuc3RyaW5nID0gZWZmX2Rpc2FibGUgPyBcIk9mZlwiIDogXCJPblwiO1xuICAgIH1cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnOWI4MTA1TGluNVByS3BGYUxyWXdvd0UnLCAnVGFua0VmZmVjdFNjcmlwdCcpO1xuLy8gU2NyaXB0L0dhbWVzY3JpcHQvVGFua0VmZmVjdFNjcmlwdC5qc1xuXG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgc3BBdGxhczogY2MuU3ByaXRlQXRsYXNcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7fSxcbiAgICBydW5FZmZlY3Q6IGZ1bmN0aW9uIHJ1bkVmZmVjdChzcEF0bGFzLCBpZCkge1xuXG4gICAgICAgIHZhciBhbGxjaGlsZCA9IHRoaXMubm9kZS5jaGlsZHJlbjtcbiAgICAgICAgZm9yICh2YXIgaXggPSAwOyBpeCA8PSA4OyBpeCsrKSB7XG4gICAgICAgICAgICB2YXIgY2hpbGROb2RlID0gYWxsY2hpbGRbaXhdO1xuICAgICAgICAgICAgdmFyIHNwID0gY2hpbGROb2RlLmdldENvbXBvbmVudChcImNjLlNwcml0ZVwiKTtcbiAgICAgICAgICAgIHNwLnNwcml0ZUZyYW1lID0gc3BBdGxhcy5nZXRTcHJpdGVGcmFtZShcIlB0YW5rLVwiICsgaWQgKyBcIl90ZXhcIiArIGl4KTtcbiAgICAgICAgICAgIHZhciB0aW1lMSA9ICgwLjMgKyBNYXRoLnJhbmRvbSgpICogMC43KSAqIDEuMjtcbiAgICAgICAgICAgIHZhciBhbmdsZSA9IDkwICsgTWF0aC5yYW5kb20oKSAqIDM2MDtcbiAgICAgICAgICAgIHZhciByb3RhdGVieSA9IGNjLnJvdGF0ZUJ5KHRpbWUxLCBhbmdsZSk7XG5cbiAgICAgICAgICAgIHZhciBtdnggPSAoMC41IC0gTWF0aC5yYW5kb20oKSkgKiAzMDA7XG4gICAgICAgICAgICB2YXIgbXZ5ID0gKDAuNSAtIE1hdGgucmFuZG9tKCkpICogMzAwO1xuXG4gICAgICAgICAgICB2YXIgYWN0aW9ubW92ZSA9IGNjLm1vdmVCeSh0aW1lMSwgY2MucChtdngsIG12eSkpO1xuICAgICAgICAgICAgdmFyIGZhZGUgPSBjYy5mYWRlVG8odGltZTEgKiAwLjMsIDApO1xuICAgICAgICAgICAgdmFyIGRlbGF5ID0gY2MuZGVsYXlUaW1lKHRpbWUxICsgMC42KTtcbiAgICAgICAgICAgIHZhciBzcWFjdGlvbiA9IGNjLnNlcXVlbmNlKGRlbGF5LCBmYWRlKTtcbiAgICAgICAgICAgIGNoaWxkTm9kZS5ydW5BY3Rpb24oY2Muc3Bhd24ocm90YXRlYnksIGFjdGlvbm1vdmUsIHNxYWN0aW9uKSk7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgc3RhcnQ6IGZ1bmN0aW9uIHN0YXJ0KCkge1xuICAgICAgICBzZXRUaW1lb3V0KChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB0aGlzLm5vZGUuZGVzdHJveSgpO1xuICAgICAgICB9KS5iaW5kKHRoaXMpLCAxNzAwKTtcbiAgICB9XG5cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnNDYyNzdxYlBSMUFDSTJaM280b1VIQmQnLCAnVGVzdENvbm5lY3QnKTtcbi8vIFNjcmlwdC9UZXN0U2NyaXB0L1Rlc3RDb25uZWN0LmpzXG5cbmNjLkNsYXNzKHtcbiAgICAnZXh0ZW5kcyc6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgbGFiZWxfc3RhdHVzOiB7XG4gICAgICAgICAgICB0eXBlOiBjYy5MYWJlbCxcbiAgICAgICAgICAgICdkZWZhdWx0JzogbnVsbFxuICAgICAgICB9XG5cbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7fSxcblxuICAgIGFjdGlvbkNvbm5lY3Q6IGZ1bmN0aW9uIGFjdGlvbkNvbm5lY3QoKSB7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgcmVxdWlyZSgnc29ja2V0LmlvJyk7XG4gICAgICAgIHRoaXMuc29ja2V0ID0gaW8uY29ubmVjdCgnbG9jYWxob3N0OjIwMjAnKTtcbiAgICAgICAgdGhpcy5zb2NrZXQub24oJ2Nvbm5lY3QnLCBmdW5jdGlvbiAobXNnU2VuZCkge1xuICAgICAgICAgICAgY2MubG9nKFwiY29ubmVjdGlvbi0tLS0tLT5cIik7XG4gICAgICAgICAgICBzZWxmLmxhYmVsX3N0YXR1cy5zdHJpbmcgPSBcIkFMS0hLSkhLRFwiO1xuICAgICAgICB9KTtcbiAgICB9XG5cbn0pO1xuLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbi8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbi8vIH0sXG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICdhZDljM3BnY245T1FyelJldEVvY21KYycsICdUZXN0RWZmZWN0Jyk7XG4vLyBTY3JpcHQvVGVzdFNjcmlwdC9UZXN0RWZmZWN0LmpzXG5cbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBzcEJ1bGxldDogY2MuTm9kZSxcbiAgICAgICAgbXNUZXh0dXJlOiBjYy5UZXh0dXJlMkQsXG4gICAgICAgIHNwWDE6IGNjLk5vZGUsXG4gICAgICAgIHNwWDI6IGNjLk5vZGUsXG4gICAgICAgIGZyYW1lQWx0czogY2MuU3ByaXRlQXRsYXMsXG4gICAgICAgIHBhcnRUZXN0OiBjYy5QYXJ0aWNsZVN5c3RlbSxcbiAgICAgICAgdGFua0VmZmVjdDogY2MuUHJlZmFiLFxuICAgICAgICBob21lTWFwOiBjYy5Ob2RlXG4gICAgICAgIC8vc3BfcGFydGljbGU6Y2MuTm9kZVxuICAgIH0sXG4gICAgc3RhcnQ6IGZ1bmN0aW9uIHN0YXJ0KCkge1xuICAgICAgICBjYy5sb2coXCJub2RlX2FkZDpzdGFydFwiKTtcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIHZhciB4Y29sY29sb3IgPSBuZXcgY2MuQ29sb3IoMjU1LCAyNTUsIDApO1xuXG4gICAgICAgIGNjLmxvZyhcIm5vZGVfYWRkOm9uTG9hZFwiKTtcblxuICAgICAgICAvL3RoaXMuc3BYMS5zZXRMb2NhbFpPcmRlcigzKTtcbiAgICAgICAgLy8gdGhpcy5zcFgyLnNldEdsb2JhbFpPcmRlcigyKTtcblxuICAgICAgICAvLyB0aGlzLnNwWDIuZ2xvYmFsWk9yZGVyPS0xO1xuICAgICAgICAvLyB0aGlzLnNwWDIuY29sb3I9bmV3IGNjLkNvbG9yKDI1NSwyNTUsMCk7XG5cbiAgICAgICAgLy92YXIgYWN0aW9uMT1jYy5Nb3ZlQnkoMTAsY2MucCg1MDAsMCkpO1xuICAgICAgICAvL3RoaXMuaG9tZU1hcC5ydW5BY3Rpb24oYWN0aW9uMSk7XG5cbiAgICAgICAgLy8gY2MubG9nKFwibm9kZV9hZGQ6bmFtZT0gJXNcIixub2RlX2FkZC5uYW1lKTtcblxuICAgICAgICAvLyB0aGlzLm5vZGVfZmlyZT1uZXcgY2MuTm9kZShcIm5vZGVQYXJ0aWNsZVN5c3RlbVwiKTtcbiAgICAgICAgLy8gdGhpcy5tcz10aGlzLm5vZGVfZmlyZS5hZGRDb21wb25lbnQoY2MuUGFydGljbGVTeXN0ZW0pO1xuICAgICAgICAvLyB0aGlzLm1zLmZpbGU9XCJcIjtcblxuICAgICAgICAvLyB0aGlzLm5vZGUuYWRkQ2hpbGQodGhpcy5ub2RlX2ZpcmUpO1xuXG4gICAgICAgIC8vY2MubG9nKFwidGhpcy5zcF9wYXJ0aWNsZS5uYW1lOiAlcyBjb3VudCBhbGxjaGlsZDpcIix0aGlzLnNwX3BhcnRpY2xlLm5hbWUsdGhpcy5ub2RlLmNoaWxkcmVuLmxlbmd0aCk7XG4gICAgICAgIC8vY2MuZGlyZWN0b3IuZ2V0U2NoZWR1bGVyKCkuc2NoZWR1bGUoZnVuY3Rpb24oKSB7IHRoaXMudGVzdE1vdmV4eCgpOyB9LCB0aGlzLCAwLjEsICF0aGlzLl9pc1J1bm5pbmcpO1xuICAgICAgICAvLyB0aGlzLnRlc3RNb3ZleHgoKTtcbiAgICB9LFxuXG4gICAgdGVzdE1vdmV4eDogZnVuY3Rpb24gdGVzdE1vdmV4eChkdCkge1xuICAgICAgICB2YXIgdGFua05vZGVFZmYgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLnRhbmtFZmZlY3QpO1xuICAgICAgICB0YW5rTm9kZUVmZi54ID0gNTA7XG4gICAgICAgIHRhbmtOb2RlRWZmLnkgPSAxODA7XG5cbiAgICAgICAgdmFyIHNjcmlwdF9lZmYgPSB0YW5rTm9kZUVmZi5nZXRDb21wb25lbnQoXCJUYW5rRWZmZWN0U2NyaXB0XCIpO1xuICAgICAgICBzY3JpcHRfZWZmLnJ1bkVmZmVjdCh0aGlzLmZyYW1lQWx0cywgMyk7XG4gICAgICAgIHRoaXMubm9kZS5hZGRDaGlsZCh0YW5rTm9kZUVmZik7XG5cbiAgICAgICAgLy90aGlzLmhvbWVNYXAuYWRkQ2hpbGQodGFua05vZGUpO1xuXG4gICAgICAgIC8vLy9jb25zb2xlLmxvZyhcInBhcnRUZXN0OiAlc1wiLHRoaXMucGFydFRlc3QuZ3JvdXApO1xuICAgICAgICAvL2lmICh0aGlzLnBhcnRUZXN0LnBvc2l0aW9uVHlwZT09MSl7XG4gICAgICAgIC8vICAgIHRoaXMucGFydFRlc3QucG9zaXRpb25UeXBlPTA7XG4gICAgICAgIC8vfWVsc2V7XG4gICAgICAgIC8vICAgIHRoaXMucGFydFRlc3QucG9zaXRpb25UeXBlPTE7XG4gICAgICAgIC8vfVxuICAgICAgICAvL1xuICAgICAgICAvL2NvbnNvbGUubG9nKFwidGFua05vZGUuY2hpbGRyZW46IFwiK3RoaXMuaG9tZU1hcC5jaGlsZHJlbi5sZW5ndGgpO1xuXG4gICAgICAgIC8vdmFyIG5vZGV4PXRhbmtOb2RlLmNoaWxkcmVuWzldO1xuICAgICAgICAvL25vZGV4LnBvc2l0aW9uVHlwZT0xO1xuICAgICAgICAvL25vZGV4PXRhbmtOb2RlLmNoaWxkcmVuWzEwXTtcbiAgICAgICAgLy9ub2RleC5wb3NpdGlvblR5cGU9MTtcbiAgICB9LFxuXG4gICAgYWN0aW9uQ2hlY2tFZmZlY3Q6IGZ1bmN0aW9uIGFjdGlvbkNoZWNrRWZmZWN0KCkge1xuICAgICAgICB0aGlzLnVuc2NoZWR1bGVBbGxDYWxsYmFja3MoKTtcbiAgICAgICAgLy8gY2MubG9nKFwidGhpcy5ub2RlLmNoaWxkcmVuLmxlbmd0aDogJXNcIix0aGlzLm5vZGUuY2hpbGRyZW4ubGVuZ3RoKTtcbiAgICAgICAgLy8gY2MubG9nKFwidGhpcy5zcF9wYXJ0aWNsZS5uYW1lOiAlc1wiLHRoaXMuc3BfcGFydGljbGUubmFtZSk7XG4gICAgICAgIC8vIGlmIChjYy5pc1ZhbGlkKHNwX3BhcnRpY2xlKSkge1xuICAgICAgICAvLyAgICAgY2MubG9nKFwiaXMgYWN0aXZhdGVcIik7XG4gICAgICAgIC8vIH1lbHNle1xuICAgICAgICAvLyAgICAgY2MubG9nKFwiaXMgUmVtb3ZlIFwiKTtcbiAgICAgICAgLy8gfVxuICAgIH0sXG5cbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuICAgIHVwZGF0ZTogZnVuY3Rpb24gdXBkYXRlKGR0KSB7XG4gICAgICAgIC8vdGhpcy5ob21lTWFwLng9dGhpcy5ob21lTWFwLngrMjtcblxuICAgIH1cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnY2YyN2EzNFZDNURVNjA3OUFmYmZTMFgnLCAnVGVzdFBhcnRpY2xlU3lzdGVtUG9zJyk7XG4vLyBTY3JpcHQvVGVzdFNjcmlwdC9UZXN0UGFydGljbGVTeXN0ZW1Qb3MuanNcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLFxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy5sb2dNeVBvc2l0aW9uKCk7XG4gICAgfSxcblxuICAgIGxvZ015UG9zaXRpb246IGZ1bmN0aW9uIGxvZ015UG9zaXRpb24oKSB7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgdGhpcy5jb3VudFN0ZXAgPSAwO1xuICAgICAgICB2YXIgVElNRV9GUkFNRV9TRVJWRVIgPSAwLjA4O1xuICAgICAgICB0aGlzLnNjaGVkdWxlKGZ1bmN0aW9uIChkdCkge1xuXG4gICAgICAgICAgICBjYy5sb2coXCItLS0tLS0tLS0tLSVzLS0tLS0tLS0tLS1Qb3M6ICVzICVzXCIsIHRoaXMubm9kZS5jaGlsZHJlbi5sZW5ndGgsIHRoaXMubm9kZS54LCB0aGlzLm5vZGUueSk7XG4gICAgICAgIH0sIDAuMDAxKTtcbiAgICB9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2VhMWE1emMxa0JCc0pwaGxHR0hqb2pXJywgJ1V0aWxzJyk7XG4vLyBTY3JpcHQvTElCL1V0aWxzLmpzXG5cbnZhciBDb3V0cnlTZXJ2ZXIgPSB7IElNOiBcInRhbmtldVwiLCBIUjogXCJ0YW5rZXVcIiwgR1c6IFwidGFua2V1XCIsIElOOiBcInRhbmthc2lhXCIsIEtFOiBcInRhbmtldVwiLCBMQTogXCJ0YW5rYXNpYVwiLCBJTzogXCJ0YW5rYXNpYVwiLCBIVDogXCJ0YW5rXCIsIEdZOiBcInRhbmtcIiwgTEI6IFwidGFua2FzaWFcIiwgS0c6IFwidGFua2FzaWFcIiwgSFU6IFwidGFua2V1XCIsIExDOiBcInRhbmtcIiwgSVE6IFwidGFua2FzaWFcIiwgS0g6IFwidGFua2FzaWFcIiwgSk06IFwidGFua1wiLCBJUjogXCJ0YW5rYXNpYVwiLCBLSTogXCJ0YW5rYXNpYVwiLCBJUzogXCJ0YW5rZXVcIiwgTUE6IFwidGFua2V1XCIsIEpPOiBcInRhbmthc2lhXCIsIElUOiBcInRhbmtldVwiLCBKUDogXCJ0YW5rYXNpYVwiLCBNQzogXCJ0YW5rZXVcIiwgS006IFwidGFua2V1XCIsIE1EOiBcInRhbmtldVwiLCBMSTogXCJ0YW5rZXVcIiwgS046IFwidGFua1wiLCBNRTogXCJ0YW5rZXVcIiwgTkE6IFwidGFua2V1XCIsIE1GOiBcInRhbmtcIiwgTEs6IFwidGFua2FzaWFcIiwgS1A6IFwidGFua2FzaWFcIiwgTUc6IFwidGFua2V1XCIsIE5DOiBcInRhbmthc2lhXCIsIE1IOiBcInRhbmthc2lhXCIsIEtSOiBcInRhbmthc2lhXCIsIE5FOiBcInRhbmtldVwiLCBORjogXCJ0YW5rYXNpYVwiLCBNSzogXCJ0YW5rZXVcIiwgTkc6IFwidGFua2V1XCIsIE1MOiBcInRhbmtldVwiLCBNTTogXCJ0YW5rYXNpYVwiLCBMUjogXCJ0YW5rZXVcIiwgTkk6IFwidGFua1wiLCBLVzogXCJ0YW5rYXNpYVwiLCBNTjogXCJ0YW5rYXNpYVwiLCBMUzogXCJ0YW5rZXVcIiwgUEE6IFwidGFua1wiLCBNTzogXCJ0YW5rYXNpYVwiLCBMVDogXCJ0YW5rZXVcIiwgS1k6IFwidGFua1wiLCBNUDogXCJ0YW5rYXNpYVwiLCBMVTogXCJ0YW5rZXVcIiwgTkw6IFwidGFua2V1XCIsIEtaOiBcInRhbmthc2lhXCIsIE1ROiBcInRhbmtcIiwgTFY6IFwidGFua2V1XCIsIE1SOiBcInRhbmtldVwiLCBQRTogXCJ0YW5rXCIsIE1TOiBcInRhbmtcIiwgUUE6IFwidGFua2FzaWFcIiwgTk86IFwidGFua2V1XCIsIFBGOiBcInRhbmthc2lhXCIsIE1UOiBcInRhbmtldVwiLCBMWTogXCJ0YW5rZXVcIiwgTlA6IFwidGFua2FzaWFcIiwgUEc6IFwidGFua2FzaWFcIiwgTVU6IFwidGFua2V1XCIsIFBIOiBcInRhbmthc2lhXCIsIE1WOiBcInRhbmthc2lhXCIsIE9NOiBcInRhbmthc2lhXCIsIE5SOiBcInRhbmthc2lhXCIsIE1XOiBcInRhbmtldVwiLCBNWDogXCJ0YW5rXCIsIFBLOiBcInRhbmthc2lhXCIsIE1ZOiBcInRhbmthc2lhXCIsIE5VOiBcInRhbmthc2lhXCIsIFBMOiBcInRhbmtldVwiLCBNWjogXCJ0YW5rZXVcIiwgUE06IFwidGFua1wiLCBQTjogXCJ0YW5rYXNpYVwiLCBSRTogXCJ0YW5rZXVcIiwgU0E6IFwidGFua2FzaWFcIiwgU0I6IFwidGFua2FzaWFcIiwgTlo6IFwidGFua2FzaWFcIiwgU0M6IFwidGFua2V1XCIsIFNEOiBcInRhbmtldVwiLCBQUjogXCJ0YW5rXCIsIFNFOiBcInRhbmtldVwiLCBQUzogXCJ0YW5rYXNpYVwiLCBQVDogXCJ0YW5rZXVcIiwgU0c6IFwidGFua2FzaWFcIiwgVEM6IFwidGFua1wiLCBTSDogXCJ0YW5rZXVcIiwgVEQ6IFwidGFua2V1XCIsIFNJOiBcInRhbmtldVwiLCBQVzogXCJ0YW5rYXNpYVwiLCBTSjogXCJ0YW5rZXVcIiwgVUE6IFwidGFua2V1XCIsIFJPOiBcInRhbmtldVwiLCBURjogXCJ0YW5rZXVcIiwgU0s6IFwidGFua2V1XCIsIFBZOiBcInRhbmtcIiwgVEc6IFwidGFua2V1XCIsIFNMOiBcInRhbmtldVwiLCBUSDogXCJ0YW5rYXNpYVwiLCBTTTogXCJ0YW5rZXVcIiwgU046IFwidGFua2V1XCIsIFJTOiBcInRhbmtldVwiLCBUSjogXCJ0YW5rYXNpYVwiLCBWQTogXCJ0YW5rZXVcIiwgU086IFwidGFua2V1XCIsIFRLOiBcInRhbmthc2lhXCIsIFVHOiBcInRhbmtldVwiLCBSVTogXCJ0YW5rZXVcIiwgVEw6IFwidGFua2FzaWFcIiwgVkM6IFwidGFua1wiLCBUTTogXCJ0YW5rYXNpYVwiLCBTUjogXCJ0YW5rXCIsIFJXOiBcInRhbmtldVwiLCBUTjogXCJ0YW5rZXVcIiwgVkU6IFwidGFua1wiLCBTUzogXCJ0YW5rZXVcIiwgVE86IFwidGFua2FzaWFcIiwgU1Q6IFwidGFua2V1XCIsIFZHOiBcInRhbmtcIiwgU1Y6IFwidGFua1wiLCBVTTogXCJ0YW5rYXNpYVwiLCBUUjogXCJ0YW5rYXNpYVwiLCBWSTogXCJ0YW5rXCIsIFNYOiBcInRhbmtcIiwgV0Y6IFwidGFua2FzaWFcIiwgVFQ6IFwidGFua1wiLCBTWTogXCJ0YW5rYXNpYVwiLCBTWjogXCJ0YW5rZXVcIiwgVFY6IFwidGFua2FzaWFcIiwgVFc6IFwidGFua2FzaWFcIiwgVk46IFwidGFua2FzaWFcIiwgVVM6IFwidGFua1wiLCBUWjogXCJ0YW5rZXVcIiwgWUU6IFwidGFua2FzaWFcIiwgWkE6IFwidGFua2V1XCIsIFhLOiBcInRhbmtldVwiLCBVWTogXCJ0YW5rXCIsIFZVOiBcInRhbmthc2lhXCIsIFVaOiBcInRhbmthc2lhXCIsIFdTOiBcInRhbmthc2lhXCIsIFpNOiBcInRhbmtldVwiLCBBRDogXCJ0YW5rZXVcIiwgWVQ6IFwidGFua2V1XCIsIEFFOiBcInRhbmthc2lhXCIsIEJBOiBcInRhbmtldVwiLCBBRjogXCJ0YW5rYXNpYVwiLCBCQjogXCJ0YW5rXCIsIEFHOiBcInRhbmtcIiwgQkQ6IFwidGFua2FzaWFcIiwgQUk6IFwidGFua1wiLCBCRTogXCJ0YW5rZXVcIiwgQ0E6IFwidGFua1wiLCBCRjogXCJ0YW5rZXVcIiwgQkc6IFwidGFua2V1XCIsIFpXOiBcInRhbmtldVwiLCBBTDogXCJ0YW5rZXVcIiwgQ0M6IFwidGFua2FzaWFcIiwgQkg6IFwidGFua2FzaWFcIiwgQU06IFwidGFua2FzaWFcIiwgQ0Q6IFwidGFua2V1XCIsIEJJOiBcInRhbmtldVwiLCBCSjogXCJ0YW5rZXVcIiwgQU86IFwidGFua2V1XCIsIENGOiBcInRhbmtldVwiLCBDRzogXCJ0YW5rZXVcIiwgQkw6IFwidGFua1wiLCBBUTogXCJ0YW5rZXVcIiwgQ0g6IFwidGFua2V1XCIsIEJNOiBcInRhbmtcIiwgQVI6IFwidGFua1wiLCBDSTogXCJ0YW5rZXVcIiwgQk46IFwidGFua2FzaWFcIiwgREU6IFwidGFua2V1XCIsIEFTOiBcInRhbmthc2lhXCIsIEJPOiBcInRhbmtcIiwgQVQ6IFwidGFua2V1XCIsIENLOiBcInRhbmthc2lhXCIsIEFVOiBcInRhbmthc2lhXCIsIENMOiBcInRhbmtcIiwgRUM6IFwidGFua1wiLCBCUTogXCJ0YW5rXCIsIENNOiBcInRhbmtldVwiLCBCUjogXCJ0YW5rXCIsIEFXOiBcInRhbmtcIiwgQ046IFwidGFua2FzaWFcIiwgRUU6IFwidGFua2V1XCIsIEJTOiBcInRhbmtcIiwgREo6IFwidGFua2V1XCIsIEFYOiBcInRhbmtldVwiLCBDTzogXCJ0YW5rXCIsIEJUOiBcInRhbmthc2lhXCIsIERLOiBcInRhbmtldVwiLCBFRzogXCJ0YW5rZXVcIiwgQVo6IFwidGFua2FzaWFcIiwgRUg6IFwidGFua2V1XCIsIEJWOiBcInRhbmtldVwiLCBETTogXCJ0YW5rXCIsIENSOiBcInRhbmtcIiwgQlc6IFwidGFua2V1XCIsIEdBOiBcInRhbmtldVwiLCBETzogXCJ0YW5rXCIsIEJZOiBcInRhbmtldVwiLCBHQjogXCJ0YW5rZXVcIiwgQ1U6IFwidGFua1wiLCBCWjogXCJ0YW5rXCIsIENWOiBcInRhbmtldVwiLCBHRDogXCJ0YW5rXCIsIEZJOiBcInRhbmtldVwiLCBDVzogXCJ0YW5rXCIsIEdFOiBcInRhbmthc2lhXCIsIEZKOiBcInRhbmthc2lhXCIsIENYOiBcInRhbmthc2lhXCIsIEdGOiBcInRhbmtcIiwgRks6IFwidGFua1wiLCBDWTogXCJ0YW5rZXVcIiwgR0c6IFwidGFua2V1XCIsIENaOiBcInRhbmtldVwiLCBHSDogXCJ0YW5rZXVcIiwgRk06IFwidGFua2FzaWFcIiwgRVI6IFwidGFua2V1XCIsIEdJOiBcInRhbmtldVwiLCBFUzogXCJ0YW5rZXVcIiwgRk86IFwidGFua2V1XCIsIEVUOiBcInRhbmtldVwiLCBHTDogXCJ0YW5rXCIsIERaOiBcInRhbmtldVwiLCBHTTogXCJ0YW5rZXVcIiwgSUQ6IFwidGFua2FzaWFcIiwgRlI6IFwidGFua2V1XCIsIEdOOiBcInRhbmtldVwiLCBJRTogXCJ0YW5rZXVcIiwgSEs6IFwidGFua2FzaWFcIiwgR1A6IFwidGFua1wiLCBHUTogXCJ0YW5rZXVcIiwgSE06IFwidGFua2V1XCIsIEdSOiBcInRhbmtldVwiLCBITjogXCJ0YW5rXCIsIEpFOiBcInRhbmtldVwiLCBHUzogXCJ0YW5rZXVcIiwgR1Q6IFwidGFua1wiLCBHVTogXCJ0YW5rYXNpYVwiLCBJTDogXCJ0YW5rYXNpYVwiIH07XG52YXIgVXRpbHMgPSB7XG4gICAgbG9nOiBmdW5jdGlvbiBsb2cobXNnb2JqZWN0KSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiLUdBTUVJT0xJVkUtOiVzXCIsIG1zZ29iamVjdCk7XG4gICAgfSxcblxuICAgIGdldFNlcnZlcjogZnVuY3Rpb24gZ2V0U2VydmVyKCkge1xuICAgICAgICB2YXIgY29udHJ5Y29kZSA9IGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImNvdW50cnlcIik7XG5cbiAgICAgICAgaWYgKHR5cGVvZiBjb250cnljb2RlID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgICAgICBjb250cnljb2RlID0gXCJVU1wiO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjb250cnljb2RlID09IG51bGwpIHtcbiAgICAgICAgICAgIGNvbnRyeWNvZGUgPSBcIlVTXCI7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNvbnRyeWNvZGUubGVuZ3RoICE9IDIpIHtcbiAgICAgICAgICAgIGNvbnRyeWNvZGUgPSBcIlVTXCI7XG4gICAgICAgIH1cbiAgICAgICAgY29udHJ5Y29kZSA9IGNvbnRyeWNvZGUudG9VcHBlckNhc2UoKTtcblxuICAgICAgICB2YXIgc3ViZG9tYWluID0gQ291dHJ5U2VydmVyW2NvbnRyeWNvZGVdO1xuICAgICAgICBpZiAodHlwZW9mIHN1YmRvbWFpbiA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICAgICAgc3ViZG9tYWluID0gXCJ0YW5rXCI7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHN1YmRvbWFpbiA9PSBudWxsKSB7XG4gICAgICAgICAgICBzdWJkb21haW4gPSBcInRhbmtcIjtcbiAgICAgICAgfVxuXG4gICAgICAgIHZhciBkb21haW4gPSBcImh0dHA6Ly9cIiArIHN1YmRvbWFpbiArIFwiLmdhbWVpby5saXZlOjIwMjBcIjtcbiAgICAgICAgY29uc29sZS5sb2coXCJjb250cnljb2RlOiAlcyAgLyAlc1wiLCBjb250cnljb2RlLCBkb21haW4pO1xuICAgICAgICByZXR1cm4gZG9tYWluO1xuICAgIH0sXG5cbiAgICBkaXN0YW5jZTJQb3M6IGZ1bmN0aW9uIGRpc3RhbmNlMlBvcyhwMSwgcDIpIHtcbiAgICAgICAgdmFyIGR0eCA9IHAxLnggLSBwMi54O1xuICAgICAgICB2YXIgZHR5ID0gcDEueSAtIHAyLnk7XG4gICAgICAgIHJldHVybiBNYXRoLnNxcnQoTWF0aC5wb3coZHR4LCAyKSArIE1hdGgucG93KGR0eSwgMikpO1xuICAgIH0sXG4gICAgbG9hZFVzZXJJbmZvOiBmdW5jdGlvbiBsb2FkVXNlckluZm8oKSB7XG4gICAgICAgIHZhciBzdHJSVCA9ICd7XCJwbGF0Zm9ybVwiOjEwLFwidmVyc2lvblwiOjEuMSxcInVzclwiOlwiVXNlck5hbWVcIixcImNvZGVcIjpcInZuXCJ9JzsgLy8gdGhlbyBxdXkgxrDhu5tjIHRow6wgOSBsw6AgaU9TLDEwIGzDoCB3ZWIgbW9iaWxlLCAxMSBsw6AgYW5kcm9pZFxuXG4gICAgICAgIHZhciBjb250cnljb2RlID0gY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiY291bnRyeVwiKTtcbiAgICAgICAgaWYgKGNvbnRyeWNvZGUgIT0gbnVsbCkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBjb250cnljb2RlID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgICAgICAgICAgY2MubG9nKFwiZXJyb3IgbG9hZCBjb250cnkgY29kZVwiKTtcbiAgICAgICAgICAgICAgICBzdHJSVCA9IHN0clJULnJlcGxhY2UoXCJ2blwiLCBcInVzXCIpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBzdHJSVCA9IHN0clJULnJlcGxhY2UoXCJ2blwiLCBjb250cnljb2RlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBzdHJSVCA9IHN0clJULnJlcGxhY2UoXCJVc2VyTmFtZVwiLCBVdGlscy5wbGF5ZXJOYW1lKTtcbiAgICAgICAgY2MubG9nKFwic3RyUlQ6ICVzXCIsIHN0clJUKTtcbiAgICAgICAgcmV0dXJuIHN0clJUO1xuICAgIH0sXG4gICAgZGVDb2RlOiBmdW5jdGlvbiBkZUNvZGUoa2V5Q29kZSkge1xuICAgICAgICB2YXIgZW5kID0ga2V5Q29kZS5sZW5ndGggKiAwLjY7XG4gICAgICAgIHZhciBiZWdpbiA9IGtleUNvZGUubGVuZ3RoICogMC4xO1xuICAgICAgICB2YXIgbmV3a2V5ID0ga2V5Q29kZS5zdWJzdHJpbmcoYmVnaW4sIGVuZCk7XG4gICAgICAgIHJldHVybiBuZXdrZXk7XG4gICAgfSxcblxuICAgIGRlY29kZVBhY2tUYW5rOiBmdW5jdGlvbiBkZWNvZGVQYWNrVGFuayhvYmplY3RFbmRjb2RlKSB7XG4gICAgICAgIHZhciBwc2VuZCA9IG9iamVjdEVuZGNvZGUucDtcbiAgICAgICAgdmFyIHhfdG1wID0gcHNlbmQgLyAxMDAwMDAuMDtcbiAgICAgICAgdmFyIHhwID0geF90bXAgLyAxMC4wO1xuICAgICAgICB4cCA9IHhwIC0gMjAwMDtcbiAgICAgICAgdmFyIHlfdG1wID0gcHNlbmQgJSAxMDAwMDA7XG4gICAgICAgIHZhciB5cCA9IHlfdG1wIC8gMTAuMDtcbiAgICAgICAgeXAgPSB5cCAtIDIwMDA7XG5cbiAgICAgICAgdmFyIGVfZ19yX2QgPSBvYmplY3RFbmRjb2RlLnI7XG4gICAgICAgIHZhciBkaXIgPSAwO1xuICAgICAgICBpZiAoZV9nX3JfZCA+PSAxMDAwMDAwKSB7XG4gICAgICAgICAgICBkaXIgPSBwYXJzZUludChlX2dfcl9kIC8gMTAwMDAwMCk7XG4gICAgICAgICAgICBlX2dfcl9kID0gZV9nX3JfZCAtIGRpciAqIDEwMDAwMDA7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHRhbmtfYW5nbGUgPSBlX2dfcl9kIC8gMTAwMDtcbiAgICAgICAgdmFyIGd1bl9hbmdsZSA9IGVfZ19yX2QgJSAxMDAwO1xuXG4gICAgICAgIHZhciBlX3ggPSBvYmplY3RFbmRjb2RlLmU7XG4gICAgICAgIHZhciBocCA9IHBhcnNlSW50KGVfeCAvIDEwMDAwLjApO1xuICAgICAgICB2YXIgYW1tbyA9IGVfeCAlIDEwMDAwO1xuXG4gICAgICAgIHZhciBsZXZlbF9zY29yZSA9IG9iamVjdEVuZGNvZGUucztcbiAgICAgICAgdmFyIGxldmVsX3MgPSBsZXZlbF9zY29yZSAvIDEwMDAwMDAuMDtcbiAgICAgICAgdmFyIHNjb3JlX3MgPSBsZXZlbF9zY29yZSAlIDEwMDAwMDA7XG5cbiAgICAgICAgdmFyIHRfSUQgPSBvYmplY3RFbmRjb2RlLmk7XG4gICAgICAgIHZhciBzcHBlZCA9IG9iamVjdEVuZGNvZGUubTtcblxuICAgICAgICB2YXIgdGFua05hbWUgPSBcIlwiO1xuICAgICAgICB2YXIgbmFtZXNlcnZlciA9IG9iamVjdEVuZGNvZGUubjtcbiAgICAgICAgaWYgKHR5cGVvZiBuYW1lc2VydmVyID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgICAgICB0YW5rTmFtZSA9IFwiXCI7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0YW5rTmFtZSA9IG9iamVjdEVuZGNvZGUubjtcbiAgICAgICAgfVxuXG4gICAgICAgIHZhciBjY29kZSA9IG9iamVjdEVuZGNvZGUuYztcbiAgICAgICAgaWYgKHR5cGVvZiBjY29kZSA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICAgICAgY2NvZGUgPSBcInZuXCI7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjY29kZSA9IG9iamVjdEVuZGNvZGUuYztcbiAgICAgICAgfVxuXG4gICAgICAgIHZhciBvYmplY3REZWNvZGUgPSB7XG4gICAgICAgICAgICB4OiB4cCxcbiAgICAgICAgICAgIHk6IHlwLFxuICAgICAgICAgICAgaWQ6IHRfSUQsXG4gICAgICAgICAgICByOiB0YW5rX2FuZ2xlLFxuICAgICAgICAgICAgbGV2ZWw6IGxldmVsX3MsXG4gICAgICAgICAgICBzY29yZTogc2NvcmVfcyxcbiAgICAgICAgICAgIGhwOiBocCxcbiAgICAgICAgICAgIGRpcjogZGlyLFxuICAgICAgICAgICAgYW1tbzogYW1tbyxcbiAgICAgICAgICAgIHNwOiBzcHBlZCxcbiAgICAgICAgICAgIG5hbWU6IHRhbmtOYW1lLFxuICAgICAgICAgICAgZ1I6IGd1bl9hbmdsZSxcbiAgICAgICAgICAgIGNvZGU6IGNjb2RlXG4gICAgICAgIH07XG4gICAgICAgIHJldHVybiBvYmplY3REZWNvZGU7XG4gICAgfSxcblxuICAgIGRlY29kZVBhY2tPYnM6IGZ1bmN0aW9uIGRlY29kZVBhY2tPYnMob2JqZWN0RW5kY29kZSkge1xuICAgICAgICB2YXIgcHNlbmQgPSBvYmplY3RFbmRjb2RlLnA7XG4gICAgICAgIHZhciB4X3RtcCA9IHBzZW5kIC8gMTAwMDAwLjA7XG4gICAgICAgIHZhciB4cCA9IHhfdG1wIC8gMTAuMDtcbiAgICAgICAgeHAgPSB4cCAtIDIwMDA7XG4gICAgICAgIHZhciB5X3RtcCA9IHBzZW5kICUgMTAwMDAwO1xuICAgICAgICB2YXIgeXAgPSB5X3RtcCAvIDEwLjA7XG4gICAgICAgIHlwID0geXAgLSAyMDAwO1xuXG4gICAgICAgIHZhciBudW1pbmZvID0gb2JqZWN0RW5kY29kZS5vO1xuICAgICAgICB2YXIgaWRPYmogPSBwYXJzZUludChudW1pbmZvIC8gMTAwMDAwMC4wKTtcblxuICAgICAgICB2YXIgc29kdSA9IG51bWluZm8gJSAxMDAwMDAwO1xuICAgICAgICB2YXIgd2QgPSBzb2R1IC8gMTAwMDtcbiAgICAgICAgdmFyIGhkID0gc29kdSAlIDEwMDA7XG5cbiAgICAgICAgdmFyIG9iakRlY29kZSA9IHtcbiAgICAgICAgICAgIHg6IHhwLFxuICAgICAgICAgICAgeTogeXAsXG4gICAgICAgICAgICB3OiB3ZCxcbiAgICAgICAgICAgIGg6IGhkLFxuICAgICAgICAgICAgaWQ6IGlkT2JqXG4gICAgICAgIH07XG4gICAgICAgIHJldHVybiBvYmpEZWNvZGU7XG4gICAgfSxcblxuICAgIGRlY29kZVBhY2tCdWxsZXQ6IGZ1bmN0aW9uIGRlY29kZVBhY2tCdWxsZXQob2JqZWN0RW5kY29kZSkge1xuICAgICAgICB2YXIgcHNlbmQgPSBvYmplY3RFbmRjb2RlLnA7XG4gICAgICAgIHZhciB4X3RtcCA9IHBzZW5kIC8gMTAwMDAwLjA7XG4gICAgICAgIHZhciB4cCA9IHhfdG1wIC8gMTAuMDtcbiAgICAgICAgeHAgPSB4cCAtIDIwMDA7XG4gICAgICAgIHZhciB5X3RtcCA9IHBzZW5kICUgMTAwMDAwO1xuICAgICAgICB2YXIgeXAgPSB5X3RtcCAvIDEwLjA7XG4gICAgICAgIHlwID0geXAgLSAyMDAwO1xuXG4gICAgICAgIHZhciBudW1iZXJfaW5mbyA9IG9iamVjdEVuZGNvZGUuaTtcbiAgICAgICAgdmFyIGJ1bGxldF9hbmdsZSA9IHBhcnNlSW50KG51bWJlcl9pbmZvIC8gMTAwMDAwKTtcbiAgICAgICAgdmFyIGJ1bGxldF9pZCA9IG51bWJlcl9pbmZvICUgMTAwMDAwO1xuXG4gICAgICAgIHZhciBvYmpEZWNvZGUgPSB7XG4gICAgICAgICAgICB4OiB4cCxcbiAgICAgICAgICAgIHk6IHlwLFxuICAgICAgICAgICAgYWc6IGJ1bGxldF9hbmdsZSxcbiAgICAgICAgICAgIGlkOiBidWxsZXRfaWRcbiAgICAgICAgfTtcbiAgICAgICAgcmV0dXJuIG9iakRlY29kZTtcbiAgICB9LFxuXG4gICAgZGVjb2RlUGFja0V4cGxvc2lvbjogZnVuY3Rpb24gZGVjb2RlUGFja0V4cGxvc2lvbihvYmplY3RFbmRjb2RlKSB7XG4gICAgICAgIHZhciBwc2VuZCA9IG9iamVjdEVuZGNvZGUucDtcbiAgICAgICAgdmFyIHhfdG1wID0gcHNlbmQgLyAxMDAwMDAuMDtcbiAgICAgICAgdmFyIHhwID0geF90bXAgLyAxMC4wO1xuICAgICAgICB4cCA9IHhwIC0gMjAwMDtcbiAgICAgICAgdmFyIHlfdG1wID0gcHNlbmQgJSAxMDAwMDA7XG4gICAgICAgIHZhciB5cCA9IHlfdG1wIC8gMTAuMDtcbiAgICAgICAgeXAgPSB5cCAtIDIwMDA7XG5cbiAgICAgICAgdmFyIHRpZCA9IG9iamVjdEVuZGNvZGUudDtcblxuICAgICAgICB2YXIgb2JqRGVjb2RlID0ge1xuICAgICAgICAgICAgeDogeHAsXG4gICAgICAgICAgICB5OiB5cCxcbiAgICAgICAgICAgIHRpZDogdGlkLFxuICAgICAgICAgICAgc3R0OiBvYmplY3RFbmRjb2RlLmUsXG4gICAgICAgICAgICB0YW5rX2FuZ2xlOiAwLFxuICAgICAgICAgICAgZ3VuX2FuZ2xlOiAwXG4gICAgICAgIH07XG4gICAgICAgIHJldHVybiBvYmpEZWNvZGU7XG4gICAgfSxcblxuICAgIGRlY29kZVBhY2tJdGVtOiBmdW5jdGlvbiBkZWNvZGVQYWNrSXRlbShvYmplY3RFbmRjb2RlKSB7XG4gICAgICAgIHZhciBwc2VuZCA9IG9iamVjdEVuZGNvZGUucDtcbiAgICAgICAgdmFyIHhfdG1wID0gcHNlbmQgLyAxMDAwMDAuMDtcbiAgICAgICAgdmFyIHhwID0geF90bXAgLyAxMC4wO1xuICAgICAgICB4cCA9IHhwIC0gMjAwMDtcbiAgICAgICAgdmFyIHlfdG1wID0gcHNlbmQgJSAxMDAwMDA7XG4gICAgICAgIHZhciB5cCA9IHlfdG1wIC8gMTAuMDtcbiAgICAgICAgeXAgPSB5cCAtIDIwMDA7XG5cbiAgICAgICAgdmFyIG51bWJlcmluZm8gPSBvYmplY3RFbmRjb2RlLmk7XG4gICAgICAgIHZhciBpZGl0ZW0gPSBudW1iZXJpbmZvICUgMTAwMDAwO1xuICAgICAgICB2YXIgdHlwZWl0ZW0gPSBwYXJzZUludChudW1iZXJpbmZvIC8gMTAwMDAwKTtcbiAgICAgICAgdmFyIG9iakRlY29kZSA9IHtcbiAgICAgICAgICAgIGlkOiBpZGl0ZW0sXG4gICAgICAgICAgICB4OiB4cCxcbiAgICAgICAgICAgIHk6IHlwLFxuICAgICAgICAgICAgdHlwZTogdHlwZWl0ZW1cbiAgICAgICAgfTtcbiAgICAgICAgcmV0dXJuIG9iakRlY29kZTtcbiAgICB9XG5cbn07XG5tb2R1bGUuZXhwb3J0cyA9IFV0aWxzO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnYzcxZTF2QWxERkhrcnQvTi9VOGpkZ3MnLCAnYnVsbGV0U2NyaXB0Jyk7XG4vLyBTY3JpcHQvR2FtZXNjcmlwdC9idWxsZXRTY3JpcHQuanNcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIG1zVGV4dHVyZTogY2MuVGV4dHVyZTJEXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICAvLyB0aGlzLm5vZGVfYWRkX2VmZWN0PW5ldyBjYy5Ob2RlKFwiZWZmZWN0XCIpO1xuICAgICAgICAvLyB2YXIgbXM9dGhpcy5ub2RlX2FkZF9lZmVjdC5hZGRDb21wb25lbnQoY2MuTW90aW9uU3RyZWFrKTtcbiAgICAgICAgLy8gbXMuZmFkZVRpbWU9MC4wODtcbiAgICAgICAgLy8gbXMubWluU2VnPTAuMjtcbiAgICAgICAgLy8gbXMuc3Ryb2tlPTU7XG4gICAgICAgIC8vIG1zLnRleHR1cmU9dGhpcy5tc1RleHR1cmU7XG4gICAgICAgIC8vIHRoaXMubm9kZS5wYXJlbnQuYWRkQ2hpbGQodGhpcy5ub2RlX2FkZF9lZmVjdCk7XG4gICAgICAgIC8vIHRoaXMuYW5nbGVNb3ZlPTA7XG5cbiAgICAgICAgdGhpcy5uZXh0RnJhbWVNb3ZlID0gMDtcbiAgICAgICAgLy90aGlzLmVmZm5vZGU9dGhpcy5ub2RlLmNoaWxkcmVuWzBdO1xuICAgIH0sXG5cbiAgICB1cGRhdGVGcmFtZTogZnVuY3Rpb24gdXBkYXRlRnJhbWUodG1wX2luZm8pIHtcbiAgICAgICAgdmFyIHhfcCA9IE51bWJlcih0bXBfaW5mby54KTtcbiAgICAgICAgdmFyIHlfcCA9IE51bWJlcih0bXBfaW5mby55KTtcbiAgICAgICAgdGhpcy5ub2RlLnNldFBvc2l0aW9uKGNjLnAoeF9wLCB5X3ApKTtcbiAgICAgICAgdGhpcy5ub2RlLmlzQWN0aXZlU0MgPSB0cnVlO1xuXG4gICAgICAgIHRoaXMuYW5nbGVNb3ZlID0gcGFyc2VJbnQodG1wX2luZm8uYWcpO1xuICAgICAgICB2YXIgdF9yID0gdGhpcy5hbmdsZU1vdmU7XG4gICAgICAgIGlmICh0X3IgPiAxODApIHtcbiAgICAgICAgICAgIHRfciA9IHRfciAtIDM2MDtcbiAgICAgICAgfVxuICAgICAgICB0X3IgPSAtdF9yO1xuICAgICAgICB0aGlzLm5leHRGcmFtZU1vdmUgPSAwO1xuICAgICAgICB0aGlzLm5vZGUucm90YXRpb24gPSB0X3I7XG5cbiAgICAgICAgLy90aGlzLnVwZGF0ZUVmZmVjdFBvc2l0aW9uKCk7XG4gICAgfVxuXG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2U1MTM5Sm9uMjFJS1lPYzRLUlY3cFY3JywgJ2V4cGxvc2lvblNjcmlwdCcpO1xuLy8gU2NyaXB0L0dhbWVzY3JpcHQvZXhwbG9zaW9uU2NyaXB0LmpzXG5cbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge30sXG5cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgY2MubG9nKFwiYXNrZGpha3NoZGFrc2Roa2FzamRoYWtqc2Roa2Fqc2hka3NhamQwMjM5MTgyMzcxODkyNzM5MTcyODkxXCIpO1xuICAgIH1cblxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICdhMzkzMHYzR20xRHU2TEJ6K1luLzZtZScsICdpdGVtU2NyaXB0Jyk7XG4vLyBTY3JpcHQvR2FtZXNjcmlwdC9pdGVtU2NyaXB0LmpzXG5cbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge30sXG5cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy5ub2RlLm9wYWNpdHkgPSAxOTA7XG4gICAgICAgIHZhciBjaGlsZHhfZWZmZWN0ID0gdGhpcy5ub2RlLmNoaWxkcmVuWzBdO1xuICAgICAgICB2YXIgYWMxID0gY2MuZmFkZVRvKGNjLnJhbmRvbTBUbzEoKSAqIDMgKyAwLjUsIDApOyAvLyB0aGFtIHNvIGRhdSB0aWVuIGxhIGR1cmF0aW9uICwgdGltZSBzbyB0aHUgMiBsYSBvcGFjaXR5XG4gICAgICAgIHZhciBhYzIgPSBjYy5mYWRlVG8oY2MucmFuZG9tMFRvMSgpICogMiArIDAuNSwgMjU1KTsgLy8gdGhhbSBzbyBkYXUgdGllbiBsYSBkdXJhdGlvbiAsIHRpbWUgc28gdGh1IDIgbGEgb3BhY2l0eVxuXG4gICAgICAgIHRoaXMucmVwZWF0ID0gY2MucmVwZWF0Rm9yZXZlcihjYy5zZXF1ZW5jZShhYzEsIGFjMikpO1xuXG4gICAgICAgIGNoaWxkeF9lZmZlY3QucnVuQWN0aW9uKHRoaXMucmVwZWF0KTtcbiAgICB9LFxuICAgIGJlZ2luQ2xlYW46IGZ1bmN0aW9uIGJlZ2luQ2xlYW4oKSB7XG4gICAgICAgIHZhciBjaGlsZHhfZWZmZWN0ID0gdGhpcy5ub2RlLmNoaWxkcmVuWzBdO1xuICAgICAgICBjaGlsZHhfZWZmZWN0LnN0b3BBbGxBY3Rpb25zKCk7XG4gICAgfSxcbiAgICB1cGRhdGVEaXNwbGF5OiBmdW5jdGlvbiB1cGRhdGVEaXNwbGF5KHRtcF9pbmZvKSB7XG4gICAgICAgIHZhciB4X3AgPSBOdW1iZXIodG1wX2luZm8ueCk7XG4gICAgICAgIHZhciB5X3AgPSBOdW1iZXIodG1wX2luZm8ueSk7XG5cbiAgICAgICAgdGhpcy5ub2RlLnNldFBvc2l0aW9uKGNjLnAoeF9wLCB5X3ApKTtcbiAgICAgICAgdGhpcy5ub2RlLmlzQWN0aXZlU0MgPSB0cnVlO1xuICAgIH1cblxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICdjM2IxZEtBcUFkRkJwMGlseHdXd1h4WCcsICdvYnNTY3JpcHQnKTtcbi8vIFNjcmlwdC9HYW1lc2NyaXB0L29ic1NjcmlwdC5qc1xuXG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gLi4uXG4gICAgfSxcblxuICAgIGluaXREaXNwbGF5OiBmdW5jdGlvbiBpbml0RGlzcGxheSh0bXBfaW5mbykge1xuICAgICAgICB2YXIgeF9wID0gTnVtYmVyKHRtcF9pbmZvLngpO1xuICAgICAgICB2YXIgeV9wID0gTnVtYmVyKHRtcF9pbmZvLnkpO1xuICAgICAgICB0aGlzLm5vZGUuc2V0UG9zaXRpb24oY2MucCh4X3AsIHlfcCkpO1xuICAgICAgICB2YXIgd3cgPSBOdW1iZXIodG1wX2luZm8udyk7XG4gICAgICAgIHZhciBoaCA9IE51bWJlcih0bXBfaW5mby5oKTtcbiAgICAgICAgdGhpcy5ub2RlLnNjYWxlWCA9IHd3IC8gMTAwO1xuICAgICAgICB0aGlzLm5vZGUuc2NhbGVZID0gaGggLyAxMDA7XG5cbiAgICAgICAgdGhpcy5PcG9zID0gY2MucCh4X3AsIHlfcCk7XG4gICAgICAgIHRoaXMubWluX3ggPSB4X3AgLSB3dyAvIDI7XG4gICAgICAgIHRoaXMubWF4X3ggPSB4X3AgKyB3dyAvIDI7XG5cbiAgICAgICAgdGhpcy5taW5feSA9IHlfcCAtIGhoIC8gMjtcbiAgICAgICAgdGhpcy5tYXhfeSA9IHlfcCArIGhoIC8gMjtcbiAgICB9XG5cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnNTUzZjZFcGR3Wkc1TGJCYmlUVlpEU2EnLCAnc29ja2V0LmlvJyk7XG4vLyBTY3JpcHQvTElCL3NvY2tldC5pby5qc1xuXG5pZiAoIWNjLnN5cy5pc05hdGl2ZSkge1xuXG4gIChmdW5jdGlvbiAoZikge1xuICAgIGlmICh0eXBlb2YgZXhwb3J0cyA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgbW9kdWxlICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICBtb2R1bGUuZXhwb3J0cyA9IGYoKTtcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiBkZWZpbmUgPT09IFwiZnVuY3Rpb25cIiAmJiBkZWZpbmUuYW1kKSB7XG4gICAgICBkZWZpbmUoW10sIGYpO1xuICAgIH0gZWxzZSB7XG4gICAgICB2YXIgZztpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICBnID0gd2luZG93O1xuICAgICAgfSBlbHNlIGlmICh0eXBlb2YgZ2xvYmFsICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgIGcgPSBnbG9iYWw7XG4gICAgICB9IGVsc2UgaWYgKHR5cGVvZiBzZWxmICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgIGcgPSBzZWxmO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZyA9IHRoaXM7XG4gICAgICB9Zy5pbyA9IGYoKTtcbiAgICB9XG4gIH0pKGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgZGVmaW5lLCBtb2R1bGUsIGV4cG9ydHM7cmV0dXJuIChmdW5jdGlvbiBlKHQsIG4sIHIpIHtcbiAgICAgIGZ1bmN0aW9uIHMobywgdSkge1xuICAgICAgICBpZiAoIW5bb10pIHtcbiAgICAgICAgICBpZiAoIXRbb10pIHtcbiAgICAgICAgICAgIHZhciBhID0gdHlwZW9mIHJlcXVpcmUgPT0gXCJmdW5jdGlvblwiICYmIHJlcXVpcmU7aWYgKCF1ICYmIGEpIHJldHVybiBhKG8sICEwKTtpZiAoaSkgcmV0dXJuIGkobywgITApO3ZhciBmID0gbmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIiArIG8gKyBcIidcIik7dGhyb3cgKGYuY29kZSA9IFwiTU9EVUxFX05PVF9GT1VORFwiLCBmKTtcbiAgICAgICAgICB9dmFyIGwgPSBuW29dID0geyBleHBvcnRzOiB7fSB9O3Rbb11bMF0uY2FsbChsLmV4cG9ydHMsIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgICAgICB2YXIgbiA9IHRbb11bMV1bZV07cmV0dXJuIHMobiA/IG4gOiBlKTtcbiAgICAgICAgICB9LCBsLCBsLmV4cG9ydHMsIGUsIHQsIG4sIHIpO1xuICAgICAgICB9cmV0dXJuIG5bb10uZXhwb3J0cztcbiAgICAgIH12YXIgaSA9IHR5cGVvZiByZXF1aXJlID09IFwiZnVuY3Rpb25cIiAmJiByZXF1aXJlO2ZvciAodmFyIG8gPSAwOyBvIDwgci5sZW5ndGg7IG8rKykgcyhyW29dKTtyZXR1cm4gcztcbiAgICB9KSh7IDE6IFtmdW5jdGlvbiAoX2RlcmVxXywgbW9kdWxlLCBleHBvcnRzKSB7XG5cbiAgICAgICAgbW9kdWxlLmV4cG9ydHMgPSBfZGVyZXFfKCcuL2xpYi8nKTtcbiAgICAgIH0sIHsgXCIuL2xpYi9cIjogMiB9XSwgMjogW2Z1bmN0aW9uIChfZGVyZXFfLCBtb2R1bGUsIGV4cG9ydHMpIHtcblxuICAgICAgICBtb2R1bGUuZXhwb3J0cyA9IF9kZXJlcV8oJy4vc29ja2V0Jyk7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEV4cG9ydHMgcGFyc2VyXG4gICAgICAgICAqXG4gICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAqXG4gICAgICAgICAqL1xuICAgICAgICBtb2R1bGUuZXhwb3J0cy5wYXJzZXIgPSBfZGVyZXFfKCdlbmdpbmUuaW8tcGFyc2VyJyk7XG4gICAgICB9LCB7IFwiLi9zb2NrZXRcIjogMywgXCJlbmdpbmUuaW8tcGFyc2VyXCI6IDE5IH1dLCAzOiBbZnVuY3Rpb24gKF9kZXJlcV8sIG1vZHVsZSwgZXhwb3J0cykge1xuICAgICAgICAoZnVuY3Rpb24gKGdsb2JhbCkge1xuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIE1vZHVsZSBkZXBlbmRlbmNpZXMuXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICB2YXIgdHJhbnNwb3J0cyA9IF9kZXJlcV8oJy4vdHJhbnNwb3J0cycpO1xuICAgICAgICAgIHZhciBFbWl0dGVyID0gX2RlcmVxXygnY29tcG9uZW50LWVtaXR0ZXInKTtcbiAgICAgICAgICB2YXIgZGVidWcgPSBfZGVyZXFfKCdkZWJ1ZycpKCdlbmdpbmUuaW8tY2xpZW50OnNvY2tldCcpO1xuICAgICAgICAgIHZhciBpbmRleCA9IF9kZXJlcV8oJ2luZGV4b2YnKTtcbiAgICAgICAgICB2YXIgcGFyc2VyID0gX2RlcmVxXygnZW5naW5lLmlvLXBhcnNlcicpO1xuICAgICAgICAgIHZhciBwYXJzZXVyaSA9IF9kZXJlcV8oJ3BhcnNldXJpJyk7XG4gICAgICAgICAgdmFyIHBhcnNlanNvbiA9IF9kZXJlcV8oJ3BhcnNlanNvbicpO1xuICAgICAgICAgIHZhciBwYXJzZXFzID0gX2RlcmVxXygncGFyc2VxcycpO1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogTW9kdWxlIGV4cG9ydHMuXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBtb2R1bGUuZXhwb3J0cyA9IFNvY2tldDtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIE5vb3AgZnVuY3Rpb24uXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIGZ1bmN0aW9uIG5vb3AoKSB7fVxuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogU29ja2V0IGNvbnN0cnVjdG9yLlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogQHBhcmFtIHtTdHJpbmd8T2JqZWN0fSB1cmkgb3Igb3B0aW9uc1xuICAgICAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zXG4gICAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIGZ1bmN0aW9uIFNvY2tldCh1cmksIG9wdHMpIHtcbiAgICAgICAgICAgIGlmICghKHRoaXMgaW5zdGFuY2VvZiBTb2NrZXQpKSByZXR1cm4gbmV3IFNvY2tldCh1cmksIG9wdHMpO1xuXG4gICAgICAgICAgICBvcHRzID0gb3B0cyB8fCB7fTtcblxuICAgICAgICAgICAgaWYgKHVyaSAmJiAnb2JqZWN0JyA9PSB0eXBlb2YgdXJpKSB7XG4gICAgICAgICAgICAgIG9wdHMgPSB1cmk7XG4gICAgICAgICAgICAgIHVyaSA9IG51bGw7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmICh1cmkpIHtcbiAgICAgICAgICAgICAgdXJpID0gcGFyc2V1cmkodXJpKTtcbiAgICAgICAgICAgICAgb3B0cy5ob3N0bmFtZSA9IHVyaS5ob3N0O1xuICAgICAgICAgICAgICBvcHRzLnNlY3VyZSA9IHVyaS5wcm90b2NvbCA9PSAnaHR0cHMnIHx8IHVyaS5wcm90b2NvbCA9PSAnd3NzJztcbiAgICAgICAgICAgICAgb3B0cy5wb3J0ID0gdXJpLnBvcnQ7XG4gICAgICAgICAgICAgIGlmICh1cmkucXVlcnkpIG9wdHMucXVlcnkgPSB1cmkucXVlcnk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKG9wdHMuaG9zdCkge1xuICAgICAgICAgICAgICBvcHRzLmhvc3RuYW1lID0gcGFyc2V1cmkob3B0cy5ob3N0KS5ob3N0O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0aGlzLnNlY3VyZSA9IG51bGwgIT0gb3B0cy5zZWN1cmUgPyBvcHRzLnNlY3VyZSA6IGdsb2JhbC5sb2NhdGlvbiAmJiAnaHR0cHM6JyA9PSBsb2NhdGlvbi5wcm90b2NvbDtcblxuICAgICAgICAgICAgaWYgKG9wdHMuaG9zdG5hbWUgJiYgIW9wdHMucG9ydCkge1xuICAgICAgICAgICAgICAvLyBpZiBubyBwb3J0IGlzIHNwZWNpZmllZCBtYW51YWxseSwgdXNlIHRoZSBwcm90b2NvbCBkZWZhdWx0XG4gICAgICAgICAgICAgIG9wdHMucG9ydCA9IHRoaXMuc2VjdXJlID8gJzQ0MycgOiAnODAnO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0aGlzLmFnZW50ID0gb3B0cy5hZ2VudCB8fCBmYWxzZTtcbiAgICAgICAgICAgIHRoaXMuaG9zdG5hbWUgPSBvcHRzLmhvc3RuYW1lIHx8IChnbG9iYWwubG9jYXRpb24gPyBsb2NhdGlvbi5ob3N0bmFtZSA6ICdsb2NhbGhvc3QnKTtcbiAgICAgICAgICAgIHRoaXMucG9ydCA9IG9wdHMucG9ydCB8fCAoZ2xvYmFsLmxvY2F0aW9uICYmIGxvY2F0aW9uLnBvcnQgPyBsb2NhdGlvbi5wb3J0IDogdGhpcy5zZWN1cmUgPyA0NDMgOiA4MCk7XG4gICAgICAgICAgICB0aGlzLnF1ZXJ5ID0gb3B0cy5xdWVyeSB8fCB7fTtcbiAgICAgICAgICAgIGlmICgnc3RyaW5nJyA9PSB0eXBlb2YgdGhpcy5xdWVyeSkgdGhpcy5xdWVyeSA9IHBhcnNlcXMuZGVjb2RlKHRoaXMucXVlcnkpO1xuICAgICAgICAgICAgdGhpcy51cGdyYWRlID0gZmFsc2UgIT09IG9wdHMudXBncmFkZTtcbiAgICAgICAgICAgIHRoaXMucGF0aCA9IChvcHRzLnBhdGggfHwgJy9lbmdpbmUuaW8nKS5yZXBsYWNlKC9cXC8kLywgJycpICsgJy8nO1xuICAgICAgICAgICAgdGhpcy5mb3JjZUpTT05QID0gISFvcHRzLmZvcmNlSlNPTlA7XG4gICAgICAgICAgICB0aGlzLmpzb25wID0gZmFsc2UgIT09IG9wdHMuanNvbnA7XG4gICAgICAgICAgICB0aGlzLmZvcmNlQmFzZTY0ID0gISFvcHRzLmZvcmNlQmFzZTY0O1xuICAgICAgICAgICAgdGhpcy5lbmFibGVzWERSID0gISFvcHRzLmVuYWJsZXNYRFI7XG4gICAgICAgICAgICB0aGlzLnRpbWVzdGFtcFBhcmFtID0gb3B0cy50aW1lc3RhbXBQYXJhbSB8fCAndCc7XG4gICAgICAgICAgICB0aGlzLnRpbWVzdGFtcFJlcXVlc3RzID0gb3B0cy50aW1lc3RhbXBSZXF1ZXN0cztcbiAgICAgICAgICAgIHRoaXMudHJhbnNwb3J0cyA9IG9wdHMudHJhbnNwb3J0cyB8fCBbJ3BvbGxpbmcnLCAnd2Vic29ja2V0J107XG4gICAgICAgICAgICB0aGlzLnJlYWR5U3RhdGUgPSAnJztcbiAgICAgICAgICAgIHRoaXMud3JpdGVCdWZmZXIgPSBbXTtcbiAgICAgICAgICAgIHRoaXMucG9saWN5UG9ydCA9IG9wdHMucG9saWN5UG9ydCB8fCA4NDM7XG4gICAgICAgICAgICB0aGlzLnJlbWVtYmVyVXBncmFkZSA9IG9wdHMucmVtZW1iZXJVcGdyYWRlIHx8IGZhbHNlO1xuICAgICAgICAgICAgdGhpcy5iaW5hcnlUeXBlID0gbnVsbDtcbiAgICAgICAgICAgIHRoaXMub25seUJpbmFyeVVwZ3JhZGVzID0gb3B0cy5vbmx5QmluYXJ5VXBncmFkZXM7XG4gICAgICAgICAgICB0aGlzLnBlck1lc3NhZ2VEZWZsYXRlID0gZmFsc2UgIT09IG9wdHMucGVyTWVzc2FnZURlZmxhdGUgPyBvcHRzLnBlck1lc3NhZ2VEZWZsYXRlIHx8IHt9IDogZmFsc2U7XG5cbiAgICAgICAgICAgIGlmICh0cnVlID09PSB0aGlzLnBlck1lc3NhZ2VEZWZsYXRlKSB0aGlzLnBlck1lc3NhZ2VEZWZsYXRlID0ge307XG4gICAgICAgICAgICBpZiAodGhpcy5wZXJNZXNzYWdlRGVmbGF0ZSAmJiBudWxsID09IHRoaXMucGVyTWVzc2FnZURlZmxhdGUudGhyZXNob2xkKSB7XG4gICAgICAgICAgICAgIHRoaXMucGVyTWVzc2FnZURlZmxhdGUudGhyZXNob2xkID0gMTAyNDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gU1NMIG9wdGlvbnMgZm9yIE5vZGUuanMgY2xpZW50XG4gICAgICAgICAgICB0aGlzLnBmeCA9IG9wdHMucGZ4IHx8IG51bGw7XG4gICAgICAgICAgICB0aGlzLmtleSA9IG9wdHMua2V5IHx8IG51bGw7XG4gICAgICAgICAgICB0aGlzLnBhc3NwaHJhc2UgPSBvcHRzLnBhc3NwaHJhc2UgfHwgbnVsbDtcbiAgICAgICAgICAgIHRoaXMuY2VydCA9IG9wdHMuY2VydCB8fCBudWxsO1xuICAgICAgICAgICAgdGhpcy5jYSA9IG9wdHMuY2EgfHwgbnVsbDtcbiAgICAgICAgICAgIHRoaXMuY2lwaGVycyA9IG9wdHMuY2lwaGVycyB8fCBudWxsO1xuICAgICAgICAgICAgdGhpcy5yZWplY3RVbmF1dGhvcml6ZWQgPSBvcHRzLnJlamVjdFVuYXV0aG9yaXplZCA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IG9wdHMucmVqZWN0VW5hdXRob3JpemVkO1xuXG4gICAgICAgICAgICAvLyBvdGhlciBvcHRpb25zIGZvciBOb2RlLmpzIGNsaWVudFxuICAgICAgICAgICAgdmFyIGZyZWVHbG9iYWwgPSB0eXBlb2YgZ2xvYmFsID09ICdvYmplY3QnICYmIGdsb2JhbDtcbiAgICAgICAgICAgIGlmIChmcmVlR2xvYmFsLmdsb2JhbCA9PT0gZnJlZUdsb2JhbCkge1xuICAgICAgICAgICAgICBpZiAob3B0cy5leHRyYUhlYWRlcnMgJiYgT2JqZWN0LmtleXMob3B0cy5leHRyYUhlYWRlcnMpLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICB0aGlzLmV4dHJhSGVhZGVycyA9IG9wdHMuZXh0cmFIZWFkZXJzO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRoaXMub3BlbigpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIFNvY2tldC5wcmlvcldlYnNvY2tldFN1Y2Nlc3MgPSBmYWxzZTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIE1peCBpbiBgRW1pdHRlcmAuXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBFbWl0dGVyKFNvY2tldC5wcm90b3R5cGUpO1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogUHJvdG9jb2wgdmVyc2lvbi5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBTb2NrZXQucHJvdG9jb2wgPSBwYXJzZXIucHJvdG9jb2w7IC8vIHRoaXMgaXMgYW4gaW50XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBFeHBvc2UgZGVwcyBmb3IgbGVnYWN5IGNvbXBhdGliaWxpdHlcbiAgICAgICAgICAgKiBhbmQgc3RhbmRhbG9uZSBicm93c2VyIGFjY2Vzcy5cbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIFNvY2tldC5Tb2NrZXQgPSBTb2NrZXQ7XG4gICAgICAgICAgU29ja2V0LlRyYW5zcG9ydCA9IF9kZXJlcV8oJy4vdHJhbnNwb3J0Jyk7XG4gICAgICAgICAgU29ja2V0LnRyYW5zcG9ydHMgPSBfZGVyZXFfKCcuL3RyYW5zcG9ydHMnKTtcbiAgICAgICAgICBTb2NrZXQucGFyc2VyID0gX2RlcmVxXygnZW5naW5lLmlvLXBhcnNlcicpO1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogQ3JlYXRlcyB0cmFuc3BvcnQgb2YgdGhlIGdpdmVuIHR5cGUuXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAcGFyYW0ge1N0cmluZ30gdHJhbnNwb3J0IG5hbWVcbiAgICAgICAgICAgKiBAcmV0dXJuIHtUcmFuc3BvcnR9XG4gICAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBTb2NrZXQucHJvdG90eXBlLmNyZWF0ZVRyYW5zcG9ydCA9IGZ1bmN0aW9uIChuYW1lKSB7XG4gICAgICAgICAgICBkZWJ1ZygnY3JlYXRpbmcgdHJhbnNwb3J0IFwiJXNcIicsIG5hbWUpO1xuICAgICAgICAgICAgdmFyIHF1ZXJ5ID0gY2xvbmUodGhpcy5xdWVyeSk7XG5cbiAgICAgICAgICAgIC8vIGFwcGVuZCBlbmdpbmUuaW8gcHJvdG9jb2wgaWRlbnRpZmllclxuICAgICAgICAgICAgcXVlcnkuRUlPID0gcGFyc2VyLnByb3RvY29sO1xuXG4gICAgICAgICAgICAvLyB0cmFuc3BvcnQgbmFtZVxuICAgICAgICAgICAgcXVlcnkudHJhbnNwb3J0ID0gbmFtZTtcblxuICAgICAgICAgICAgLy8gc2Vzc2lvbiBpZCBpZiB3ZSBhbHJlYWR5IGhhdmUgb25lXG4gICAgICAgICAgICBpZiAodGhpcy5pZCkgcXVlcnkuc2lkID0gdGhpcy5pZDtcblxuICAgICAgICAgICAgdmFyIHRyYW5zcG9ydCA9IG5ldyB0cmFuc3BvcnRzW25hbWVdKHtcbiAgICAgICAgICAgICAgYWdlbnQ6IHRoaXMuYWdlbnQsXG4gICAgICAgICAgICAgIGhvc3RuYW1lOiB0aGlzLmhvc3RuYW1lLFxuICAgICAgICAgICAgICBwb3J0OiB0aGlzLnBvcnQsXG4gICAgICAgICAgICAgIHNlY3VyZTogdGhpcy5zZWN1cmUsXG4gICAgICAgICAgICAgIHBhdGg6IHRoaXMucGF0aCxcbiAgICAgICAgICAgICAgcXVlcnk6IHF1ZXJ5LFxuICAgICAgICAgICAgICBmb3JjZUpTT05QOiB0aGlzLmZvcmNlSlNPTlAsXG4gICAgICAgICAgICAgIGpzb25wOiB0aGlzLmpzb25wLFxuICAgICAgICAgICAgICBmb3JjZUJhc2U2NDogdGhpcy5mb3JjZUJhc2U2NCxcbiAgICAgICAgICAgICAgZW5hYmxlc1hEUjogdGhpcy5lbmFibGVzWERSLFxuICAgICAgICAgICAgICB0aW1lc3RhbXBSZXF1ZXN0czogdGhpcy50aW1lc3RhbXBSZXF1ZXN0cyxcbiAgICAgICAgICAgICAgdGltZXN0YW1wUGFyYW06IHRoaXMudGltZXN0YW1wUGFyYW0sXG4gICAgICAgICAgICAgIHBvbGljeVBvcnQ6IHRoaXMucG9saWN5UG9ydCxcbiAgICAgICAgICAgICAgc29ja2V0OiB0aGlzLFxuICAgICAgICAgICAgICBwZng6IHRoaXMucGZ4LFxuICAgICAgICAgICAgICBrZXk6IHRoaXMua2V5LFxuICAgICAgICAgICAgICBwYXNzcGhyYXNlOiB0aGlzLnBhc3NwaHJhc2UsXG4gICAgICAgICAgICAgIGNlcnQ6IHRoaXMuY2VydCxcbiAgICAgICAgICAgICAgY2E6IHRoaXMuY2EsXG4gICAgICAgICAgICAgIGNpcGhlcnM6IHRoaXMuY2lwaGVycyxcbiAgICAgICAgICAgICAgcmVqZWN0VW5hdXRob3JpemVkOiB0aGlzLnJlamVjdFVuYXV0aG9yaXplZCxcbiAgICAgICAgICAgICAgcGVyTWVzc2FnZURlZmxhdGU6IHRoaXMucGVyTWVzc2FnZURlZmxhdGUsXG4gICAgICAgICAgICAgIGV4dHJhSGVhZGVyczogdGhpcy5leHRyYUhlYWRlcnNcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICByZXR1cm4gdHJhbnNwb3J0O1xuICAgICAgICAgIH07XG5cbiAgICAgICAgICBmdW5jdGlvbiBjbG9uZShvYmopIHtcbiAgICAgICAgICAgIHZhciBvID0ge307XG4gICAgICAgICAgICBmb3IgKHZhciBpIGluIG9iaikge1xuICAgICAgICAgICAgICBpZiAob2JqLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgICAgICAgb1tpXSA9IG9ialtpXTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG87XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogSW5pdGlhbGl6ZXMgdHJhbnNwb3J0IHRvIHVzZSBhbmQgc3RhcnRzIHByb2JlLlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAgICovXG4gICAgICAgICAgU29ja2V0LnByb3RvdHlwZS5vcGVuID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIHRyYW5zcG9ydDtcbiAgICAgICAgICAgIGlmICh0aGlzLnJlbWVtYmVyVXBncmFkZSAmJiBTb2NrZXQucHJpb3JXZWJzb2NrZXRTdWNjZXNzICYmIHRoaXMudHJhbnNwb3J0cy5pbmRleE9mKCd3ZWJzb2NrZXQnKSAhPSAtMSkge1xuICAgICAgICAgICAgICB0cmFuc3BvcnQgPSAnd2Vic29ja2V0JztcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoMCA9PT0gdGhpcy50cmFuc3BvcnRzLmxlbmd0aCkge1xuICAgICAgICAgICAgICAvLyBFbWl0IGVycm9yIG9uIG5leHQgdGljayBzbyBpdCBjYW4gYmUgbGlzdGVuZWQgdG9cbiAgICAgICAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBzZWxmLmVtaXQoJ2Vycm9yJywgJ05vIHRyYW5zcG9ydHMgYXZhaWxhYmxlJyk7XG4gICAgICAgICAgICAgIH0sIDApO1xuICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICB0cmFuc3BvcnQgPSB0aGlzLnRyYW5zcG9ydHNbMF07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLnJlYWR5U3RhdGUgPSAnb3BlbmluZyc7XG5cbiAgICAgICAgICAgIC8vIFJldHJ5IHdpdGggdGhlIG5leHQgdHJhbnNwb3J0IGlmIHRoZSB0cmFuc3BvcnQgaXMgZGlzYWJsZWQgKGpzb25wOiBmYWxzZSlcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgIHRyYW5zcG9ydCA9IHRoaXMuY3JlYXRlVHJhbnNwb3J0KHRyYW5zcG9ydCk7XG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgIHRoaXMudHJhbnNwb3J0cy5zaGlmdCgpO1xuICAgICAgICAgICAgICB0aGlzLm9wZW4oKTtcbiAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0cmFuc3BvcnQub3BlbigpO1xuICAgICAgICAgICAgdGhpcy5zZXRUcmFuc3BvcnQodHJhbnNwb3J0KTtcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogU2V0cyB0aGUgY3VycmVudCB0cmFuc3BvcnQuIERpc2FibGVzIHRoZSBleGlzdGluZyBvbmUgKGlmIGFueSkuXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIFNvY2tldC5wcm90b3R5cGUuc2V0VHJhbnNwb3J0ID0gZnVuY3Rpb24gKHRyYW5zcG9ydCkge1xuICAgICAgICAgICAgZGVidWcoJ3NldHRpbmcgdHJhbnNwb3J0ICVzJywgdHJhbnNwb3J0Lm5hbWUpO1xuICAgICAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgICAgICAgICBpZiAodGhpcy50cmFuc3BvcnQpIHtcbiAgICAgICAgICAgICAgZGVidWcoJ2NsZWFyaW5nIGV4aXN0aW5nIHRyYW5zcG9ydCAlcycsIHRoaXMudHJhbnNwb3J0Lm5hbWUpO1xuICAgICAgICAgICAgICB0aGlzLnRyYW5zcG9ydC5yZW1vdmVBbGxMaXN0ZW5lcnMoKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gc2V0IHVwIHRyYW5zcG9ydFxuICAgICAgICAgICAgdGhpcy50cmFuc3BvcnQgPSB0cmFuc3BvcnQ7XG5cbiAgICAgICAgICAgIC8vIHNldCB1cCB0cmFuc3BvcnQgbGlzdGVuZXJzXG4gICAgICAgICAgICB0cmFuc3BvcnQub24oJ2RyYWluJywgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICBzZWxmLm9uRHJhaW4oKTtcbiAgICAgICAgICAgIH0pLm9uKCdwYWNrZXQnLCBmdW5jdGlvbiAocGFja2V0KSB7XG4gICAgICAgICAgICAgIHNlbGYub25QYWNrZXQocGFja2V0KTtcbiAgICAgICAgICAgIH0pLm9uKCdlcnJvcicsIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgICAgICAgIHNlbGYub25FcnJvcihlKTtcbiAgICAgICAgICAgIH0pLm9uKCdjbG9zZScsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgc2VsZi5vbkNsb3NlKCd0cmFuc3BvcnQgY2xvc2UnKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH07XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBQcm9iZXMgYSB0cmFuc3BvcnQuXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAcGFyYW0ge1N0cmluZ30gdHJhbnNwb3J0IG5hbWVcbiAgICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIFNvY2tldC5wcm90b3R5cGUucHJvYmUgPSBmdW5jdGlvbiAobmFtZSkge1xuICAgICAgICAgICAgZGVidWcoJ3Byb2JpbmcgdHJhbnNwb3J0IFwiJXNcIicsIG5hbWUpO1xuICAgICAgICAgICAgdmFyIHRyYW5zcG9ydCA9IHRoaXMuY3JlYXRlVHJhbnNwb3J0KG5hbWUsIHsgcHJvYmU6IDEgfSksXG4gICAgICAgICAgICAgICAgZmFpbGVkID0gZmFsc2UsXG4gICAgICAgICAgICAgICAgc2VsZiA9IHRoaXM7XG5cbiAgICAgICAgICAgIFNvY2tldC5wcmlvcldlYnNvY2tldFN1Y2Nlc3MgPSBmYWxzZTtcblxuICAgICAgICAgICAgZnVuY3Rpb24gb25UcmFuc3BvcnRPcGVuKCkge1xuICAgICAgICAgICAgICBpZiAoc2VsZi5vbmx5QmluYXJ5VXBncmFkZXMpIHtcbiAgICAgICAgICAgICAgICB2YXIgdXBncmFkZUxvc2VzQmluYXJ5ID0gIXRoaXMuc3VwcG9ydHNCaW5hcnkgJiYgc2VsZi50cmFuc3BvcnQuc3VwcG9ydHNCaW5hcnk7XG4gICAgICAgICAgICAgICAgZmFpbGVkID0gZmFpbGVkIHx8IHVwZ3JhZGVMb3Nlc0JpbmFyeTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBpZiAoZmFpbGVkKSByZXR1cm47XG5cbiAgICAgICAgICAgICAgZGVidWcoJ3Byb2JlIHRyYW5zcG9ydCBcIiVzXCIgb3BlbmVkJywgbmFtZSk7XG4gICAgICAgICAgICAgIHRyYW5zcG9ydC5zZW5kKFt7IHR5cGU6ICdwaW5nJywgZGF0YTogJ3Byb2JlJyB9XSk7XG4gICAgICAgICAgICAgIHRyYW5zcG9ydC5vbmNlKCdwYWNrZXQnLCBmdW5jdGlvbiAobXNnKSB7XG4gICAgICAgICAgICAgICAgaWYgKGZhaWxlZCkgcmV0dXJuO1xuICAgICAgICAgICAgICAgIGlmICgncG9uZycgPT0gbXNnLnR5cGUgJiYgJ3Byb2JlJyA9PSBtc2cuZGF0YSkge1xuICAgICAgICAgICAgICAgICAgZGVidWcoJ3Byb2JlIHRyYW5zcG9ydCBcIiVzXCIgcG9uZycsIG5hbWUpO1xuICAgICAgICAgICAgICAgICAgc2VsZi51cGdyYWRpbmcgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgc2VsZi5lbWl0KCd1cGdyYWRpbmcnLCB0cmFuc3BvcnQpO1xuICAgICAgICAgICAgICAgICAgaWYgKCF0cmFuc3BvcnQpIHJldHVybjtcbiAgICAgICAgICAgICAgICAgIFNvY2tldC5wcmlvcldlYnNvY2tldFN1Y2Nlc3MgPSAnd2Vic29ja2V0JyA9PSB0cmFuc3BvcnQubmFtZTtcblxuICAgICAgICAgICAgICAgICAgZGVidWcoJ3BhdXNpbmcgY3VycmVudCB0cmFuc3BvcnQgXCIlc1wiJywgc2VsZi50cmFuc3BvcnQubmFtZSk7XG4gICAgICAgICAgICAgICAgICBzZWxmLnRyYW5zcG9ydC5wYXVzZShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChmYWlsZWQpIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCdjbG9zZWQnID09IHNlbGYucmVhZHlTdGF0ZSkgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICBkZWJ1ZygnY2hhbmdpbmcgdHJhbnNwb3J0IGFuZCBzZW5kaW5nIHVwZ3JhZGUgcGFja2V0Jyk7XG5cbiAgICAgICAgICAgICAgICAgICAgY2xlYW51cCgpO1xuXG4gICAgICAgICAgICAgICAgICAgIHNlbGYuc2V0VHJhbnNwb3J0KHRyYW5zcG9ydCk7XG4gICAgICAgICAgICAgICAgICAgIHRyYW5zcG9ydC5zZW5kKFt7IHR5cGU6ICd1cGdyYWRlJyB9XSk7XG4gICAgICAgICAgICAgICAgICAgIHNlbGYuZW1pdCgndXBncmFkZScsIHRyYW5zcG9ydCk7XG4gICAgICAgICAgICAgICAgICAgIHRyYW5zcG9ydCA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgIHNlbGYudXBncmFkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgIHNlbGYuZmx1c2goKTtcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICBkZWJ1ZygncHJvYmUgdHJhbnNwb3J0IFwiJXNcIiBmYWlsZWQnLCBuYW1lKTtcbiAgICAgICAgICAgICAgICAgIHZhciBlcnIgPSBuZXcgRXJyb3IoJ3Byb2JlIGVycm9yJyk7XG4gICAgICAgICAgICAgICAgICBlcnIudHJhbnNwb3J0ID0gdHJhbnNwb3J0Lm5hbWU7XG4gICAgICAgICAgICAgICAgICBzZWxmLmVtaXQoJ3VwZ3JhZGVFcnJvcicsIGVycik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgZnVuY3Rpb24gZnJlZXplVHJhbnNwb3J0KCkge1xuICAgICAgICAgICAgICBpZiAoZmFpbGVkKSByZXR1cm47XG5cbiAgICAgICAgICAgICAgLy8gQW55IGNhbGxiYWNrIGNhbGxlZCBieSB0cmFuc3BvcnQgc2hvdWxkIGJlIGlnbm9yZWQgc2luY2Ugbm93XG4gICAgICAgICAgICAgIGZhaWxlZCA9IHRydWU7XG5cbiAgICAgICAgICAgICAgY2xlYW51cCgpO1xuXG4gICAgICAgICAgICAgIHRyYW5zcG9ydC5jbG9zZSgpO1xuICAgICAgICAgICAgICB0cmFuc3BvcnQgPSBudWxsO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvL0hhbmRsZSBhbnkgZXJyb3IgdGhhdCBoYXBwZW5zIHdoaWxlIHByb2JpbmdcbiAgICAgICAgICAgIGZ1bmN0aW9uIG9uZXJyb3IoZXJyKSB7XG4gICAgICAgICAgICAgIHZhciBlcnJvciA9IG5ldyBFcnJvcigncHJvYmUgZXJyb3I6ICcgKyBlcnIpO1xuICAgICAgICAgICAgICBlcnJvci50cmFuc3BvcnQgPSB0cmFuc3BvcnQubmFtZTtcblxuICAgICAgICAgICAgICBmcmVlemVUcmFuc3BvcnQoKTtcblxuICAgICAgICAgICAgICBkZWJ1ZygncHJvYmUgdHJhbnNwb3J0IFwiJXNcIiBmYWlsZWQgYmVjYXVzZSBvZiBlcnJvcjogJXMnLCBuYW1lLCBlcnIpO1xuXG4gICAgICAgICAgICAgIHNlbGYuZW1pdCgndXBncmFkZUVycm9yJywgZXJyb3IpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBmdW5jdGlvbiBvblRyYW5zcG9ydENsb3NlKCkge1xuICAgICAgICAgICAgICBvbmVycm9yKFwidHJhbnNwb3J0IGNsb3NlZFwiKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy9XaGVuIHRoZSBzb2NrZXQgaXMgY2xvc2VkIHdoaWxlIHdlJ3JlIHByb2JpbmdcbiAgICAgICAgICAgIGZ1bmN0aW9uIG9uY2xvc2UoKSB7XG4gICAgICAgICAgICAgIG9uZXJyb3IoXCJzb2NrZXQgY2xvc2VkXCIpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvL1doZW4gdGhlIHNvY2tldCBpcyB1cGdyYWRlZCB3aGlsZSB3ZSdyZSBwcm9iaW5nXG4gICAgICAgICAgICBmdW5jdGlvbiBvbnVwZ3JhZGUodG8pIHtcbiAgICAgICAgICAgICAgaWYgKHRyYW5zcG9ydCAmJiB0by5uYW1lICE9IHRyYW5zcG9ydC5uYW1lKSB7XG4gICAgICAgICAgICAgICAgZGVidWcoJ1wiJXNcIiB3b3JrcyAtIGFib3J0aW5nIFwiJXNcIicsIHRvLm5hbWUsIHRyYW5zcG9ydC5uYW1lKTtcbiAgICAgICAgICAgICAgICBmcmVlemVUcmFuc3BvcnQoKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvL1JlbW92ZSBhbGwgbGlzdGVuZXJzIG9uIHRoZSB0cmFuc3BvcnQgYW5kIG9uIHNlbGZcbiAgICAgICAgICAgIGZ1bmN0aW9uIGNsZWFudXAoKSB7XG4gICAgICAgICAgICAgIHRyYW5zcG9ydC5yZW1vdmVMaXN0ZW5lcignb3BlbicsIG9uVHJhbnNwb3J0T3Blbik7XG4gICAgICAgICAgICAgIHRyYW5zcG9ydC5yZW1vdmVMaXN0ZW5lcignZXJyb3InLCBvbmVycm9yKTtcbiAgICAgICAgICAgICAgdHJhbnNwb3J0LnJlbW92ZUxpc3RlbmVyKCdjbG9zZScsIG9uVHJhbnNwb3J0Q2xvc2UpO1xuICAgICAgICAgICAgICBzZWxmLnJlbW92ZUxpc3RlbmVyKCdjbG9zZScsIG9uY2xvc2UpO1xuICAgICAgICAgICAgICBzZWxmLnJlbW92ZUxpc3RlbmVyKCd1cGdyYWRpbmcnLCBvbnVwZ3JhZGUpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0cmFuc3BvcnQub25jZSgnb3BlbicsIG9uVHJhbnNwb3J0T3Blbik7XG4gICAgICAgICAgICB0cmFuc3BvcnQub25jZSgnZXJyb3InLCBvbmVycm9yKTtcbiAgICAgICAgICAgIHRyYW5zcG9ydC5vbmNlKCdjbG9zZScsIG9uVHJhbnNwb3J0Q2xvc2UpO1xuXG4gICAgICAgICAgICB0aGlzLm9uY2UoJ2Nsb3NlJywgb25jbG9zZSk7XG4gICAgICAgICAgICB0aGlzLm9uY2UoJ3VwZ3JhZGluZycsIG9udXBncmFkZSk7XG5cbiAgICAgICAgICAgIHRyYW5zcG9ydC5vcGVuKCk7XG4gICAgICAgICAgfTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIENhbGxlZCB3aGVuIGNvbm5lY3Rpb24gaXMgZGVlbWVkIG9wZW4uXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgU29ja2V0LnByb3RvdHlwZS5vbk9wZW4gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBkZWJ1Zygnc29ja2V0IG9wZW4nKTtcbiAgICAgICAgICAgIHRoaXMucmVhZHlTdGF0ZSA9ICdvcGVuJztcbiAgICAgICAgICAgIFNvY2tldC5wcmlvcldlYnNvY2tldFN1Y2Nlc3MgPSAnd2Vic29ja2V0JyA9PSB0aGlzLnRyYW5zcG9ydC5uYW1lO1xuICAgICAgICAgICAgdGhpcy5lbWl0KCdvcGVuJyk7XG4gICAgICAgICAgICB0aGlzLmZsdXNoKCk7XG5cbiAgICAgICAgICAgIC8vIHdlIGNoZWNrIGZvciBgcmVhZHlTdGF0ZWAgaW4gY2FzZSBhbiBgb3BlbmBcbiAgICAgICAgICAgIC8vIGxpc3RlbmVyIGFscmVhZHkgY2xvc2VkIHRoZSBzb2NrZXRcbiAgICAgICAgICAgIGlmICgnb3BlbicgPT0gdGhpcy5yZWFkeVN0YXRlICYmIHRoaXMudXBncmFkZSAmJiB0aGlzLnRyYW5zcG9ydC5wYXVzZSkge1xuICAgICAgICAgICAgICBkZWJ1Zygnc3RhcnRpbmcgdXBncmFkZSBwcm9iZXMnKTtcbiAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDAsIGwgPSB0aGlzLnVwZ3JhZGVzLmxlbmd0aDsgaSA8IGw7IGkrKykge1xuICAgICAgICAgICAgICAgIHRoaXMucHJvYmUodGhpcy51cGdyYWRlc1tpXSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogSGFuZGxlcyBhIHBhY2tldC5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgU29ja2V0LnByb3RvdHlwZS5vblBhY2tldCA9IGZ1bmN0aW9uIChwYWNrZXQpIHtcbiAgICAgICAgICAgIGlmICgnb3BlbmluZycgPT0gdGhpcy5yZWFkeVN0YXRlIHx8ICdvcGVuJyA9PSB0aGlzLnJlYWR5U3RhdGUpIHtcbiAgICAgICAgICAgICAgZGVidWcoJ3NvY2tldCByZWNlaXZlOiB0eXBlIFwiJXNcIiwgZGF0YSBcIiVzXCInLCBwYWNrZXQudHlwZSwgcGFja2V0LmRhdGEpO1xuXG4gICAgICAgICAgICAgIHRoaXMuZW1pdCgncGFja2V0JywgcGFja2V0KTtcblxuICAgICAgICAgICAgICAvLyBTb2NrZXQgaXMgbGl2ZSAtIGFueSBwYWNrZXQgY291bnRzXG4gICAgICAgICAgICAgIHRoaXMuZW1pdCgnaGVhcnRiZWF0Jyk7XG5cbiAgICAgICAgICAgICAgc3dpdGNoIChwYWNrZXQudHlwZSkge1xuICAgICAgICAgICAgICAgIGNhc2UgJ29wZW4nOlxuICAgICAgICAgICAgICAgICAgdGhpcy5vbkhhbmRzaGFrZShwYXJzZWpzb24ocGFja2V0LmRhdGEpKTtcbiAgICAgICAgICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgICAgICAgICAgY2FzZSAncG9uZyc6XG4gICAgICAgICAgICAgICAgICB0aGlzLnNldFBpbmcoKTtcbiAgICAgICAgICAgICAgICAgIHRoaXMuZW1pdCgncG9uZycpO1xuICAgICAgICAgICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgICAgICAgICBjYXNlICdlcnJvcic6XG4gICAgICAgICAgICAgICAgICB2YXIgZXJyID0gbmV3IEVycm9yKCdzZXJ2ZXIgZXJyb3InKTtcbiAgICAgICAgICAgICAgICAgIGVyci5jb2RlID0gcGFja2V0LmRhdGE7XG4gICAgICAgICAgICAgICAgICB0aGlzLm9uRXJyb3IoZXJyKTtcbiAgICAgICAgICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgICAgICAgICAgY2FzZSAnbWVzc2FnZSc6XG4gICAgICAgICAgICAgICAgICB0aGlzLmVtaXQoJ2RhdGEnLCBwYWNrZXQuZGF0YSk7XG4gICAgICAgICAgICAgICAgICB0aGlzLmVtaXQoJ21lc3NhZ2UnLCBwYWNrZXQuZGF0YSk7XG4gICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgZGVidWcoJ3BhY2tldCByZWNlaXZlZCB3aXRoIHNvY2tldCByZWFkeVN0YXRlIFwiJXNcIicsIHRoaXMucmVhZHlTdGF0ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIENhbGxlZCB1cG9uIGhhbmRzaGFrZSBjb21wbGV0aW9uLlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogQHBhcmFtIHtPYmplY3R9IGhhbmRzaGFrZSBvYmpcbiAgICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIFNvY2tldC5wcm90b3R5cGUub25IYW5kc2hha2UgPSBmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgICAgICAgdGhpcy5lbWl0KCdoYW5kc2hha2UnLCBkYXRhKTtcbiAgICAgICAgICAgIHRoaXMuaWQgPSBkYXRhLnNpZDtcbiAgICAgICAgICAgIHRoaXMudHJhbnNwb3J0LnF1ZXJ5LnNpZCA9IGRhdGEuc2lkO1xuICAgICAgICAgICAgdGhpcy51cGdyYWRlcyA9IHRoaXMuZmlsdGVyVXBncmFkZXMoZGF0YS51cGdyYWRlcyk7XG4gICAgICAgICAgICB0aGlzLnBpbmdJbnRlcnZhbCA9IGRhdGEucGluZ0ludGVydmFsO1xuICAgICAgICAgICAgdGhpcy5waW5nVGltZW91dCA9IGRhdGEucGluZ1RpbWVvdXQ7XG4gICAgICAgICAgICB0aGlzLm9uT3BlbigpO1xuICAgICAgICAgICAgLy8gSW4gY2FzZSBvcGVuIGhhbmRsZXIgY2xvc2VzIHNvY2tldFxuICAgICAgICAgICAgaWYgKCdjbG9zZWQnID09IHRoaXMucmVhZHlTdGF0ZSkgcmV0dXJuO1xuICAgICAgICAgICAgdGhpcy5zZXRQaW5nKCk7XG5cbiAgICAgICAgICAgIC8vIFByb2xvbmcgbGl2ZW5lc3Mgb2Ygc29ja2V0IG9uIGhlYXJ0YmVhdFxuICAgICAgICAgICAgdGhpcy5yZW1vdmVMaXN0ZW5lcignaGVhcnRiZWF0JywgdGhpcy5vbkhlYXJ0YmVhdCk7XG4gICAgICAgICAgICB0aGlzLm9uKCdoZWFydGJlYXQnLCB0aGlzLm9uSGVhcnRiZWF0KTtcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogUmVzZXRzIHBpbmcgdGltZW91dC5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgU29ja2V0LnByb3RvdHlwZS5vbkhlYXJ0YmVhdCA9IGZ1bmN0aW9uICh0aW1lb3V0KSB7XG4gICAgICAgICAgICBjbGVhclRpbWVvdXQodGhpcy5waW5nVGltZW91dFRpbWVyKTtcbiAgICAgICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgICAgIHNlbGYucGluZ1RpbWVvdXRUaW1lciA9IHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICBpZiAoJ2Nsb3NlZCcgPT0gc2VsZi5yZWFkeVN0YXRlKSByZXR1cm47XG4gICAgICAgICAgICAgIHNlbGYub25DbG9zZSgncGluZyB0aW1lb3V0Jyk7XG4gICAgICAgICAgICB9LCB0aW1lb3V0IHx8IHNlbGYucGluZ0ludGVydmFsICsgc2VsZi5waW5nVGltZW91dCk7XG4gICAgICAgICAgfTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIFBpbmdzIHNlcnZlciBldmVyeSBgdGhpcy5waW5nSW50ZXJ2YWxgIGFuZCBleHBlY3RzIHJlc3BvbnNlXG4gICAgICAgICAgICogd2l0aGluIGB0aGlzLnBpbmdUaW1lb3V0YCBvciBjbG9zZXMgY29ubmVjdGlvbi5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgU29ja2V0LnByb3RvdHlwZS5zZXRQaW5nID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICAgICAgY2xlYXJUaW1lb3V0KHNlbGYucGluZ0ludGVydmFsVGltZXIpO1xuICAgICAgICAgICAgc2VsZi5waW5nSW50ZXJ2YWxUaW1lciA9IHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICBkZWJ1Zygnd3JpdGluZyBwaW5nIHBhY2tldCAtIGV4cGVjdGluZyBwb25nIHdpdGhpbiAlc21zJywgc2VsZi5waW5nVGltZW91dCk7XG4gICAgICAgICAgICAgIHNlbGYucGluZygpO1xuICAgICAgICAgICAgICBzZWxmLm9uSGVhcnRiZWF0KHNlbGYucGluZ1RpbWVvdXQpO1xuICAgICAgICAgICAgfSwgc2VsZi5waW5nSW50ZXJ2YWwpO1xuICAgICAgICAgIH07XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAqIFNlbmRzIGEgcGluZyBwYWNrZXQuXG4gICAgICAgICAgKlxuICAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAgKi9cblxuICAgICAgICAgIFNvY2tldC5wcm90b3R5cGUucGluZyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgICAgIHRoaXMuc2VuZFBhY2tldCgncGluZycsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgc2VsZi5lbWl0KCdwaW5nJyk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogQ2FsbGVkIG9uIGBkcmFpbmAgZXZlbnRcbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgU29ja2V0LnByb3RvdHlwZS5vbkRyYWluID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdGhpcy53cml0ZUJ1ZmZlci5zcGxpY2UoMCwgdGhpcy5wcmV2QnVmZmVyTGVuKTtcblxuICAgICAgICAgICAgLy8gc2V0dGluZyBwcmV2QnVmZmVyTGVuID0gMCBpcyB2ZXJ5IGltcG9ydGFudFxuICAgICAgICAgICAgLy8gZm9yIGV4YW1wbGUsIHdoZW4gdXBncmFkaW5nLCB1cGdyYWRlIHBhY2tldCBpcyBzZW50IG92ZXIsXG4gICAgICAgICAgICAvLyBhbmQgYSBub256ZXJvIHByZXZCdWZmZXJMZW4gY291bGQgY2F1c2UgcHJvYmxlbXMgb24gYGRyYWluYFxuICAgICAgICAgICAgdGhpcy5wcmV2QnVmZmVyTGVuID0gMDtcblxuICAgICAgICAgICAgaWYgKDAgPT09IHRoaXMud3JpdGVCdWZmZXIubGVuZ3RoKSB7XG4gICAgICAgICAgICAgIHRoaXMuZW1pdCgnZHJhaW4nKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHRoaXMuZmx1c2goKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogRmx1c2ggd3JpdGUgYnVmZmVycy5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgU29ja2V0LnByb3RvdHlwZS5mbHVzaCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlmICgnY2xvc2VkJyAhPSB0aGlzLnJlYWR5U3RhdGUgJiYgdGhpcy50cmFuc3BvcnQud3JpdGFibGUgJiYgIXRoaXMudXBncmFkaW5nICYmIHRoaXMud3JpdGVCdWZmZXIubGVuZ3RoKSB7XG4gICAgICAgICAgICAgIGRlYnVnKCdmbHVzaGluZyAlZCBwYWNrZXRzIGluIHNvY2tldCcsIHRoaXMud3JpdGVCdWZmZXIubGVuZ3RoKTtcbiAgICAgICAgICAgICAgdGhpcy50cmFuc3BvcnQuc2VuZCh0aGlzLndyaXRlQnVmZmVyKTtcbiAgICAgICAgICAgICAgLy8ga2VlcCB0cmFjayBvZiBjdXJyZW50IGxlbmd0aCBvZiB3cml0ZUJ1ZmZlclxuICAgICAgICAgICAgICAvLyBzcGxpY2Ugd3JpdGVCdWZmZXIgYW5kIGNhbGxiYWNrQnVmZmVyIG9uIGBkcmFpbmBcbiAgICAgICAgICAgICAgdGhpcy5wcmV2QnVmZmVyTGVuID0gdGhpcy53cml0ZUJ1ZmZlci5sZW5ndGg7XG4gICAgICAgICAgICAgIHRoaXMuZW1pdCgnZmx1c2gnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogU2VuZHMgYSBtZXNzYWdlLlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogQHBhcmFtIHtTdHJpbmd9IG1lc3NhZ2UuXG4gICAgICAgICAgICogQHBhcmFtIHtGdW5jdGlvbn0gY2FsbGJhY2sgZnVuY3Rpb24uXG4gICAgICAgICAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnMuXG4gICAgICAgICAgICogQHJldHVybiB7U29ja2V0fSBmb3IgY2hhaW5pbmcuXG4gICAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIFNvY2tldC5wcm90b3R5cGUud3JpdGUgPSBTb2NrZXQucHJvdG90eXBlLnNlbmQgPSBmdW5jdGlvbiAobXNnLCBvcHRpb25zLCBmbikge1xuICAgICAgICAgICAgdGhpcy5zZW5kUGFja2V0KCdtZXNzYWdlJywgbXNnLCBvcHRpb25zLCBmbik7XG4gICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogU2VuZHMgYSBwYWNrZXQuXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAcGFyYW0ge1N0cmluZ30gcGFja2V0IHR5cGUuXG4gICAgICAgICAgICogQHBhcmFtIHtTdHJpbmd9IGRhdGEuXG4gICAgICAgICAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnMuXG4gICAgICAgICAgICogQHBhcmFtIHtGdW5jdGlvbn0gY2FsbGJhY2sgZnVuY3Rpb24uXG4gICAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBTb2NrZXQucHJvdG90eXBlLnNlbmRQYWNrZXQgPSBmdW5jdGlvbiAodHlwZSwgZGF0YSwgb3B0aW9ucywgZm4pIHtcbiAgICAgICAgICAgIGlmICgnZnVuY3Rpb24nID09IHR5cGVvZiBkYXRhKSB7XG4gICAgICAgICAgICAgIGZuID0gZGF0YTtcbiAgICAgICAgICAgICAgZGF0YSA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKCdmdW5jdGlvbicgPT0gdHlwZW9mIG9wdGlvbnMpIHtcbiAgICAgICAgICAgICAgZm4gPSBvcHRpb25zO1xuICAgICAgICAgICAgICBvcHRpb25zID0gbnVsbDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKCdjbG9zaW5nJyA9PSB0aGlzLnJlYWR5U3RhdGUgfHwgJ2Nsb3NlZCcgPT0gdGhpcy5yZWFkeVN0YXRlKSB7XG4gICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgb3B0aW9ucyA9IG9wdGlvbnMgfHwge307XG4gICAgICAgICAgICBvcHRpb25zLmNvbXByZXNzID0gZmFsc2UgIT09IG9wdGlvbnMuY29tcHJlc3M7XG5cbiAgICAgICAgICAgIHZhciBwYWNrZXQgPSB7XG4gICAgICAgICAgICAgIHR5cGU6IHR5cGUsXG4gICAgICAgICAgICAgIGRhdGE6IGRhdGEsXG4gICAgICAgICAgICAgIG9wdGlvbnM6IG9wdGlvbnNcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICB0aGlzLmVtaXQoJ3BhY2tldENyZWF0ZScsIHBhY2tldCk7XG4gICAgICAgICAgICB0aGlzLndyaXRlQnVmZmVyLnB1c2gocGFja2V0KTtcbiAgICAgICAgICAgIGlmIChmbikgdGhpcy5vbmNlKCdmbHVzaCcsIGZuKTtcbiAgICAgICAgICAgIHRoaXMuZmx1c2goKTtcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogQ2xvc2VzIHRoZSBjb25uZWN0aW9uLlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBTb2NrZXQucHJvdG90eXBlLmNsb3NlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaWYgKCdvcGVuaW5nJyA9PSB0aGlzLnJlYWR5U3RhdGUgfHwgJ29wZW4nID09IHRoaXMucmVhZHlTdGF0ZSkge1xuICAgICAgICAgICAgICB0aGlzLnJlYWR5U3RhdGUgPSAnY2xvc2luZyc7XG5cbiAgICAgICAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgICAgICAgICAgIGlmICh0aGlzLndyaXRlQnVmZmVyLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIHRoaXMub25jZSgnZHJhaW4nLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICBpZiAodGhpcy51cGdyYWRpbmcpIHtcbiAgICAgICAgICAgICAgICAgICAgd2FpdEZvclVwZ3JhZGUoKTtcbiAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGNsb3NlKCk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIH0gZWxzZSBpZiAodGhpcy51cGdyYWRpbmcpIHtcbiAgICAgICAgICAgICAgICB3YWl0Rm9yVXBncmFkZSgpO1xuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGNsb3NlKCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgZnVuY3Rpb24gY2xvc2UoKSB7XG4gICAgICAgICAgICAgIHNlbGYub25DbG9zZSgnZm9yY2VkIGNsb3NlJyk7XG4gICAgICAgICAgICAgIGRlYnVnKCdzb2NrZXQgY2xvc2luZyAtIHRlbGxpbmcgdHJhbnNwb3J0IHRvIGNsb3NlJyk7XG4gICAgICAgICAgICAgIHNlbGYudHJhbnNwb3J0LmNsb3NlKCk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGZ1bmN0aW9uIGNsZWFudXBBbmRDbG9zZSgpIHtcbiAgICAgICAgICAgICAgc2VsZi5yZW1vdmVMaXN0ZW5lcigndXBncmFkZScsIGNsZWFudXBBbmRDbG9zZSk7XG4gICAgICAgICAgICAgIHNlbGYucmVtb3ZlTGlzdGVuZXIoJ3VwZ3JhZGVFcnJvcicsIGNsZWFudXBBbmRDbG9zZSk7XG4gICAgICAgICAgICAgIGNsb3NlKCk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGZ1bmN0aW9uIHdhaXRGb3JVcGdyYWRlKCkge1xuICAgICAgICAgICAgICAvLyB3YWl0IGZvciB1cGdyYWRlIHRvIGZpbmlzaCBzaW5jZSB3ZSBjYW4ndCBzZW5kIHBhY2tldHMgd2hpbGUgcGF1c2luZyBhIHRyYW5zcG9ydFxuICAgICAgICAgICAgICBzZWxmLm9uY2UoJ3VwZ3JhZGUnLCBjbGVhbnVwQW5kQ2xvc2UpO1xuICAgICAgICAgICAgICBzZWxmLm9uY2UoJ3VwZ3JhZGVFcnJvcicsIGNsZWFudXBBbmRDbG9zZSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICAgIH07XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBDYWxsZWQgdXBvbiB0cmFuc3BvcnQgZXJyb3JcbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgU29ja2V0LnByb3RvdHlwZS5vbkVycm9yID0gZnVuY3Rpb24gKGVycikge1xuICAgICAgICAgICAgZGVidWcoJ3NvY2tldCBlcnJvciAlaicsIGVycik7XG4gICAgICAgICAgICBTb2NrZXQucHJpb3JXZWJzb2NrZXRTdWNjZXNzID0gZmFsc2U7XG4gICAgICAgICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgICAgICAgIHRoaXMub25DbG9zZSgndHJhbnNwb3J0IGVycm9yJywgZXJyKTtcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogQ2FsbGVkIHVwb24gdHJhbnNwb3J0IGNsb3NlLlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBTb2NrZXQucHJvdG90eXBlLm9uQ2xvc2UgPSBmdW5jdGlvbiAocmVhc29uLCBkZXNjKSB7XG4gICAgICAgICAgICBpZiAoJ29wZW5pbmcnID09IHRoaXMucmVhZHlTdGF0ZSB8fCAnb3BlbicgPT0gdGhpcy5yZWFkeVN0YXRlIHx8ICdjbG9zaW5nJyA9PSB0aGlzLnJlYWR5U3RhdGUpIHtcbiAgICAgICAgICAgICAgZGVidWcoJ3NvY2tldCBjbG9zZSB3aXRoIHJlYXNvbjogXCIlc1wiJywgcmVhc29uKTtcbiAgICAgICAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgICAgICAgICAgIC8vIGNsZWFyIHRpbWVyc1xuICAgICAgICAgICAgICBjbGVhclRpbWVvdXQodGhpcy5waW5nSW50ZXJ2YWxUaW1lcik7XG4gICAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aGlzLnBpbmdUaW1lb3V0VGltZXIpO1xuXG4gICAgICAgICAgICAgIC8vIHN0b3AgZXZlbnQgZnJvbSBmaXJpbmcgYWdhaW4gZm9yIHRyYW5zcG9ydFxuICAgICAgICAgICAgICB0aGlzLnRyYW5zcG9ydC5yZW1vdmVBbGxMaXN0ZW5lcnMoJ2Nsb3NlJyk7XG5cbiAgICAgICAgICAgICAgLy8gZW5zdXJlIHRyYW5zcG9ydCB3b24ndCBzdGF5IG9wZW5cbiAgICAgICAgICAgICAgdGhpcy50cmFuc3BvcnQuY2xvc2UoKTtcblxuICAgICAgICAgICAgICAvLyBpZ25vcmUgZnVydGhlciB0cmFuc3BvcnQgY29tbXVuaWNhdGlvblxuICAgICAgICAgICAgICB0aGlzLnRyYW5zcG9ydC5yZW1vdmVBbGxMaXN0ZW5lcnMoKTtcblxuICAgICAgICAgICAgICAvLyBzZXQgcmVhZHkgc3RhdGVcbiAgICAgICAgICAgICAgdGhpcy5yZWFkeVN0YXRlID0gJ2Nsb3NlZCc7XG5cbiAgICAgICAgICAgICAgLy8gY2xlYXIgc2Vzc2lvbiBpZFxuICAgICAgICAgICAgICB0aGlzLmlkID0gbnVsbDtcblxuICAgICAgICAgICAgICAvLyBlbWl0IGNsb3NlIGV2ZW50XG4gICAgICAgICAgICAgIHRoaXMuZW1pdCgnY2xvc2UnLCByZWFzb24sIGRlc2MpO1xuXG4gICAgICAgICAgICAgIC8vIGNsZWFuIGJ1ZmZlcnMgYWZ0ZXIsIHNvIHVzZXJzIGNhbiBzdGlsbFxuICAgICAgICAgICAgICAvLyBncmFiIHRoZSBidWZmZXJzIG9uIGBjbG9zZWAgZXZlbnRcbiAgICAgICAgICAgICAgc2VsZi53cml0ZUJ1ZmZlciA9IFtdO1xuICAgICAgICAgICAgICBzZWxmLnByZXZCdWZmZXJMZW4gPSAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH07XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBGaWx0ZXJzIHVwZ3JhZGVzLCByZXR1cm5pbmcgb25seSB0aG9zZSBtYXRjaGluZyBjbGllbnQgdHJhbnNwb3J0cy5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBwYXJhbSB7QXJyYXl9IHNlcnZlciB1cGdyYWRlc1xuICAgICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgICAqXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBTb2NrZXQucHJvdG90eXBlLmZpbHRlclVwZ3JhZGVzID0gZnVuY3Rpb24gKHVwZ3JhZGVzKSB7XG4gICAgICAgICAgICB2YXIgZmlsdGVyZWRVcGdyYWRlcyA9IFtdO1xuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDAsIGogPSB1cGdyYWRlcy5sZW5ndGg7IGkgPCBqOyBpKyspIHtcbiAgICAgICAgICAgICAgaWYgKH5pbmRleCh0aGlzLnRyYW5zcG9ydHMsIHVwZ3JhZGVzW2ldKSkgZmlsdGVyZWRVcGdyYWRlcy5wdXNoKHVwZ3JhZGVzW2ldKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBmaWx0ZXJlZFVwZ3JhZGVzO1xuICAgICAgICAgIH07XG4gICAgICAgIH0pLmNhbGwodGhpcywgdHlwZW9mIHNlbGYgIT09IFwidW5kZWZpbmVkXCIgPyBzZWxmIDogdHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiA/IHdpbmRvdyA6IHR5cGVvZiBnbG9iYWwgIT09IFwidW5kZWZpbmVkXCIgPyBnbG9iYWwgOiB7fSk7XG4gICAgICB9LCB7IFwiLi90cmFuc3BvcnRcIjogNCwgXCIuL3RyYW5zcG9ydHNcIjogNSwgXCJjb21wb25lbnQtZW1pdHRlclwiOiAxNSwgXCJkZWJ1Z1wiOiAxNywgXCJlbmdpbmUuaW8tcGFyc2VyXCI6IDE5LCBcImluZGV4b2ZcIjogMjMsIFwicGFyc2Vqc29uXCI6IDI2LCBcInBhcnNlcXNcIjogMjcsIFwicGFyc2V1cmlcIjogMjggfV0sIDQ6IFtmdW5jdGlvbiAoX2RlcmVxXywgbW9kdWxlLCBleHBvcnRzKSB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBNb2R1bGUgZGVwZW5kZW5jaWVzLlxuICAgICAgICAgKi9cblxuICAgICAgICB2YXIgcGFyc2VyID0gX2RlcmVxXygnZW5naW5lLmlvLXBhcnNlcicpO1xuICAgICAgICB2YXIgRW1pdHRlciA9IF9kZXJlcV8oJ2NvbXBvbmVudC1lbWl0dGVyJyk7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIE1vZHVsZSBleHBvcnRzLlxuICAgICAgICAgKi9cblxuICAgICAgICBtb2R1bGUuZXhwb3J0cyA9IFRyYW5zcG9ydDtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVHJhbnNwb3J0IGFic3RyYWN0IGNvbnN0cnVjdG9yLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ge09iamVjdH0gb3B0aW9ucy5cbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIGZ1bmN0aW9uIFRyYW5zcG9ydChvcHRzKSB7XG4gICAgICAgICAgdGhpcy5wYXRoID0gb3B0cy5wYXRoO1xuICAgICAgICAgIHRoaXMuaG9zdG5hbWUgPSBvcHRzLmhvc3RuYW1lO1xuICAgICAgICAgIHRoaXMucG9ydCA9IG9wdHMucG9ydDtcbiAgICAgICAgICB0aGlzLnNlY3VyZSA9IG9wdHMuc2VjdXJlO1xuICAgICAgICAgIHRoaXMucXVlcnkgPSBvcHRzLnF1ZXJ5O1xuICAgICAgICAgIHRoaXMudGltZXN0YW1wUGFyYW0gPSBvcHRzLnRpbWVzdGFtcFBhcmFtO1xuICAgICAgICAgIHRoaXMudGltZXN0YW1wUmVxdWVzdHMgPSBvcHRzLnRpbWVzdGFtcFJlcXVlc3RzO1xuICAgICAgICAgIHRoaXMucmVhZHlTdGF0ZSA9ICcnO1xuICAgICAgICAgIHRoaXMuYWdlbnQgPSBvcHRzLmFnZW50IHx8IGZhbHNlO1xuICAgICAgICAgIHRoaXMuc29ja2V0ID0gb3B0cy5zb2NrZXQ7XG4gICAgICAgICAgdGhpcy5lbmFibGVzWERSID0gb3B0cy5lbmFibGVzWERSO1xuXG4gICAgICAgICAgLy8gU1NMIG9wdGlvbnMgZm9yIE5vZGUuanMgY2xpZW50XG4gICAgICAgICAgdGhpcy5wZnggPSBvcHRzLnBmeDtcbiAgICAgICAgICB0aGlzLmtleSA9IG9wdHMua2V5O1xuICAgICAgICAgIHRoaXMucGFzc3BocmFzZSA9IG9wdHMucGFzc3BocmFzZTtcbiAgICAgICAgICB0aGlzLmNlcnQgPSBvcHRzLmNlcnQ7XG4gICAgICAgICAgdGhpcy5jYSA9IG9wdHMuY2E7XG4gICAgICAgICAgdGhpcy5jaXBoZXJzID0gb3B0cy5jaXBoZXJzO1xuICAgICAgICAgIHRoaXMucmVqZWN0VW5hdXRob3JpemVkID0gb3B0cy5yZWplY3RVbmF1dGhvcml6ZWQ7XG5cbiAgICAgICAgICAvLyBvdGhlciBvcHRpb25zIGZvciBOb2RlLmpzIGNsaWVudFxuICAgICAgICAgIHRoaXMuZXh0cmFIZWFkZXJzID0gb3B0cy5leHRyYUhlYWRlcnM7XG4gICAgICAgIH1cblxuICAgICAgICAvKipcbiAgICAgICAgICogTWl4IGluIGBFbWl0dGVyYC5cbiAgICAgICAgICovXG5cbiAgICAgICAgRW1pdHRlcihUcmFuc3BvcnQucHJvdG90eXBlKTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW1pdHMgYW4gZXJyb3IuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7U3RyaW5nfSBzdHJcbiAgICAgICAgICogQHJldHVybiB7VHJhbnNwb3J0fSBmb3IgY2hhaW5pbmdcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgVHJhbnNwb3J0LnByb3RvdHlwZS5vbkVycm9yID0gZnVuY3Rpb24gKG1zZywgZGVzYykge1xuICAgICAgICAgIHZhciBlcnIgPSBuZXcgRXJyb3IobXNnKTtcbiAgICAgICAgICBlcnIudHlwZSA9ICdUcmFuc3BvcnRFcnJvcic7XG4gICAgICAgICAgZXJyLmRlc2NyaXB0aW9uID0gZGVzYztcbiAgICAgICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogT3BlbnMgdGhlIHRyYW5zcG9ydC5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgVHJhbnNwb3J0LnByb3RvdHlwZS5vcGVuID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIGlmICgnY2xvc2VkJyA9PSB0aGlzLnJlYWR5U3RhdGUgfHwgJycgPT0gdGhpcy5yZWFkeVN0YXRlKSB7XG4gICAgICAgICAgICB0aGlzLnJlYWR5U3RhdGUgPSAnb3BlbmluZyc7XG4gICAgICAgICAgICB0aGlzLmRvT3BlbigpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDbG9zZXMgdGhlIHRyYW5zcG9ydC5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIFRyYW5zcG9ydC5wcm90b3R5cGUuY2xvc2UgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgaWYgKCdvcGVuaW5nJyA9PSB0aGlzLnJlYWR5U3RhdGUgfHwgJ29wZW4nID09IHRoaXMucmVhZHlTdGF0ZSkge1xuICAgICAgICAgICAgdGhpcy5kb0Nsb3NlKCk7XG4gICAgICAgICAgICB0aGlzLm9uQ2xvc2UoKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogU2VuZHMgbXVsdGlwbGUgcGFja2V0cy5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtBcnJheX0gcGFja2V0c1xuICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICovXG5cbiAgICAgICAgVHJhbnNwb3J0LnByb3RvdHlwZS5zZW5kID0gZnVuY3Rpb24gKHBhY2tldHMpIHtcbiAgICAgICAgICBpZiAoJ29wZW4nID09IHRoaXMucmVhZHlTdGF0ZSkge1xuICAgICAgICAgICAgdGhpcy53cml0ZShwYWNrZXRzKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdUcmFuc3BvcnQgbm90IG9wZW4nKTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENhbGxlZCB1cG9uIG9wZW5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIFRyYW5zcG9ydC5wcm90b3R5cGUub25PcGVuID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHRoaXMucmVhZHlTdGF0ZSA9ICdvcGVuJztcbiAgICAgICAgICB0aGlzLndyaXRhYmxlID0gdHJ1ZTtcbiAgICAgICAgICB0aGlzLmVtaXQoJ29wZW4nKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ2FsbGVkIHdpdGggZGF0YS5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtTdHJpbmd9IGRhdGFcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIFRyYW5zcG9ydC5wcm90b3R5cGUub25EYXRhID0gZnVuY3Rpb24gKGRhdGEpIHtcbiAgICAgICAgICB2YXIgcGFja2V0ID0gcGFyc2VyLmRlY29kZVBhY2tldChkYXRhLCB0aGlzLnNvY2tldC5iaW5hcnlUeXBlKTtcbiAgICAgICAgICB0aGlzLm9uUGFja2V0KHBhY2tldCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENhbGxlZCB3aXRoIGEgZGVjb2RlZCBwYWNrZXQuXG4gICAgICAgICAqL1xuXG4gICAgICAgIFRyYW5zcG9ydC5wcm90b3R5cGUub25QYWNrZXQgPSBmdW5jdGlvbiAocGFja2V0KSB7XG4gICAgICAgICAgdGhpcy5lbWl0KCdwYWNrZXQnLCBwYWNrZXQpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDYWxsZWQgdXBvbiBjbG9zZS5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIFRyYW5zcG9ydC5wcm90b3R5cGUub25DbG9zZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICB0aGlzLnJlYWR5U3RhdGUgPSAnY2xvc2VkJztcbiAgICAgICAgICB0aGlzLmVtaXQoJ2Nsb3NlJyk7XG4gICAgICAgIH07XG4gICAgICB9LCB7IFwiY29tcG9uZW50LWVtaXR0ZXJcIjogMTUsIFwiZW5naW5lLmlvLXBhcnNlclwiOiAxOSB9XSwgNTogW2Z1bmN0aW9uIChfZGVyZXFfLCBtb2R1bGUsIGV4cG9ydHMpIHtcbiAgICAgICAgKGZ1bmN0aW9uIChnbG9iYWwpIHtcbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBNb2R1bGUgZGVwZW5kZW5jaWVzXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICB2YXIgWE1MSHR0cFJlcXVlc3QgPSBfZGVyZXFfKCd4bWxodHRwcmVxdWVzdC1zc2wnKTtcbiAgICAgICAgICB2YXIgWEhSID0gX2RlcmVxXygnLi9wb2xsaW5nLXhocicpO1xuICAgICAgICAgIHZhciBKU09OUCA9IF9kZXJlcV8oJy4vcG9sbGluZy1qc29ucCcpO1xuICAgICAgICAgIHZhciB3ZWJzb2NrZXQgPSBfZGVyZXFfKCcuL3dlYnNvY2tldCcpO1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogRXhwb3J0IHRyYW5zcG9ydHMuXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBleHBvcnRzLnBvbGxpbmcgPSBwb2xsaW5nO1xuICAgICAgICAgIGV4cG9ydHMud2Vic29ja2V0ID0gd2Vic29ja2V0O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogUG9sbGluZyB0cmFuc3BvcnQgcG9seW1vcnBoaWMgY29uc3RydWN0b3IuXG4gICAgICAgICAgICogRGVjaWRlcyBvbiB4aHIgdnMganNvbnAgYmFzZWQgb24gZmVhdHVyZSBkZXRlY3Rpb24uXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIGZ1bmN0aW9uIHBvbGxpbmcob3B0cykge1xuICAgICAgICAgICAgdmFyIHhocjtcbiAgICAgICAgICAgIHZhciB4ZCA9IGZhbHNlO1xuICAgICAgICAgICAgdmFyIHhzID0gZmFsc2U7XG4gICAgICAgICAgICB2YXIganNvbnAgPSBmYWxzZSAhPT0gb3B0cy5qc29ucDtcblxuICAgICAgICAgICAgaWYgKGdsb2JhbC5sb2NhdGlvbikge1xuICAgICAgICAgICAgICB2YXIgaXNTU0wgPSAnaHR0cHM6JyA9PSBsb2NhdGlvbi5wcm90b2NvbDtcbiAgICAgICAgICAgICAgdmFyIHBvcnQgPSBsb2NhdGlvbi5wb3J0O1xuXG4gICAgICAgICAgICAgIC8vIHNvbWUgdXNlciBhZ2VudHMgaGF2ZSBlbXB0eSBgbG9jYXRpb24ucG9ydGBcbiAgICAgICAgICAgICAgaWYgKCFwb3J0KSB7XG4gICAgICAgICAgICAgICAgcG9ydCA9IGlzU1NMID8gNDQzIDogODA7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICB4ZCA9IG9wdHMuaG9zdG5hbWUgIT0gbG9jYXRpb24uaG9zdG5hbWUgfHwgcG9ydCAhPSBvcHRzLnBvcnQ7XG4gICAgICAgICAgICAgIHhzID0gb3B0cy5zZWN1cmUgIT0gaXNTU0w7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIG9wdHMueGRvbWFpbiA9IHhkO1xuICAgICAgICAgICAgb3B0cy54c2NoZW1lID0geHM7XG4gICAgICAgICAgICB4aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3Qob3B0cyk7XG5cbiAgICAgICAgICAgIGlmICgnb3BlbicgaW4geGhyICYmICFvcHRzLmZvcmNlSlNPTlApIHtcbiAgICAgICAgICAgICAgcmV0dXJuIG5ldyBYSFIob3B0cyk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBpZiAoIWpzb25wKSB0aHJvdyBuZXcgRXJyb3IoJ0pTT05QIGRpc2FibGVkJyk7XG4gICAgICAgICAgICAgIHJldHVybiBuZXcgSlNPTlAob3B0cyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9KS5jYWxsKHRoaXMsIHR5cGVvZiBzZWxmICE9PSBcInVuZGVmaW5lZFwiID8gc2VsZiA6IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgPyB3aW5kb3cgOiB0eXBlb2YgZ2xvYmFsICE9PSBcInVuZGVmaW5lZFwiID8gZ2xvYmFsIDoge30pO1xuICAgICAgfSwgeyBcIi4vcG9sbGluZy1qc29ucFwiOiA2LCBcIi4vcG9sbGluZy14aHJcIjogNywgXCIuL3dlYnNvY2tldFwiOiA5LCBcInhtbGh0dHByZXF1ZXN0LXNzbFwiOiAxMCB9XSwgNjogW2Z1bmN0aW9uIChfZGVyZXFfLCBtb2R1bGUsIGV4cG9ydHMpIHtcbiAgICAgICAgKGZ1bmN0aW9uIChnbG9iYWwpIHtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIE1vZHVsZSByZXF1aXJlbWVudHMuXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICB2YXIgUG9sbGluZyA9IF9kZXJlcV8oJy4vcG9sbGluZycpO1xuICAgICAgICAgIHZhciBpbmhlcml0ID0gX2RlcmVxXygnY29tcG9uZW50LWluaGVyaXQnKTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIE1vZHVsZSBleHBvcnRzLlxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgbW9kdWxlLmV4cG9ydHMgPSBKU09OUFBvbGxpbmc7XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBDYWNoZWQgcmVndWxhciBleHByZXNzaW9ucy5cbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIHZhciByTmV3bGluZSA9IC9cXG4vZztcbiAgICAgICAgICB2YXIgckVzY2FwZWROZXdsaW5lID0gL1xcXFxuL2c7XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBHbG9iYWwgSlNPTlAgY2FsbGJhY2tzLlxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgdmFyIGNhbGxiYWNrcztcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIENhbGxiYWNrcyBjb3VudC5cbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIHZhciBpbmRleCA9IDA7XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBOb29wLlxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgZnVuY3Rpb24gZW1wdHkoKSB7fVxuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogSlNPTlAgUG9sbGluZyBjb25zdHJ1Y3Rvci5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRzLlxuICAgICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBmdW5jdGlvbiBKU09OUFBvbGxpbmcob3B0cykge1xuICAgICAgICAgICAgUG9sbGluZy5jYWxsKHRoaXMsIG9wdHMpO1xuXG4gICAgICAgICAgICB0aGlzLnF1ZXJ5ID0gdGhpcy5xdWVyeSB8fCB7fTtcblxuICAgICAgICAgICAgLy8gZGVmaW5lIGdsb2JhbCBjYWxsYmFja3MgYXJyYXkgaWYgbm90IHByZXNlbnRcbiAgICAgICAgICAgIC8vIHdlIGRvIHRoaXMgaGVyZSAobGF6aWx5KSB0byBhdm9pZCB1bm5lZWRlZCBnbG9iYWwgcG9sbHV0aW9uXG4gICAgICAgICAgICBpZiAoIWNhbGxiYWNrcykge1xuICAgICAgICAgICAgICAvLyB3ZSBuZWVkIHRvIGNvbnNpZGVyIG11bHRpcGxlIGVuZ2luZXMgaW4gdGhlIHNhbWUgcGFnZVxuICAgICAgICAgICAgICBpZiAoIWdsb2JhbC5fX19laW8pIGdsb2JhbC5fX19laW8gPSBbXTtcbiAgICAgICAgICAgICAgY2FsbGJhY2tzID0gZ2xvYmFsLl9fX2VpbztcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gY2FsbGJhY2sgaWRlbnRpZmllclxuICAgICAgICAgICAgdGhpcy5pbmRleCA9IGNhbGxiYWNrcy5sZW5ndGg7XG5cbiAgICAgICAgICAgIC8vIGFkZCBjYWxsYmFjayB0byBqc29ucCBnbG9iYWxcbiAgICAgICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgICAgIGNhbGxiYWNrcy5wdXNoKGZ1bmN0aW9uIChtc2cpIHtcbiAgICAgICAgICAgICAgc2VsZi5vbkRhdGEobXNnKTtcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAvLyBhcHBlbmQgdG8gcXVlcnkgc3RyaW5nXG4gICAgICAgICAgICB0aGlzLnF1ZXJ5LmogPSB0aGlzLmluZGV4O1xuXG4gICAgICAgICAgICAvLyBwcmV2ZW50IHNwdXJpb3VzIGVycm9ycyBmcm9tIGJlaW5nIGVtaXR0ZWQgd2hlbiB0aGUgd2luZG93IGlzIHVubG9hZGVkXG4gICAgICAgICAgICBpZiAoZ2xvYmFsLmRvY3VtZW50ICYmIGdsb2JhbC5hZGRFdmVudExpc3RlbmVyKSB7XG4gICAgICAgICAgICAgIGdsb2JhbC5hZGRFdmVudExpc3RlbmVyKCdiZWZvcmV1bmxvYWQnLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgaWYgKHNlbGYuc2NyaXB0KSBzZWxmLnNjcmlwdC5vbmVycm9yID0gZW1wdHk7XG4gICAgICAgICAgICAgIH0sIGZhbHNlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBJbmhlcml0cyBmcm9tIFBvbGxpbmcuXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBpbmhlcml0KEpTT05QUG9sbGluZywgUG9sbGluZyk7XG5cbiAgICAgICAgICAvKlxuICAgICAgICAgICAqIEpTT05QIG9ubHkgc3VwcG9ydHMgYmluYXJ5IGFzIGJhc2U2NCBlbmNvZGVkIHN0cmluZ3NcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIEpTT05QUG9sbGluZy5wcm90b3R5cGUuc3VwcG9ydHNCaW5hcnkgPSBmYWxzZTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIENsb3NlcyB0aGUgc29ja2V0LlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBKU09OUFBvbGxpbmcucHJvdG90eXBlLmRvQ2xvc2UgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5zY3JpcHQpIHtcbiAgICAgICAgICAgICAgdGhpcy5zY3JpcHQucGFyZW50Tm9kZS5yZW1vdmVDaGlsZCh0aGlzLnNjcmlwdCk7XG4gICAgICAgICAgICAgIHRoaXMuc2NyaXB0ID0gbnVsbDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKHRoaXMuZm9ybSkge1xuICAgICAgICAgICAgICB0aGlzLmZvcm0ucGFyZW50Tm9kZS5yZW1vdmVDaGlsZCh0aGlzLmZvcm0pO1xuICAgICAgICAgICAgICB0aGlzLmZvcm0gPSBudWxsO1xuICAgICAgICAgICAgICB0aGlzLmlmcmFtZSA9IG51bGw7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIFBvbGxpbmcucHJvdG90eXBlLmRvQ2xvc2UuY2FsbCh0aGlzKTtcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogU3RhcnRzIGEgcG9sbCBjeWNsZS5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgSlNPTlBQb2xsaW5nLnByb3RvdHlwZS5kb1BvbGwgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICAgICAgICB2YXIgc2NyaXB0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc2NyaXB0Jyk7XG5cbiAgICAgICAgICAgIGlmICh0aGlzLnNjcmlwdCkge1xuICAgICAgICAgICAgICB0aGlzLnNjcmlwdC5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKHRoaXMuc2NyaXB0KTtcbiAgICAgICAgICAgICAgdGhpcy5zY3JpcHQgPSBudWxsO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBzY3JpcHQuYXN5bmMgPSB0cnVlO1xuICAgICAgICAgICAgc2NyaXB0LnNyYyA9IHRoaXMudXJpKCk7XG4gICAgICAgICAgICBzY3JpcHQub25lcnJvciA9IGZ1bmN0aW9uIChlKSB7XG4gICAgICAgICAgICAgIHNlbGYub25FcnJvcignanNvbnAgcG9sbCBlcnJvcicsIGUpO1xuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgdmFyIGluc2VydEF0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ3NjcmlwdCcpWzBdO1xuICAgICAgICAgICAgaWYgKGluc2VydEF0KSB7XG4gICAgICAgICAgICAgIGluc2VydEF0LnBhcmVudE5vZGUuaW5zZXJ0QmVmb3JlKHNjcmlwdCwgaW5zZXJ0QXQpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgKGRvY3VtZW50LmhlYWQgfHwgZG9jdW1lbnQuYm9keSkuYXBwZW5kQ2hpbGQoc2NyaXB0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuc2NyaXB0ID0gc2NyaXB0O1xuXG4gICAgICAgICAgICB2YXIgaXNVQWdlY2tvID0gJ3VuZGVmaW5lZCcgIT0gdHlwZW9mIG5hdmlnYXRvciAmJiAvZ2Vja28vaS50ZXN0KG5hdmlnYXRvci51c2VyQWdlbnQpO1xuXG4gICAgICAgICAgICBpZiAoaXNVQWdlY2tvKSB7XG4gICAgICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHZhciBpZnJhbWUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdpZnJhbWUnKTtcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGlmcmFtZSk7XG4gICAgICAgICAgICAgICAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChpZnJhbWUpO1xuICAgICAgICAgICAgICB9LCAxMDApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH07XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBXcml0ZXMgd2l0aCBhIGhpZGRlbiBpZnJhbWUuXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAcGFyYW0ge1N0cmluZ30gZGF0YSB0byBzZW5kXG4gICAgICAgICAgICogQHBhcmFtIHtGdW5jdGlvbn0gY2FsbGVkIHVwb24gZmx1c2guXG4gICAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBKU09OUFBvbGxpbmcucHJvdG90eXBlLmRvV3JpdGUgPSBmdW5jdGlvbiAoZGF0YSwgZm4pIHtcbiAgICAgICAgICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgICAgICAgICAgaWYgKCF0aGlzLmZvcm0pIHtcbiAgICAgICAgICAgICAgdmFyIGZvcm0gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdmb3JtJyk7XG4gICAgICAgICAgICAgIHZhciBhcmVhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgndGV4dGFyZWEnKTtcbiAgICAgICAgICAgICAgdmFyIGlkID0gdGhpcy5pZnJhbWVJZCA9ICdlaW9faWZyYW1lXycgKyB0aGlzLmluZGV4O1xuICAgICAgICAgICAgICB2YXIgaWZyYW1lO1xuXG4gICAgICAgICAgICAgIGZvcm0uY2xhc3NOYW1lID0gJ3NvY2tldGlvJztcbiAgICAgICAgICAgICAgZm9ybS5zdHlsZS5wb3NpdGlvbiA9ICdhYnNvbHV0ZSc7XG4gICAgICAgICAgICAgIGZvcm0uc3R5bGUudG9wID0gJy0xMDAwcHgnO1xuICAgICAgICAgICAgICBmb3JtLnN0eWxlLmxlZnQgPSAnLTEwMDBweCc7XG4gICAgICAgICAgICAgIGZvcm0udGFyZ2V0ID0gaWQ7XG4gICAgICAgICAgICAgIGZvcm0ubWV0aG9kID0gJ1BPU1QnO1xuICAgICAgICAgICAgICBmb3JtLnNldEF0dHJpYnV0ZSgnYWNjZXB0LWNoYXJzZXQnLCAndXRmLTgnKTtcbiAgICAgICAgICAgICAgYXJlYS5uYW1lID0gJ2QnO1xuICAgICAgICAgICAgICBmb3JtLmFwcGVuZENoaWxkKGFyZWEpO1xuICAgICAgICAgICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGZvcm0pO1xuXG4gICAgICAgICAgICAgIHRoaXMuZm9ybSA9IGZvcm07XG4gICAgICAgICAgICAgIHRoaXMuYXJlYSA9IGFyZWE7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRoaXMuZm9ybS5hY3Rpb24gPSB0aGlzLnVyaSgpO1xuXG4gICAgICAgICAgICBmdW5jdGlvbiBjb21wbGV0ZSgpIHtcbiAgICAgICAgICAgICAgaW5pdElmcmFtZSgpO1xuICAgICAgICAgICAgICBmbigpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBmdW5jdGlvbiBpbml0SWZyYW1lKCkge1xuICAgICAgICAgICAgICBpZiAoc2VsZi5pZnJhbWUpIHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgc2VsZi5mb3JtLnJlbW92ZUNoaWxkKHNlbGYuaWZyYW1lKTtcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICBzZWxmLm9uRXJyb3IoJ2pzb25wIHBvbGxpbmcgaWZyYW1lIHJlbW92YWwgZXJyb3InLCBlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIC8vIGllNiBkeW5hbWljIGlmcmFtZXMgd2l0aCB0YXJnZXQ9XCJcIiBzdXBwb3J0ICh0aGFua3MgQ2hyaXMgTGFtYmFjaGVyKVxuICAgICAgICAgICAgICAgIHZhciBodG1sID0gJzxpZnJhbWUgc3JjPVwiamF2YXNjcmlwdDowXCIgbmFtZT1cIicgKyBzZWxmLmlmcmFtZUlkICsgJ1wiPic7XG4gICAgICAgICAgICAgICAgaWZyYW1lID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChodG1sKTtcbiAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIGlmcmFtZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2lmcmFtZScpO1xuICAgICAgICAgICAgICAgIGlmcmFtZS5uYW1lID0gc2VsZi5pZnJhbWVJZDtcbiAgICAgICAgICAgICAgICBpZnJhbWUuc3JjID0gJ2phdmFzY3JpcHQ6MCc7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICBpZnJhbWUuaWQgPSBzZWxmLmlmcmFtZUlkO1xuXG4gICAgICAgICAgICAgIHNlbGYuZm9ybS5hcHBlbmRDaGlsZChpZnJhbWUpO1xuICAgICAgICAgICAgICBzZWxmLmlmcmFtZSA9IGlmcmFtZTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaW5pdElmcmFtZSgpO1xuXG4gICAgICAgICAgICAvLyBlc2NhcGUgXFxuIHRvIHByZXZlbnQgaXQgZnJvbSBiZWluZyBjb252ZXJ0ZWQgaW50byBcXHJcXG4gYnkgc29tZSBVQXNcbiAgICAgICAgICAgIC8vIGRvdWJsZSBlc2NhcGluZyBpcyByZXF1aXJlZCBmb3IgZXNjYXBlZCBuZXcgbGluZXMgYmVjYXVzZSB1bmVzY2FwaW5nIG9mIG5ldyBsaW5lcyBjYW4gYmUgZG9uZSBzYWZlbHkgb24gc2VydmVyLXNpZGVcbiAgICAgICAgICAgIGRhdGEgPSBkYXRhLnJlcGxhY2UockVzY2FwZWROZXdsaW5lLCAnXFxcXFxcbicpO1xuICAgICAgICAgICAgdGhpcy5hcmVhLnZhbHVlID0gZGF0YS5yZXBsYWNlKHJOZXdsaW5lLCAnXFxcXG4nKTtcblxuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgdGhpcy5mb3JtLnN1Ym1pdCgpO1xuICAgICAgICAgICAgfSBjYXRjaCAoZSkge31cblxuICAgICAgICAgICAgaWYgKHRoaXMuaWZyYW1lLmF0dGFjaEV2ZW50KSB7XG4gICAgICAgICAgICAgIHRoaXMuaWZyYW1lLm9ucmVhZHlzdGF0ZWNoYW5nZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBpZiAoc2VsZi5pZnJhbWUucmVhZHlTdGF0ZSA9PSAnY29tcGxldGUnKSB7XG4gICAgICAgICAgICAgICAgICBjb21wbGV0ZSgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHRoaXMuaWZyYW1lLm9ubG9hZCA9IGNvbXBsZXRlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH07XG4gICAgICAgIH0pLmNhbGwodGhpcywgdHlwZW9mIHNlbGYgIT09IFwidW5kZWZpbmVkXCIgPyBzZWxmIDogdHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiA/IHdpbmRvdyA6IHR5cGVvZiBnbG9iYWwgIT09IFwidW5kZWZpbmVkXCIgPyBnbG9iYWwgOiB7fSk7XG4gICAgICB9LCB7IFwiLi9wb2xsaW5nXCI6IDgsIFwiY29tcG9uZW50LWluaGVyaXRcIjogMTYgfV0sIDc6IFtmdW5jdGlvbiAoX2RlcmVxXywgbW9kdWxlLCBleHBvcnRzKSB7XG4gICAgICAgIChmdW5jdGlvbiAoZ2xvYmFsKSB7XG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogTW9kdWxlIHJlcXVpcmVtZW50cy5cbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIHZhciBYTUxIdHRwUmVxdWVzdCA9IF9kZXJlcV8oJ3htbGh0dHByZXF1ZXN0LXNzbCcpO1xuICAgICAgICAgIHZhciBQb2xsaW5nID0gX2RlcmVxXygnLi9wb2xsaW5nJyk7XG4gICAgICAgICAgdmFyIEVtaXR0ZXIgPSBfZGVyZXFfKCdjb21wb25lbnQtZW1pdHRlcicpO1xuICAgICAgICAgIHZhciBpbmhlcml0ID0gX2RlcmVxXygnY29tcG9uZW50LWluaGVyaXQnKTtcbiAgICAgICAgICB2YXIgZGVidWcgPSBfZGVyZXFfKCdkZWJ1ZycpKCdlbmdpbmUuaW8tY2xpZW50OnBvbGxpbmcteGhyJyk7XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBNb2R1bGUgZXhwb3J0cy5cbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIG1vZHVsZS5leHBvcnRzID0gWEhSO1xuICAgICAgICAgIG1vZHVsZS5leHBvcnRzLlJlcXVlc3QgPSBSZXF1ZXN0O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogRW1wdHkgZnVuY3Rpb25cbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIGZ1bmN0aW9uIGVtcHR5KCkge31cblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIFhIUiBQb2xsaW5nIGNvbnN0cnVjdG9yLlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogQHBhcmFtIHtPYmplY3R9IG9wdHNcbiAgICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgZnVuY3Rpb24gWEhSKG9wdHMpIHtcbiAgICAgICAgICAgIFBvbGxpbmcuY2FsbCh0aGlzLCBvcHRzKTtcblxuICAgICAgICAgICAgaWYgKGdsb2JhbC5sb2NhdGlvbikge1xuICAgICAgICAgICAgICB2YXIgaXNTU0wgPSAnaHR0cHM6JyA9PSBsb2NhdGlvbi5wcm90b2NvbDtcbiAgICAgICAgICAgICAgdmFyIHBvcnQgPSBsb2NhdGlvbi5wb3J0O1xuXG4gICAgICAgICAgICAgIC8vIHNvbWUgdXNlciBhZ2VudHMgaGF2ZSBlbXB0eSBgbG9jYXRpb24ucG9ydGBcbiAgICAgICAgICAgICAgaWYgKCFwb3J0KSB7XG4gICAgICAgICAgICAgICAgcG9ydCA9IGlzU1NMID8gNDQzIDogODA7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICB0aGlzLnhkID0gb3B0cy5ob3N0bmFtZSAhPSBnbG9iYWwubG9jYXRpb24uaG9zdG5hbWUgfHwgcG9ydCAhPSBvcHRzLnBvcnQ7XG4gICAgICAgICAgICAgIHRoaXMueHMgPSBvcHRzLnNlY3VyZSAhPSBpc1NTTDtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHRoaXMuZXh0cmFIZWFkZXJzID0gb3B0cy5leHRyYUhlYWRlcnM7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogSW5oZXJpdHMgZnJvbSBQb2xsaW5nLlxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgaW5oZXJpdChYSFIsIFBvbGxpbmcpO1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogWEhSIHN1cHBvcnRzIGJpbmFyeVxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgWEhSLnByb3RvdHlwZS5zdXBwb3J0c0JpbmFyeSA9IHRydWU7XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBDcmVhdGVzIGEgcmVxdWVzdC5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBwYXJhbSB7U3RyaW5nfSBtZXRob2RcbiAgICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIFhIUi5wcm90b3R5cGUucmVxdWVzdCA9IGZ1bmN0aW9uIChvcHRzKSB7XG4gICAgICAgICAgICBvcHRzID0gb3B0cyB8fCB7fTtcbiAgICAgICAgICAgIG9wdHMudXJpID0gdGhpcy51cmkoKTtcbiAgICAgICAgICAgIG9wdHMueGQgPSB0aGlzLnhkO1xuICAgICAgICAgICAgb3B0cy54cyA9IHRoaXMueHM7XG4gICAgICAgICAgICBvcHRzLmFnZW50ID0gdGhpcy5hZ2VudCB8fCBmYWxzZTtcbiAgICAgICAgICAgIG9wdHMuc3VwcG9ydHNCaW5hcnkgPSB0aGlzLnN1cHBvcnRzQmluYXJ5O1xuICAgICAgICAgICAgb3B0cy5lbmFibGVzWERSID0gdGhpcy5lbmFibGVzWERSO1xuXG4gICAgICAgICAgICAvLyBTU0wgb3B0aW9ucyBmb3IgTm9kZS5qcyBjbGllbnRcbiAgICAgICAgICAgIG9wdHMucGZ4ID0gdGhpcy5wZng7XG4gICAgICAgICAgICBvcHRzLmtleSA9IHRoaXMua2V5O1xuICAgICAgICAgICAgb3B0cy5wYXNzcGhyYXNlID0gdGhpcy5wYXNzcGhyYXNlO1xuICAgICAgICAgICAgb3B0cy5jZXJ0ID0gdGhpcy5jZXJ0O1xuICAgICAgICAgICAgb3B0cy5jYSA9IHRoaXMuY2E7XG4gICAgICAgICAgICBvcHRzLmNpcGhlcnMgPSB0aGlzLmNpcGhlcnM7XG4gICAgICAgICAgICBvcHRzLnJlamVjdFVuYXV0aG9yaXplZCA9IHRoaXMucmVqZWN0VW5hdXRob3JpemVkO1xuXG4gICAgICAgICAgICAvLyBvdGhlciBvcHRpb25zIGZvciBOb2RlLmpzIGNsaWVudFxuICAgICAgICAgICAgb3B0cy5leHRyYUhlYWRlcnMgPSB0aGlzLmV4dHJhSGVhZGVycztcblxuICAgICAgICAgICAgcmV0dXJuIG5ldyBSZXF1ZXN0KG9wdHMpO1xuICAgICAgICAgIH07XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBTZW5kcyBkYXRhLlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogQHBhcmFtIHtTdHJpbmd9IGRhdGEgdG8gc2VuZC5cbiAgICAgICAgICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYWxsZWQgdXBvbiBmbHVzaC5cbiAgICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIFhIUi5wcm90b3R5cGUuZG9Xcml0ZSA9IGZ1bmN0aW9uIChkYXRhLCBmbikge1xuICAgICAgICAgICAgdmFyIGlzQmluYXJ5ID0gdHlwZW9mIGRhdGEgIT09ICdzdHJpbmcnICYmIGRhdGEgIT09IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIHZhciByZXEgPSB0aGlzLnJlcXVlc3QoeyBtZXRob2Q6ICdQT1NUJywgZGF0YTogZGF0YSwgaXNCaW5hcnk6IGlzQmluYXJ5IH0pO1xuICAgICAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICAgICAgcmVxLm9uKCdzdWNjZXNzJywgZm4pO1xuICAgICAgICAgICAgcmVxLm9uKCdlcnJvcicsIGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgICAgICAgICAgc2VsZi5vbkVycm9yKCd4aHIgcG9zdCBlcnJvcicsIGVycik7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuc2VuZFhociA9IHJlcTtcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogU3RhcnRzIGEgcG9sbCBjeWNsZS5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgWEhSLnByb3RvdHlwZS5kb1BvbGwgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBkZWJ1ZygneGhyIHBvbGwnKTtcbiAgICAgICAgICAgIHZhciByZXEgPSB0aGlzLnJlcXVlc3QoKTtcbiAgICAgICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgICAgIHJlcS5vbignZGF0YScsIGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgICAgICAgIHNlbGYub25EYXRhKGRhdGEpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICByZXEub24oJ2Vycm9yJywgZnVuY3Rpb24gKGVycikge1xuICAgICAgICAgICAgICBzZWxmLm9uRXJyb3IoJ3hociBwb2xsIGVycm9yJywgZXJyKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5wb2xsWGhyID0gcmVxO1xuICAgICAgICAgIH07XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBSZXF1ZXN0IGNvbnN0cnVjdG9yXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAcGFyYW0ge09iamVjdH0gb3B0aW9uc1xuICAgICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBmdW5jdGlvbiBSZXF1ZXN0KG9wdHMpIHtcbiAgICAgICAgICAgIHRoaXMubWV0aG9kID0gb3B0cy5tZXRob2QgfHwgJ0dFVCc7XG4gICAgICAgICAgICB0aGlzLnVyaSA9IG9wdHMudXJpO1xuICAgICAgICAgICAgdGhpcy54ZCA9ICEhb3B0cy54ZDtcbiAgICAgICAgICAgIHRoaXMueHMgPSAhIW9wdHMueHM7XG4gICAgICAgICAgICB0aGlzLmFzeW5jID0gZmFsc2UgIT09IG9wdHMuYXN5bmM7XG4gICAgICAgICAgICB0aGlzLmRhdGEgPSB1bmRlZmluZWQgIT0gb3B0cy5kYXRhID8gb3B0cy5kYXRhIDogbnVsbDtcbiAgICAgICAgICAgIHRoaXMuYWdlbnQgPSBvcHRzLmFnZW50O1xuICAgICAgICAgICAgdGhpcy5pc0JpbmFyeSA9IG9wdHMuaXNCaW5hcnk7XG4gICAgICAgICAgICB0aGlzLnN1cHBvcnRzQmluYXJ5ID0gb3B0cy5zdXBwb3J0c0JpbmFyeTtcbiAgICAgICAgICAgIHRoaXMuZW5hYmxlc1hEUiA9IG9wdHMuZW5hYmxlc1hEUjtcblxuICAgICAgICAgICAgLy8gU1NMIG9wdGlvbnMgZm9yIE5vZGUuanMgY2xpZW50XG4gICAgICAgICAgICB0aGlzLnBmeCA9IG9wdHMucGZ4O1xuICAgICAgICAgICAgdGhpcy5rZXkgPSBvcHRzLmtleTtcbiAgICAgICAgICAgIHRoaXMucGFzc3BocmFzZSA9IG9wdHMucGFzc3BocmFzZTtcbiAgICAgICAgICAgIHRoaXMuY2VydCA9IG9wdHMuY2VydDtcbiAgICAgICAgICAgIHRoaXMuY2EgPSBvcHRzLmNhO1xuICAgICAgICAgICAgdGhpcy5jaXBoZXJzID0gb3B0cy5jaXBoZXJzO1xuICAgICAgICAgICAgdGhpcy5yZWplY3RVbmF1dGhvcml6ZWQgPSBvcHRzLnJlamVjdFVuYXV0aG9yaXplZDtcblxuICAgICAgICAgICAgLy8gb3RoZXIgb3B0aW9ucyBmb3IgTm9kZS5qcyBjbGllbnRcbiAgICAgICAgICAgIHRoaXMuZXh0cmFIZWFkZXJzID0gb3B0cy5leHRyYUhlYWRlcnM7XG5cbiAgICAgICAgICAgIHRoaXMuY3JlYXRlKCk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogTWl4IGluIGBFbWl0dGVyYC5cbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIEVtaXR0ZXIoUmVxdWVzdC5wcm90b3R5cGUpO1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogQ3JlYXRlcyB0aGUgWEhSIG9iamVjdCBhbmQgc2VuZHMgdGhlIHJlcXVlc3QuXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIFJlcXVlc3QucHJvdG90eXBlLmNyZWF0ZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBvcHRzID0geyBhZ2VudDogdGhpcy5hZ2VudCwgeGRvbWFpbjogdGhpcy54ZCwgeHNjaGVtZTogdGhpcy54cywgZW5hYmxlc1hEUjogdGhpcy5lbmFibGVzWERSIH07XG5cbiAgICAgICAgICAgIC8vIFNTTCBvcHRpb25zIGZvciBOb2RlLmpzIGNsaWVudFxuICAgICAgICAgICAgb3B0cy5wZnggPSB0aGlzLnBmeDtcbiAgICAgICAgICAgIG9wdHMua2V5ID0gdGhpcy5rZXk7XG4gICAgICAgICAgICBvcHRzLnBhc3NwaHJhc2UgPSB0aGlzLnBhc3NwaHJhc2U7XG4gICAgICAgICAgICBvcHRzLmNlcnQgPSB0aGlzLmNlcnQ7XG4gICAgICAgICAgICBvcHRzLmNhID0gdGhpcy5jYTtcbiAgICAgICAgICAgIG9wdHMuY2lwaGVycyA9IHRoaXMuY2lwaGVycztcbiAgICAgICAgICAgIG9wdHMucmVqZWN0VW5hdXRob3JpemVkID0gdGhpcy5yZWplY3RVbmF1dGhvcml6ZWQ7XG5cbiAgICAgICAgICAgIHZhciB4aHIgPSB0aGlzLnhociA9IG5ldyBYTUxIdHRwUmVxdWVzdChvcHRzKTtcbiAgICAgICAgICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgZGVidWcoJ3hociBvcGVuICVzOiAlcycsIHRoaXMubWV0aG9kLCB0aGlzLnVyaSk7XG4gICAgICAgICAgICAgIHhoci5vcGVuKHRoaXMubWV0aG9kLCB0aGlzLnVyaSwgdGhpcy5hc3luYyk7XG4gICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuZXh0cmFIZWFkZXJzKSB7XG4gICAgICAgICAgICAgICAgICB4aHIuc2V0RGlzYWJsZUhlYWRlckNoZWNrKHRydWUpO1xuICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSBpbiB0aGlzLmV4dHJhSGVhZGVycykge1xuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5leHRyYUhlYWRlcnMuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICB4aHIuc2V0UmVxdWVzdEhlYWRlcihpLCB0aGlzLmV4dHJhSGVhZGVyc1tpXSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHt9XG4gICAgICAgICAgICAgIGlmICh0aGlzLnN1cHBvcnRzQmluYXJ5KSB7XG4gICAgICAgICAgICAgICAgLy8gVGhpcyBoYXMgdG8gYmUgZG9uZSBhZnRlciBvcGVuIGJlY2F1c2UgRmlyZWZveCBpcyBzdHVwaWRcbiAgICAgICAgICAgICAgICAvLyBodHRwOi8vc3RhY2tvdmVyZmxvdy5jb20vcXVlc3Rpb25zLzEzMjE2OTAzL2dldC1iaW5hcnktZGF0YS13aXRoLXhtbGh0dHByZXF1ZXN0LWluLWEtZmlyZWZveC1leHRlbnNpb25cbiAgICAgICAgICAgICAgICB4aHIucmVzcG9uc2VUeXBlID0gJ2FycmF5YnVmZmVyJztcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIGlmICgnUE9TVCcgPT0gdGhpcy5tZXRob2QpIHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuaXNCaW5hcnkpIHtcbiAgICAgICAgICAgICAgICAgICAgeGhyLnNldFJlcXVlc3RIZWFkZXIoJ0NvbnRlbnQtdHlwZScsICdhcHBsaWNhdGlvbi9vY3RldC1zdHJlYW0nKTtcbiAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHhoci5zZXRSZXF1ZXN0SGVhZGVyKCdDb250ZW50LXR5cGUnLCAndGV4dC9wbGFpbjtjaGFyc2V0PVVURi04Jyk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge31cbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIC8vIGllNiBjaGVja1xuICAgICAgICAgICAgICBpZiAoJ3dpdGhDcmVkZW50aWFscycgaW4geGhyKSB7XG4gICAgICAgICAgICAgICAgeGhyLndpdGhDcmVkZW50aWFscyA9IHRydWU7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICBpZiAodGhpcy5oYXNYRFIoKSkge1xuICAgICAgICAgICAgICAgIHhoci5vbmxvYWQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICBzZWxmLm9uTG9hZCgpO1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgeGhyLm9uZXJyb3IgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICBzZWxmLm9uRXJyb3IoeGhyLnJlc3BvbnNlVGV4dCk7XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB4aHIub25yZWFkeXN0YXRlY2hhbmdlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgaWYgKDQgIT0geGhyLnJlYWR5U3RhdGUpIHJldHVybjtcbiAgICAgICAgICAgICAgICAgIGlmICgyMDAgPT0geGhyLnN0YXR1cyB8fCAxMjIzID09IHhoci5zdGF0dXMpIHtcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5vbkxvYWQoKTtcbiAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIG1ha2Ugc3VyZSB0aGUgYGVycm9yYCBldmVudCBoYW5kbGVyIHRoYXQncyB1c2VyLXNldFxuICAgICAgICAgICAgICAgICAgICAvLyBkb2VzIG5vdCB0aHJvdyBpbiB0aGUgc2FtZSB0aWNrIGFuZCBnZXRzIGNhdWdodCBoZXJlXG4gICAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgIHNlbGYub25FcnJvcih4aHIuc3RhdHVzKTtcbiAgICAgICAgICAgICAgICAgICAgfSwgMCk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIGRlYnVnKCd4aHIgZGF0YSAlcycsIHRoaXMuZGF0YSk7XG4gICAgICAgICAgICAgIHhoci5zZW5kKHRoaXMuZGF0YSk7XG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgIC8vIE5lZWQgdG8gZGVmZXIgc2luY2UgLmNyZWF0ZSgpIGlzIGNhbGxlZCBkaXJlY3RseSBmaHJvbSB0aGUgY29uc3RydWN0b3JcbiAgICAgICAgICAgICAgLy8gYW5kIHRodXMgdGhlICdlcnJvcicgZXZlbnQgY2FuIG9ubHkgYmUgb25seSBib3VuZCAqYWZ0ZXIqIHRoaXMgZXhjZXB0aW9uXG4gICAgICAgICAgICAgIC8vIG9jY3Vycy4gIFRoZXJlZm9yZSwgYWxzbywgd2UgY2Fubm90IHRocm93IGhlcmUgYXQgYWxsLlxuICAgICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBzZWxmLm9uRXJyb3IoZSk7XG4gICAgICAgICAgICAgIH0sIDApO1xuICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChnbG9iYWwuZG9jdW1lbnQpIHtcbiAgICAgICAgICAgICAgdGhpcy5pbmRleCA9IFJlcXVlc3QucmVxdWVzdHNDb3VudCsrO1xuICAgICAgICAgICAgICBSZXF1ZXN0LnJlcXVlc3RzW3RoaXMuaW5kZXhdID0gdGhpcztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogQ2FsbGVkIHVwb24gc3VjY2Vzc2Z1bCByZXNwb25zZS5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgUmVxdWVzdC5wcm90b3R5cGUub25TdWNjZXNzID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdGhpcy5lbWl0KCdzdWNjZXNzJyk7XG4gICAgICAgICAgICB0aGlzLmNsZWFudXAoKTtcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogQ2FsbGVkIGlmIHdlIGhhdmUgZGF0YS5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgUmVxdWVzdC5wcm90b3R5cGUub25EYXRhID0gZnVuY3Rpb24gKGRhdGEpIHtcbiAgICAgICAgICAgIHRoaXMuZW1pdCgnZGF0YScsIGRhdGEpO1xuICAgICAgICAgICAgdGhpcy5vblN1Y2Nlc3MoKTtcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogQ2FsbGVkIHVwb24gZXJyb3IuXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIFJlcXVlc3QucHJvdG90eXBlLm9uRXJyb3IgPSBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICAgICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgICAgICAgIHRoaXMuY2xlYW51cCh0cnVlKTtcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogQ2xlYW5zIHVwIGhvdXNlLlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBSZXF1ZXN0LnByb3RvdHlwZS5jbGVhbnVwID0gZnVuY3Rpb24gKGZyb21FcnJvcikge1xuICAgICAgICAgICAgaWYgKCd1bmRlZmluZWQnID09IHR5cGVvZiB0aGlzLnhociB8fCBudWxsID09PSB0aGlzLnhocikge1xuICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyB4bWxodHRwcmVxdWVzdFxuICAgICAgICAgICAgaWYgKHRoaXMuaGFzWERSKCkpIHtcbiAgICAgICAgICAgICAgdGhpcy54aHIub25sb2FkID0gdGhpcy54aHIub25lcnJvciA9IGVtcHR5O1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgdGhpcy54aHIub25yZWFkeXN0YXRlY2hhbmdlID0gZW1wdHk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChmcm9tRXJyb3IpIHtcbiAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICB0aGlzLnhoci5hYm9ydCgpO1xuICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7fVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoZ2xvYmFsLmRvY3VtZW50KSB7XG4gICAgICAgICAgICAgIGRlbGV0ZSBSZXF1ZXN0LnJlcXVlc3RzW3RoaXMuaW5kZXhdO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0aGlzLnhociA9IG51bGw7XG4gICAgICAgICAgfTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIENhbGxlZCB1cG9uIGxvYWQuXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIFJlcXVlc3QucHJvdG90eXBlLm9uTG9hZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBkYXRhO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgdmFyIGNvbnRlbnRUeXBlO1xuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnRlbnRUeXBlID0gdGhpcy54aHIuZ2V0UmVzcG9uc2VIZWFkZXIoJ0NvbnRlbnQtVHlwZScpLnNwbGl0KCc7JylbMF07XG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHt9XG4gICAgICAgICAgICAgIGlmIChjb250ZW50VHlwZSA9PT0gJ2FwcGxpY2F0aW9uL29jdGV0LXN0cmVhbScpIHtcbiAgICAgICAgICAgICAgICBkYXRhID0gdGhpcy54aHIucmVzcG9uc2U7XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgaWYgKCF0aGlzLnN1cHBvcnRzQmluYXJ5KSB7XG4gICAgICAgICAgICAgICAgICBkYXRhID0gdGhpcy54aHIucmVzcG9uc2VUZXh0O1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICBkYXRhID0gU3RyaW5nLmZyb21DaGFyQ29kZS5hcHBseShudWxsLCBuZXcgVWludDhBcnJheSh0aGlzLnhoci5yZXNwb25zZSkpO1xuICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgdWk4QXJyID0gbmV3IFVpbnQ4QXJyYXkodGhpcy54aHIucmVzcG9uc2UpO1xuICAgICAgICAgICAgICAgICAgICB2YXIgZGF0YUFycmF5ID0gW107XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGlkeCA9IDAsIGxlbmd0aCA9IHVpOEFyci5sZW5ndGg7IGlkeCA8IGxlbmd0aDsgaWR4KyspIHtcbiAgICAgICAgICAgICAgICAgICAgICBkYXRhQXJyYXkucHVzaCh1aThBcnJbaWR4XSk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBkYXRhID0gU3RyaW5nLmZyb21DaGFyQ29kZS5hcHBseShudWxsLCBkYXRhQXJyYXkpO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICB0aGlzLm9uRXJyb3IoZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAobnVsbCAhPSBkYXRhKSB7XG4gICAgICAgICAgICAgIHRoaXMub25EYXRhKGRhdGEpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH07XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBDaGVjayBpZiBpdCBoYXMgWERvbWFpblJlcXVlc3QuXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIFJlcXVlc3QucHJvdG90eXBlLmhhc1hEUiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiAndW5kZWZpbmVkJyAhPT0gdHlwZW9mIGdsb2JhbC5YRG9tYWluUmVxdWVzdCAmJiAhdGhpcy54cyAmJiB0aGlzLmVuYWJsZXNYRFI7XG4gICAgICAgICAgfTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIEFib3J0cyB0aGUgcmVxdWVzdC5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBSZXF1ZXN0LnByb3RvdHlwZS5hYm9ydCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHRoaXMuY2xlYW51cCgpO1xuICAgICAgICAgIH07XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBBYm9ydHMgcGVuZGluZyByZXF1ZXN0cyB3aGVuIHVubG9hZGluZyB0aGUgd2luZG93LiBUaGlzIGlzIG5lZWRlZCB0byBwcmV2ZW50XG4gICAgICAgICAgICogbWVtb3J5IGxlYWtzIChlLmcuIHdoZW4gdXNpbmcgSUUpIGFuZCB0byBlbnN1cmUgdGhhdCBubyBzcHVyaW91cyBlcnJvciBpc1xuICAgICAgICAgICAqIGVtaXR0ZWQuXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBpZiAoZ2xvYmFsLmRvY3VtZW50KSB7XG4gICAgICAgICAgICBSZXF1ZXN0LnJlcXVlc3RzQ291bnQgPSAwO1xuICAgICAgICAgICAgUmVxdWVzdC5yZXF1ZXN0cyA9IHt9O1xuICAgICAgICAgICAgaWYgKGdsb2JhbC5hdHRhY2hFdmVudCkge1xuICAgICAgICAgICAgICBnbG9iYWwuYXR0YWNoRXZlbnQoJ29udW5sb2FkJywgdW5sb2FkSGFuZGxlcik7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGdsb2JhbC5hZGRFdmVudExpc3RlbmVyKSB7XG4gICAgICAgICAgICAgIGdsb2JhbC5hZGRFdmVudExpc3RlbmVyKCdiZWZvcmV1bmxvYWQnLCB1bmxvYWRIYW5kbGVyLCBmYWxzZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgZnVuY3Rpb24gdW5sb2FkSGFuZGxlcigpIHtcbiAgICAgICAgICAgIGZvciAodmFyIGkgaW4gUmVxdWVzdC5yZXF1ZXN0cykge1xuICAgICAgICAgICAgICBpZiAoUmVxdWVzdC5yZXF1ZXN0cy5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgICAgICAgIFJlcXVlc3QucmVxdWVzdHNbaV0uYWJvcnQoKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSkuY2FsbCh0aGlzLCB0eXBlb2Ygc2VsZiAhPT0gXCJ1bmRlZmluZWRcIiA/IHNlbGYgOiB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiID8gd2luZG93IDogdHlwZW9mIGdsb2JhbCAhPT0gXCJ1bmRlZmluZWRcIiA/IGdsb2JhbCA6IHt9KTtcbiAgICAgIH0sIHsgXCIuL3BvbGxpbmdcIjogOCwgXCJjb21wb25lbnQtZW1pdHRlclwiOiAxNSwgXCJjb21wb25lbnQtaW5oZXJpdFwiOiAxNiwgXCJkZWJ1Z1wiOiAxNywgXCJ4bWxodHRwcmVxdWVzdC1zc2xcIjogMTAgfV0sIDg6IFtmdW5jdGlvbiAoX2RlcmVxXywgbW9kdWxlLCBleHBvcnRzKSB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBNb2R1bGUgZGVwZW5kZW5jaWVzLlxuICAgICAgICAgKi9cblxuICAgICAgICB2YXIgVHJhbnNwb3J0ID0gX2RlcmVxXygnLi4vdHJhbnNwb3J0Jyk7XG4gICAgICAgIHZhciBwYXJzZXFzID0gX2RlcmVxXygncGFyc2VxcycpO1xuICAgICAgICB2YXIgcGFyc2VyID0gX2RlcmVxXygnZW5naW5lLmlvLXBhcnNlcicpO1xuICAgICAgICB2YXIgaW5oZXJpdCA9IF9kZXJlcV8oJ2NvbXBvbmVudC1pbmhlcml0Jyk7XG4gICAgICAgIHZhciB5ZWFzdCA9IF9kZXJlcV8oJ3llYXN0Jyk7XG4gICAgICAgIHZhciBkZWJ1ZyA9IF9kZXJlcV8oJ2RlYnVnJykoJ2VuZ2luZS5pby1jbGllbnQ6cG9sbGluZycpO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBNb2R1bGUgZXhwb3J0cy5cbiAgICAgICAgICovXG5cbiAgICAgICAgbW9kdWxlLmV4cG9ydHMgPSBQb2xsaW5nO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBJcyBYSFIyIHN1cHBvcnRlZD9cbiAgICAgICAgICovXG5cbiAgICAgICAgdmFyIGhhc1hIUjIgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHZhciBYTUxIdHRwUmVxdWVzdCA9IF9kZXJlcV8oJ3htbGh0dHByZXF1ZXN0LXNzbCcpO1xuICAgICAgICAgIHZhciB4aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3QoeyB4ZG9tYWluOiBmYWxzZSB9KTtcbiAgICAgICAgICByZXR1cm4gbnVsbCAhPSB4aHIucmVzcG9uc2VUeXBlO1xuICAgICAgICB9KSgpO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBQb2xsaW5nIGludGVyZmFjZS5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3R9IG9wdHNcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIGZ1bmN0aW9uIFBvbGxpbmcob3B0cykge1xuICAgICAgICAgIHZhciBmb3JjZUJhc2U2NCA9IG9wdHMgJiYgb3B0cy5mb3JjZUJhc2U2NDtcbiAgICAgICAgICBpZiAoIWhhc1hIUjIgfHwgZm9yY2VCYXNlNjQpIHtcbiAgICAgICAgICAgIHRoaXMuc3VwcG9ydHNCaW5hcnkgPSBmYWxzZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgVHJhbnNwb3J0LmNhbGwodGhpcywgb3B0cyk7XG4gICAgICAgIH1cblxuICAgICAgICAvKipcbiAgICAgICAgICogSW5oZXJpdHMgZnJvbSBUcmFuc3BvcnQuXG4gICAgICAgICAqL1xuXG4gICAgICAgIGluaGVyaXQoUG9sbGluZywgVHJhbnNwb3J0KTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVHJhbnNwb3J0IG5hbWUuXG4gICAgICAgICAqL1xuXG4gICAgICAgIFBvbGxpbmcucHJvdG90eXBlLm5hbWUgPSAncG9sbGluZyc7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIE9wZW5zIHRoZSBzb2NrZXQgKHRyaWdnZXJzIHBvbGxpbmcpLiBXZSB3cml0ZSBhIFBJTkcgbWVzc2FnZSB0byBkZXRlcm1pbmVcbiAgICAgICAgICogd2hlbiB0aGUgdHJhbnNwb3J0IGlzIG9wZW4uXG4gICAgICAgICAqXG4gICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgKi9cblxuICAgICAgICBQb2xsaW5nLnByb3RvdHlwZS5kb09wZW4gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgdGhpcy5wb2xsKCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFBhdXNlcyBwb2xsaW5nLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYWxsYmFjayB1cG9uIGJ1ZmZlcnMgYXJlIGZsdXNoZWQgYW5kIHRyYW5zcG9ydCBpcyBwYXVzZWRcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIFBvbGxpbmcucHJvdG90eXBlLnBhdXNlID0gZnVuY3Rpb24gKG9uUGF1c2UpIHtcbiAgICAgICAgICB2YXIgcGVuZGluZyA9IDA7XG4gICAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgICAgICAgdGhpcy5yZWFkeVN0YXRlID0gJ3BhdXNpbmcnO1xuXG4gICAgICAgICAgZnVuY3Rpb24gcGF1c2UoKSB7XG4gICAgICAgICAgICBkZWJ1ZygncGF1c2VkJyk7XG4gICAgICAgICAgICBzZWxmLnJlYWR5U3RhdGUgPSAncGF1c2VkJztcbiAgICAgICAgICAgIG9uUGF1c2UoKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAodGhpcy5wb2xsaW5nIHx8ICF0aGlzLndyaXRhYmxlKSB7XG4gICAgICAgICAgICB2YXIgdG90YWwgPSAwO1xuXG4gICAgICAgICAgICBpZiAodGhpcy5wb2xsaW5nKSB7XG4gICAgICAgICAgICAgIGRlYnVnKCd3ZSBhcmUgY3VycmVudGx5IHBvbGxpbmcgLSB3YWl0aW5nIHRvIHBhdXNlJyk7XG4gICAgICAgICAgICAgIHRvdGFsKys7XG4gICAgICAgICAgICAgIHRoaXMub25jZSgncG9sbENvbXBsZXRlJywgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIGRlYnVnKCdwcmUtcGF1c2UgcG9sbGluZyBjb21wbGV0ZScpO1xuICAgICAgICAgICAgICAgIC0tdG90YWwgfHwgcGF1c2UoKTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmICghdGhpcy53cml0YWJsZSkge1xuICAgICAgICAgICAgICBkZWJ1Zygnd2UgYXJlIGN1cnJlbnRseSB3cml0aW5nIC0gd2FpdGluZyB0byBwYXVzZScpO1xuICAgICAgICAgICAgICB0b3RhbCsrO1xuICAgICAgICAgICAgICB0aGlzLm9uY2UoJ2RyYWluJywgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIGRlYnVnKCdwcmUtcGF1c2Ugd3JpdGluZyBjb21wbGV0ZScpO1xuICAgICAgICAgICAgICAgIC0tdG90YWwgfHwgcGF1c2UoKTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHBhdXNlKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBTdGFydHMgcG9sbGluZyBjeWNsZS5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgUG9sbGluZy5wcm90b3R5cGUucG9sbCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBkZWJ1ZygncG9sbGluZycpO1xuICAgICAgICAgIHRoaXMucG9sbGluZyA9IHRydWU7XG4gICAgICAgICAgdGhpcy5kb1BvbGwoKTtcbiAgICAgICAgICB0aGlzLmVtaXQoJ3BvbGwnKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogT3ZlcmxvYWRzIG9uRGF0YSB0byBkZXRlY3QgcGF5bG9hZHMuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgKi9cblxuICAgICAgICBQb2xsaW5nLnByb3RvdHlwZS5vbkRhdGEgPSBmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgICBkZWJ1ZygncG9sbGluZyBnb3QgZGF0YSAlcycsIGRhdGEpO1xuICAgICAgICAgIHZhciBjYWxsYmFjayA9IGZ1bmN0aW9uIGNhbGxiYWNrKHBhY2tldCwgaW5kZXgsIHRvdGFsKSB7XG4gICAgICAgICAgICAvLyBpZiBpdHMgdGhlIGZpcnN0IG1lc3NhZ2Ugd2UgY29uc2lkZXIgdGhlIHRyYW5zcG9ydCBvcGVuXG4gICAgICAgICAgICBpZiAoJ29wZW5pbmcnID09IHNlbGYucmVhZHlTdGF0ZSkge1xuICAgICAgICAgICAgICBzZWxmLm9uT3BlbigpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBpZiBpdHMgYSBjbG9zZSBwYWNrZXQsIHdlIGNsb3NlIHRoZSBvbmdvaW5nIHJlcXVlc3RzXG4gICAgICAgICAgICBpZiAoJ2Nsb3NlJyA9PSBwYWNrZXQudHlwZSkge1xuICAgICAgICAgICAgICBzZWxmLm9uQ2xvc2UoKTtcbiAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBvdGhlcndpc2UgYnlwYXNzIG9uRGF0YSBhbmQgaGFuZGxlIHRoZSBtZXNzYWdlXG4gICAgICAgICAgICBzZWxmLm9uUGFja2V0KHBhY2tldCk7XG4gICAgICAgICAgfTtcblxuICAgICAgICAgIC8vIGRlY29kZSBwYXlsb2FkXG4gICAgICAgICAgcGFyc2VyLmRlY29kZVBheWxvYWQoZGF0YSwgdGhpcy5zb2NrZXQuYmluYXJ5VHlwZSwgY2FsbGJhY2spO1xuXG4gICAgICAgICAgLy8gaWYgYW4gZXZlbnQgZGlkIG5vdCB0cmlnZ2VyIGNsb3NpbmdcbiAgICAgICAgICBpZiAoJ2Nsb3NlZCcgIT0gdGhpcy5yZWFkeVN0YXRlKSB7XG4gICAgICAgICAgICAvLyBpZiB3ZSBnb3QgZGF0YSB3ZSdyZSBub3QgcG9sbGluZ1xuICAgICAgICAgICAgdGhpcy5wb2xsaW5nID0gZmFsc2U7XG4gICAgICAgICAgICB0aGlzLmVtaXQoJ3BvbGxDb21wbGV0ZScpO1xuXG4gICAgICAgICAgICBpZiAoJ29wZW4nID09IHRoaXMucmVhZHlTdGF0ZSkge1xuICAgICAgICAgICAgICB0aGlzLnBvbGwoKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIGRlYnVnKCdpZ25vcmluZyBwb2xsIC0gdHJhbnNwb3J0IHN0YXRlIFwiJXNcIicsIHRoaXMucmVhZHlTdGF0ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBGb3IgcG9sbGluZywgc2VuZCBhIGNsb3NlIHBhY2tldC5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIFBvbGxpbmcucHJvdG90eXBlLmRvQ2xvc2UgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgICAgICAgZnVuY3Rpb24gY2xvc2UoKSB7XG4gICAgICAgICAgICBkZWJ1Zygnd3JpdGluZyBjbG9zZSBwYWNrZXQnKTtcbiAgICAgICAgICAgIHNlbGYud3JpdGUoW3sgdHlwZTogJ2Nsb3NlJyB9XSk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKCdvcGVuJyA9PSB0aGlzLnJlYWR5U3RhdGUpIHtcbiAgICAgICAgICAgIGRlYnVnKCd0cmFuc3BvcnQgb3BlbiAtIGNsb3NpbmcnKTtcbiAgICAgICAgICAgIGNsb3NlKCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIGluIGNhc2Ugd2UncmUgdHJ5aW5nIHRvIGNsb3NlIHdoaWxlXG4gICAgICAgICAgICAvLyBoYW5kc2hha2luZyBpcyBpbiBwcm9ncmVzcyAoR0gtMTY0KVxuICAgICAgICAgICAgZGVidWcoJ3RyYW5zcG9ydCBub3Qgb3BlbiAtIGRlZmVycmluZyBjbG9zZScpO1xuICAgICAgICAgICAgdGhpcy5vbmNlKCdvcGVuJywgY2xvc2UpO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogV3JpdGVzIGEgcGFja2V0cyBwYXlsb2FkLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ge0FycmF5fSBkYXRhIHBhY2tldHNcbiAgICAgICAgICogQHBhcmFtIHtGdW5jdGlvbn0gZHJhaW4gY2FsbGJhY2tcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIFBvbGxpbmcucHJvdG90eXBlLndyaXRlID0gZnVuY3Rpb24gKHBhY2tldHMpIHtcbiAgICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICAgICAgdGhpcy53cml0YWJsZSA9IGZhbHNlO1xuICAgICAgICAgIHZhciBjYWxsYmFja2ZuID0gZnVuY3Rpb24gY2FsbGJhY2tmbigpIHtcbiAgICAgICAgICAgIHNlbGYud3JpdGFibGUgPSB0cnVlO1xuICAgICAgICAgICAgc2VsZi5lbWl0KCdkcmFpbicpO1xuICAgICAgICAgIH07XG5cbiAgICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICAgICAgcGFyc2VyLmVuY29kZVBheWxvYWQocGFja2V0cywgdGhpcy5zdXBwb3J0c0JpbmFyeSwgZnVuY3Rpb24gKGRhdGEpIHtcbiAgICAgICAgICAgIHNlbGYuZG9Xcml0ZShkYXRhLCBjYWxsYmFja2ZuKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogR2VuZXJhdGVzIHVyaSBmb3IgY29ubmVjdGlvbi5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIFBvbGxpbmcucHJvdG90eXBlLnVyaSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICB2YXIgcXVlcnkgPSB0aGlzLnF1ZXJ5IHx8IHt9O1xuICAgICAgICAgIHZhciBzY2hlbWEgPSB0aGlzLnNlY3VyZSA/ICdodHRwcycgOiAnaHR0cCc7XG4gICAgICAgICAgdmFyIHBvcnQgPSAnJztcblxuICAgICAgICAgIC8vIGNhY2hlIGJ1c3RpbmcgaXMgZm9yY2VkXG4gICAgICAgICAgaWYgKGZhbHNlICE9PSB0aGlzLnRpbWVzdGFtcFJlcXVlc3RzKSB7XG4gICAgICAgICAgICBxdWVyeVt0aGlzLnRpbWVzdGFtcFBhcmFtXSA9IHllYXN0KCk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKCF0aGlzLnN1cHBvcnRzQmluYXJ5ICYmICFxdWVyeS5zaWQpIHtcbiAgICAgICAgICAgIHF1ZXJ5LmI2NCA9IDE7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgcXVlcnkgPSBwYXJzZXFzLmVuY29kZShxdWVyeSk7XG5cbiAgICAgICAgICAvLyBhdm9pZCBwb3J0IGlmIGRlZmF1bHQgZm9yIHNjaGVtYVxuICAgICAgICAgIGlmICh0aGlzLnBvcnQgJiYgKCdodHRwcycgPT0gc2NoZW1hICYmIHRoaXMucG9ydCAhPSA0NDMgfHwgJ2h0dHAnID09IHNjaGVtYSAmJiB0aGlzLnBvcnQgIT0gODApKSB7XG4gICAgICAgICAgICBwb3J0ID0gJzonICsgdGhpcy5wb3J0O1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC8vIHByZXBlbmQgPyB0byBxdWVyeVxuICAgICAgICAgIGlmIChxdWVyeS5sZW5ndGgpIHtcbiAgICAgICAgICAgIHF1ZXJ5ID0gJz8nICsgcXVlcnk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgdmFyIGlwdjYgPSB0aGlzLmhvc3RuYW1lLmluZGV4T2YoJzonKSAhPT0gLTE7XG4gICAgICAgICAgcmV0dXJuIHNjaGVtYSArICc6Ly8nICsgKGlwdjYgPyAnWycgKyB0aGlzLmhvc3RuYW1lICsgJ10nIDogdGhpcy5ob3N0bmFtZSkgKyBwb3J0ICsgdGhpcy5wYXRoICsgcXVlcnk7XG4gICAgICAgIH07XG4gICAgICB9LCB7IFwiLi4vdHJhbnNwb3J0XCI6IDQsIFwiY29tcG9uZW50LWluaGVyaXRcIjogMTYsIFwiZGVidWdcIjogMTcsIFwiZW5naW5lLmlvLXBhcnNlclwiOiAxOSwgXCJwYXJzZXFzXCI6IDI3LCBcInhtbGh0dHByZXF1ZXN0LXNzbFwiOiAxMCwgXCJ5ZWFzdFwiOiAzMCB9XSwgOTogW2Z1bmN0aW9uIChfZGVyZXFfLCBtb2R1bGUsIGV4cG9ydHMpIHtcbiAgICAgICAgKGZ1bmN0aW9uIChnbG9iYWwpIHtcbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBNb2R1bGUgZGVwZW5kZW5jaWVzLlxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgdmFyIFRyYW5zcG9ydCA9IF9kZXJlcV8oJy4uL3RyYW5zcG9ydCcpO1xuICAgICAgICAgIHZhciBwYXJzZXIgPSBfZGVyZXFfKCdlbmdpbmUuaW8tcGFyc2VyJyk7XG4gICAgICAgICAgdmFyIHBhcnNlcXMgPSBfZGVyZXFfKCdwYXJzZXFzJyk7XG4gICAgICAgICAgdmFyIGluaGVyaXQgPSBfZGVyZXFfKCdjb21wb25lbnQtaW5oZXJpdCcpO1xuICAgICAgICAgIHZhciB5ZWFzdCA9IF9kZXJlcV8oJ3llYXN0Jyk7XG4gICAgICAgICAgdmFyIGRlYnVnID0gX2RlcmVxXygnZGVidWcnKSgnZW5naW5lLmlvLWNsaWVudDp3ZWJzb2NrZXQnKTtcbiAgICAgICAgICB2YXIgQnJvd3NlcldlYlNvY2tldCA9IGdsb2JhbC5XZWJTb2NrZXQgfHwgZ2xvYmFsLk1veldlYlNvY2tldDtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIEdldCBlaXRoZXIgdGhlIGBXZWJTb2NrZXRgIG9yIGBNb3pXZWJTb2NrZXRgIGdsb2JhbHNcbiAgICAgICAgICAgKiBpbiB0aGUgYnJvd3NlciBvciB0aGUgV2ViU29ja2V0LWNvbXBhdGlibGUgaW50ZXJmYWNlXG4gICAgICAgICAgICogZXhwb3NlZCBieSBgd3NgIGZvciBOb2RlIGVudmlyb25tZW50LlxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgdmFyIFdlYlNvY2tldCA9IEJyb3dzZXJXZWJTb2NrZXQgfHwgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnID8gbnVsbCA6IF9kZXJlcV8oJ3dzJykpO1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogTW9kdWxlIGV4cG9ydHMuXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBtb2R1bGUuZXhwb3J0cyA9IFdTO1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogV2ViU29ja2V0IHRyYW5zcG9ydCBjb25zdHJ1Y3Rvci5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBhcGkge09iamVjdH0gY29ubmVjdGlvbiBvcHRpb25zXG4gICAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIGZ1bmN0aW9uIFdTKG9wdHMpIHtcbiAgICAgICAgICAgIHZhciBmb3JjZUJhc2U2NCA9IG9wdHMgJiYgb3B0cy5mb3JjZUJhc2U2NDtcbiAgICAgICAgICAgIGlmIChmb3JjZUJhc2U2NCkge1xuICAgICAgICAgICAgICB0aGlzLnN1cHBvcnRzQmluYXJ5ID0gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLnBlck1lc3NhZ2VEZWZsYXRlID0gb3B0cy5wZXJNZXNzYWdlRGVmbGF0ZTtcbiAgICAgICAgICAgIFRyYW5zcG9ydC5jYWxsKHRoaXMsIG9wdHMpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIEluaGVyaXRzIGZyb20gVHJhbnNwb3J0LlxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgaW5oZXJpdChXUywgVHJhbnNwb3J0KTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIFRyYW5zcG9ydCBuYW1lLlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIFdTLnByb3RvdHlwZS5uYW1lID0gJ3dlYnNvY2tldCc7XG5cbiAgICAgICAgICAvKlxuICAgICAgICAgICAqIFdlYlNvY2tldHMgc3VwcG9ydCBiaW5hcnlcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIFdTLnByb3RvdHlwZS5zdXBwb3J0c0JpbmFyeSA9IHRydWU7XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBPcGVucyBzb2NrZXQuXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIFdTLnByb3RvdHlwZS5kb09wZW4gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAoIXRoaXMuY2hlY2soKSkge1xuICAgICAgICAgICAgICAvLyBsZXQgcHJvYmUgdGltZW91dFxuICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgICAgIHZhciB1cmkgPSB0aGlzLnVyaSgpO1xuICAgICAgICAgICAgdmFyIHByb3RvY29scyA9IHZvaWQgMDtcbiAgICAgICAgICAgIHZhciBvcHRzID0ge1xuICAgICAgICAgICAgICBhZ2VudDogdGhpcy5hZ2VudCxcbiAgICAgICAgICAgICAgcGVyTWVzc2FnZURlZmxhdGU6IHRoaXMucGVyTWVzc2FnZURlZmxhdGVcbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIC8vIFNTTCBvcHRpb25zIGZvciBOb2RlLmpzIGNsaWVudFxuICAgICAgICAgICAgb3B0cy5wZnggPSB0aGlzLnBmeDtcbiAgICAgICAgICAgIG9wdHMua2V5ID0gdGhpcy5rZXk7XG4gICAgICAgICAgICBvcHRzLnBhc3NwaHJhc2UgPSB0aGlzLnBhc3NwaHJhc2U7XG4gICAgICAgICAgICBvcHRzLmNlcnQgPSB0aGlzLmNlcnQ7XG4gICAgICAgICAgICBvcHRzLmNhID0gdGhpcy5jYTtcbiAgICAgICAgICAgIG9wdHMuY2lwaGVycyA9IHRoaXMuY2lwaGVycztcbiAgICAgICAgICAgIG9wdHMucmVqZWN0VW5hdXRob3JpemVkID0gdGhpcy5yZWplY3RVbmF1dGhvcml6ZWQ7XG4gICAgICAgICAgICBpZiAodGhpcy5leHRyYUhlYWRlcnMpIHtcbiAgICAgICAgICAgICAgb3B0cy5oZWFkZXJzID0gdGhpcy5leHRyYUhlYWRlcnM7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRoaXMud3MgPSBCcm93c2VyV2ViU29ja2V0ID8gbmV3IFdlYlNvY2tldCh1cmkpIDogbmV3IFdlYlNvY2tldCh1cmksIHByb3RvY29scywgb3B0cyk7XG5cbiAgICAgICAgICAgIGlmICh0aGlzLndzLmJpbmFyeVR5cGUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICB0aGlzLnN1cHBvcnRzQmluYXJ5ID0gZmFsc2U7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmICh0aGlzLndzLnN1cHBvcnRzICYmIHRoaXMud3Muc3VwcG9ydHMuYmluYXJ5KSB7XG4gICAgICAgICAgICAgIHRoaXMuc3VwcG9ydHNCaW5hcnkgPSB0cnVlO1xuICAgICAgICAgICAgICB0aGlzLndzLmJpbmFyeVR5cGUgPSAnYnVmZmVyJztcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHRoaXMud3MuYmluYXJ5VHlwZSA9ICdhcnJheWJ1ZmZlcic7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRoaXMuYWRkRXZlbnRMaXN0ZW5lcnMoKTtcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogQWRkcyBldmVudCBsaXN0ZW5lcnMgdG8gdGhlIHNvY2tldFxuICAgICAgICAgICAqXG4gICAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBXUy5wcm90b3R5cGUuYWRkRXZlbnRMaXN0ZW5lcnMgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgICAgICAgICAgIHRoaXMud3Mub25vcGVuID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICBzZWxmLm9uT3BlbigpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHRoaXMud3Mub25jbG9zZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgc2VsZi5vbkNsb3NlKCk7XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgdGhpcy53cy5vbm1lc3NhZ2UgPSBmdW5jdGlvbiAoZXYpIHtcbiAgICAgICAgICAgICAgc2VsZi5vbkRhdGEoZXYuZGF0YSk7XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgdGhpcy53cy5vbmVycm9yID0gZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgICAgICAgc2VsZi5vbkVycm9yKCd3ZWJzb2NrZXQgZXJyb3InLCBlKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIE92ZXJyaWRlIGBvbkRhdGFgIHRvIHVzZSBhIHRpbWVyIG9uIGlPUy5cbiAgICAgICAgICAgKiBTZWU6IGh0dHBzOi8vZ2lzdC5naXRodWIuY29tL21sb3VnaHJhbi8yMDUyMDA2XG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIGlmICgndW5kZWZpbmVkJyAhPSB0eXBlb2YgbmF2aWdhdG9yICYmIC9pUGFkfGlQaG9uZXxpUG9kL2kudGVzdChuYXZpZ2F0b3IudXNlckFnZW50KSkge1xuICAgICAgICAgICAgV1MucHJvdG90eXBlLm9uRGF0YSA9IGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgVHJhbnNwb3J0LnByb3RvdHlwZS5vbkRhdGEuY2FsbChzZWxmLCBkYXRhKTtcbiAgICAgICAgICAgICAgfSwgMCk7XG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIFdyaXRlcyBkYXRhIHRvIHNvY2tldC5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBwYXJhbSB7QXJyYXl9IGFycmF5IG9mIHBhY2tldHMuXG4gICAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBXUy5wcm90b3R5cGUud3JpdGUgPSBmdW5jdGlvbiAocGFja2V0cykge1xuICAgICAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICAgICAgdGhpcy53cml0YWJsZSA9IGZhbHNlO1xuXG4gICAgICAgICAgICAvLyBlbmNvZGVQYWNrZXQgZWZmaWNpZW50IGFzIGl0IHVzZXMgV1MgZnJhbWluZ1xuICAgICAgICAgICAgLy8gbm8gbmVlZCBmb3IgZW5jb2RlUGF5bG9hZFxuICAgICAgICAgICAgdmFyIHRvdGFsID0gcGFja2V0cy5sZW5ndGg7XG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMCwgbCA9IHRvdGFsOyBpIDwgbDsgaSsrKSB7XG4gICAgICAgICAgICAgIChmdW5jdGlvbiAocGFja2V0KSB7XG4gICAgICAgICAgICAgICAgcGFyc2VyLmVuY29kZVBhY2tldChwYWNrZXQsIHNlbGYuc3VwcG9ydHNCaW5hcnksIGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgICAgICAgICAgICBpZiAoIUJyb3dzZXJXZWJTb2NrZXQpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gYWx3YXlzIGNyZWF0ZSBhIG5ldyBvYmplY3QgKEdILTQzNylcbiAgICAgICAgICAgICAgICAgICAgdmFyIG9wdHMgPSB7fTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBhY2tldC5vcHRpb25zKSB7XG4gICAgICAgICAgICAgICAgICAgICAgb3B0cy5jb21wcmVzcyA9IHBhY2tldC5vcHRpb25zLmNvbXByZXNzO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKHNlbGYucGVyTWVzc2FnZURlZmxhdGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgbGVuID0gJ3N0cmluZycgPT0gdHlwZW9mIGRhdGEgPyBnbG9iYWwuQnVmZmVyLmJ5dGVMZW5ndGgoZGF0YSkgOiBkYXRhLmxlbmd0aDtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAobGVuIDwgc2VsZi5wZXJNZXNzYWdlRGVmbGF0ZS50aHJlc2hvbGQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdHMuY29tcHJlc3MgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgLy9Tb21ldGltZXMgdGhlIHdlYnNvY2tldCBoYXMgYWxyZWFkeSBiZWVuIGNsb3NlZCBidXQgdGhlIGJyb3dzZXIgZGlkbid0XG4gICAgICAgICAgICAgICAgICAvL2hhdmUgYSBjaGFuY2Ugb2YgaW5mb3JtaW5nIHVzIGFib3V0IGl0IHlldCwgaW4gdGhhdCBjYXNlIHNlbmQgd2lsbFxuICAgICAgICAgICAgICAgICAgLy90aHJvdyBhbiBlcnJvclxuICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKEJyb3dzZXJXZWJTb2NrZXQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAvLyBUeXBlRXJyb3IgaXMgdGhyb3duIHdoZW4gcGFzc2luZyB0aGUgc2Vjb25kIGFyZ3VtZW50IG9uIFNhZmFyaVxuICAgICAgICAgICAgICAgICAgICAgIHNlbGYud3Muc2VuZChkYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICBzZWxmLndzLnNlbmQoZGF0YSwgb3B0cyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgZGVidWcoJ3dlYnNvY2tldCBjbG9zZWQgYmVmb3JlIG9uY2xvc2UgZXZlbnQnKTtcbiAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgLS10b3RhbCB8fCBkb25lKCk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIH0pKHBhY2tldHNbaV0pO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBmdW5jdGlvbiBkb25lKCkge1xuICAgICAgICAgICAgICBzZWxmLmVtaXQoJ2ZsdXNoJyk7XG5cbiAgICAgICAgICAgICAgLy8gZmFrZSBkcmFpblxuICAgICAgICAgICAgICAvLyBkZWZlciB0byBuZXh0IHRpY2sgdG8gYWxsb3cgU29ja2V0IHRvIGNsZWFyIHdyaXRlQnVmZmVyXG4gICAgICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHNlbGYud3JpdGFibGUgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHNlbGYuZW1pdCgnZHJhaW4nKTtcbiAgICAgICAgICAgICAgfSwgMCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIENhbGxlZCB1cG9uIGNsb3NlXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIFdTLnByb3RvdHlwZS5vbkNsb3NlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgVHJhbnNwb3J0LnByb3RvdHlwZS5vbkNsb3NlLmNhbGwodGhpcyk7XG4gICAgICAgICAgfTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIENsb3NlcyBzb2NrZXQuXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIFdTLnByb3RvdHlwZS5kb0Nsb3NlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLndzICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgICB0aGlzLndzLmNsb3NlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIEdlbmVyYXRlcyB1cmkgZm9yIGNvbm5lY3Rpb24uXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIFdTLnByb3RvdHlwZS51cmkgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgcXVlcnkgPSB0aGlzLnF1ZXJ5IHx8IHt9O1xuICAgICAgICAgICAgdmFyIHNjaGVtYSA9IHRoaXMuc2VjdXJlID8gJ3dzcycgOiAnd3MnO1xuICAgICAgICAgICAgdmFyIHBvcnQgPSAnJztcblxuICAgICAgICAgICAgLy8gYXZvaWQgcG9ydCBpZiBkZWZhdWx0IGZvciBzY2hlbWFcbiAgICAgICAgICAgIGlmICh0aGlzLnBvcnQgJiYgKCd3c3MnID09IHNjaGVtYSAmJiB0aGlzLnBvcnQgIT0gNDQzIHx8ICd3cycgPT0gc2NoZW1hICYmIHRoaXMucG9ydCAhPSA4MCkpIHtcbiAgICAgICAgICAgICAgcG9ydCA9ICc6JyArIHRoaXMucG9ydDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gYXBwZW5kIHRpbWVzdGFtcCB0byBVUklcbiAgICAgICAgICAgIGlmICh0aGlzLnRpbWVzdGFtcFJlcXVlc3RzKSB7XG4gICAgICAgICAgICAgIHF1ZXJ5W3RoaXMudGltZXN0YW1wUGFyYW1dID0geWVhc3QoKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gY29tbXVuaWNhdGUgYmluYXJ5IHN1cHBvcnQgY2FwYWJpbGl0aWVzXG4gICAgICAgICAgICBpZiAoIXRoaXMuc3VwcG9ydHNCaW5hcnkpIHtcbiAgICAgICAgICAgICAgcXVlcnkuYjY0ID0gMTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcXVlcnkgPSBwYXJzZXFzLmVuY29kZShxdWVyeSk7XG5cbiAgICAgICAgICAgIC8vIHByZXBlbmQgPyB0byBxdWVyeVxuICAgICAgICAgICAgaWYgKHF1ZXJ5Lmxlbmd0aCkge1xuICAgICAgICAgICAgICBxdWVyeSA9ICc/JyArIHF1ZXJ5O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB2YXIgaXB2NiA9IHRoaXMuaG9zdG5hbWUuaW5kZXhPZignOicpICE9PSAtMTtcbiAgICAgICAgICAgIHJldHVybiBzY2hlbWEgKyAnOi8vJyArIChpcHY2ID8gJ1snICsgdGhpcy5ob3N0bmFtZSArICddJyA6IHRoaXMuaG9zdG5hbWUpICsgcG9ydCArIHRoaXMucGF0aCArIHF1ZXJ5O1xuICAgICAgICAgIH07XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBGZWF0dXJlIGRldGVjdGlvbiBmb3IgV2ViU29ja2V0LlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogQHJldHVybiB7Qm9vbGVhbn0gd2hldGhlciB0aGlzIHRyYW5zcG9ydCBpcyBhdmFpbGFibGUuXG4gICAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIFdTLnByb3RvdHlwZS5jaGVjayA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiAhIVdlYlNvY2tldCAmJiAhKCdfX2luaXRpYWxpemUnIGluIFdlYlNvY2tldCAmJiB0aGlzLm5hbWUgPT09IFdTLnByb3RvdHlwZS5uYW1lKTtcbiAgICAgICAgICB9O1xuICAgICAgICB9KS5jYWxsKHRoaXMsIHR5cGVvZiBzZWxmICE9PSBcInVuZGVmaW5lZFwiID8gc2VsZiA6IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgPyB3aW5kb3cgOiB0eXBlb2YgZ2xvYmFsICE9PSBcInVuZGVmaW5lZFwiID8gZ2xvYmFsIDoge30pO1xuICAgICAgfSwgeyBcIi4uL3RyYW5zcG9ydFwiOiA0LCBcImNvbXBvbmVudC1pbmhlcml0XCI6IDE2LCBcImRlYnVnXCI6IDE3LCBcImVuZ2luZS5pby1wYXJzZXJcIjogMTksIFwicGFyc2Vxc1wiOiAyNywgXCJ3c1wiOiB1bmRlZmluZWQsIFwieWVhc3RcIjogMzAgfV0sIDEwOiBbZnVuY3Rpb24gKF9kZXJlcV8sIG1vZHVsZSwgZXhwb3J0cykge1xuICAgICAgICAvLyBicm93c2VyIHNoaW0gZm9yIHhtbGh0dHByZXF1ZXN0IG1vZHVsZVxuICAgICAgICB2YXIgaGFzQ09SUyA9IF9kZXJlcV8oJ2hhcy1jb3JzJyk7XG5cbiAgICAgICAgbW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAob3B0cykge1xuICAgICAgICAgIHZhciB4ZG9tYWluID0gb3B0cy54ZG9tYWluO1xuXG4gICAgICAgICAgLy8gc2NoZW1lIG11c3QgYmUgc2FtZSB3aGVuIHVzaWduIFhEb21haW5SZXF1ZXN0XG4gICAgICAgICAgLy8gaHR0cDovL2Jsb2dzLm1zZG4uY29tL2IvaWVpbnRlcm5hbHMvYXJjaGl2ZS8yMDEwLzA1LzEzL3hkb21haW5yZXF1ZXN0LXJlc3RyaWN0aW9ucy1saW1pdGF0aW9ucy1hbmQtd29ya2Fyb3VuZHMuYXNweFxuICAgICAgICAgIHZhciB4c2NoZW1lID0gb3B0cy54c2NoZW1lO1xuXG4gICAgICAgICAgLy8gWERvbWFpblJlcXVlc3QgaGFzIGEgZmxvdyBvZiBub3Qgc2VuZGluZyBjb29raWUsIHRoZXJlZm9yZSBpdCBzaG91bGQgYmUgZGlzYWJsZWQgYXMgYSBkZWZhdWx0LlxuICAgICAgICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9BdXRvbWF0dGljL2VuZ2luZS5pby1jbGllbnQvcHVsbC8yMTdcbiAgICAgICAgICB2YXIgZW5hYmxlc1hEUiA9IG9wdHMuZW5hYmxlc1hEUjtcblxuICAgICAgICAgIC8vIFhNTEh0dHBSZXF1ZXN0IGNhbiBiZSBkaXNhYmxlZCBvbiBJRVxuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZiAoJ3VuZGVmaW5lZCcgIT0gdHlwZW9mIFhNTEh0dHBSZXF1ZXN0ICYmICgheGRvbWFpbiB8fCBoYXNDT1JTKSkge1xuICAgICAgICAgICAgICByZXR1cm4gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBjYXRjaCAoZSkge31cblxuICAgICAgICAgIC8vIFVzZSBYRG9tYWluUmVxdWVzdCBmb3IgSUU4IGlmIGVuYWJsZXNYRFIgaXMgdHJ1ZVxuICAgICAgICAgIC8vIGJlY2F1c2UgbG9hZGluZyBiYXIga2VlcHMgZmxhc2hpbmcgd2hlbiB1c2luZyBqc29ucC1wb2xsaW5nXG4gICAgICAgICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL3l1amlvc2FrYS9zb2NrZS5pby1pZTgtbG9hZGluZy1leGFtcGxlXG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGlmICgndW5kZWZpbmVkJyAhPSB0eXBlb2YgWERvbWFpblJlcXVlc3QgJiYgIXhzY2hlbWUgJiYgZW5hYmxlc1hEUikge1xuICAgICAgICAgICAgICByZXR1cm4gbmV3IFhEb21haW5SZXF1ZXN0KCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBjYXRjaCAoZSkge31cblxuICAgICAgICAgIGlmICgheGRvbWFpbikge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgcmV0dXJuIG5ldyBBY3RpdmVYT2JqZWN0KCdNaWNyb3NvZnQuWE1MSFRUUCcpO1xuICAgICAgICAgICAgfSBjYXRjaCAoZSkge31cbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICB9LCB7IFwiaGFzLWNvcnNcIjogMjIgfV0sIDExOiBbZnVuY3Rpb24gKF9kZXJlcV8sIG1vZHVsZSwgZXhwb3J0cykge1xuICAgICAgICBtb2R1bGUuZXhwb3J0cyA9IGFmdGVyO1xuXG4gICAgICAgIGZ1bmN0aW9uIGFmdGVyKGNvdW50LCBjYWxsYmFjaywgZXJyX2NiKSB7XG4gICAgICAgICAgdmFyIGJhaWwgPSBmYWxzZTtcbiAgICAgICAgICBlcnJfY2IgPSBlcnJfY2IgfHwgbm9vcDtcbiAgICAgICAgICBwcm94eS5jb3VudCA9IGNvdW50O1xuXG4gICAgICAgICAgcmV0dXJuIGNvdW50ID09PSAwID8gY2FsbGJhY2soKSA6IHByb3h5O1xuXG4gICAgICAgICAgZnVuY3Rpb24gcHJveHkoZXJyLCByZXN1bHQpIHtcbiAgICAgICAgICAgIGlmIChwcm94eS5jb3VudCA8PSAwKSB7XG4gICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignYWZ0ZXIgY2FsbGVkIHRvbyBtYW55IHRpbWVzJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAtLXByb3h5LmNvdW50O1xuXG4gICAgICAgICAgICAvLyBhZnRlciBmaXJzdCBlcnJvciwgcmVzdCBhcmUgcGFzc2VkIHRvIGVycl9jYlxuICAgICAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgICAgICBiYWlsID0gdHJ1ZTtcbiAgICAgICAgICAgICAgY2FsbGJhY2soZXJyKTtcbiAgICAgICAgICAgICAgLy8gZnV0dXJlIGVycm9yIGNhbGxiYWNrcyB3aWxsIGdvIHRvIGVycm9yIGhhbmRsZXJcbiAgICAgICAgICAgICAgY2FsbGJhY2sgPSBlcnJfY2I7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHByb3h5LmNvdW50ID09PSAwICYmICFiYWlsKSB7XG4gICAgICAgICAgICAgIGNhbGxiYWNrKG51bGwsIHJlc3VsdCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gbm9vcCgpIHt9XG4gICAgICB9LCB7fV0sIDEyOiBbZnVuY3Rpb24gKF9kZXJlcV8sIG1vZHVsZSwgZXhwb3J0cykge1xuICAgICAgICAvKipcbiAgICAgICAgICogQW4gYWJzdHJhY3Rpb24gZm9yIHNsaWNpbmcgYW4gYXJyYXlidWZmZXIgZXZlbiB3aGVuXG4gICAgICAgICAqIEFycmF5QnVmZmVyLnByb3RvdHlwZS5zbGljZSBpcyBub3Qgc3VwcG9ydGVkXG4gICAgICAgICAqXG4gICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAqL1xuXG4gICAgICAgIG1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGFycmF5YnVmZmVyLCBzdGFydCwgZW5kKSB7XG4gICAgICAgICAgdmFyIGJ5dGVzID0gYXJyYXlidWZmZXIuYnl0ZUxlbmd0aDtcbiAgICAgICAgICBzdGFydCA9IHN0YXJ0IHx8IDA7XG4gICAgICAgICAgZW5kID0gZW5kIHx8IGJ5dGVzO1xuXG4gICAgICAgICAgaWYgKGFycmF5YnVmZmVyLnNsaWNlKSB7XG4gICAgICAgICAgICByZXR1cm4gYXJyYXlidWZmZXIuc2xpY2Uoc3RhcnQsIGVuZCk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKHN0YXJ0IDwgMCkge1xuICAgICAgICAgICAgc3RhcnQgKz0gYnl0ZXM7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChlbmQgPCAwKSB7XG4gICAgICAgICAgICBlbmQgKz0gYnl0ZXM7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChlbmQgPiBieXRlcykge1xuICAgICAgICAgICAgZW5kID0gYnl0ZXM7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKHN0YXJ0ID49IGJ5dGVzIHx8IHN0YXJ0ID49IGVuZCB8fCBieXRlcyA9PT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBBcnJheUJ1ZmZlcigwKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICB2YXIgYWJ2ID0gbmV3IFVpbnQ4QXJyYXkoYXJyYXlidWZmZXIpO1xuICAgICAgICAgIHZhciByZXN1bHQgPSBuZXcgVWludDhBcnJheShlbmQgLSBzdGFydCk7XG4gICAgICAgICAgZm9yICh2YXIgaSA9IHN0YXJ0LCBpaSA9IDA7IGkgPCBlbmQ7IGkrKywgaWkrKykge1xuICAgICAgICAgICAgcmVzdWx0W2lpXSA9IGFidltpXTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHJlc3VsdC5idWZmZXI7XG4gICAgICAgIH07XG4gICAgICB9LCB7fV0sIDEzOiBbZnVuY3Rpb24gKF9kZXJlcV8sIG1vZHVsZSwgZXhwb3J0cykge1xuICAgICAgICAvKlxuICAgICAgICAgKiBiYXNlNjQtYXJyYXlidWZmZXJcbiAgICAgICAgICogaHR0cHM6Ly9naXRodWIuY29tL25pa2xhc3ZoL2Jhc2U2NC1hcnJheWJ1ZmZlclxuICAgICAgICAgKlxuICAgICAgICAgKiBDb3B5cmlnaHQgKGMpIDIwMTIgTmlrbGFzIHZvbiBIZXJ0emVuXG4gICAgICAgICAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgbGljZW5zZS5cbiAgICAgICAgICovXG4gICAgICAgIChmdW5jdGlvbiAoY2hhcnMpIHtcbiAgICAgICAgICBcInVzZSBzdHJpY3RcIjtcblxuICAgICAgICAgIGV4cG9ydHMuZW5jb2RlID0gZnVuY3Rpb24gKGFycmF5YnVmZmVyKSB7XG4gICAgICAgICAgICB2YXIgYnl0ZXMgPSBuZXcgVWludDhBcnJheShhcnJheWJ1ZmZlciksXG4gICAgICAgICAgICAgICAgaSxcbiAgICAgICAgICAgICAgICBsZW4gPSBieXRlcy5sZW5ndGgsXG4gICAgICAgICAgICAgICAgYmFzZTY0ID0gXCJcIjtcblxuICAgICAgICAgICAgZm9yIChpID0gMDsgaSA8IGxlbjsgaSArPSAzKSB7XG4gICAgICAgICAgICAgIGJhc2U2NCArPSBjaGFyc1tieXRlc1tpXSA+PiAyXTtcbiAgICAgICAgICAgICAgYmFzZTY0ICs9IGNoYXJzWyhieXRlc1tpXSAmIDMpIDw8IDQgfCBieXRlc1tpICsgMV0gPj4gNF07XG4gICAgICAgICAgICAgIGJhc2U2NCArPSBjaGFyc1soYnl0ZXNbaSArIDFdICYgMTUpIDw8IDIgfCBieXRlc1tpICsgMl0gPj4gNl07XG4gICAgICAgICAgICAgIGJhc2U2NCArPSBjaGFyc1tieXRlc1tpICsgMl0gJiA2M107XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChsZW4gJSAzID09PSAyKSB7XG4gICAgICAgICAgICAgIGJhc2U2NCA9IGJhc2U2NC5zdWJzdHJpbmcoMCwgYmFzZTY0Lmxlbmd0aCAtIDEpICsgXCI9XCI7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGxlbiAlIDMgPT09IDEpIHtcbiAgICAgICAgICAgICAgYmFzZTY0ID0gYmFzZTY0LnN1YnN0cmluZygwLCBiYXNlNjQubGVuZ3RoIC0gMikgKyBcIj09XCI7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiBiYXNlNjQ7XG4gICAgICAgICAgfTtcblxuICAgICAgICAgIGV4cG9ydHMuZGVjb2RlID0gZnVuY3Rpb24gKGJhc2U2NCkge1xuICAgICAgICAgICAgdmFyIGJ1ZmZlckxlbmd0aCA9IGJhc2U2NC5sZW5ndGggKiAwLjc1LFxuICAgICAgICAgICAgICAgIGxlbiA9IGJhc2U2NC5sZW5ndGgsXG4gICAgICAgICAgICAgICAgaSxcbiAgICAgICAgICAgICAgICBwID0gMCxcbiAgICAgICAgICAgICAgICBlbmNvZGVkMSxcbiAgICAgICAgICAgICAgICBlbmNvZGVkMixcbiAgICAgICAgICAgICAgICBlbmNvZGVkMyxcbiAgICAgICAgICAgICAgICBlbmNvZGVkNDtcblxuICAgICAgICAgICAgaWYgKGJhc2U2NFtiYXNlNjQubGVuZ3RoIC0gMV0gPT09IFwiPVwiKSB7XG4gICAgICAgICAgICAgIGJ1ZmZlckxlbmd0aC0tO1xuICAgICAgICAgICAgICBpZiAoYmFzZTY0W2Jhc2U2NC5sZW5ndGggLSAyXSA9PT0gXCI9XCIpIHtcbiAgICAgICAgICAgICAgICBidWZmZXJMZW5ndGgtLTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB2YXIgYXJyYXlidWZmZXIgPSBuZXcgQXJyYXlCdWZmZXIoYnVmZmVyTGVuZ3RoKSxcbiAgICAgICAgICAgICAgICBieXRlcyA9IG5ldyBVaW50OEFycmF5KGFycmF5YnVmZmVyKTtcblxuICAgICAgICAgICAgZm9yIChpID0gMDsgaSA8IGxlbjsgaSArPSA0KSB7XG4gICAgICAgICAgICAgIGVuY29kZWQxID0gY2hhcnMuaW5kZXhPZihiYXNlNjRbaV0pO1xuICAgICAgICAgICAgICBlbmNvZGVkMiA9IGNoYXJzLmluZGV4T2YoYmFzZTY0W2kgKyAxXSk7XG4gICAgICAgICAgICAgIGVuY29kZWQzID0gY2hhcnMuaW5kZXhPZihiYXNlNjRbaSArIDJdKTtcbiAgICAgICAgICAgICAgZW5jb2RlZDQgPSBjaGFycy5pbmRleE9mKGJhc2U2NFtpICsgM10pO1xuXG4gICAgICAgICAgICAgIGJ5dGVzW3ArK10gPSBlbmNvZGVkMSA8PCAyIHwgZW5jb2RlZDIgPj4gNDtcbiAgICAgICAgICAgICAgYnl0ZXNbcCsrXSA9IChlbmNvZGVkMiAmIDE1KSA8PCA0IHwgZW5jb2RlZDMgPj4gMjtcbiAgICAgICAgICAgICAgYnl0ZXNbcCsrXSA9IChlbmNvZGVkMyAmIDMpIDw8IDYgfCBlbmNvZGVkNCAmIDYzO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gYXJyYXlidWZmZXI7XG4gICAgICAgICAgfTtcbiAgICAgICAgfSkoXCJBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWmFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6MDEyMzQ1Njc4OSsvXCIpO1xuICAgICAgfSwge31dLCAxNDogW2Z1bmN0aW9uIChfZGVyZXFfLCBtb2R1bGUsIGV4cG9ydHMpIHtcbiAgICAgICAgKGZ1bmN0aW9uIChnbG9iYWwpIHtcbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBDcmVhdGUgYSBibG9iIGJ1aWxkZXIgZXZlbiB3aGVuIHZlbmRvciBwcmVmaXhlcyBleGlzdFxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgdmFyIEJsb2JCdWlsZGVyID0gZ2xvYmFsLkJsb2JCdWlsZGVyIHx8IGdsb2JhbC5XZWJLaXRCbG9iQnVpbGRlciB8fCBnbG9iYWwuTVNCbG9iQnVpbGRlciB8fCBnbG9iYWwuTW96QmxvYkJ1aWxkZXI7XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBDaGVjayBpZiBCbG9iIGNvbnN0cnVjdG9yIGlzIHN1cHBvcnRlZFxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgdmFyIGJsb2JTdXBwb3J0ZWQgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgdmFyIGEgPSBuZXcgQmxvYihbJ2hpJ10pO1xuICAgICAgICAgICAgICByZXR1cm4gYS5zaXplID09PSAyO1xuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSkoKTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIENoZWNrIGlmIEJsb2IgY29uc3RydWN0b3Igc3VwcG9ydHMgQXJyYXlCdWZmZXJWaWV3c1xuICAgICAgICAgICAqIEZhaWxzIGluIFNhZmFyaSA2LCBzbyB3ZSBuZWVkIHRvIG1hcCB0byBBcnJheUJ1ZmZlcnMgdGhlcmUuXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICB2YXIgYmxvYlN1cHBvcnRzQXJyYXlCdWZmZXJWaWV3ID0gYmxvYlN1cHBvcnRlZCAmJiAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgdmFyIGIgPSBuZXcgQmxvYihbbmV3IFVpbnQ4QXJyYXkoWzEsIDJdKV0pO1xuICAgICAgICAgICAgICByZXR1cm4gYi5zaXplID09PSAyO1xuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSkoKTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIENoZWNrIGlmIEJsb2JCdWlsZGVyIGlzIHN1cHBvcnRlZFxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgdmFyIGJsb2JCdWlsZGVyU3VwcG9ydGVkID0gQmxvYkJ1aWxkZXIgJiYgQmxvYkJ1aWxkZXIucHJvdG90eXBlLmFwcGVuZCAmJiBCbG9iQnVpbGRlci5wcm90b3R5cGUuZ2V0QmxvYjtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIEhlbHBlciBmdW5jdGlvbiB0aGF0IG1hcHMgQXJyYXlCdWZmZXJWaWV3cyB0byBBcnJheUJ1ZmZlcnNcbiAgICAgICAgICAgKiBVc2VkIGJ5IEJsb2JCdWlsZGVyIGNvbnN0cnVjdG9yIGFuZCBvbGQgYnJvd3NlcnMgdGhhdCBkaWRuJ3RcbiAgICAgICAgICAgKiBzdXBwb3J0IGl0IGluIHRoZSBCbG9iIGNvbnN0cnVjdG9yLlxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgZnVuY3Rpb24gbWFwQXJyYXlCdWZmZXJWaWV3cyhhcnkpIHtcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYXJ5Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgIHZhciBjaHVuayA9IGFyeVtpXTtcbiAgICAgICAgICAgICAgaWYgKGNodW5rLmJ1ZmZlciBpbnN0YW5jZW9mIEFycmF5QnVmZmVyKSB7XG4gICAgICAgICAgICAgICAgdmFyIGJ1ZiA9IGNodW5rLmJ1ZmZlcjtcblxuICAgICAgICAgICAgICAgIC8vIGlmIHRoaXMgaXMgYSBzdWJhcnJheSwgbWFrZSBhIGNvcHkgc28gd2Ugb25seVxuICAgICAgICAgICAgICAgIC8vIGluY2x1ZGUgdGhlIHN1YmFycmF5IHJlZ2lvbiBmcm9tIHRoZSB1bmRlcmx5aW5nIGJ1ZmZlclxuICAgICAgICAgICAgICAgIGlmIChjaHVuay5ieXRlTGVuZ3RoICE9PSBidWYuYnl0ZUxlbmd0aCkge1xuICAgICAgICAgICAgICAgICAgdmFyIGNvcHkgPSBuZXcgVWludDhBcnJheShjaHVuay5ieXRlTGVuZ3RoKTtcbiAgICAgICAgICAgICAgICAgIGNvcHkuc2V0KG5ldyBVaW50OEFycmF5KGJ1ZiwgY2h1bmsuYnl0ZU9mZnNldCwgY2h1bmsuYnl0ZUxlbmd0aCkpO1xuICAgICAgICAgICAgICAgICAgYnVmID0gY29weS5idWZmZXI7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgYXJ5W2ldID0gYnVmO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgZnVuY3Rpb24gQmxvYkJ1aWxkZXJDb25zdHJ1Y3RvcihhcnksIG9wdGlvbnMpIHtcbiAgICAgICAgICAgIG9wdGlvbnMgPSBvcHRpb25zIHx8IHt9O1xuXG4gICAgICAgICAgICB2YXIgYmIgPSBuZXcgQmxvYkJ1aWxkZXIoKTtcbiAgICAgICAgICAgIG1hcEFycmF5QnVmZmVyVmlld3MoYXJ5KTtcblxuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhcnkubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgYmIuYXBwZW5kKGFyeVtpXSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiBvcHRpb25zLnR5cGUgPyBiYi5nZXRCbG9iKG9wdGlvbnMudHlwZSkgOiBiYi5nZXRCbG9iKCk7XG4gICAgICAgICAgfTtcblxuICAgICAgICAgIGZ1bmN0aW9uIEJsb2JDb25zdHJ1Y3RvcihhcnksIG9wdGlvbnMpIHtcbiAgICAgICAgICAgIG1hcEFycmF5QnVmZmVyVmlld3MoYXJ5KTtcbiAgICAgICAgICAgIHJldHVybiBuZXcgQmxvYihhcnksIG9wdGlvbnMgfHwge30pO1xuICAgICAgICAgIH07XG5cbiAgICAgICAgICBtb2R1bGUuZXhwb3J0cyA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAoYmxvYlN1cHBvcnRlZCkge1xuICAgICAgICAgICAgICByZXR1cm4gYmxvYlN1cHBvcnRzQXJyYXlCdWZmZXJWaWV3ID8gZ2xvYmFsLkJsb2IgOiBCbG9iQ29uc3RydWN0b3I7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGJsb2JCdWlsZGVyU3VwcG9ydGVkKSB7XG4gICAgICAgICAgICAgIHJldHVybiBCbG9iQnVpbGRlckNvbnN0cnVjdG9yO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KSgpO1xuICAgICAgICB9KS5jYWxsKHRoaXMsIHR5cGVvZiBzZWxmICE9PSBcInVuZGVmaW5lZFwiID8gc2VsZiA6IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgPyB3aW5kb3cgOiB0eXBlb2YgZ2xvYmFsICE9PSBcInVuZGVmaW5lZFwiID8gZ2xvYmFsIDoge30pO1xuICAgICAgfSwge31dLCAxNTogW2Z1bmN0aW9uIChfZGVyZXFfLCBtb2R1bGUsIGV4cG9ydHMpIHtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRXhwb3NlIGBFbWl0dGVyYC5cbiAgICAgICAgICovXG5cbiAgICAgICAgbW9kdWxlLmV4cG9ydHMgPSBFbWl0dGVyO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBJbml0aWFsaXplIGEgbmV3IGBFbWl0dGVyYC5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgZnVuY3Rpb24gRW1pdHRlcihvYmopIHtcbiAgICAgICAgICBpZiAob2JqKSByZXR1cm4gbWl4aW4ob2JqKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogTWl4aW4gdGhlIGVtaXR0ZXIgcHJvcGVydGllcy5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3R9IG9ialxuICAgICAgICAgKiBAcmV0dXJuIHtPYmplY3R9XG4gICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgKi9cblxuICAgICAgICBmdW5jdGlvbiBtaXhpbihvYmopIHtcbiAgICAgICAgICBmb3IgKHZhciBrZXkgaW4gRW1pdHRlci5wcm90b3R5cGUpIHtcbiAgICAgICAgICAgIG9ialtrZXldID0gRW1pdHRlci5wcm90b3R5cGVba2V5XTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIG9iajtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBMaXN0ZW4gb24gdGhlIGdpdmVuIGBldmVudGAgd2l0aCBgZm5gLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ge1N0cmluZ30gZXZlbnRcbiAgICAgICAgICogQHBhcmFtIHtGdW5jdGlvbn0gZm5cbiAgICAgICAgICogQHJldHVybiB7RW1pdHRlcn1cbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgRW1pdHRlci5wcm90b3R5cGUub24gPSBFbWl0dGVyLnByb3RvdHlwZS5hZGRFdmVudExpc3RlbmVyID0gZnVuY3Rpb24gKGV2ZW50LCBmbikge1xuICAgICAgICAgIHRoaXMuX2NhbGxiYWNrcyA9IHRoaXMuX2NhbGxiYWNrcyB8fCB7fTtcbiAgICAgICAgICAodGhpcy5fY2FsbGJhY2tzW2V2ZW50XSA9IHRoaXMuX2NhbGxiYWNrc1tldmVudF0gfHwgW10pLnB1c2goZm4pO1xuICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBBZGRzIGFuIGBldmVudGAgbGlzdGVuZXIgdGhhdCB3aWxsIGJlIGludm9rZWQgYSBzaW5nbGVcbiAgICAgICAgICogdGltZSB0aGVuIGF1dG9tYXRpY2FsbHkgcmVtb3ZlZC5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtTdHJpbmd9IGV2ZW50XG4gICAgICAgICAqIEBwYXJhbSB7RnVuY3Rpb259IGZuXG4gICAgICAgICAqIEByZXR1cm4ge0VtaXR0ZXJ9XG4gICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAqL1xuXG4gICAgICAgIEVtaXR0ZXIucHJvdG90eXBlLm9uY2UgPSBmdW5jdGlvbiAoZXZlbnQsIGZuKSB7XG4gICAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICAgIHRoaXMuX2NhbGxiYWNrcyA9IHRoaXMuX2NhbGxiYWNrcyB8fCB7fTtcblxuICAgICAgICAgIGZ1bmN0aW9uIG9uKCkge1xuICAgICAgICAgICAgc2VsZi5vZmYoZXZlbnQsIG9uKTtcbiAgICAgICAgICAgIGZuLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgb24uZm4gPSBmbjtcbiAgICAgICAgICB0aGlzLm9uKGV2ZW50LCBvbik7XG4gICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFJlbW92ZSB0aGUgZ2l2ZW4gY2FsbGJhY2sgZm9yIGBldmVudGAgb3IgYWxsXG4gICAgICAgICAqIHJlZ2lzdGVyZWQgY2FsbGJhY2tzLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ge1N0cmluZ30gZXZlbnRcbiAgICAgICAgICogQHBhcmFtIHtGdW5jdGlvbn0gZm5cbiAgICAgICAgICogQHJldHVybiB7RW1pdHRlcn1cbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgRW1pdHRlci5wcm90b3R5cGUub2ZmID0gRW1pdHRlci5wcm90b3R5cGUucmVtb3ZlTGlzdGVuZXIgPSBFbWl0dGVyLnByb3RvdHlwZS5yZW1vdmVBbGxMaXN0ZW5lcnMgPSBFbWl0dGVyLnByb3RvdHlwZS5yZW1vdmVFdmVudExpc3RlbmVyID0gZnVuY3Rpb24gKGV2ZW50LCBmbikge1xuICAgICAgICAgIHRoaXMuX2NhbGxiYWNrcyA9IHRoaXMuX2NhbGxiYWNrcyB8fCB7fTtcblxuICAgICAgICAgIC8vIGFsbFxuICAgICAgICAgIGlmICgwID09IGFyZ3VtZW50cy5sZW5ndGgpIHtcbiAgICAgICAgICAgIHRoaXMuX2NhbGxiYWNrcyA9IHt9O1xuICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLy8gc3BlY2lmaWMgZXZlbnRcbiAgICAgICAgICB2YXIgY2FsbGJhY2tzID0gdGhpcy5fY2FsbGJhY2tzW2V2ZW50XTtcbiAgICAgICAgICBpZiAoIWNhbGxiYWNrcykgcmV0dXJuIHRoaXM7XG5cbiAgICAgICAgICAvLyByZW1vdmUgYWxsIGhhbmRsZXJzXG4gICAgICAgICAgaWYgKDEgPT0gYXJndW1lbnRzLmxlbmd0aCkge1xuICAgICAgICAgICAgZGVsZXRlIHRoaXMuX2NhbGxiYWNrc1tldmVudF07XG4gICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyByZW1vdmUgc3BlY2lmaWMgaGFuZGxlclxuICAgICAgICAgIHZhciBjYjtcbiAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGNhbGxiYWNrcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgY2IgPSBjYWxsYmFja3NbaV07XG4gICAgICAgICAgICBpZiAoY2IgPT09IGZuIHx8IGNiLmZuID09PSBmbikge1xuICAgICAgICAgICAgICBjYWxsYmFja3Muc3BsaWNlKGksIDEpO1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEVtaXQgYGV2ZW50YCB3aXRoIHRoZSBnaXZlbiBhcmdzLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ge1N0cmluZ30gZXZlbnRcbiAgICAgICAgICogQHBhcmFtIHtNaXhlZH0gLi4uXG4gICAgICAgICAqIEByZXR1cm4ge0VtaXR0ZXJ9XG4gICAgICAgICAqL1xuXG4gICAgICAgIEVtaXR0ZXIucHJvdG90eXBlLmVtaXQgPSBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgICB0aGlzLl9jYWxsYmFja3MgPSB0aGlzLl9jYWxsYmFja3MgfHwge307XG4gICAgICAgICAgdmFyIGFyZ3MgPSBbXS5zbGljZS5jYWxsKGFyZ3VtZW50cywgMSksXG4gICAgICAgICAgICAgIGNhbGxiYWNrcyA9IHRoaXMuX2NhbGxiYWNrc1tldmVudF07XG5cbiAgICAgICAgICBpZiAoY2FsbGJhY2tzKSB7XG4gICAgICAgICAgICBjYWxsYmFja3MgPSBjYWxsYmFja3Muc2xpY2UoMCk7XG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMCwgbGVuID0gY2FsbGJhY2tzLmxlbmd0aDsgaSA8IGxlbjsgKytpKSB7XG4gICAgICAgICAgICAgIGNhbGxiYWNrc1tpXS5hcHBseSh0aGlzLCBhcmdzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogUmV0dXJuIGFycmF5IG9mIGNhbGxiYWNrcyBmb3IgYGV2ZW50YC5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtTdHJpbmd9IGV2ZW50XG4gICAgICAgICAqIEByZXR1cm4ge0FycmF5fVxuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cblxuICAgICAgICBFbWl0dGVyLnByb3RvdHlwZS5saXN0ZW5lcnMgPSBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgICB0aGlzLl9jYWxsYmFja3MgPSB0aGlzLl9jYWxsYmFja3MgfHwge307XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX2NhbGxiYWNrc1tldmVudF0gfHwgW107XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENoZWNrIGlmIHRoaXMgZW1pdHRlciBoYXMgYGV2ZW50YCBoYW5kbGVycy5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtTdHJpbmd9IGV2ZW50XG4gICAgICAgICAqIEByZXR1cm4ge0Jvb2xlYW59XG4gICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAqL1xuXG4gICAgICAgIEVtaXR0ZXIucHJvdG90eXBlLmhhc0xpc3RlbmVycyA9IGZ1bmN0aW9uIChldmVudCkge1xuICAgICAgICAgIHJldHVybiAhIXRoaXMubGlzdGVuZXJzKGV2ZW50KS5sZW5ndGg7XG4gICAgICAgIH07XG4gICAgICB9LCB7fV0sIDE2OiBbZnVuY3Rpb24gKF9kZXJlcV8sIG1vZHVsZSwgZXhwb3J0cykge1xuXG4gICAgICAgIG1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGEsIGIpIHtcbiAgICAgICAgICB2YXIgZm4gPSBmdW5jdGlvbiBmbigpIHt9O1xuICAgICAgICAgIGZuLnByb3RvdHlwZSA9IGIucHJvdG90eXBlO1xuICAgICAgICAgIGEucHJvdG90eXBlID0gbmV3IGZuKCk7XG4gICAgICAgICAgYS5wcm90b3R5cGUuY29uc3RydWN0b3IgPSBhO1xuICAgICAgICB9O1xuICAgICAgfSwge31dLCAxNzogW2Z1bmN0aW9uIChfZGVyZXFfLCBtb2R1bGUsIGV4cG9ydHMpIHtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVGhpcyBpcyB0aGUgd2ViIGJyb3dzZXIgaW1wbGVtZW50YXRpb24gb2YgYGRlYnVnKClgLlxuICAgICAgICAgKlxuICAgICAgICAgKiBFeHBvc2UgYGRlYnVnKClgIGFzIHRoZSBtb2R1bGUuXG4gICAgICAgICAqL1xuXG4gICAgICAgIGV4cG9ydHMgPSBtb2R1bGUuZXhwb3J0cyA9IF9kZXJlcV8oJy4vZGVidWcnKTtcbiAgICAgICAgZXhwb3J0cy5sb2cgPSBsb2c7XG4gICAgICAgIGV4cG9ydHMuZm9ybWF0QXJncyA9IGZvcm1hdEFyZ3M7XG4gICAgICAgIGV4cG9ydHMuc2F2ZSA9IHNhdmU7XG4gICAgICAgIGV4cG9ydHMubG9hZCA9IGxvYWQ7XG4gICAgICAgIGV4cG9ydHMudXNlQ29sb3JzID0gdXNlQ29sb3JzO1xuICAgICAgICBleHBvcnRzLnN0b3JhZ2UgPSAndW5kZWZpbmVkJyAhPSB0eXBlb2YgY2hyb21lICYmICd1bmRlZmluZWQnICE9IHR5cGVvZiBjaHJvbWUuc3RvcmFnZSA/IGNocm9tZS5zdG9yYWdlLmxvY2FsIDogbG9jYWxzdG9yYWdlKCk7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENvbG9ycy5cbiAgICAgICAgICovXG5cbiAgICAgICAgZXhwb3J0cy5jb2xvcnMgPSBbJ2xpZ2h0c2VhZ3JlZW4nLCAnZm9yZXN0Z3JlZW4nLCAnZ29sZGVucm9kJywgJ2RvZGdlcmJsdWUnLCAnZGFya29yY2hpZCcsICdjcmltc29uJ107XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEN1cnJlbnRseSBvbmx5IFdlYktpdC1iYXNlZCBXZWIgSW5zcGVjdG9ycywgRmlyZWZveCA+PSB2MzEsXG4gICAgICAgICAqIGFuZCB0aGUgRmlyZWJ1ZyBleHRlbnNpb24gKGFueSBGaXJlZm94IHZlcnNpb24pIGFyZSBrbm93blxuICAgICAgICAgKiB0byBzdXBwb3J0IFwiJWNcIiBDU1MgY3VzdG9taXphdGlvbnMuXG4gICAgICAgICAqXG4gICAgICAgICAqIFRPRE86IGFkZCBhIGBsb2NhbFN0b3JhZ2VgIHZhcmlhYmxlIHRvIGV4cGxpY2l0bHkgZW5hYmxlL2Rpc2FibGUgY29sb3JzXG4gICAgICAgICAqL1xuXG4gICAgICAgIGZ1bmN0aW9uIHVzZUNvbG9ycygpIHtcbiAgICAgICAgICAvLyBpcyB3ZWJraXQ/IGh0dHA6Ly9zdGFja292ZXJmbG93LmNvbS9hLzE2NDU5NjA2LzM3Njc3M1xuICAgICAgICAgIHJldHVybiAnV2Via2l0QXBwZWFyYW5jZScgaW4gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnN0eWxlIHx8XG4gICAgICAgICAgLy8gaXMgZmlyZWJ1Zz8gaHR0cDovL3N0YWNrb3ZlcmZsb3cuY29tL2EvMzk4MTIwLzM3Njc3M1xuICAgICAgICAgIHdpbmRvdy5jb25zb2xlICYmIChjb25zb2xlLmZpcmVidWcgfHwgY29uc29sZS5leGNlcHRpb24gJiYgY29uc29sZS50YWJsZSkgfHxcbiAgICAgICAgICAvLyBpcyBmaXJlZm94ID49IHYzMT9cbiAgICAgICAgICAvLyBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1Rvb2xzL1dlYl9Db25zb2xlI1N0eWxpbmdfbWVzc2FnZXNcbiAgICAgICAgICBuYXZpZ2F0b3IudXNlckFnZW50LnRvTG93ZXJDYXNlKCkubWF0Y2goL2ZpcmVmb3hcXC8oXFxkKykvKSAmJiBwYXJzZUludChSZWdFeHAuJDEsIDEwKSA+PSAzMTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBNYXAgJWogdG8gYEpTT04uc3RyaW5naWZ5KClgLCBzaW5jZSBubyBXZWIgSW5zcGVjdG9ycyBkbyB0aGF0IGJ5IGRlZmF1bHQuXG4gICAgICAgICAqL1xuXG4gICAgICAgIGV4cG9ydHMuZm9ybWF0dGVycy5qID0gZnVuY3Rpb24gKHYpIHtcbiAgICAgICAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkodik7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENvbG9yaXplIGxvZyBhcmd1bWVudHMgaWYgZW5hYmxlZC5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgZnVuY3Rpb24gZm9ybWF0QXJncygpIHtcbiAgICAgICAgICB2YXIgYXJncyA9IGFyZ3VtZW50cztcbiAgICAgICAgICB2YXIgdXNlQ29sb3JzID0gdGhpcy51c2VDb2xvcnM7XG5cbiAgICAgICAgICBhcmdzWzBdID0gKHVzZUNvbG9ycyA/ICclYycgOiAnJykgKyB0aGlzLm5hbWVzcGFjZSArICh1c2VDb2xvcnMgPyAnICVjJyA6ICcgJykgKyBhcmdzWzBdICsgKHVzZUNvbG9ycyA/ICclYyAnIDogJyAnKSArICcrJyArIGV4cG9ydHMuaHVtYW5pemUodGhpcy5kaWZmKTtcblxuICAgICAgICAgIGlmICghdXNlQ29sb3JzKSByZXR1cm4gYXJncztcblxuICAgICAgICAgIHZhciBjID0gJ2NvbG9yOiAnICsgdGhpcy5jb2xvcjtcbiAgICAgICAgICBhcmdzID0gW2FyZ3NbMF0sIGMsICdjb2xvcjogaW5oZXJpdCddLmNvbmNhdChBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChhcmdzLCAxKSk7XG5cbiAgICAgICAgICAvLyB0aGUgZmluYWwgXCIlY1wiIGlzIHNvbWV3aGF0IHRyaWNreSwgYmVjYXVzZSB0aGVyZSBjb3VsZCBiZSBvdGhlclxuICAgICAgICAgIC8vIGFyZ3VtZW50cyBwYXNzZWQgZWl0aGVyIGJlZm9yZSBvciBhZnRlciB0aGUgJWMsIHNvIHdlIG5lZWQgdG9cbiAgICAgICAgICAvLyBmaWd1cmUgb3V0IHRoZSBjb3JyZWN0IGluZGV4IHRvIGluc2VydCB0aGUgQ1NTIGludG9cbiAgICAgICAgICB2YXIgaW5kZXggPSAwO1xuICAgICAgICAgIHZhciBsYXN0QyA9IDA7XG4gICAgICAgICAgYXJnc1swXS5yZXBsYWNlKC8lW2EteiVdL2csIGZ1bmN0aW9uIChtYXRjaCkge1xuICAgICAgICAgICAgaWYgKCclJScgPT09IG1hdGNoKSByZXR1cm47XG4gICAgICAgICAgICBpbmRleCsrO1xuICAgICAgICAgICAgaWYgKCclYycgPT09IG1hdGNoKSB7XG4gICAgICAgICAgICAgIC8vIHdlIG9ubHkgYXJlIGludGVyZXN0ZWQgaW4gdGhlICpsYXN0KiAlY1xuICAgICAgICAgICAgICAvLyAodGhlIHVzZXIgbWF5IGhhdmUgcHJvdmlkZWQgdGhlaXIgb3duKVxuICAgICAgICAgICAgICBsYXN0QyA9IGluZGV4O1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgYXJncy5zcGxpY2UobGFzdEMsIDAsIGMpO1xuICAgICAgICAgIHJldHVybiBhcmdzO1xuICAgICAgICB9XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEludm9rZXMgYGNvbnNvbGUubG9nKClgIHdoZW4gYXZhaWxhYmxlLlxuICAgICAgICAgKiBOby1vcCB3aGVuIGBjb25zb2xlLmxvZ2AgaXMgbm90IGEgXCJmdW5jdGlvblwiLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cblxuICAgICAgICBmdW5jdGlvbiBsb2coKSB7XG4gICAgICAgICAgLy8gdGhpcyBoYWNrZXJ5IGlzIHJlcXVpcmVkIGZvciBJRTgvOSwgd2hlcmVcbiAgICAgICAgICAvLyB0aGUgYGNvbnNvbGUubG9nYCBmdW5jdGlvbiBkb2Vzbid0IGhhdmUgJ2FwcGx5J1xuXG4gICAgICAgICAgcmV0dXJuICdvYmplY3QnID09PSB0eXBlb2YgY29uc29sZSAmJiBjb25zb2xlLmxvZyAmJiBGdW5jdGlvbi5wcm90b3R5cGUuYXBwbHkuY2FsbChjb25zb2xlLmxvZywgY29uc29sZSwgYXJndW1lbnRzKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBTYXZlIGBuYW1lc3BhY2VzYC5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtTdHJpbmd9IG5hbWVzcGFjZXNcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIGZ1bmN0aW9uIHNhdmUobmFtZXNwYWNlcykge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZiAobnVsbCA9PSBuYW1lc3BhY2VzKSB7XG4gICAgICAgICAgICAgIGV4cG9ydHMuc3RvcmFnZS5yZW1vdmVJdGVtKCdkZWJ1ZycpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgZXhwb3J0cy5zdG9yYWdlLmRlYnVnID0gbmFtZXNwYWNlcztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGNhdGNoIChlKSB7fVxuICAgICAgICB9XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIExvYWQgYG5hbWVzcGFjZXNgLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcmV0dXJuIHtTdHJpbmd9IHJldHVybnMgdGhlIHByZXZpb3VzbHkgcGVyc2lzdGVkIGRlYnVnIG1vZGVzXG4gICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgKi9cblxuICAgICAgICBmdW5jdGlvbiBsb2FkKCkge1xuICAgICAgICAgIHZhciByO1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICByID0gZXhwb3J0cy5zdG9yYWdlLmRlYnVnO1xuICAgICAgICAgIH0gY2F0Y2ggKGUpIHt9XG4gICAgICAgICAgcmV0dXJuIHI7XG4gICAgICAgIH1cblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5hYmxlIG5hbWVzcGFjZXMgbGlzdGVkIGluIGBsb2NhbFN0b3JhZ2UuZGVidWdgIGluaXRpYWxseS5cbiAgICAgICAgICovXG5cbiAgICAgICAgZXhwb3J0cy5lbmFibGUobG9hZCgpKTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogTG9jYWxzdG9yYWdlIGF0dGVtcHRzIHRvIHJldHVybiB0aGUgbG9jYWxzdG9yYWdlLlxuICAgICAgICAgKlxuICAgICAgICAgKiBUaGlzIGlzIG5lY2Vzc2FyeSBiZWNhdXNlIHNhZmFyaSB0aHJvd3NcbiAgICAgICAgICogd2hlbiBhIHVzZXIgZGlzYWJsZXMgY29va2llcy9sb2NhbHN0b3JhZ2VcbiAgICAgICAgICogYW5kIHlvdSBhdHRlbXB0IHRvIGFjY2VzcyBpdC5cbiAgICAgICAgICpcbiAgICAgICAgICogQHJldHVybiB7TG9jYWxTdG9yYWdlfVxuICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICovXG5cbiAgICAgICAgZnVuY3Rpb24gbG9jYWxzdG9yYWdlKCkge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXR1cm4gd2luZG93LmxvY2FsU3RvcmFnZTtcbiAgICAgICAgICB9IGNhdGNoIChlKSB7fVxuICAgICAgICB9XG4gICAgICB9LCB7IFwiLi9kZWJ1Z1wiOiAxOCB9XSwgMTg6IFtmdW5jdGlvbiAoX2RlcmVxXywgbW9kdWxlLCBleHBvcnRzKSB7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFRoaXMgaXMgdGhlIGNvbW1vbiBsb2dpYyBmb3IgYm90aCB0aGUgTm9kZS5qcyBhbmQgd2ViIGJyb3dzZXJcbiAgICAgICAgICogaW1wbGVtZW50YXRpb25zIG9mIGBkZWJ1ZygpYC5cbiAgICAgICAgICpcbiAgICAgICAgICogRXhwb3NlIGBkZWJ1ZygpYCBhcyB0aGUgbW9kdWxlLlxuICAgICAgICAgKi9cblxuICAgICAgICBleHBvcnRzID0gbW9kdWxlLmV4cG9ydHMgPSBkZWJ1ZztcbiAgICAgICAgZXhwb3J0cy5jb2VyY2UgPSBjb2VyY2U7XG4gICAgICAgIGV4cG9ydHMuZGlzYWJsZSA9IGRpc2FibGU7XG4gICAgICAgIGV4cG9ydHMuZW5hYmxlID0gZW5hYmxlO1xuICAgICAgICBleHBvcnRzLmVuYWJsZWQgPSBlbmFibGVkO1xuICAgICAgICBleHBvcnRzLmh1bWFuaXplID0gX2RlcmVxXygnbXMnKTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVGhlIGN1cnJlbnRseSBhY3RpdmUgZGVidWcgbW9kZSBuYW1lcywgYW5kIG5hbWVzIHRvIHNraXAuXG4gICAgICAgICAqL1xuXG4gICAgICAgIGV4cG9ydHMubmFtZXMgPSBbXTtcbiAgICAgICAgZXhwb3J0cy5za2lwcyA9IFtdO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBNYXAgb2Ygc3BlY2lhbCBcIiVuXCIgaGFuZGxpbmcgZnVuY3Rpb25zLCBmb3IgdGhlIGRlYnVnIFwiZm9ybWF0XCIgYXJndW1lbnQuXG4gICAgICAgICAqXG4gICAgICAgICAqIFZhbGlkIGtleSBuYW1lcyBhcmUgYSBzaW5nbGUsIGxvd2VyY2FzZWQgbGV0dGVyLCBpLmUuIFwiblwiLlxuICAgICAgICAgKi9cblxuICAgICAgICBleHBvcnRzLmZvcm1hdHRlcnMgPSB7fTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogUHJldmlvdXNseSBhc3NpZ25lZCBjb2xvci5cbiAgICAgICAgICovXG5cbiAgICAgICAgdmFyIHByZXZDb2xvciA9IDA7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFByZXZpb3VzIGxvZyB0aW1lc3RhbXAuXG4gICAgICAgICAqL1xuXG4gICAgICAgIHZhciBwcmV2VGltZTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogU2VsZWN0IGEgY29sb3IuXG4gICAgICAgICAqXG4gICAgICAgICAqIEByZXR1cm4ge051bWJlcn1cbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIGZ1bmN0aW9uIHNlbGVjdENvbG9yKCkge1xuICAgICAgICAgIHJldHVybiBleHBvcnRzLmNvbG9yc1twcmV2Q29sb3IrKyAlIGV4cG9ydHMuY29sb3JzLmxlbmd0aF07XG4gICAgICAgIH1cblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlIGEgZGVidWdnZXIgd2l0aCB0aGUgZ2l2ZW4gYG5hbWVzcGFjZWAuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7U3RyaW5nfSBuYW1lc3BhY2VcbiAgICAgICAgICogQHJldHVybiB7RnVuY3Rpb259XG4gICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAqL1xuXG4gICAgICAgIGZ1bmN0aW9uIGRlYnVnKG5hbWVzcGFjZSkge1xuXG4gICAgICAgICAgLy8gZGVmaW5lIHRoZSBgZGlzYWJsZWRgIHZlcnNpb25cbiAgICAgICAgICBmdW5jdGlvbiBkaXNhYmxlZCgpIHt9XG4gICAgICAgICAgZGlzYWJsZWQuZW5hYmxlZCA9IGZhbHNlO1xuXG4gICAgICAgICAgLy8gZGVmaW5lIHRoZSBgZW5hYmxlZGAgdmVyc2lvblxuICAgICAgICAgIGZ1bmN0aW9uIGVuYWJsZWQoKSB7XG5cbiAgICAgICAgICAgIHZhciBzZWxmID0gZW5hYmxlZDtcblxuICAgICAgICAgICAgLy8gc2V0IGBkaWZmYCB0aW1lc3RhbXBcbiAgICAgICAgICAgIHZhciBjdXJyID0gK25ldyBEYXRlKCk7XG4gICAgICAgICAgICB2YXIgbXMgPSBjdXJyIC0gKHByZXZUaW1lIHx8IGN1cnIpO1xuICAgICAgICAgICAgc2VsZi5kaWZmID0gbXM7XG4gICAgICAgICAgICBzZWxmLnByZXYgPSBwcmV2VGltZTtcbiAgICAgICAgICAgIHNlbGYuY3VyciA9IGN1cnI7XG4gICAgICAgICAgICBwcmV2VGltZSA9IGN1cnI7XG5cbiAgICAgICAgICAgIC8vIGFkZCB0aGUgYGNvbG9yYCBpZiBub3Qgc2V0XG4gICAgICAgICAgICBpZiAobnVsbCA9PSBzZWxmLnVzZUNvbG9ycykgc2VsZi51c2VDb2xvcnMgPSBleHBvcnRzLnVzZUNvbG9ycygpO1xuICAgICAgICAgICAgaWYgKG51bGwgPT0gc2VsZi5jb2xvciAmJiBzZWxmLnVzZUNvbG9ycykgc2VsZi5jb2xvciA9IHNlbGVjdENvbG9yKCk7XG5cbiAgICAgICAgICAgIHZhciBhcmdzID0gQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwoYXJndW1lbnRzKTtcblxuICAgICAgICAgICAgYXJnc1swXSA9IGV4cG9ydHMuY29lcmNlKGFyZ3NbMF0pO1xuXG4gICAgICAgICAgICBpZiAoJ3N0cmluZycgIT09IHR5cGVvZiBhcmdzWzBdKSB7XG4gICAgICAgICAgICAgIC8vIGFueXRoaW5nIGVsc2UgbGV0J3MgaW5zcGVjdCB3aXRoICVvXG4gICAgICAgICAgICAgIGFyZ3MgPSBbJyVvJ10uY29uY2F0KGFyZ3MpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBhcHBseSBhbnkgYGZvcm1hdHRlcnNgIHRyYW5zZm9ybWF0aW9uc1xuICAgICAgICAgICAgdmFyIGluZGV4ID0gMDtcbiAgICAgICAgICAgIGFyZ3NbMF0gPSBhcmdzWzBdLnJlcGxhY2UoLyUoW2EteiVdKS9nLCBmdW5jdGlvbiAobWF0Y2gsIGZvcm1hdCkge1xuICAgICAgICAgICAgICAvLyBpZiB3ZSBlbmNvdW50ZXIgYW4gZXNjYXBlZCAlIHRoZW4gZG9uJ3QgaW5jcmVhc2UgdGhlIGFycmF5IGluZGV4XG4gICAgICAgICAgICAgIGlmIChtYXRjaCA9PT0gJyUlJykgcmV0dXJuIG1hdGNoO1xuICAgICAgICAgICAgICBpbmRleCsrO1xuICAgICAgICAgICAgICB2YXIgZm9ybWF0dGVyID0gZXhwb3J0cy5mb3JtYXR0ZXJzW2Zvcm1hdF07XG4gICAgICAgICAgICAgIGlmICgnZnVuY3Rpb24nID09PSB0eXBlb2YgZm9ybWF0dGVyKSB7XG4gICAgICAgICAgICAgICAgdmFyIHZhbCA9IGFyZ3NbaW5kZXhdO1xuICAgICAgICAgICAgICAgIG1hdGNoID0gZm9ybWF0dGVyLmNhbGwoc2VsZiwgdmFsKTtcblxuICAgICAgICAgICAgICAgIC8vIG5vdyB3ZSBuZWVkIHRvIHJlbW92ZSBgYXJnc1tpbmRleF1gIHNpbmNlIGl0J3MgaW5saW5lZCBpbiB0aGUgYGZvcm1hdGBcbiAgICAgICAgICAgICAgICBhcmdzLnNwbGljZShpbmRleCwgMSk7XG4gICAgICAgICAgICAgICAgaW5kZXgtLTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICByZXR1cm4gbWF0Y2g7XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgaWYgKCdmdW5jdGlvbicgPT09IHR5cGVvZiBleHBvcnRzLmZvcm1hdEFyZ3MpIHtcbiAgICAgICAgICAgICAgYXJncyA9IGV4cG9ydHMuZm9ybWF0QXJncy5hcHBseShzZWxmLCBhcmdzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHZhciBsb2dGbiA9IGVuYWJsZWQubG9nIHx8IGV4cG9ydHMubG9nIHx8IGNvbnNvbGUubG9nLmJpbmQoY29uc29sZSk7XG4gICAgICAgICAgICBsb2dGbi5hcHBseShzZWxmLCBhcmdzKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgZW5hYmxlZC5lbmFibGVkID0gdHJ1ZTtcblxuICAgICAgICAgIHZhciBmbiA9IGV4cG9ydHMuZW5hYmxlZChuYW1lc3BhY2UpID8gZW5hYmxlZCA6IGRpc2FibGVkO1xuXG4gICAgICAgICAgZm4ubmFtZXNwYWNlID0gbmFtZXNwYWNlO1xuXG4gICAgICAgICAgcmV0dXJuIGZuO1xuICAgICAgICB9XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEVuYWJsZXMgYSBkZWJ1ZyBtb2RlIGJ5IG5hbWVzcGFjZXMuIFRoaXMgY2FuIGluY2x1ZGUgbW9kZXNcbiAgICAgICAgICogc2VwYXJhdGVkIGJ5IGEgY29sb24gYW5kIHdpbGRjYXJkcy5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtTdHJpbmd9IG5hbWVzcGFjZXNcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgZnVuY3Rpb24gZW5hYmxlKG5hbWVzcGFjZXMpIHtcbiAgICAgICAgICBleHBvcnRzLnNhdmUobmFtZXNwYWNlcyk7XG5cbiAgICAgICAgICB2YXIgc3BsaXQgPSAobmFtZXNwYWNlcyB8fCAnJykuc3BsaXQoL1tcXHMsXSsvKTtcbiAgICAgICAgICB2YXIgbGVuID0gc3BsaXQubGVuZ3RoO1xuXG4gICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW47IGkrKykge1xuICAgICAgICAgICAgaWYgKCFzcGxpdFtpXSkgY29udGludWU7IC8vIGlnbm9yZSBlbXB0eSBzdHJpbmdzXG4gICAgICAgICAgICBuYW1lc3BhY2VzID0gc3BsaXRbaV0ucmVwbGFjZSgvXFwqL2csICcuKj8nKTtcbiAgICAgICAgICAgIGlmIChuYW1lc3BhY2VzWzBdID09PSAnLScpIHtcbiAgICAgICAgICAgICAgZXhwb3J0cy5za2lwcy5wdXNoKG5ldyBSZWdFeHAoJ14nICsgbmFtZXNwYWNlcy5zdWJzdHIoMSkgKyAnJCcpKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIGV4cG9ydHMubmFtZXMucHVzaChuZXcgUmVnRXhwKCdeJyArIG5hbWVzcGFjZXMgKyAnJCcpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvKipcbiAgICAgICAgICogRGlzYWJsZSBkZWJ1ZyBvdXRwdXQuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAqL1xuXG4gICAgICAgIGZ1bmN0aW9uIGRpc2FibGUoKSB7XG4gICAgICAgICAgZXhwb3J0cy5lbmFibGUoJycpO1xuICAgICAgICB9XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgZ2l2ZW4gbW9kZSBuYW1lIGlzIGVuYWJsZWQsIGZhbHNlIG90aGVyd2lzZS5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtTdHJpbmd9IG5hbWVcbiAgICAgICAgICogQHJldHVybiB7Qm9vbGVhbn1cbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgZnVuY3Rpb24gZW5hYmxlZChuYW1lKSB7XG4gICAgICAgICAgdmFyIGksIGxlbjtcbiAgICAgICAgICBmb3IgKGkgPSAwLCBsZW4gPSBleHBvcnRzLnNraXBzLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICAgICAgICBpZiAoZXhwb3J0cy5za2lwc1tpXS50ZXN0KG5hbWUpKSB7XG4gICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgZm9yIChpID0gMCwgbGVuID0gZXhwb3J0cy5uYW1lcy5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuICAgICAgICAgICAgaWYgKGV4cG9ydHMubmFtZXNbaV0udGVzdChuYW1lKSkge1xuICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENvZXJjZSBgdmFsYC5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtNaXhlZH0gdmFsXG4gICAgICAgICAqIEByZXR1cm4ge01peGVkfVxuICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICovXG5cbiAgICAgICAgZnVuY3Rpb24gY29lcmNlKHZhbCkge1xuICAgICAgICAgIGlmICh2YWwgaW5zdGFuY2VvZiBFcnJvcikgcmV0dXJuIHZhbC5zdGFjayB8fCB2YWwubWVzc2FnZTtcbiAgICAgICAgICByZXR1cm4gdmFsO1xuICAgICAgICB9XG4gICAgICB9LCB7IFwibXNcIjogMjUgfV0sIDE5OiBbZnVuY3Rpb24gKF9kZXJlcV8sIG1vZHVsZSwgZXhwb3J0cykge1xuICAgICAgICAoZnVuY3Rpb24gKGdsb2JhbCkge1xuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIE1vZHVsZSBkZXBlbmRlbmNpZXMuXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICB2YXIga2V5cyA9IF9kZXJlcV8oJy4va2V5cycpO1xuICAgICAgICAgIHZhciBoYXNCaW5hcnkgPSBfZGVyZXFfKCdoYXMtYmluYXJ5Jyk7XG4gICAgICAgICAgdmFyIHNsaWNlQnVmZmVyID0gX2RlcmVxXygnYXJyYXlidWZmZXIuc2xpY2UnKTtcbiAgICAgICAgICB2YXIgYmFzZTY0ZW5jb2RlciA9IF9kZXJlcV8oJ2Jhc2U2NC1hcnJheWJ1ZmZlcicpO1xuICAgICAgICAgIHZhciBhZnRlciA9IF9kZXJlcV8oJ2FmdGVyJyk7XG4gICAgICAgICAgdmFyIHV0ZjggPSBfZGVyZXFfKCd1dGY4Jyk7XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBDaGVjayBpZiB3ZSBhcmUgcnVubmluZyBhbiBhbmRyb2lkIGJyb3dzZXIuIFRoYXQgcmVxdWlyZXMgdXMgdG8gdXNlXG4gICAgICAgICAgICogQXJyYXlCdWZmZXIgd2l0aCBwb2xsaW5nIHRyYW5zcG9ydHMuLi5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIGh0dHA6Ly9naGluZGEubmV0L2pwZWctYmxvYi1hamF4LWFuZHJvaWQvXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICB2YXIgaXNBbmRyb2lkID0gbmF2aWdhdG9yLnVzZXJBZ2VudC5tYXRjaCgvQW5kcm9pZC9pKTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIENoZWNrIGlmIHdlIGFyZSBydW5uaW5nIGluIFBoYW50b21KUy5cbiAgICAgICAgICAgKiBVcGxvYWRpbmcgYSBCbG9iIHdpdGggUGhhbnRvbUpTIGRvZXMgbm90IHdvcmsgY29ycmVjdGx5LCBhcyByZXBvcnRlZCBoZXJlOlxuICAgICAgICAgICAqIGh0dHBzOi8vZ2l0aHViLmNvbS9hcml5YS9waGFudG9tanMvaXNzdWVzLzExMzk1XG4gICAgICAgICAgICogQHR5cGUgYm9vbGVhblxuICAgICAgICAgICAqL1xuICAgICAgICAgIHZhciBpc1BoYW50b21KUyA9IC9QaGFudG9tSlMvaS50ZXN0KG5hdmlnYXRvci51c2VyQWdlbnQpO1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogV2hlbiB0cnVlLCBhdm9pZHMgdXNpbmcgQmxvYnMgdG8gZW5jb2RlIHBheWxvYWRzLlxuICAgICAgICAgICAqIEB0eXBlIGJvb2xlYW5cbiAgICAgICAgICAgKi9cbiAgICAgICAgICB2YXIgZG9udFNlbmRCbG9icyA9IGlzQW5kcm9pZCB8fCBpc1BoYW50b21KUztcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIEN1cnJlbnQgcHJvdG9jb2wgdmVyc2lvbi5cbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIGV4cG9ydHMucHJvdG9jb2wgPSAzO1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogUGFja2V0IHR5cGVzLlxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgdmFyIHBhY2tldHMgPSBleHBvcnRzLnBhY2tldHMgPSB7XG4gICAgICAgICAgICBvcGVuOiAwLCAvLyBub24td3NcbiAgICAgICAgICAgIGNsb3NlOiAxLCAvLyBub24td3NcbiAgICAgICAgICAgIHBpbmc6IDIsXG4gICAgICAgICAgICBwb25nOiAzLFxuICAgICAgICAgICAgbWVzc2FnZTogNCxcbiAgICAgICAgICAgIHVwZ3JhZGU6IDUsXG4gICAgICAgICAgICBub29wOiA2XG4gICAgICAgICAgfTtcblxuICAgICAgICAgIHZhciBwYWNrZXRzbGlzdCA9IGtleXMocGFja2V0cyk7XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBQcmVtYWRlIGVycm9yIHBhY2tldC5cbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIHZhciBlcnIgPSB7IHR5cGU6ICdlcnJvcicsIGRhdGE6ICdwYXJzZXIgZXJyb3InIH07XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBDcmVhdGUgYSBibG9iIGFwaSBldmVuIGZvciBibG9iIGJ1aWxkZXIgd2hlbiB2ZW5kb3IgcHJlZml4ZXMgZXhpc3RcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIHZhciBCbG9iID0gX2RlcmVxXygnYmxvYicpO1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogRW5jb2RlcyBhIHBhY2tldC5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqICAgICA8cGFja2V0IHR5cGUgaWQ+IFsgPGRhdGE+IF1cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEV4YW1wbGU6XG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiAgICAgNWhlbGxvIHdvcmxkXG4gICAgICAgICAgICogICAgIDNcbiAgICAgICAgICAgKiAgICAgNFxuICAgICAgICAgICAqXG4gICAgICAgICAgICogQmluYXJ5IGlzIGVuY29kZWQgaW4gYW4gaWRlbnRpY2FsIHByaW5jaXBsZVxuICAgICAgICAgICAqXG4gICAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBleHBvcnRzLmVuY29kZVBhY2tldCA9IGZ1bmN0aW9uIChwYWNrZXQsIHN1cHBvcnRzQmluYXJ5LCB1dGY4ZW5jb2RlLCBjYWxsYmFjaykge1xuICAgICAgICAgICAgaWYgKCdmdW5jdGlvbicgPT0gdHlwZW9mIHN1cHBvcnRzQmluYXJ5KSB7XG4gICAgICAgICAgICAgIGNhbGxiYWNrID0gc3VwcG9ydHNCaW5hcnk7XG4gICAgICAgICAgICAgIHN1cHBvcnRzQmluYXJ5ID0gZmFsc2U7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmICgnZnVuY3Rpb24nID09IHR5cGVvZiB1dGY4ZW5jb2RlKSB7XG4gICAgICAgICAgICAgIGNhbGxiYWNrID0gdXRmOGVuY29kZTtcbiAgICAgICAgICAgICAgdXRmOGVuY29kZSA9IG51bGw7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHZhciBkYXRhID0gcGFja2V0LmRhdGEgPT09IHVuZGVmaW5lZCA/IHVuZGVmaW5lZCA6IHBhY2tldC5kYXRhLmJ1ZmZlciB8fCBwYWNrZXQuZGF0YTtcblxuICAgICAgICAgICAgaWYgKGdsb2JhbC5BcnJheUJ1ZmZlciAmJiBkYXRhIGluc3RhbmNlb2YgQXJyYXlCdWZmZXIpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGVuY29kZUFycmF5QnVmZmVyKHBhY2tldCwgc3VwcG9ydHNCaW5hcnksIGNhbGxiYWNrKTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoQmxvYiAmJiBkYXRhIGluc3RhbmNlb2YgZ2xvYmFsLkJsb2IpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGVuY29kZUJsb2IocGFja2V0LCBzdXBwb3J0c0JpbmFyeSwgY2FsbGJhY2spO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBtaWdodCBiZSBhbiBvYmplY3Qgd2l0aCB7IGJhc2U2NDogdHJ1ZSwgZGF0YTogZGF0YUFzQmFzZTY0U3RyaW5nIH1cbiAgICAgICAgICAgIGlmIChkYXRhICYmIGRhdGEuYmFzZTY0KSB7XG4gICAgICAgICAgICAgIHJldHVybiBlbmNvZGVCYXNlNjRPYmplY3QocGFja2V0LCBjYWxsYmFjayk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIFNlbmRpbmcgZGF0YSBhcyBhIHV0Zi04IHN0cmluZ1xuICAgICAgICAgICAgdmFyIGVuY29kZWQgPSBwYWNrZXRzW3BhY2tldC50eXBlXTtcblxuICAgICAgICAgICAgLy8gZGF0YSBmcmFnbWVudCBpcyBvcHRpb25hbFxuICAgICAgICAgICAgaWYgKHVuZGVmaW5lZCAhPT0gcGFja2V0LmRhdGEpIHtcbiAgICAgICAgICAgICAgZW5jb2RlZCArPSB1dGY4ZW5jb2RlID8gdXRmOC5lbmNvZGUoU3RyaW5nKHBhY2tldC5kYXRhKSkgOiBTdHJpbmcocGFja2V0LmRhdGEpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gY2FsbGJhY2soJycgKyBlbmNvZGVkKTtcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgZnVuY3Rpb24gZW5jb2RlQmFzZTY0T2JqZWN0KHBhY2tldCwgY2FsbGJhY2spIHtcbiAgICAgICAgICAgIC8vIHBhY2tldCBkYXRhIGlzIGFuIG9iamVjdCB7IGJhc2U2NDogdHJ1ZSwgZGF0YTogZGF0YUFzQmFzZTY0U3RyaW5nIH1cbiAgICAgICAgICAgIHZhciBtZXNzYWdlID0gJ2InICsgZXhwb3J0cy5wYWNrZXRzW3BhY2tldC50eXBlXSArIHBhY2tldC5kYXRhLmRhdGE7XG4gICAgICAgICAgICByZXR1cm4gY2FsbGJhY2sobWVzc2FnZSk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogRW5jb2RlIHBhY2tldCBoZWxwZXJzIGZvciBiaW5hcnkgdHlwZXNcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIGZ1bmN0aW9uIGVuY29kZUFycmF5QnVmZmVyKHBhY2tldCwgc3VwcG9ydHNCaW5hcnksIGNhbGxiYWNrKSB7XG4gICAgICAgICAgICBpZiAoIXN1cHBvcnRzQmluYXJ5KSB7XG4gICAgICAgICAgICAgIHJldHVybiBleHBvcnRzLmVuY29kZUJhc2U2NFBhY2tldChwYWNrZXQsIGNhbGxiYWNrKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdmFyIGRhdGEgPSBwYWNrZXQuZGF0YTtcbiAgICAgICAgICAgIHZhciBjb250ZW50QXJyYXkgPSBuZXcgVWludDhBcnJheShkYXRhKTtcbiAgICAgICAgICAgIHZhciByZXN1bHRCdWZmZXIgPSBuZXcgVWludDhBcnJheSgxICsgZGF0YS5ieXRlTGVuZ3RoKTtcblxuICAgICAgICAgICAgcmVzdWx0QnVmZmVyWzBdID0gcGFja2V0c1twYWNrZXQudHlwZV07XG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGNvbnRlbnRBcnJheS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICByZXN1bHRCdWZmZXJbaSArIDFdID0gY29udGVudEFycmF5W2ldO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gY2FsbGJhY2socmVzdWx0QnVmZmVyLmJ1ZmZlcik7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgZnVuY3Rpb24gZW5jb2RlQmxvYkFzQXJyYXlCdWZmZXIocGFja2V0LCBzdXBwb3J0c0JpbmFyeSwgY2FsbGJhY2spIHtcbiAgICAgICAgICAgIGlmICghc3VwcG9ydHNCaW5hcnkpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGV4cG9ydHMuZW5jb2RlQmFzZTY0UGFja2V0KHBhY2tldCwgY2FsbGJhY2spO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB2YXIgZnIgPSBuZXcgRmlsZVJlYWRlcigpO1xuICAgICAgICAgICAgZnIub25sb2FkID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICBwYWNrZXQuZGF0YSA9IGZyLnJlc3VsdDtcbiAgICAgICAgICAgICAgZXhwb3J0cy5lbmNvZGVQYWNrZXQocGFja2V0LCBzdXBwb3J0c0JpbmFyeSwgdHJ1ZSwgY2FsbGJhY2spO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHJldHVybiBmci5yZWFkQXNBcnJheUJ1ZmZlcihwYWNrZXQuZGF0YSk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgZnVuY3Rpb24gZW5jb2RlQmxvYihwYWNrZXQsIHN1cHBvcnRzQmluYXJ5LCBjYWxsYmFjaykge1xuICAgICAgICAgICAgaWYgKCFzdXBwb3J0c0JpbmFyeSkge1xuICAgICAgICAgICAgICByZXR1cm4gZXhwb3J0cy5lbmNvZGVCYXNlNjRQYWNrZXQocGFja2V0LCBjYWxsYmFjayk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChkb250U2VuZEJsb2JzKSB7XG4gICAgICAgICAgICAgIHJldHVybiBlbmNvZGVCbG9iQXNBcnJheUJ1ZmZlcihwYWNrZXQsIHN1cHBvcnRzQmluYXJ5LCBjYWxsYmFjayk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHZhciBsZW5ndGggPSBuZXcgVWludDhBcnJheSgxKTtcbiAgICAgICAgICAgIGxlbmd0aFswXSA9IHBhY2tldHNbcGFja2V0LnR5cGVdO1xuICAgICAgICAgICAgdmFyIGJsb2IgPSBuZXcgQmxvYihbbGVuZ3RoLmJ1ZmZlciwgcGFja2V0LmRhdGFdKTtcblxuICAgICAgICAgICAgcmV0dXJuIGNhbGxiYWNrKGJsb2IpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIEVuY29kZXMgYSBwYWNrZXQgd2l0aCBiaW5hcnkgZGF0YSBpbiBhIGJhc2U2NCBzdHJpbmdcbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBwYWNrZXQsIGhhcyBgdHlwZWAgYW5kIGBkYXRhYFxuICAgICAgICAgICAqIEByZXR1cm4ge1N0cmluZ30gYmFzZTY0IGVuY29kZWQgbWVzc2FnZVxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgZXhwb3J0cy5lbmNvZGVCYXNlNjRQYWNrZXQgPSBmdW5jdGlvbiAocGFja2V0LCBjYWxsYmFjaykge1xuICAgICAgICAgICAgdmFyIG1lc3NhZ2UgPSAnYicgKyBleHBvcnRzLnBhY2tldHNbcGFja2V0LnR5cGVdO1xuICAgICAgICAgICAgaWYgKEJsb2IgJiYgcGFja2V0LmRhdGEgaW5zdGFuY2VvZiBnbG9iYWwuQmxvYikge1xuICAgICAgICAgICAgICB2YXIgZnIgPSBuZXcgRmlsZVJlYWRlcigpO1xuICAgICAgICAgICAgICBmci5vbmxvYWQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgdmFyIGI2NCA9IGZyLnJlc3VsdC5zcGxpdCgnLCcpWzFdO1xuICAgICAgICAgICAgICAgIGNhbGxiYWNrKG1lc3NhZ2UgKyBiNjQpO1xuICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICByZXR1cm4gZnIucmVhZEFzRGF0YVVSTChwYWNrZXQuZGF0YSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHZhciBiNjRkYXRhO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgYjY0ZGF0YSA9IFN0cmluZy5mcm9tQ2hhckNvZGUuYXBwbHkobnVsbCwgbmV3IFVpbnQ4QXJyYXkocGFja2V0LmRhdGEpKTtcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgLy8gaVBob25lIFNhZmFyaSBkb2Vzbid0IGxldCB5b3UgYXBwbHkgd2l0aCB0eXBlZCBhcnJheXNcbiAgICAgICAgICAgICAgdmFyIHR5cGVkID0gbmV3IFVpbnQ4QXJyYXkocGFja2V0LmRhdGEpO1xuICAgICAgICAgICAgICB2YXIgYmFzaWMgPSBuZXcgQXJyYXkodHlwZWQubGVuZ3RoKTtcbiAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0eXBlZC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIGJhc2ljW2ldID0gdHlwZWRbaV07XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgYjY0ZGF0YSA9IFN0cmluZy5mcm9tQ2hhckNvZGUuYXBwbHkobnVsbCwgYmFzaWMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbWVzc2FnZSArPSBnbG9iYWwuYnRvYShiNjRkYXRhKTtcbiAgICAgICAgICAgIHJldHVybiBjYWxsYmFjayhtZXNzYWdlKTtcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogRGVjb2RlcyBhIHBhY2tldC4gQ2hhbmdlcyBmb3JtYXQgdG8gQmxvYiBpZiByZXF1ZXN0ZWQuXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAcmV0dXJuIHtPYmplY3R9IHdpdGggYHR5cGVgIGFuZCBgZGF0YWAgKGlmIGFueSlcbiAgICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIGV4cG9ydHMuZGVjb2RlUGFja2V0ID0gZnVuY3Rpb24gKGRhdGEsIGJpbmFyeVR5cGUsIHV0ZjhkZWNvZGUpIHtcbiAgICAgICAgICAgIC8vIFN0cmluZyBkYXRhXG4gICAgICAgICAgICBpZiAodHlwZW9mIGRhdGEgPT0gJ3N0cmluZycgfHwgZGF0YSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgIGlmIChkYXRhLmNoYXJBdCgwKSA9PSAnYicpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZXhwb3J0cy5kZWNvZGVCYXNlNjRQYWNrZXQoZGF0YS5zdWJzdHIoMSksIGJpbmFyeVR5cGUpO1xuICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgaWYgKHV0ZjhkZWNvZGUpIHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgZGF0YSA9IHV0ZjguZGVjb2RlKGRhdGEpO1xuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBlcnI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHZhciB0eXBlID0gZGF0YS5jaGFyQXQoMCk7XG5cbiAgICAgICAgICAgICAgaWYgKE51bWJlcih0eXBlKSAhPSB0eXBlIHx8ICFwYWNrZXRzbGlzdFt0eXBlXSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBlcnI7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICBpZiAoZGF0YS5sZW5ndGggPiAxKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHsgdHlwZTogcGFja2V0c2xpc3RbdHlwZV0sIGRhdGE6IGRhdGEuc3Vic3RyaW5nKDEpIH07XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHsgdHlwZTogcGFja2V0c2xpc3RbdHlwZV0gfTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB2YXIgYXNBcnJheSA9IG5ldyBVaW50OEFycmF5KGRhdGEpO1xuICAgICAgICAgICAgdmFyIHR5cGUgPSBhc0FycmF5WzBdO1xuICAgICAgICAgICAgdmFyIHJlc3QgPSBzbGljZUJ1ZmZlcihkYXRhLCAxKTtcbiAgICAgICAgICAgIGlmIChCbG9iICYmIGJpbmFyeVR5cGUgPT09ICdibG9iJykge1xuICAgICAgICAgICAgICByZXN0ID0gbmV3IEJsb2IoW3Jlc3RdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB7IHR5cGU6IHBhY2tldHNsaXN0W3R5cGVdLCBkYXRhOiByZXN0IH07XG4gICAgICAgICAgfTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIERlY29kZXMgYSBwYWNrZXQgZW5jb2RlZCBpbiBhIGJhc2U2NCBzdHJpbmdcbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBwYXJhbSB7U3RyaW5nfSBiYXNlNjQgZW5jb2RlZCBtZXNzYWdlXG4gICAgICAgICAgICogQHJldHVybiB7T2JqZWN0fSB3aXRoIGB0eXBlYCBhbmQgYGRhdGFgIChpZiBhbnkpXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBleHBvcnRzLmRlY29kZUJhc2U2NFBhY2tldCA9IGZ1bmN0aW9uIChtc2csIGJpbmFyeVR5cGUpIHtcbiAgICAgICAgICAgIHZhciB0eXBlID0gcGFja2V0c2xpc3RbbXNnLmNoYXJBdCgwKV07XG4gICAgICAgICAgICBpZiAoIWdsb2JhbC5BcnJheUJ1ZmZlcikge1xuICAgICAgICAgICAgICByZXR1cm4geyB0eXBlOiB0eXBlLCBkYXRhOiB7IGJhc2U2NDogdHJ1ZSwgZGF0YTogbXNnLnN1YnN0cigxKSB9IH07XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHZhciBkYXRhID0gYmFzZTY0ZW5jb2Rlci5kZWNvZGUobXNnLnN1YnN0cigxKSk7XG5cbiAgICAgICAgICAgIGlmIChiaW5hcnlUeXBlID09PSAnYmxvYicgJiYgQmxvYikge1xuICAgICAgICAgICAgICBkYXRhID0gbmV3IEJsb2IoW2RhdGFdKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIHsgdHlwZTogdHlwZSwgZGF0YTogZGF0YSB9O1xuICAgICAgICAgIH07XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBFbmNvZGVzIG11bHRpcGxlIG1lc3NhZ2VzIChwYXlsb2FkKS5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqICAgICA8bGVuZ3RoPjpkYXRhXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBFeGFtcGxlOlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogICAgIDExOmhlbGxvIHdvcmxkMjpoaVxuICAgICAgICAgICAqXG4gICAgICAgICAgICogSWYgYW55IGNvbnRlbnRzIGFyZSBiaW5hcnksIHRoZXkgd2lsbCBiZSBlbmNvZGVkIGFzIGJhc2U2NCBzdHJpbmdzLiBCYXNlNjRcbiAgICAgICAgICAgKiBlbmNvZGVkIHN0cmluZ3MgYXJlIG1hcmtlZCB3aXRoIGEgYiBiZWZvcmUgdGhlIGxlbmd0aCBzcGVjaWZpZXJcbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBwYXJhbSB7QXJyYXl9IHBhY2tldHNcbiAgICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIGV4cG9ydHMuZW5jb2RlUGF5bG9hZCA9IGZ1bmN0aW9uIChwYWNrZXRzLCBzdXBwb3J0c0JpbmFyeSwgY2FsbGJhY2spIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2Ygc3VwcG9ydHNCaW5hcnkgPT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICBjYWxsYmFjayA9IHN1cHBvcnRzQmluYXJ5O1xuICAgICAgICAgICAgICBzdXBwb3J0c0JpbmFyeSA9IG51bGw7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHZhciBpc0JpbmFyeSA9IGhhc0JpbmFyeShwYWNrZXRzKTtcblxuICAgICAgICAgICAgaWYgKHN1cHBvcnRzQmluYXJ5ICYmIGlzQmluYXJ5KSB7XG4gICAgICAgICAgICAgIGlmIChCbG9iICYmICFkb250U2VuZEJsb2JzKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGV4cG9ydHMuZW5jb2RlUGF5bG9hZEFzQmxvYihwYWNrZXRzLCBjYWxsYmFjayk7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICByZXR1cm4gZXhwb3J0cy5lbmNvZGVQYXlsb2FkQXNBcnJheUJ1ZmZlcihwYWNrZXRzLCBjYWxsYmFjayk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmICghcGFja2V0cy5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGNhbGxiYWNrKCcwOicpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBmdW5jdGlvbiBzZXRMZW5ndGhIZWFkZXIobWVzc2FnZSkge1xuICAgICAgICAgICAgICByZXR1cm4gbWVzc2FnZS5sZW5ndGggKyAnOicgKyBtZXNzYWdlO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBmdW5jdGlvbiBlbmNvZGVPbmUocGFja2V0LCBkb25lQ2FsbGJhY2spIHtcbiAgICAgICAgICAgICAgZXhwb3J0cy5lbmNvZGVQYWNrZXQocGFja2V0LCAhaXNCaW5hcnkgPyBmYWxzZSA6IHN1cHBvcnRzQmluYXJ5LCB0cnVlLCBmdW5jdGlvbiAobWVzc2FnZSkge1xuICAgICAgICAgICAgICAgIGRvbmVDYWxsYmFjayhudWxsLCBzZXRMZW5ndGhIZWFkZXIobWVzc2FnZSkpO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgbWFwKHBhY2tldHMsIGVuY29kZU9uZSwgZnVuY3Rpb24gKGVyciwgcmVzdWx0cykge1xuICAgICAgICAgICAgICByZXR1cm4gY2FsbGJhY2socmVzdWx0cy5qb2luKCcnKSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogQXN5bmMgYXJyYXkgbWFwIHVzaW5nIGFmdGVyXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBmdW5jdGlvbiBtYXAoYXJ5LCBlYWNoLCBkb25lKSB7XG4gICAgICAgICAgICB2YXIgcmVzdWx0ID0gbmV3IEFycmF5KGFyeS5sZW5ndGgpO1xuICAgICAgICAgICAgdmFyIG5leHQgPSBhZnRlcihhcnkubGVuZ3RoLCBkb25lKTtcblxuICAgICAgICAgICAgdmFyIGVhY2hXaXRoSW5kZXggPSBmdW5jdGlvbiBlYWNoV2l0aEluZGV4KGksIGVsLCBjYikge1xuICAgICAgICAgICAgICBlYWNoKGVsLCBmdW5jdGlvbiAoZXJyb3IsIG1zZykge1xuICAgICAgICAgICAgICAgIHJlc3VsdFtpXSA9IG1zZztcbiAgICAgICAgICAgICAgICBjYihlcnJvciwgcmVzdWx0KTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFyeS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICBlYWNoV2l0aEluZGV4KGksIGFyeVtpXSwgbmV4dCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLypcbiAgICAgICAgICAgKiBEZWNvZGVzIGRhdGEgd2hlbiBhIHBheWxvYWQgaXMgbWF5YmUgZXhwZWN0ZWQuIFBvc3NpYmxlIGJpbmFyeSBjb250ZW50cyBhcmVcbiAgICAgICAgICAgKiBkZWNvZGVkIGZyb20gdGhlaXIgYmFzZTY0IHJlcHJlc2VudGF0aW9uXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAcGFyYW0ge1N0cmluZ30gZGF0YSwgY2FsbGJhY2sgbWV0aG9kXG4gICAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIGV4cG9ydHMuZGVjb2RlUGF5bG9hZCA9IGZ1bmN0aW9uIChkYXRhLCBiaW5hcnlUeXBlLCBjYWxsYmFjaykge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBkYXRhICE9ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICAgIHJldHVybiBleHBvcnRzLmRlY29kZVBheWxvYWRBc0JpbmFyeShkYXRhLCBiaW5hcnlUeXBlLCBjYWxsYmFjayk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmICh0eXBlb2YgYmluYXJ5VHlwZSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICBjYWxsYmFjayA9IGJpbmFyeVR5cGU7XG4gICAgICAgICAgICAgIGJpbmFyeVR5cGUgPSBudWxsO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB2YXIgcGFja2V0O1xuICAgICAgICAgICAgaWYgKGRhdGEgPT0gJycpIHtcbiAgICAgICAgICAgICAgLy8gcGFyc2VyIGVycm9yIC0gaWdub3JpbmcgcGF5bG9hZFxuICAgICAgICAgICAgICByZXR1cm4gY2FsbGJhY2soZXJyLCAwLCAxKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdmFyIGxlbmd0aCA9ICcnLFxuICAgICAgICAgICAgICAgIG4sXG4gICAgICAgICAgICAgICAgbXNnO1xuXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMCwgbCA9IGRhdGEubGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG4gICAgICAgICAgICAgIHZhciBjaHIgPSBkYXRhLmNoYXJBdChpKTtcblxuICAgICAgICAgICAgICBpZiAoJzonICE9IGNocikge1xuICAgICAgICAgICAgICAgIGxlbmd0aCArPSBjaHI7XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgaWYgKCcnID09IGxlbmd0aCB8fCBsZW5ndGggIT0gKG4gPSBOdW1iZXIobGVuZ3RoKSkpIHtcbiAgICAgICAgICAgICAgICAgIC8vIHBhcnNlciBlcnJvciAtIGlnbm9yaW5nIHBheWxvYWRcbiAgICAgICAgICAgICAgICAgIHJldHVybiBjYWxsYmFjayhlcnIsIDAsIDEpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIG1zZyA9IGRhdGEuc3Vic3RyKGkgKyAxLCBuKTtcblxuICAgICAgICAgICAgICAgIGlmIChsZW5ndGggIT0gbXNnLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgICAgLy8gcGFyc2VyIGVycm9yIC0gaWdub3JpbmcgcGF5bG9hZFxuICAgICAgICAgICAgICAgICAgcmV0dXJuIGNhbGxiYWNrKGVyciwgMCwgMSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgaWYgKG1zZy5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgIHBhY2tldCA9IGV4cG9ydHMuZGVjb2RlUGFja2V0KG1zZywgYmluYXJ5VHlwZSwgdHJ1ZSk7XG5cbiAgICAgICAgICAgICAgICAgIGlmIChlcnIudHlwZSA9PSBwYWNrZXQudHlwZSAmJiBlcnIuZGF0YSA9PSBwYWNrZXQuZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICAvLyBwYXJzZXIgZXJyb3IgaW4gaW5kaXZpZHVhbCBwYWNrZXQgLSBpZ25vcmluZyBwYXlsb2FkXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBjYWxsYmFjayhlcnIsIDAsIDEpO1xuICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICB2YXIgcmV0ID0gY2FsbGJhY2socGFja2V0LCBpICsgbiwgbCk7XG4gICAgICAgICAgICAgICAgICBpZiAoZmFsc2UgPT09IHJldCkgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vIGFkdmFuY2UgY3Vyc29yXG4gICAgICAgICAgICAgICAgaSArPSBuO1xuICAgICAgICAgICAgICAgIGxlbmd0aCA9ICcnO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChsZW5ndGggIT0gJycpIHtcbiAgICAgICAgICAgICAgLy8gcGFyc2VyIGVycm9yIC0gaWdub3JpbmcgcGF5bG9hZFxuICAgICAgICAgICAgICByZXR1cm4gY2FsbGJhY2soZXJyLCAwLCAxKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogRW5jb2RlcyBtdWx0aXBsZSBtZXNzYWdlcyAocGF5bG9hZCkgYXMgYmluYXJ5LlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogPDEgPSBiaW5hcnksIDAgPSBzdHJpbmc+PG51bWJlciBmcm9tIDAtOT48bnVtYmVyIGZyb20gMC05PlsuLi5dPG51bWJlclxuICAgICAgICAgICAqIDI1NT48ZGF0YT5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEV4YW1wbGU6XG4gICAgICAgICAgICogMSAzIDI1NSAxIDIgMywgaWYgdGhlIGJpbmFyeSBjb250ZW50cyBhcmUgaW50ZXJwcmV0ZWQgYXMgOCBiaXQgaW50ZWdlcnNcbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBwYXJhbSB7QXJyYXl9IHBhY2tldHNcbiAgICAgICAgICAgKiBAcmV0dXJuIHtBcnJheUJ1ZmZlcn0gZW5jb2RlZCBwYXlsb2FkXG4gICAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBleHBvcnRzLmVuY29kZVBheWxvYWRBc0FycmF5QnVmZmVyID0gZnVuY3Rpb24gKHBhY2tldHMsIGNhbGxiYWNrKSB7XG4gICAgICAgICAgICBpZiAoIXBhY2tldHMubGVuZ3RoKSB7XG4gICAgICAgICAgICAgIHJldHVybiBjYWxsYmFjayhuZXcgQXJyYXlCdWZmZXIoMCkpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBmdW5jdGlvbiBlbmNvZGVPbmUocGFja2V0LCBkb25lQ2FsbGJhY2spIHtcbiAgICAgICAgICAgICAgZXhwb3J0cy5lbmNvZGVQYWNrZXQocGFja2V0LCB0cnVlLCB0cnVlLCBmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBkb25lQ2FsbGJhY2sobnVsbCwgZGF0YSk7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBtYXAocGFja2V0cywgZW5jb2RlT25lLCBmdW5jdGlvbiAoZXJyLCBlbmNvZGVkUGFja2V0cykge1xuICAgICAgICAgICAgICB2YXIgdG90YWxMZW5ndGggPSBlbmNvZGVkUGFja2V0cy5yZWR1Y2UoZnVuY3Rpb24gKGFjYywgcCkge1xuICAgICAgICAgICAgICAgIHZhciBsZW47XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBwID09PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgICAgICAgbGVuID0gcC5sZW5ndGg7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIGxlbiA9IHAuYnl0ZUxlbmd0aDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIGFjYyArIGxlbi50b1N0cmluZygpLmxlbmd0aCArIGxlbiArIDI7IC8vIHN0cmluZy9iaW5hcnkgaWRlbnRpZmllciArIHNlcGFyYXRvciA9IDJcbiAgICAgICAgICAgICAgfSwgMCk7XG5cbiAgICAgICAgICAgICAgdmFyIHJlc3VsdEFycmF5ID0gbmV3IFVpbnQ4QXJyYXkodG90YWxMZW5ndGgpO1xuXG4gICAgICAgICAgICAgIHZhciBidWZmZXJJbmRleCA9IDA7XG4gICAgICAgICAgICAgIGVuY29kZWRQYWNrZXRzLmZvckVhY2goZnVuY3Rpb24gKHApIHtcbiAgICAgICAgICAgICAgICB2YXIgaXNTdHJpbmcgPSB0eXBlb2YgcCA9PT0gJ3N0cmluZyc7XG4gICAgICAgICAgICAgICAgdmFyIGFiID0gcDtcbiAgICAgICAgICAgICAgICBpZiAoaXNTdHJpbmcpIHtcbiAgICAgICAgICAgICAgICAgIHZhciB2aWV3ID0gbmV3IFVpbnQ4QXJyYXkocC5sZW5ndGgpO1xuICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBwLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgIHZpZXdbaV0gPSBwLmNoYXJDb2RlQXQoaSk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBhYiA9IHZpZXcuYnVmZmVyO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmIChpc1N0cmluZykge1xuICAgICAgICAgICAgICAgICAgLy8gbm90IHRydWUgYmluYXJ5XG4gICAgICAgICAgICAgICAgICByZXN1bHRBcnJheVtidWZmZXJJbmRleCsrXSA9IDA7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIC8vIHRydWUgYmluYXJ5XG4gICAgICAgICAgICAgICAgICByZXN1bHRBcnJheVtidWZmZXJJbmRleCsrXSA9IDE7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgdmFyIGxlblN0ciA9IGFiLmJ5dGVMZW5ndGgudG9TdHJpbmcoKTtcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxlblN0ci5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgcmVzdWx0QXJyYXlbYnVmZmVySW5kZXgrK10gPSBwYXJzZUludChsZW5TdHJbaV0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXN1bHRBcnJheVtidWZmZXJJbmRleCsrXSA9IDI1NTtcblxuICAgICAgICAgICAgICAgIHZhciB2aWV3ID0gbmV3IFVpbnQ4QXJyYXkoYWIpO1xuICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdmlldy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgcmVzdWx0QXJyYXlbYnVmZmVySW5kZXgrK10gPSB2aWV3W2ldO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgcmV0dXJuIGNhbGxiYWNrKHJlc3VsdEFycmF5LmJ1ZmZlcik7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogRW5jb2RlIGFzIEJsb2JcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIGV4cG9ydHMuZW5jb2RlUGF5bG9hZEFzQmxvYiA9IGZ1bmN0aW9uIChwYWNrZXRzLCBjYWxsYmFjaykge1xuICAgICAgICAgICAgZnVuY3Rpb24gZW5jb2RlT25lKHBhY2tldCwgZG9uZUNhbGxiYWNrKSB7XG4gICAgICAgICAgICAgIGV4cG9ydHMuZW5jb2RlUGFja2V0KHBhY2tldCwgdHJ1ZSwgdHJ1ZSwgZnVuY3Rpb24gKGVuY29kZWQpIHtcbiAgICAgICAgICAgICAgICB2YXIgYmluYXJ5SWRlbnRpZmllciA9IG5ldyBVaW50OEFycmF5KDEpO1xuICAgICAgICAgICAgICAgIGJpbmFyeUlkZW50aWZpZXJbMF0gPSAxO1xuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgZW5jb2RlZCA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgICAgICAgIHZhciB2aWV3ID0gbmV3IFVpbnQ4QXJyYXkoZW5jb2RlZC5sZW5ndGgpO1xuICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBlbmNvZGVkLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgIHZpZXdbaV0gPSBlbmNvZGVkLmNoYXJDb2RlQXQoaSk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBlbmNvZGVkID0gdmlldy5idWZmZXI7XG4gICAgICAgICAgICAgICAgICBiaW5hcnlJZGVudGlmaWVyWzBdID0gMDtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB2YXIgbGVuID0gZW5jb2RlZCBpbnN0YW5jZW9mIEFycmF5QnVmZmVyID8gZW5jb2RlZC5ieXRlTGVuZ3RoIDogZW5jb2RlZC5zaXplO1xuXG4gICAgICAgICAgICAgICAgdmFyIGxlblN0ciA9IGxlbi50b1N0cmluZygpO1xuICAgICAgICAgICAgICAgIHZhciBsZW5ndGhBcnkgPSBuZXcgVWludDhBcnJheShsZW5TdHIubGVuZ3RoICsgMSk7XG4gICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW5TdHIubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgIGxlbmd0aEFyeVtpXSA9IHBhcnNlSW50KGxlblN0cltpXSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGxlbmd0aEFyeVtsZW5TdHIubGVuZ3RoXSA9IDI1NTtcblxuICAgICAgICAgICAgICAgIGlmIChCbG9iKSB7XG4gICAgICAgICAgICAgICAgICB2YXIgYmxvYiA9IG5ldyBCbG9iKFtiaW5hcnlJZGVudGlmaWVyLmJ1ZmZlciwgbGVuZ3RoQXJ5LmJ1ZmZlciwgZW5jb2RlZF0pO1xuICAgICAgICAgICAgICAgICAgZG9uZUNhbGxiYWNrKG51bGwsIGJsb2IpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIG1hcChwYWNrZXRzLCBlbmNvZGVPbmUsIGZ1bmN0aW9uIChlcnIsIHJlc3VsdHMpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGNhbGxiYWNrKG5ldyBCbG9iKHJlc3VsdHMpKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH07XG5cbiAgICAgICAgICAvKlxuICAgICAgICAgICAqIERlY29kZXMgZGF0YSB3aGVuIGEgcGF5bG9hZCBpcyBtYXliZSBleHBlY3RlZC4gU3RyaW5ncyBhcmUgZGVjb2RlZCBieVxuICAgICAgICAgICAqIGludGVycHJldGluZyBlYWNoIGJ5dGUgYXMgYSBrZXkgY29kZSBmb3IgZW50cmllcyBtYXJrZWQgdG8gc3RhcnQgd2l0aCAwLiBTZWVcbiAgICAgICAgICAgKiBkZXNjcmlwdGlvbiBvZiBlbmNvZGVQYXlsb2FkQXNCaW5hcnlcbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBwYXJhbSB7QXJyYXlCdWZmZXJ9IGRhdGEsIGNhbGxiYWNrIG1ldGhvZFxuICAgICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBleHBvcnRzLmRlY29kZVBheWxvYWRBc0JpbmFyeSA9IGZ1bmN0aW9uIChkYXRhLCBiaW5hcnlUeXBlLCBjYWxsYmFjaykge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBiaW5hcnlUeXBlID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgIGNhbGxiYWNrID0gYmluYXJ5VHlwZTtcbiAgICAgICAgICAgICAgYmluYXJ5VHlwZSA9IG51bGw7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHZhciBidWZmZXJUYWlsID0gZGF0YTtcbiAgICAgICAgICAgIHZhciBidWZmZXJzID0gW107XG5cbiAgICAgICAgICAgIHZhciBudW1iZXJUb29Mb25nID0gZmFsc2U7XG4gICAgICAgICAgICB3aGlsZSAoYnVmZmVyVGFpbC5ieXRlTGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICB2YXIgdGFpbEFycmF5ID0gbmV3IFVpbnQ4QXJyYXkoYnVmZmVyVGFpbCk7XG4gICAgICAgICAgICAgIHZhciBpc1N0cmluZyA9IHRhaWxBcnJheVswXSA9PT0gMDtcbiAgICAgICAgICAgICAgdmFyIG1zZ0xlbmd0aCA9ICcnO1xuXG4gICAgICAgICAgICAgIGZvciAodmFyIGkgPSAxOzsgaSsrKSB7XG4gICAgICAgICAgICAgICAgaWYgKHRhaWxBcnJheVtpXSA9PSAyNTUpIGJyZWFrO1xuXG4gICAgICAgICAgICAgICAgaWYgKG1zZ0xlbmd0aC5sZW5ndGggPiAzMTApIHtcbiAgICAgICAgICAgICAgICAgIG51bWJlclRvb0xvbmcgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgbXNnTGVuZ3RoICs9IHRhaWxBcnJheVtpXTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIGlmIChudW1iZXJUb29Mb25nKSByZXR1cm4gY2FsbGJhY2soZXJyLCAwLCAxKTtcblxuICAgICAgICAgICAgICBidWZmZXJUYWlsID0gc2xpY2VCdWZmZXIoYnVmZmVyVGFpbCwgMiArIG1zZ0xlbmd0aC5sZW5ndGgpO1xuICAgICAgICAgICAgICBtc2dMZW5ndGggPSBwYXJzZUludChtc2dMZW5ndGgpO1xuXG4gICAgICAgICAgICAgIHZhciBtc2cgPSBzbGljZUJ1ZmZlcihidWZmZXJUYWlsLCAwLCBtc2dMZW5ndGgpO1xuICAgICAgICAgICAgICBpZiAoaXNTdHJpbmcpIHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgbXNnID0gU3RyaW5nLmZyb21DaGFyQ29kZS5hcHBseShudWxsLCBuZXcgVWludDhBcnJheShtc2cpKTtcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAvLyBpUGhvbmUgU2FmYXJpIGRvZXNuJ3QgbGV0IHlvdSBhcHBseSB0byB0eXBlZCBhcnJheXNcbiAgICAgICAgICAgICAgICAgIHZhciB0eXBlZCA9IG5ldyBVaW50OEFycmF5KG1zZyk7XG4gICAgICAgICAgICAgICAgICBtc2cgPSAnJztcbiAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdHlwZWQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgbXNnICs9IFN0cmluZy5mcm9tQ2hhckNvZGUodHlwZWRbaV0pO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIGJ1ZmZlcnMucHVzaChtc2cpO1xuICAgICAgICAgICAgICBidWZmZXJUYWlsID0gc2xpY2VCdWZmZXIoYnVmZmVyVGFpbCwgbXNnTGVuZ3RoKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdmFyIHRvdGFsID0gYnVmZmVycy5sZW5ndGg7XG4gICAgICAgICAgICBidWZmZXJzLmZvckVhY2goZnVuY3Rpb24gKGJ1ZmZlciwgaSkge1xuICAgICAgICAgICAgICBjYWxsYmFjayhleHBvcnRzLmRlY29kZVBhY2tldChidWZmZXIsIGJpbmFyeVR5cGUsIHRydWUpLCBpLCB0b3RhbCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9O1xuICAgICAgICB9KS5jYWxsKHRoaXMsIHR5cGVvZiBzZWxmICE9PSBcInVuZGVmaW5lZFwiID8gc2VsZiA6IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgPyB3aW5kb3cgOiB0eXBlb2YgZ2xvYmFsICE9PSBcInVuZGVmaW5lZFwiID8gZ2xvYmFsIDoge30pO1xuICAgICAgfSwgeyBcIi4va2V5c1wiOiAyMCwgXCJhZnRlclwiOiAxMSwgXCJhcnJheWJ1ZmZlci5zbGljZVwiOiAxMiwgXCJiYXNlNjQtYXJyYXlidWZmZXJcIjogMTMsIFwiYmxvYlwiOiAxNCwgXCJoYXMtYmluYXJ5XCI6IDIxLCBcInV0ZjhcIjogMjkgfV0sIDIwOiBbZnVuY3Rpb24gKF9kZXJlcV8sIG1vZHVsZSwgZXhwb3J0cykge1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBHZXRzIHRoZSBrZXlzIGZvciBhbiBvYmplY3QuXG4gICAgICAgICAqXG4gICAgICAgICAqIEByZXR1cm4ge0FycmF5fSBrZXlzXG4gICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgKi9cblxuICAgICAgICBtb2R1bGUuZXhwb3J0cyA9IE9iamVjdC5rZXlzIHx8IGZ1bmN0aW9uIGtleXMob2JqKSB7XG4gICAgICAgICAgdmFyIGFyciA9IFtdO1xuICAgICAgICAgIHZhciBoYXMgPSBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5O1xuXG4gICAgICAgICAgZm9yICh2YXIgaSBpbiBvYmopIHtcbiAgICAgICAgICAgIGlmIChoYXMuY2FsbChvYmosIGkpKSB7XG4gICAgICAgICAgICAgIGFyci5wdXNoKGkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gYXJyO1xuICAgICAgICB9O1xuICAgICAgfSwge31dLCAyMTogW2Z1bmN0aW9uIChfZGVyZXFfLCBtb2R1bGUsIGV4cG9ydHMpIHtcbiAgICAgICAgKGZ1bmN0aW9uIChnbG9iYWwpIHtcblxuICAgICAgICAgIC8qXG4gICAgICAgICAgICogTW9kdWxlIHJlcXVpcmVtZW50cy5cbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIHZhciBpc0FycmF5ID0gX2RlcmVxXygnaXNhcnJheScpO1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogTW9kdWxlIGV4cG9ydHMuXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBtb2R1bGUuZXhwb3J0cyA9IGhhc0JpbmFyeTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIENoZWNrcyBmb3IgYmluYXJ5IGRhdGEuXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBSaWdodCBub3cgb25seSBCdWZmZXIgYW5kIEFycmF5QnVmZmVyIGFyZSBzdXBwb3J0ZWQuLlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogQHBhcmFtIHtPYmplY3R9IGFueXRoaW5nXG4gICAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIGZ1bmN0aW9uIGhhc0JpbmFyeShkYXRhKSB7XG5cbiAgICAgICAgICAgIGZ1bmN0aW9uIF9oYXNCaW5hcnkob2JqKSB7XG4gICAgICAgICAgICAgIGlmICghb2JqKSByZXR1cm4gZmFsc2U7XG5cbiAgICAgICAgICAgICAgaWYgKGdsb2JhbC5CdWZmZXIgJiYgZ2xvYmFsLkJ1ZmZlci5pc0J1ZmZlcihvYmopIHx8IGdsb2JhbC5BcnJheUJ1ZmZlciAmJiBvYmogaW5zdGFuY2VvZiBBcnJheUJ1ZmZlciB8fCBnbG9iYWwuQmxvYiAmJiBvYmogaW5zdGFuY2VvZiBCbG9iIHx8IGdsb2JhbC5GaWxlICYmIG9iaiBpbnN0YW5jZW9mIEZpbGUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIGlmIChpc0FycmF5KG9iaikpIHtcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IG9iai5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgaWYgKF9oYXNCaW5hcnkob2JqW2ldKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0gZWxzZSBpZiAob2JqICYmICdvYmplY3QnID09IHR5cGVvZiBvYmopIHtcbiAgICAgICAgICAgICAgICBpZiAob2JqLnRvSlNPTikge1xuICAgICAgICAgICAgICAgICAgb2JqID0gb2JqLnRvSlNPTigpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGZvciAodmFyIGtleSBpbiBvYmopIHtcbiAgICAgICAgICAgICAgICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBrZXkpICYmIF9oYXNCaW5hcnkob2JqW2tleV0pKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIF9oYXNCaW5hcnkoZGF0YSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KS5jYWxsKHRoaXMsIHR5cGVvZiBzZWxmICE9PSBcInVuZGVmaW5lZFwiID8gc2VsZiA6IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgPyB3aW5kb3cgOiB0eXBlb2YgZ2xvYmFsICE9PSBcInVuZGVmaW5lZFwiID8gZ2xvYmFsIDoge30pO1xuICAgICAgfSwgeyBcImlzYXJyYXlcIjogMjQgfV0sIDIyOiBbZnVuY3Rpb24gKF9kZXJlcV8sIG1vZHVsZSwgZXhwb3J0cykge1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBNb2R1bGUgZXhwb3J0cy5cbiAgICAgICAgICpcbiAgICAgICAgICogTG9naWMgYm9ycm93ZWQgZnJvbSBNb2Rlcm5penI6XG4gICAgICAgICAqXG4gICAgICAgICAqICAgLSBodHRwczovL2dpdGh1Yi5jb20vTW9kZXJuaXpyL01vZGVybml6ci9ibG9iL21hc3Rlci9mZWF0dXJlLWRldGVjdHMvY29ycy5qc1xuICAgICAgICAgKi9cblxuICAgICAgICB0cnkge1xuICAgICAgICAgIG1vZHVsZS5leHBvcnRzID0gdHlwZW9mIFhNTEh0dHBSZXF1ZXN0ICE9PSAndW5kZWZpbmVkJyAmJiAnd2l0aENyZWRlbnRpYWxzJyBpbiBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgLy8gaWYgWE1MSHR0cCBzdXBwb3J0IGlzIGRpc2FibGVkIGluIElFIHRoZW4gaXQgd2lsbCB0aHJvd1xuICAgICAgICAgIC8vIHdoZW4gdHJ5aW5nIHRvIGNyZWF0ZVxuICAgICAgICAgIG1vZHVsZS5leHBvcnRzID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgIH0sIHt9XSwgMjM6IFtmdW5jdGlvbiAoX2RlcmVxXywgbW9kdWxlLCBleHBvcnRzKSB7XG5cbiAgICAgICAgdmFyIGluZGV4T2YgPSBbXS5pbmRleE9mO1xuXG4gICAgICAgIG1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGFyciwgb2JqKSB7XG4gICAgICAgICAgaWYgKGluZGV4T2YpIHJldHVybiBhcnIuaW5kZXhPZihvYmopO1xuICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYXJyLmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICBpZiAoYXJyW2ldID09PSBvYmopIHJldHVybiBpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gLTE7XG4gICAgICAgIH07XG4gICAgICB9LCB7fV0sIDI0OiBbZnVuY3Rpb24gKF9kZXJlcV8sIG1vZHVsZSwgZXhwb3J0cykge1xuICAgICAgICBtb2R1bGUuZXhwb3J0cyA9IEFycmF5LmlzQXJyYXkgfHwgZnVuY3Rpb24gKGFycikge1xuICAgICAgICAgIHJldHVybiBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwoYXJyKSA9PSAnW29iamVjdCBBcnJheV0nO1xuICAgICAgICB9O1xuICAgICAgfSwge31dLCAyNTogW2Z1bmN0aW9uIChfZGVyZXFfLCBtb2R1bGUsIGV4cG9ydHMpIHtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIEhlbHBlcnMuXG4gICAgICAgICAqL1xuXG4gICAgICAgIHZhciBzID0gMTAwMDtcbiAgICAgICAgdmFyIG0gPSBzICogNjA7XG4gICAgICAgIHZhciBoID0gbSAqIDYwO1xuICAgICAgICB2YXIgZCA9IGggKiAyNDtcbiAgICAgICAgdmFyIHkgPSBkICogMzY1LjI1O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBQYXJzZSBvciBmb3JtYXQgdGhlIGdpdmVuIGB2YWxgLlxuICAgICAgICAgKlxuICAgICAgICAgKiBPcHRpb25zOlxuICAgICAgICAgKlxuICAgICAgICAgKiAgLSBgbG9uZ2AgdmVyYm9zZSBmb3JtYXR0aW5nIFtmYWxzZV1cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtTdHJpbmd8TnVtYmVyfSB2YWxcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnNcbiAgICAgICAgICogQHJldHVybiB7U3RyaW5nfE51bWJlcn1cbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgbW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAodmFsLCBvcHRpb25zKSB7XG4gICAgICAgICAgb3B0aW9ucyA9IG9wdGlvbnMgfHwge307XG4gICAgICAgICAgaWYgKCdzdHJpbmcnID09IHR5cGVvZiB2YWwpIHJldHVybiBwYXJzZSh2YWwpO1xuICAgICAgICAgIHJldHVybiBvcHRpb25zLmxvbmcgPyBsb25nKHZhbCkgOiBzaG9ydCh2YWwpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBQYXJzZSB0aGUgZ2l2ZW4gYHN0cmAgYW5kIHJldHVybiBtaWxsaXNlY29uZHMuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7U3RyaW5nfSBzdHJcbiAgICAgICAgICogQHJldHVybiB7TnVtYmVyfVxuICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICovXG5cbiAgICAgICAgZnVuY3Rpb24gcGFyc2Uoc3RyKSB7XG4gICAgICAgICAgc3RyID0gJycgKyBzdHI7XG4gICAgICAgICAgaWYgKHN0ci5sZW5ndGggPiAxMDAwMCkgcmV0dXJuO1xuICAgICAgICAgIHZhciBtYXRjaCA9IC9eKCg/OlxcZCspP1xcLj9cXGQrKSAqKG1pbGxpc2Vjb25kcz98bXNlY3M/fG1zfHNlY29uZHM/fHNlY3M/fHN8bWludXRlcz98bWlucz98bXxob3Vycz98aHJzP3xofGRheXM/fGR8eWVhcnM/fHlycz98eSk/JC9pLmV4ZWMoc3RyKTtcbiAgICAgICAgICBpZiAoIW1hdGNoKSByZXR1cm47XG4gICAgICAgICAgdmFyIG4gPSBwYXJzZUZsb2F0KG1hdGNoWzFdKTtcbiAgICAgICAgICB2YXIgdHlwZSA9IChtYXRjaFsyXSB8fCAnbXMnKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICAgIHN3aXRjaCAodHlwZSkge1xuICAgICAgICAgICAgY2FzZSAneWVhcnMnOlxuICAgICAgICAgICAgY2FzZSAneWVhcic6XG4gICAgICAgICAgICBjYXNlICd5cnMnOlxuICAgICAgICAgICAgY2FzZSAneXInOlxuICAgICAgICAgICAgY2FzZSAneSc6XG4gICAgICAgICAgICAgIHJldHVybiBuICogeTtcbiAgICAgICAgICAgIGNhc2UgJ2RheXMnOlxuICAgICAgICAgICAgY2FzZSAnZGF5JzpcbiAgICAgICAgICAgIGNhc2UgJ2QnOlxuICAgICAgICAgICAgICByZXR1cm4gbiAqIGQ7XG4gICAgICAgICAgICBjYXNlICdob3Vycyc6XG4gICAgICAgICAgICBjYXNlICdob3VyJzpcbiAgICAgICAgICAgIGNhc2UgJ2hycyc6XG4gICAgICAgICAgICBjYXNlICdocic6XG4gICAgICAgICAgICBjYXNlICdoJzpcbiAgICAgICAgICAgICAgcmV0dXJuIG4gKiBoO1xuICAgICAgICAgICAgY2FzZSAnbWludXRlcyc6XG4gICAgICAgICAgICBjYXNlICdtaW51dGUnOlxuICAgICAgICAgICAgY2FzZSAnbWlucyc6XG4gICAgICAgICAgICBjYXNlICdtaW4nOlxuICAgICAgICAgICAgY2FzZSAnbSc6XG4gICAgICAgICAgICAgIHJldHVybiBuICogbTtcbiAgICAgICAgICAgIGNhc2UgJ3NlY29uZHMnOlxuICAgICAgICAgICAgY2FzZSAnc2Vjb25kJzpcbiAgICAgICAgICAgIGNhc2UgJ3NlY3MnOlxuICAgICAgICAgICAgY2FzZSAnc2VjJzpcbiAgICAgICAgICAgIGNhc2UgJ3MnOlxuICAgICAgICAgICAgICByZXR1cm4gbiAqIHM7XG4gICAgICAgICAgICBjYXNlICdtaWxsaXNlY29uZHMnOlxuICAgICAgICAgICAgY2FzZSAnbWlsbGlzZWNvbmQnOlxuICAgICAgICAgICAgY2FzZSAnbXNlY3MnOlxuICAgICAgICAgICAgY2FzZSAnbXNlYyc6XG4gICAgICAgICAgICBjYXNlICdtcyc6XG4gICAgICAgICAgICAgIHJldHVybiBuO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBTaG9ydCBmb3JtYXQgZm9yIGBtc2AuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7TnVtYmVyfSBtc1xuICAgICAgICAgKiBAcmV0dXJuIHtTdHJpbmd9XG4gICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgKi9cblxuICAgICAgICBmdW5jdGlvbiBzaG9ydChtcykge1xuICAgICAgICAgIGlmIChtcyA+PSBkKSByZXR1cm4gTWF0aC5yb3VuZChtcyAvIGQpICsgJ2QnO1xuICAgICAgICAgIGlmIChtcyA+PSBoKSByZXR1cm4gTWF0aC5yb3VuZChtcyAvIGgpICsgJ2gnO1xuICAgICAgICAgIGlmIChtcyA+PSBtKSByZXR1cm4gTWF0aC5yb3VuZChtcyAvIG0pICsgJ20nO1xuICAgICAgICAgIGlmIChtcyA+PSBzKSByZXR1cm4gTWF0aC5yb3VuZChtcyAvIHMpICsgJ3MnO1xuICAgICAgICAgIHJldHVybiBtcyArICdtcyc7XG4gICAgICAgIH1cblxuICAgICAgICAvKipcbiAgICAgICAgICogTG9uZyBmb3JtYXQgZm9yIGBtc2AuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7TnVtYmVyfSBtc1xuICAgICAgICAgKiBAcmV0dXJuIHtTdHJpbmd9XG4gICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgKi9cblxuICAgICAgICBmdW5jdGlvbiBsb25nKG1zKSB7XG4gICAgICAgICAgcmV0dXJuIHBsdXJhbChtcywgZCwgJ2RheScpIHx8IHBsdXJhbChtcywgaCwgJ2hvdXInKSB8fCBwbHVyYWwobXMsIG0sICdtaW51dGUnKSB8fCBwbHVyYWwobXMsIHMsICdzZWNvbmQnKSB8fCBtcyArICcgbXMnO1xuICAgICAgICB9XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFBsdXJhbGl6YXRpb24gaGVscGVyLlxuICAgICAgICAgKi9cblxuICAgICAgICBmdW5jdGlvbiBwbHVyYWwobXMsIG4sIG5hbWUpIHtcbiAgICAgICAgICBpZiAobXMgPCBuKSByZXR1cm47XG4gICAgICAgICAgaWYgKG1zIDwgbiAqIDEuNSkgcmV0dXJuIE1hdGguZmxvb3IobXMgLyBuKSArICcgJyArIG5hbWU7XG4gICAgICAgICAgcmV0dXJuIE1hdGguY2VpbChtcyAvIG4pICsgJyAnICsgbmFtZSArICdzJztcbiAgICAgICAgfVxuICAgICAgfSwge31dLCAyNjogW2Z1bmN0aW9uIChfZGVyZXFfLCBtb2R1bGUsIGV4cG9ydHMpIHtcbiAgICAgICAgKGZ1bmN0aW9uIChnbG9iYWwpIHtcbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBKU09OIHBhcnNlLlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogQHNlZSBCYXNlZCBvbiBqUXVlcnkjcGFyc2VKU09OIChNSVQpIGFuZCBKU09OMlxuICAgICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgdmFyIHJ2YWxpZGNoYXJzID0gL15bXFxdLDp7fVxcc10qJC87XG4gICAgICAgICAgdmFyIHJ2YWxpZGVzY2FwZSA9IC9cXFxcKD86W1wiXFxcXFxcL2JmbnJ0XXx1WzAtOWEtZkEtRl17NH0pL2c7XG4gICAgICAgICAgdmFyIHJ2YWxpZHRva2VucyA9IC9cIlteXCJcXFxcXFxuXFxyXSpcInx0cnVlfGZhbHNlfG51bGx8LT9cXGQrKD86XFwuXFxkKik/KD86W2VFXVsrXFwtXT9cXGQrKT8vZztcbiAgICAgICAgICB2YXIgcnZhbGlkYnJhY2VzID0gLyg/Ol58OnwsKSg/OlxccypcXFspKy9nO1xuICAgICAgICAgIHZhciBydHJpbUxlZnQgPSAvXlxccysvO1xuICAgICAgICAgIHZhciBydHJpbVJpZ2h0ID0gL1xccyskLztcblxuICAgICAgICAgIG1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gcGFyc2Vqc29uKGRhdGEpIHtcbiAgICAgICAgICAgIGlmICgnc3RyaW5nJyAhPSB0eXBlb2YgZGF0YSB8fCAhZGF0YSkge1xuICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgZGF0YSA9IGRhdGEucmVwbGFjZShydHJpbUxlZnQsICcnKS5yZXBsYWNlKHJ0cmltUmlnaHQsICcnKTtcblxuICAgICAgICAgICAgLy8gQXR0ZW1wdCB0byBwYXJzZSB1c2luZyB0aGUgbmF0aXZlIEpTT04gcGFyc2VyIGZpcnN0XG4gICAgICAgICAgICBpZiAoZ2xvYmFsLkpTT04gJiYgSlNPTi5wYXJzZSkge1xuICAgICAgICAgICAgICByZXR1cm4gSlNPTi5wYXJzZShkYXRhKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKHJ2YWxpZGNoYXJzLnRlc3QoZGF0YS5yZXBsYWNlKHJ2YWxpZGVzY2FwZSwgJ0AnKS5yZXBsYWNlKHJ2YWxpZHRva2VucywgJ10nKS5yZXBsYWNlKHJ2YWxpZGJyYWNlcywgJycpKSkge1xuICAgICAgICAgICAgICByZXR1cm4gbmV3IEZ1bmN0aW9uKCdyZXR1cm4gJyArIGRhdGEpKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfTtcbiAgICAgICAgfSkuY2FsbCh0aGlzLCB0eXBlb2Ygc2VsZiAhPT0gXCJ1bmRlZmluZWRcIiA/IHNlbGYgOiB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiID8gd2luZG93IDogdHlwZW9mIGdsb2JhbCAhPT0gXCJ1bmRlZmluZWRcIiA/IGdsb2JhbCA6IHt9KTtcbiAgICAgIH0sIHt9XSwgMjc6IFtmdW5jdGlvbiAoX2RlcmVxXywgbW9kdWxlLCBleHBvcnRzKSB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDb21waWxlcyBhIHF1ZXJ5c3RyaW5nXG4gICAgICAgICAqIFJldHVybnMgc3RyaW5nIHJlcHJlc2VudGF0aW9uIG9mIHRoZSBvYmplY3RcbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3R9XG4gICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgKi9cblxuICAgICAgICBleHBvcnRzLmVuY29kZSA9IGZ1bmN0aW9uIChvYmopIHtcbiAgICAgICAgICB2YXIgc3RyID0gJyc7XG5cbiAgICAgICAgICBmb3IgKHZhciBpIGluIG9iaikge1xuICAgICAgICAgICAgaWYgKG9iai5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgICAgICBpZiAoc3RyLmxlbmd0aCkgc3RyICs9ICcmJztcbiAgICAgICAgICAgICAgc3RyICs9IGVuY29kZVVSSUNvbXBvbmVudChpKSArICc9JyArIGVuY29kZVVSSUNvbXBvbmVudChvYmpbaV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cblxuICAgICAgICAgIHJldHVybiBzdHI7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFBhcnNlcyBhIHNpbXBsZSBxdWVyeXN0cmluZyBpbnRvIGFuIG9iamVjdFxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ge1N0cmluZ30gcXNcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIGV4cG9ydHMuZGVjb2RlID0gZnVuY3Rpb24gKHFzKSB7XG4gICAgICAgICAgdmFyIHFyeSA9IHt9O1xuICAgICAgICAgIHZhciBwYWlycyA9IHFzLnNwbGl0KCcmJyk7XG4gICAgICAgICAgZm9yICh2YXIgaSA9IDAsIGwgPSBwYWlycy5sZW5ndGg7IGkgPCBsOyBpKyspIHtcbiAgICAgICAgICAgIHZhciBwYWlyID0gcGFpcnNbaV0uc3BsaXQoJz0nKTtcbiAgICAgICAgICAgIHFyeVtkZWNvZGVVUklDb21wb25lbnQocGFpclswXSldID0gZGVjb2RlVVJJQ29tcG9uZW50KHBhaXJbMV0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gcXJ5O1xuICAgICAgICB9O1xuICAgICAgfSwge31dLCAyODogW2Z1bmN0aW9uIChfZGVyZXFfLCBtb2R1bGUsIGV4cG9ydHMpIHtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFBhcnNlcyBhbiBVUklcbiAgICAgICAgICpcbiAgICAgICAgICogQGF1dGhvciBTdGV2ZW4gTGV2aXRoYW4gPHN0ZXZlbmxldml0aGFuLmNvbT4gKE1JVCBsaWNlbnNlKVxuICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICovXG5cbiAgICAgICAgdmFyIHJlID0gL14oPzooPyFbXjpAXSs6W146QFxcL10qQCkoaHR0cHxodHRwc3x3c3x3c3MpOlxcL1xcLyk/KCg/OigoW146QF0qKSg/OjooW146QF0qKSk/KT9AKT8oKD86W2EtZjAtOV17MCw0fTopezIsN31bYS1mMC05XXswLDR9fFteOlxcLz8jXSopKD86OihcXGQqKSk/KSgoKFxcLyg/OltePyNdKD8hW14/I1xcL10qXFwuW14/I1xcLy5dKyg/Ols/I118JCkpKSpcXC8/KT8oW14/I1xcL10qKSkoPzpcXD8oW14jXSopKT8oPzojKC4qKSk/KS87XG5cbiAgICAgICAgdmFyIHBhcnRzID0gWydzb3VyY2UnLCAncHJvdG9jb2wnLCAnYXV0aG9yaXR5JywgJ3VzZXJJbmZvJywgJ3VzZXInLCAncGFzc3dvcmQnLCAnaG9zdCcsICdwb3J0JywgJ3JlbGF0aXZlJywgJ3BhdGgnLCAnZGlyZWN0b3J5JywgJ2ZpbGUnLCAncXVlcnknLCAnYW5jaG9yJ107XG5cbiAgICAgICAgbW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBwYXJzZXVyaShzdHIpIHtcbiAgICAgICAgICB2YXIgc3JjID0gc3RyLFxuICAgICAgICAgICAgICBiID0gc3RyLmluZGV4T2YoJ1snKSxcbiAgICAgICAgICAgICAgZSA9IHN0ci5pbmRleE9mKCddJyk7XG5cbiAgICAgICAgICBpZiAoYiAhPSAtMSAmJiBlICE9IC0xKSB7XG4gICAgICAgICAgICBzdHIgPSBzdHIuc3Vic3RyaW5nKDAsIGIpICsgc3RyLnN1YnN0cmluZyhiLCBlKS5yZXBsYWNlKC86L2csICc7JykgKyBzdHIuc3Vic3RyaW5nKGUsIHN0ci5sZW5ndGgpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHZhciBtID0gcmUuZXhlYyhzdHIgfHwgJycpLFxuICAgICAgICAgICAgICB1cmkgPSB7fSxcbiAgICAgICAgICAgICAgaSA9IDE0O1xuXG4gICAgICAgICAgd2hpbGUgKGktLSkge1xuICAgICAgICAgICAgdXJpW3BhcnRzW2ldXSA9IG1baV0gfHwgJyc7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKGIgIT0gLTEgJiYgZSAhPSAtMSkge1xuICAgICAgICAgICAgdXJpLnNvdXJjZSA9IHNyYztcbiAgICAgICAgICAgIHVyaS5ob3N0ID0gdXJpLmhvc3Quc3Vic3RyaW5nKDEsIHVyaS5ob3N0Lmxlbmd0aCAtIDEpLnJlcGxhY2UoLzsvZywgJzonKTtcbiAgICAgICAgICAgIHVyaS5hdXRob3JpdHkgPSB1cmkuYXV0aG9yaXR5LnJlcGxhY2UoJ1snLCAnJykucmVwbGFjZSgnXScsICcnKS5yZXBsYWNlKC87L2csICc6Jyk7XG4gICAgICAgICAgICB1cmkuaXB2NnVyaSA9IHRydWU7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgcmV0dXJuIHVyaTtcbiAgICAgICAgfTtcbiAgICAgIH0sIHt9XSwgMjk6IFtmdW5jdGlvbiAoX2RlcmVxXywgbW9kdWxlLCBleHBvcnRzKSB7XG4gICAgICAgIChmdW5jdGlvbiAoZ2xvYmFsKSB7XG4gICAgICAgICAgLyohIGh0dHBzOi8vbXRocy5iZS91dGY4anMgdjIuMC4wIGJ5IEBtYXRoaWFzICovXG4gICAgICAgICAgOyhmdW5jdGlvbiAocm9vdCkge1xuXG4gICAgICAgICAgICAvLyBEZXRlY3QgZnJlZSB2YXJpYWJsZXMgYGV4cG9ydHNgXG4gICAgICAgICAgICB2YXIgZnJlZUV4cG9ydHMgPSB0eXBlb2YgZXhwb3J0cyA9PSAnb2JqZWN0JyAmJiBleHBvcnRzO1xuXG4gICAgICAgICAgICAvLyBEZXRlY3QgZnJlZSB2YXJpYWJsZSBgbW9kdWxlYFxuICAgICAgICAgICAgdmFyIGZyZWVNb2R1bGUgPSB0eXBlb2YgbW9kdWxlID09ICdvYmplY3QnICYmIG1vZHVsZSAmJiBtb2R1bGUuZXhwb3J0cyA9PSBmcmVlRXhwb3J0cyAmJiBtb2R1bGU7XG5cbiAgICAgICAgICAgIC8vIERldGVjdCBmcmVlIHZhcmlhYmxlIGBnbG9iYWxgLCBmcm9tIE5vZGUuanMgb3IgQnJvd3NlcmlmaWVkIGNvZGUsXG4gICAgICAgICAgICAvLyBhbmQgdXNlIGl0IGFzIGByb290YFxuICAgICAgICAgICAgdmFyIGZyZWVHbG9iYWwgPSB0eXBlb2YgZ2xvYmFsID09ICdvYmplY3QnICYmIGdsb2JhbDtcbiAgICAgICAgICAgIGlmIChmcmVlR2xvYmFsLmdsb2JhbCA9PT0gZnJlZUdsb2JhbCB8fCBmcmVlR2xvYmFsLndpbmRvdyA9PT0gZnJlZUdsb2JhbCkge1xuICAgICAgICAgICAgICByb290ID0gZnJlZUdsb2JhbDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbiAgICAgICAgICAgIHZhciBzdHJpbmdGcm9tQ2hhckNvZGUgPSBTdHJpbmcuZnJvbUNoYXJDb2RlO1xuXG4gICAgICAgICAgICAvLyBUYWtlbiBmcm9tIGh0dHBzOi8vbXRocy5iZS9wdW55Y29kZVxuICAgICAgICAgICAgZnVuY3Rpb24gdWNzMmRlY29kZShzdHJpbmcpIHtcbiAgICAgICAgICAgICAgdmFyIG91dHB1dCA9IFtdO1xuICAgICAgICAgICAgICB2YXIgY291bnRlciA9IDA7XG4gICAgICAgICAgICAgIHZhciBsZW5ndGggPSBzdHJpbmcubGVuZ3RoO1xuICAgICAgICAgICAgICB2YXIgdmFsdWU7XG4gICAgICAgICAgICAgIHZhciBleHRyYTtcbiAgICAgICAgICAgICAgd2hpbGUgKGNvdW50ZXIgPCBsZW5ndGgpIHtcbiAgICAgICAgICAgICAgICB2YWx1ZSA9IHN0cmluZy5jaGFyQ29kZUF0KGNvdW50ZXIrKyk7XG4gICAgICAgICAgICAgICAgaWYgKHZhbHVlID49IDB4RDgwMCAmJiB2YWx1ZSA8PSAweERCRkYgJiYgY291bnRlciA8IGxlbmd0aCkge1xuICAgICAgICAgICAgICAgICAgLy8gaGlnaCBzdXJyb2dhdGUsIGFuZCB0aGVyZSBpcyBhIG5leHQgY2hhcmFjdGVyXG4gICAgICAgICAgICAgICAgICBleHRyYSA9IHN0cmluZy5jaGFyQ29kZUF0KGNvdW50ZXIrKyk7XG4gICAgICAgICAgICAgICAgICBpZiAoKGV4dHJhICYgMHhGQzAwKSA9PSAweERDMDApIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gbG93IHN1cnJvZ2F0ZVxuICAgICAgICAgICAgICAgICAgICBvdXRwdXQucHVzaCgoKHZhbHVlICYgMHgzRkYpIDw8IDEwKSArIChleHRyYSAmIDB4M0ZGKSArIDB4MTAwMDApO1xuICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gdW5tYXRjaGVkIHN1cnJvZ2F0ZTsgb25seSBhcHBlbmQgdGhpcyBjb2RlIHVuaXQsIGluIGNhc2UgdGhlIG5leHRcbiAgICAgICAgICAgICAgICAgICAgLy8gY29kZSB1bml0IGlzIHRoZSBoaWdoIHN1cnJvZ2F0ZSBvZiBhIHN1cnJvZ2F0ZSBwYWlyXG4gICAgICAgICAgICAgICAgICAgIG91dHB1dC5wdXNoKHZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgY291bnRlci0tO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICBvdXRwdXQucHVzaCh2YWx1ZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHJldHVybiBvdXRwdXQ7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIFRha2VuIGZyb20gaHR0cHM6Ly9tdGhzLmJlL3B1bnljb2RlXG4gICAgICAgICAgICBmdW5jdGlvbiB1Y3MyZW5jb2RlKGFycmF5KSB7XG4gICAgICAgICAgICAgIHZhciBsZW5ndGggPSBhcnJheS5sZW5ndGg7XG4gICAgICAgICAgICAgIHZhciBpbmRleCA9IC0xO1xuICAgICAgICAgICAgICB2YXIgdmFsdWU7XG4gICAgICAgICAgICAgIHZhciBvdXRwdXQgPSAnJztcbiAgICAgICAgICAgICAgd2hpbGUgKCsraW5kZXggPCBsZW5ndGgpIHtcbiAgICAgICAgICAgICAgICB2YWx1ZSA9IGFycmF5W2luZGV4XTtcbiAgICAgICAgICAgICAgICBpZiAodmFsdWUgPiAweEZGRkYpIHtcbiAgICAgICAgICAgICAgICAgIHZhbHVlIC09IDB4MTAwMDA7XG4gICAgICAgICAgICAgICAgICBvdXRwdXQgKz0gc3RyaW5nRnJvbUNoYXJDb2RlKHZhbHVlID4+PiAxMCAmIDB4M0ZGIHwgMHhEODAwKTtcbiAgICAgICAgICAgICAgICAgIHZhbHVlID0gMHhEQzAwIHwgdmFsdWUgJiAweDNGRjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgb3V0cHV0ICs9IHN0cmluZ0Zyb21DaGFyQ29kZSh2YWx1ZSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgcmV0dXJuIG91dHB1dDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgZnVuY3Rpb24gY2hlY2tTY2FsYXJWYWx1ZShjb2RlUG9pbnQpIHtcbiAgICAgICAgICAgICAgaWYgKGNvZGVQb2ludCA+PSAweEQ4MDAgJiYgY29kZVBvaW50IDw9IDB4REZGRikge1xuICAgICAgICAgICAgICAgIHRocm93IEVycm9yKCdMb25lIHN1cnJvZ2F0ZSBVKycgKyBjb2RlUG9pbnQudG9TdHJpbmcoMTYpLnRvVXBwZXJDYXNlKCkgKyAnIGlzIG5vdCBhIHNjYWxhciB2YWx1ZScpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuICAgICAgICAgICAgZnVuY3Rpb24gY3JlYXRlQnl0ZShjb2RlUG9pbnQsIHNoaWZ0KSB7XG4gICAgICAgICAgICAgIHJldHVybiBzdHJpbmdGcm9tQ2hhckNvZGUoY29kZVBvaW50ID4+IHNoaWZ0ICYgMHgzRiB8IDB4ODApO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBmdW5jdGlvbiBlbmNvZGVDb2RlUG9pbnQoY29kZVBvaW50KSB7XG4gICAgICAgICAgICAgIGlmICgoY29kZVBvaW50ICYgMHhGRkZGRkY4MCkgPT0gMCkge1xuICAgICAgICAgICAgICAgIC8vIDEtYnl0ZSBzZXF1ZW5jZVxuICAgICAgICAgICAgICAgIHJldHVybiBzdHJpbmdGcm9tQ2hhckNvZGUoY29kZVBvaW50KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB2YXIgc3ltYm9sID0gJyc7XG4gICAgICAgICAgICAgIGlmICgoY29kZVBvaW50ICYgMHhGRkZGRjgwMCkgPT0gMCkge1xuICAgICAgICAgICAgICAgIC8vIDItYnl0ZSBzZXF1ZW5jZVxuICAgICAgICAgICAgICAgIHN5bWJvbCA9IHN0cmluZ0Zyb21DaGFyQ29kZShjb2RlUG9pbnQgPj4gNiAmIDB4MUYgfCAweEMwKTtcbiAgICAgICAgICAgICAgfSBlbHNlIGlmICgoY29kZVBvaW50ICYgMHhGRkZGMDAwMCkgPT0gMCkge1xuICAgICAgICAgICAgICAgIC8vIDMtYnl0ZSBzZXF1ZW5jZVxuICAgICAgICAgICAgICAgIGNoZWNrU2NhbGFyVmFsdWUoY29kZVBvaW50KTtcbiAgICAgICAgICAgICAgICBzeW1ib2wgPSBzdHJpbmdGcm9tQ2hhckNvZGUoY29kZVBvaW50ID4+IDEyICYgMHgwRiB8IDB4RTApO1xuICAgICAgICAgICAgICAgIHN5bWJvbCArPSBjcmVhdGVCeXRlKGNvZGVQb2ludCwgNik7XG4gICAgICAgICAgICAgIH0gZWxzZSBpZiAoKGNvZGVQb2ludCAmIDB4RkZFMDAwMDApID09IDApIHtcbiAgICAgICAgICAgICAgICAvLyA0LWJ5dGUgc2VxdWVuY2VcbiAgICAgICAgICAgICAgICBzeW1ib2wgPSBzdHJpbmdGcm9tQ2hhckNvZGUoY29kZVBvaW50ID4+IDE4ICYgMHgwNyB8IDB4RjApO1xuICAgICAgICAgICAgICAgIHN5bWJvbCArPSBjcmVhdGVCeXRlKGNvZGVQb2ludCwgMTIpO1xuICAgICAgICAgICAgICAgIHN5bWJvbCArPSBjcmVhdGVCeXRlKGNvZGVQb2ludCwgNik7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgc3ltYm9sICs9IHN0cmluZ0Zyb21DaGFyQ29kZShjb2RlUG9pbnQgJiAweDNGIHwgMHg4MCk7XG4gICAgICAgICAgICAgIHJldHVybiBzeW1ib2w7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGZ1bmN0aW9uIHV0ZjhlbmNvZGUoc3RyaW5nKSB7XG4gICAgICAgICAgICAgIHZhciBjb2RlUG9pbnRzID0gdWNzMmRlY29kZShzdHJpbmcpO1xuICAgICAgICAgICAgICB2YXIgbGVuZ3RoID0gY29kZVBvaW50cy5sZW5ndGg7XG4gICAgICAgICAgICAgIHZhciBpbmRleCA9IC0xO1xuICAgICAgICAgICAgICB2YXIgY29kZVBvaW50O1xuICAgICAgICAgICAgICB2YXIgYnl0ZVN0cmluZyA9ICcnO1xuICAgICAgICAgICAgICB3aGlsZSAoKytpbmRleCA8IGxlbmd0aCkge1xuICAgICAgICAgICAgICAgIGNvZGVQb2ludCA9IGNvZGVQb2ludHNbaW5kZXhdO1xuICAgICAgICAgICAgICAgIGJ5dGVTdHJpbmcgKz0gZW5jb2RlQ29kZVBvaW50KGNvZGVQb2ludCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgcmV0dXJuIGJ5dGVTdHJpbmc7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG4gICAgICAgICAgICBmdW5jdGlvbiByZWFkQ29udGludWF0aW9uQnl0ZSgpIHtcbiAgICAgICAgICAgICAgaWYgKGJ5dGVJbmRleCA+PSBieXRlQ291bnQpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBFcnJvcignSW52YWxpZCBieXRlIGluZGV4Jyk7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICB2YXIgY29udGludWF0aW9uQnl0ZSA9IGJ5dGVBcnJheVtieXRlSW5kZXhdICYgMHhGRjtcbiAgICAgICAgICAgICAgYnl0ZUluZGV4Kys7XG5cbiAgICAgICAgICAgICAgaWYgKChjb250aW51YXRpb25CeXRlICYgMHhDMCkgPT0gMHg4MCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBjb250aW51YXRpb25CeXRlICYgMHgzRjtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIC8vIElmIHdlIGVuZCB1cCBoZXJlLCBpdOKAmXMgbm90IGEgY29udGludWF0aW9uIGJ5dGVcbiAgICAgICAgICAgICAgdGhyb3cgRXJyb3IoJ0ludmFsaWQgY29udGludWF0aW9uIGJ5dGUnKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgZnVuY3Rpb24gZGVjb2RlU3ltYm9sKCkge1xuICAgICAgICAgICAgICB2YXIgYnl0ZTE7XG4gICAgICAgICAgICAgIHZhciBieXRlMjtcbiAgICAgICAgICAgICAgdmFyIGJ5dGUzO1xuICAgICAgICAgICAgICB2YXIgYnl0ZTQ7XG4gICAgICAgICAgICAgIHZhciBjb2RlUG9pbnQ7XG5cbiAgICAgICAgICAgICAgaWYgKGJ5dGVJbmRleCA+IGJ5dGVDb3VudCkge1xuICAgICAgICAgICAgICAgIHRocm93IEVycm9yKCdJbnZhbGlkIGJ5dGUgaW5kZXgnKTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIGlmIChieXRlSW5kZXggPT0gYnl0ZUNvdW50KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgLy8gUmVhZCBmaXJzdCBieXRlXG4gICAgICAgICAgICAgIGJ5dGUxID0gYnl0ZUFycmF5W2J5dGVJbmRleF0gJiAweEZGO1xuICAgICAgICAgICAgICBieXRlSW5kZXgrKztcblxuICAgICAgICAgICAgICAvLyAxLWJ5dGUgc2VxdWVuY2UgKG5vIGNvbnRpbnVhdGlvbiBieXRlcylcbiAgICAgICAgICAgICAgaWYgKChieXRlMSAmIDB4ODApID09IDApIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYnl0ZTE7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAvLyAyLWJ5dGUgc2VxdWVuY2VcbiAgICAgICAgICAgICAgaWYgKChieXRlMSAmIDB4RTApID09IDB4QzApIHtcbiAgICAgICAgICAgICAgICB2YXIgYnl0ZTIgPSByZWFkQ29udGludWF0aW9uQnl0ZSgpO1xuICAgICAgICAgICAgICAgIGNvZGVQb2ludCA9IChieXRlMSAmIDB4MUYpIDw8IDYgfCBieXRlMjtcbiAgICAgICAgICAgICAgICBpZiAoY29kZVBvaW50ID49IDB4ODApIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBjb2RlUG9pbnQ7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIHRocm93IEVycm9yKCdJbnZhbGlkIGNvbnRpbnVhdGlvbiBieXRlJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgLy8gMy1ieXRlIHNlcXVlbmNlIChtYXkgaW5jbHVkZSB1bnBhaXJlZCBzdXJyb2dhdGVzKVxuICAgICAgICAgICAgICBpZiAoKGJ5dGUxICYgMHhGMCkgPT0gMHhFMCkge1xuICAgICAgICAgICAgICAgIGJ5dGUyID0gcmVhZENvbnRpbnVhdGlvbkJ5dGUoKTtcbiAgICAgICAgICAgICAgICBieXRlMyA9IHJlYWRDb250aW51YXRpb25CeXRlKCk7XG4gICAgICAgICAgICAgICAgY29kZVBvaW50ID0gKGJ5dGUxICYgMHgwRikgPDwgMTIgfCBieXRlMiA8PCA2IHwgYnl0ZTM7XG4gICAgICAgICAgICAgICAgaWYgKGNvZGVQb2ludCA+PSAweDA4MDApIHtcbiAgICAgICAgICAgICAgICAgIGNoZWNrU2NhbGFyVmFsdWUoY29kZVBvaW50KTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBjb2RlUG9pbnQ7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIHRocm93IEVycm9yKCdJbnZhbGlkIGNvbnRpbnVhdGlvbiBieXRlJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgLy8gNC1ieXRlIHNlcXVlbmNlXG4gICAgICAgICAgICAgIGlmICgoYnl0ZTEgJiAweEY4KSA9PSAweEYwKSB7XG4gICAgICAgICAgICAgICAgYnl0ZTIgPSByZWFkQ29udGludWF0aW9uQnl0ZSgpO1xuICAgICAgICAgICAgICAgIGJ5dGUzID0gcmVhZENvbnRpbnVhdGlvbkJ5dGUoKTtcbiAgICAgICAgICAgICAgICBieXRlNCA9IHJlYWRDb250aW51YXRpb25CeXRlKCk7XG4gICAgICAgICAgICAgICAgY29kZVBvaW50ID0gKGJ5dGUxICYgMHgwRikgPDwgMHgxMiB8IGJ5dGUyIDw8IDB4MEMgfCBieXRlMyA8PCAweDA2IHwgYnl0ZTQ7XG4gICAgICAgICAgICAgICAgaWYgKGNvZGVQb2ludCA+PSAweDAxMDAwMCAmJiBjb2RlUG9pbnQgPD0gMHgxMEZGRkYpIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBjb2RlUG9pbnQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgdGhyb3cgRXJyb3IoJ0ludmFsaWQgVVRGLTggZGV0ZWN0ZWQnKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdmFyIGJ5dGVBcnJheTtcbiAgICAgICAgICAgIHZhciBieXRlQ291bnQ7XG4gICAgICAgICAgICB2YXIgYnl0ZUluZGV4O1xuICAgICAgICAgICAgZnVuY3Rpb24gdXRmOGRlY29kZShieXRlU3RyaW5nKSB7XG4gICAgICAgICAgICAgIGJ5dGVBcnJheSA9IHVjczJkZWNvZGUoYnl0ZVN0cmluZyk7XG4gICAgICAgICAgICAgIGJ5dGVDb3VudCA9IGJ5dGVBcnJheS5sZW5ndGg7XG4gICAgICAgICAgICAgIGJ5dGVJbmRleCA9IDA7XG4gICAgICAgICAgICAgIHZhciBjb2RlUG9pbnRzID0gW107XG4gICAgICAgICAgICAgIHZhciB0bXA7XG4gICAgICAgICAgICAgIHdoaWxlICgodG1wID0gZGVjb2RlU3ltYm9sKCkpICE9PSBmYWxzZSkge1xuICAgICAgICAgICAgICAgIGNvZGVQb2ludHMucHVzaCh0bXApO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHJldHVybiB1Y3MyZW5jb2RlKGNvZGVQb2ludHMpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuICAgICAgICAgICAgdmFyIHV0ZjggPSB7XG4gICAgICAgICAgICAgICd2ZXJzaW9uJzogJzIuMC4wJyxcbiAgICAgICAgICAgICAgJ2VuY29kZSc6IHV0ZjhlbmNvZGUsXG4gICAgICAgICAgICAgICdkZWNvZGUnOiB1dGY4ZGVjb2RlXG4gICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAvLyBTb21lIEFNRCBidWlsZCBvcHRpbWl6ZXJzLCBsaWtlIHIuanMsIGNoZWNrIGZvciBzcGVjaWZpYyBjb25kaXRpb24gcGF0dGVybnNcbiAgICAgICAgICAgIC8vIGxpa2UgdGhlIGZvbGxvd2luZzpcbiAgICAgICAgICAgIGlmICh0eXBlb2YgZGVmaW5lID09ICdmdW5jdGlvbicgJiYgdHlwZW9mIGRlZmluZS5hbWQgPT0gJ29iamVjdCcgJiYgZGVmaW5lLmFtZCkge1xuICAgICAgICAgICAgICBkZWZpbmUoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB1dGY4O1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoZnJlZUV4cG9ydHMgJiYgIWZyZWVFeHBvcnRzLm5vZGVUeXBlKSB7XG4gICAgICAgICAgICAgIGlmIChmcmVlTW9kdWxlKSB7XG4gICAgICAgICAgICAgICAgLy8gaW4gTm9kZS5qcyBvciBSaW5nb0pTIHYwLjguMCtcbiAgICAgICAgICAgICAgICBmcmVlTW9kdWxlLmV4cG9ydHMgPSB1dGY4O1xuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIGluIE5hcndoYWwgb3IgUmluZ29KUyB2MC43LjAtXG4gICAgICAgICAgICAgICAgdmFyIG9iamVjdCA9IHt9O1xuICAgICAgICAgICAgICAgIHZhciBoYXNPd25Qcm9wZXJ0eSA9IG9iamVjdC5oYXNPd25Qcm9wZXJ0eTtcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBrZXkgaW4gdXRmOCkge1xuICAgICAgICAgICAgICAgICAgaGFzT3duUHJvcGVydHkuY2FsbCh1dGY4LCBrZXkpICYmIChmcmVlRXhwb3J0c1trZXldID0gdXRmOFtrZXldKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIC8vIGluIFJoaW5vIG9yIGEgd2ViIGJyb3dzZXJcbiAgICAgICAgICAgICAgcm9vdC51dGY4ID0gdXRmODtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KSh0aGlzKTtcbiAgICAgICAgfSkuY2FsbCh0aGlzLCB0eXBlb2Ygc2VsZiAhPT0gXCJ1bmRlZmluZWRcIiA/IHNlbGYgOiB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiID8gd2luZG93IDogdHlwZW9mIGdsb2JhbCAhPT0gXCJ1bmRlZmluZWRcIiA/IGdsb2JhbCA6IHt9KTtcbiAgICAgIH0sIHt9XSwgMzA6IFtmdW5jdGlvbiAoX2RlcmVxXywgbW9kdWxlLCBleHBvcnRzKSB7XG4gICAgICAgICd1c2Ugc3RyaWN0JztcblxuICAgICAgICB2YXIgYWxwaGFiZXQgPSAnMDEyMzQ1Njc4OUFCQ0RFRkdISUpLTE1OT1BRUlNUVVZXWFlaYWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXotXycuc3BsaXQoJycpLFxuICAgICAgICAgICAgbGVuZ3RoID0gNjQsXG4gICAgICAgICAgICBtYXAgPSB7fSxcbiAgICAgICAgICAgIHNlZWQgPSAwLFxuICAgICAgICAgICAgaSA9IDAsXG4gICAgICAgICAgICBwcmV2O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBSZXR1cm4gYSBzdHJpbmcgcmVwcmVzZW50aW5nIHRoZSBzcGVjaWZpZWQgbnVtYmVyLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ge051bWJlcn0gbnVtIFRoZSBudW1iZXIgdG8gY29udmVydC5cbiAgICAgICAgICogQHJldHVybnMge1N0cmluZ30gVGhlIHN0cmluZyByZXByZXNlbnRhdGlvbiBvZiB0aGUgbnVtYmVyLlxuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cbiAgICAgICAgZnVuY3Rpb24gZW5jb2RlKG51bSkge1xuICAgICAgICAgIHZhciBlbmNvZGVkID0gJyc7XG5cbiAgICAgICAgICBkbyB7XG4gICAgICAgICAgICBlbmNvZGVkID0gYWxwaGFiZXRbbnVtICUgbGVuZ3RoXSArIGVuY29kZWQ7XG4gICAgICAgICAgICBudW0gPSBNYXRoLmZsb29yKG51bSAvIGxlbmd0aCk7XG4gICAgICAgICAgfSB3aGlsZSAobnVtID4gMCk7XG5cbiAgICAgICAgICByZXR1cm4gZW5jb2RlZDtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBSZXR1cm4gdGhlIGludGVnZXIgdmFsdWUgc3BlY2lmaWVkIGJ5IHRoZSBnaXZlbiBzdHJpbmcuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7U3RyaW5nfSBzdHIgVGhlIHN0cmluZyB0byBjb252ZXJ0LlxuICAgICAgICAgKiBAcmV0dXJucyB7TnVtYmVyfSBUaGUgaW50ZWdlciB2YWx1ZSByZXByZXNlbnRlZCBieSB0aGUgc3RyaW5nLlxuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cbiAgICAgICAgZnVuY3Rpb24gZGVjb2RlKHN0cikge1xuICAgICAgICAgIHZhciBkZWNvZGVkID0gMDtcblxuICAgICAgICAgIGZvciAoaSA9IDA7IGkgPCBzdHIubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGRlY29kZWQgPSBkZWNvZGVkICogbGVuZ3RoICsgbWFwW3N0ci5jaGFyQXQoaSldO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHJldHVybiBkZWNvZGVkO1xuICAgICAgICB9XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFllYXN0OiBBIHRpbnkgZ3Jvd2luZyBpZCBnZW5lcmF0b3IuXG4gICAgICAgICAqXG4gICAgICAgICAqIEByZXR1cm5zIHtTdHJpbmd9IEEgdW5pcXVlIGlkLlxuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cbiAgICAgICAgZnVuY3Rpb24geWVhc3QoKSB7XG4gICAgICAgICAgdmFyIG5vdyA9IGVuY29kZSgrbmV3IERhdGUoKSk7XG5cbiAgICAgICAgICBpZiAobm93ICE9PSBwcmV2KSByZXR1cm4gc2VlZCA9IDAsIHByZXYgPSBub3c7XG4gICAgICAgICAgcmV0dXJuIG5vdyArICcuJyArIGVuY29kZShzZWVkKyspO1xuICAgICAgICB9XG5cbiAgICAgICAgLy9cbiAgICAgICAgLy8gTWFwIGVhY2ggY2hhcmFjdGVyIHRvIGl0cyBpbmRleC5cbiAgICAgICAgLy9cbiAgICAgICAgZm9yICg7IGkgPCBsZW5ndGg7IGkrKykgbWFwW2FscGhhYmV0W2ldXSA9IGk7XG5cbiAgICAgICAgLy9cbiAgICAgICAgLy8gRXhwb3NlIHRoZSBgeWVhc3RgLCBgZW5jb2RlYCBhbmQgYGRlY29kZWAgZnVuY3Rpb25zLlxuICAgICAgICAvL1xuICAgICAgICB5ZWFzdC5lbmNvZGUgPSBlbmNvZGU7XG4gICAgICAgIHllYXN0LmRlY29kZSA9IGRlY29kZTtcbiAgICAgICAgbW9kdWxlLmV4cG9ydHMgPSB5ZWFzdDtcbiAgICAgIH0sIHt9XSwgMzE6IFtmdW5jdGlvbiAoX2RlcmVxXywgbW9kdWxlLCBleHBvcnRzKSB7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIE1vZHVsZSBkZXBlbmRlbmNpZXMuXG4gICAgICAgICAqL1xuXG4gICAgICAgIHZhciB1cmwgPSBfZGVyZXFfKCcuL3VybCcpO1xuICAgICAgICB2YXIgcGFyc2VyID0gX2RlcmVxXygnc29ja2V0LmlvLXBhcnNlcicpO1xuICAgICAgICB2YXIgTWFuYWdlciA9IF9kZXJlcV8oJy4vbWFuYWdlcicpO1xuICAgICAgICB2YXIgZGVidWcgPSBfZGVyZXFfKCdkZWJ1ZycpKCdzb2NrZXQuaW8tY2xpZW50Jyk7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIE1vZHVsZSBleHBvcnRzLlxuICAgICAgICAgKi9cblxuICAgICAgICBtb2R1bGUuZXhwb3J0cyA9IGV4cG9ydHMgPSBsb29rdXA7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIE1hbmFnZXJzIGNhY2hlLlxuICAgICAgICAgKi9cblxuICAgICAgICB2YXIgY2FjaGUgPSBleHBvcnRzLm1hbmFnZXJzID0ge307XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIExvb2tzIHVwIGFuIGV4aXN0aW5nIGBNYW5hZ2VyYCBmb3IgbXVsdGlwbGV4aW5nLlxuICAgICAgICAgKiBJZiB0aGUgdXNlciBzdW1tb25zOlxuICAgICAgICAgKlxuICAgICAgICAgKiAgIGBpbygnaHR0cDovL2xvY2FsaG9zdC9hJyk7YFxuICAgICAgICAgKiAgIGBpbygnaHR0cDovL2xvY2FsaG9zdC9iJyk7YFxuICAgICAgICAgKlxuICAgICAgICAgKiBXZSByZXVzZSB0aGUgZXhpc3RpbmcgaW5zdGFuY2UgYmFzZWQgb24gc2FtZSBzY2hlbWUvcG9ydC9ob3N0LFxuICAgICAgICAgKiBhbmQgd2UgaW5pdGlhbGl6ZSBzb2NrZXRzIGZvciBlYWNoIG5hbWVzcGFjZS5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgZnVuY3Rpb24gbG9va3VwKHVyaSwgb3B0cykge1xuICAgICAgICAgIGlmICh0eXBlb2YgdXJpID09ICdvYmplY3QnKSB7XG4gICAgICAgICAgICBvcHRzID0gdXJpO1xuICAgICAgICAgICAgdXJpID0gdW5kZWZpbmVkO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIG9wdHMgPSBvcHRzIHx8IHt9O1xuXG4gICAgICAgICAgdmFyIHBhcnNlZCA9IHVybCh1cmkpO1xuICAgICAgICAgIHZhciBzb3VyY2UgPSBwYXJzZWQuc291cmNlO1xuICAgICAgICAgIHZhciBpZCA9IHBhcnNlZC5pZDtcbiAgICAgICAgICB2YXIgcGF0aCA9IHBhcnNlZC5wYXRoO1xuICAgICAgICAgIHZhciBzYW1lTmFtZXNwYWNlID0gY2FjaGVbaWRdICYmIHBhdGggaW4gY2FjaGVbaWRdLm5zcHM7XG4gICAgICAgICAgdmFyIG5ld0Nvbm5lY3Rpb24gPSBvcHRzLmZvcmNlTmV3IHx8IG9wdHNbJ2ZvcmNlIG5ldyBjb25uZWN0aW9uJ10gfHwgZmFsc2UgPT09IG9wdHMubXVsdGlwbGV4IHx8IHNhbWVOYW1lc3BhY2U7XG5cbiAgICAgICAgICB2YXIgaW87XG5cbiAgICAgICAgICBpZiAobmV3Q29ubmVjdGlvbikge1xuICAgICAgICAgICAgZGVidWcoJ2lnbm9yaW5nIHNvY2tldCBjYWNoZSBmb3IgJXMnLCBzb3VyY2UpO1xuICAgICAgICAgICAgaW8gPSBNYW5hZ2VyKHNvdXJjZSwgb3B0cyk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGlmICghY2FjaGVbaWRdKSB7XG4gICAgICAgICAgICAgIGRlYnVnKCduZXcgaW8gaW5zdGFuY2UgZm9yICVzJywgc291cmNlKTtcbiAgICAgICAgICAgICAgY2FjaGVbaWRdID0gTWFuYWdlcihzb3VyY2UsIG9wdHMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaW8gPSBjYWNoZVtpZF07XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgcmV0dXJuIGlvLnNvY2tldChwYXJzZWQucGF0aCk7XG4gICAgICAgIH1cblxuICAgICAgICAvKipcbiAgICAgICAgICogUHJvdG9jb2wgdmVyc2lvbi5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgZXhwb3J0cy5wcm90b2NvbCA9IHBhcnNlci5wcm90b2NvbDtcblxuICAgICAgICAvKipcbiAgICAgICAgICogYGNvbm5lY3RgLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ge1N0cmluZ30gdXJpXG4gICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAqL1xuXG4gICAgICAgIGV4cG9ydHMuY29ubmVjdCA9IGxvb2t1cDtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRXhwb3NlIGNvbnN0cnVjdG9ycyBmb3Igc3RhbmRhbG9uZSBidWlsZC5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgZXhwb3J0cy5NYW5hZ2VyID0gX2RlcmVxXygnLi9tYW5hZ2VyJyk7XG4gICAgICAgIGV4cG9ydHMuU29ja2V0ID0gX2RlcmVxXygnLi9zb2NrZXQnKTtcbiAgICAgIH0sIHsgXCIuL21hbmFnZXJcIjogMzIsIFwiLi9zb2NrZXRcIjogMzQsIFwiLi91cmxcIjogMzUsIFwiZGVidWdcIjogMzksIFwic29ja2V0LmlvLXBhcnNlclwiOiA0NyB9XSwgMzI6IFtmdW5jdGlvbiAoX2RlcmVxXywgbW9kdWxlLCBleHBvcnRzKSB7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIE1vZHVsZSBkZXBlbmRlbmNpZXMuXG4gICAgICAgICAqL1xuXG4gICAgICAgIHZhciBlaW8gPSBfZGVyZXFfKCdlbmdpbmUuaW8tY2xpZW50Jyk7XG4gICAgICAgIHZhciBTb2NrZXQgPSBfZGVyZXFfKCcuL3NvY2tldCcpO1xuICAgICAgICB2YXIgRW1pdHRlciA9IF9kZXJlcV8oJ2NvbXBvbmVudC1lbWl0dGVyJyk7XG4gICAgICAgIHZhciBwYXJzZXIgPSBfZGVyZXFfKCdzb2NrZXQuaW8tcGFyc2VyJyk7XG4gICAgICAgIHZhciBvbiA9IF9kZXJlcV8oJy4vb24nKTtcbiAgICAgICAgdmFyIGJpbmQgPSBfZGVyZXFfKCdjb21wb25lbnQtYmluZCcpO1xuICAgICAgICB2YXIgZGVidWcgPSBfZGVyZXFfKCdkZWJ1ZycpKCdzb2NrZXQuaW8tY2xpZW50Om1hbmFnZXInKTtcbiAgICAgICAgdmFyIGluZGV4T2YgPSBfZGVyZXFfKCdpbmRleG9mJyk7XG4gICAgICAgIHZhciBCYWNrb2ZmID0gX2RlcmVxXygnYmFja28yJyk7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIElFNisgaGFzT3duUHJvcGVydHlcbiAgICAgICAgICovXG5cbiAgICAgICAgdmFyIGhhcyA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIE1vZHVsZSBleHBvcnRzXG4gICAgICAgICAqL1xuXG4gICAgICAgIG1vZHVsZS5leHBvcnRzID0gTWFuYWdlcjtcblxuICAgICAgICAvKipcbiAgICAgICAgICogYE1hbmFnZXJgIGNvbnN0cnVjdG9yLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ge1N0cmluZ30gZW5naW5lIGluc3RhbmNlIG9yIGVuZ2luZSB1cmkvb3B0c1xuICAgICAgICAgKiBAcGFyYW0ge09iamVjdH0gb3B0aW9uc1xuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cblxuICAgICAgICBmdW5jdGlvbiBNYW5hZ2VyKHVyaSwgb3B0cykge1xuICAgICAgICAgIGlmICghKHRoaXMgaW5zdGFuY2VvZiBNYW5hZ2VyKSkgcmV0dXJuIG5ldyBNYW5hZ2VyKHVyaSwgb3B0cyk7XG4gICAgICAgICAgaWYgKHVyaSAmJiAnb2JqZWN0JyA9PSB0eXBlb2YgdXJpKSB7XG4gICAgICAgICAgICBvcHRzID0gdXJpO1xuICAgICAgICAgICAgdXJpID0gdW5kZWZpbmVkO1xuICAgICAgICAgIH1cbiAgICAgICAgICBvcHRzID0gb3B0cyB8fCB7fTtcblxuICAgICAgICAgIG9wdHMucGF0aCA9IG9wdHMucGF0aCB8fCAnL3NvY2tldC5pbyc7XG4gICAgICAgICAgdGhpcy5uc3BzID0ge307XG4gICAgICAgICAgdGhpcy5zdWJzID0gW107XG4gICAgICAgICAgdGhpcy5vcHRzID0gb3B0cztcbiAgICAgICAgICB0aGlzLnJlY29ubmVjdGlvbihvcHRzLnJlY29ubmVjdGlvbiAhPT0gZmFsc2UpO1xuICAgICAgICAgIHRoaXMucmVjb25uZWN0aW9uQXR0ZW1wdHMob3B0cy5yZWNvbm5lY3Rpb25BdHRlbXB0cyB8fCBJbmZpbml0eSk7XG4gICAgICAgICAgdGhpcy5yZWNvbm5lY3Rpb25EZWxheShvcHRzLnJlY29ubmVjdGlvbkRlbGF5IHx8IDEwMDApO1xuICAgICAgICAgIHRoaXMucmVjb25uZWN0aW9uRGVsYXlNYXgob3B0cy5yZWNvbm5lY3Rpb25EZWxheU1heCB8fCA1MDAwKTtcbiAgICAgICAgICB0aGlzLnJhbmRvbWl6YXRpb25GYWN0b3Iob3B0cy5yYW5kb21pemF0aW9uRmFjdG9yIHx8IDAuNSk7XG4gICAgICAgICAgdGhpcy5iYWNrb2ZmID0gbmV3IEJhY2tvZmYoe1xuICAgICAgICAgICAgbWluOiB0aGlzLnJlY29ubmVjdGlvbkRlbGF5KCksXG4gICAgICAgICAgICBtYXg6IHRoaXMucmVjb25uZWN0aW9uRGVsYXlNYXgoKSxcbiAgICAgICAgICAgIGppdHRlcjogdGhpcy5yYW5kb21pemF0aW9uRmFjdG9yKClcbiAgICAgICAgICB9KTtcbiAgICAgICAgICB0aGlzLnRpbWVvdXQobnVsbCA9PSBvcHRzLnRpbWVvdXQgPyAyMDAwMCA6IG9wdHMudGltZW91dCk7XG4gICAgICAgICAgdGhpcy5yZWFkeVN0YXRlID0gJ2Nsb3NlZCc7XG4gICAgICAgICAgdGhpcy51cmkgPSB1cmk7XG4gICAgICAgICAgdGhpcy5jb25uZWN0aW5nID0gW107XG4gICAgICAgICAgdGhpcy5sYXN0UGluZyA9IG51bGw7XG4gICAgICAgICAgdGhpcy5lbmNvZGluZyA9IGZhbHNlO1xuICAgICAgICAgIHRoaXMucGFja2V0QnVmZmVyID0gW107XG4gICAgICAgICAgdGhpcy5lbmNvZGVyID0gbmV3IHBhcnNlci5FbmNvZGVyKCk7XG4gICAgICAgICAgdGhpcy5kZWNvZGVyID0gbmV3IHBhcnNlci5EZWNvZGVyKCk7XG4gICAgICAgICAgdGhpcy5hdXRvQ29ubmVjdCA9IG9wdHMuYXV0b0Nvbm5lY3QgIT09IGZhbHNlO1xuICAgICAgICAgIGlmICh0aGlzLmF1dG9Db25uZWN0KSB0aGlzLm9wZW4oKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBQcm9wYWdhdGUgZ2l2ZW4gZXZlbnQgdG8gc29ja2V0cyBhbmQgZW1pdCBvbiBgdGhpc2BcbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIE1hbmFnZXIucHJvdG90eXBlLmVtaXRBbGwgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgdGhpcy5lbWl0LmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICAgICAgZm9yICh2YXIgbnNwIGluIHRoaXMubnNwcykge1xuICAgICAgICAgICAgaWYgKGhhcy5jYWxsKHRoaXMubnNwcywgbnNwKSkge1xuICAgICAgICAgICAgICB0aGlzLm5zcHNbbnNwXS5lbWl0LmFwcGx5KHRoaXMubnNwc1tuc3BdLCBhcmd1bWVudHMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVXBkYXRlIGBzb2NrZXQuaWRgIG9mIGFsbCBzb2NrZXRzXG4gICAgICAgICAqXG4gICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgKi9cblxuICAgICAgICBNYW5hZ2VyLnByb3RvdHlwZS51cGRhdGVTb2NrZXRJZHMgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgZm9yICh2YXIgbnNwIGluIHRoaXMubnNwcykge1xuICAgICAgICAgICAgaWYgKGhhcy5jYWxsKHRoaXMubnNwcywgbnNwKSkge1xuICAgICAgICAgICAgICB0aGlzLm5zcHNbbnNwXS5pZCA9IHRoaXMuZW5naW5lLmlkO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogTWl4IGluIGBFbWl0dGVyYC5cbiAgICAgICAgICovXG5cbiAgICAgICAgRW1pdHRlcihNYW5hZ2VyLnByb3RvdHlwZSk7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFNldHMgdGhlIGByZWNvbm5lY3Rpb25gIGNvbmZpZy5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtCb29sZWFufSB0cnVlL2ZhbHNlIGlmIGl0IHNob3VsZCBhdXRvbWF0aWNhbGx5IHJlY29ubmVjdFxuICAgICAgICAgKiBAcmV0dXJuIHtNYW5hZ2VyfSBzZWxmIG9yIHZhbHVlXG4gICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAqL1xuXG4gICAgICAgIE1hbmFnZXIucHJvdG90eXBlLnJlY29ubmVjdGlvbiA9IGZ1bmN0aW9uICh2KSB7XG4gICAgICAgICAgaWYgKCFhcmd1bWVudHMubGVuZ3RoKSByZXR1cm4gdGhpcy5fcmVjb25uZWN0aW9uO1xuICAgICAgICAgIHRoaXMuX3JlY29ubmVjdGlvbiA9ICEhdjtcbiAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogU2V0cyB0aGUgcmVjb25uZWN0aW9uIGF0dGVtcHRzIGNvbmZpZy5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtOdW1iZXJ9IG1heCByZWNvbm5lY3Rpb24gYXR0ZW1wdHMgYmVmb3JlIGdpdmluZyB1cFxuICAgICAgICAgKiBAcmV0dXJuIHtNYW5hZ2VyfSBzZWxmIG9yIHZhbHVlXG4gICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAqL1xuXG4gICAgICAgIE1hbmFnZXIucHJvdG90eXBlLnJlY29ubmVjdGlvbkF0dGVtcHRzID0gZnVuY3Rpb24gKHYpIHtcbiAgICAgICAgICBpZiAoIWFyZ3VtZW50cy5sZW5ndGgpIHJldHVybiB0aGlzLl9yZWNvbm5lY3Rpb25BdHRlbXB0cztcbiAgICAgICAgICB0aGlzLl9yZWNvbm5lY3Rpb25BdHRlbXB0cyA9IHY7XG4gICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFNldHMgdGhlIGRlbGF5IGJldHdlZW4gcmVjb25uZWN0aW9ucy5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtOdW1iZXJ9IGRlbGF5XG4gICAgICAgICAqIEByZXR1cm4ge01hbmFnZXJ9IHNlbGYgb3IgdmFsdWVcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgTWFuYWdlci5wcm90b3R5cGUucmVjb25uZWN0aW9uRGVsYXkgPSBmdW5jdGlvbiAodikge1xuICAgICAgICAgIGlmICghYXJndW1lbnRzLmxlbmd0aCkgcmV0dXJuIHRoaXMuX3JlY29ubmVjdGlvbkRlbGF5O1xuICAgICAgICAgIHRoaXMuX3JlY29ubmVjdGlvbkRlbGF5ID0gdjtcbiAgICAgICAgICB0aGlzLmJhY2tvZmYgJiYgdGhpcy5iYWNrb2ZmLnNldE1pbih2KTtcbiAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfTtcblxuICAgICAgICBNYW5hZ2VyLnByb3RvdHlwZS5yYW5kb21pemF0aW9uRmFjdG9yID0gZnVuY3Rpb24gKHYpIHtcbiAgICAgICAgICBpZiAoIWFyZ3VtZW50cy5sZW5ndGgpIHJldHVybiB0aGlzLl9yYW5kb21pemF0aW9uRmFjdG9yO1xuICAgICAgICAgIHRoaXMuX3JhbmRvbWl6YXRpb25GYWN0b3IgPSB2O1xuICAgICAgICAgIHRoaXMuYmFja29mZiAmJiB0aGlzLmJhY2tvZmYuc2V0Sml0dGVyKHYpO1xuICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBTZXRzIHRoZSBtYXhpbXVtIGRlbGF5IGJldHdlZW4gcmVjb25uZWN0aW9ucy5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtOdW1iZXJ9IGRlbGF5XG4gICAgICAgICAqIEByZXR1cm4ge01hbmFnZXJ9IHNlbGYgb3IgdmFsdWVcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgTWFuYWdlci5wcm90b3R5cGUucmVjb25uZWN0aW9uRGVsYXlNYXggPSBmdW5jdGlvbiAodikge1xuICAgICAgICAgIGlmICghYXJndW1lbnRzLmxlbmd0aCkgcmV0dXJuIHRoaXMuX3JlY29ubmVjdGlvbkRlbGF5TWF4O1xuICAgICAgICAgIHRoaXMuX3JlY29ubmVjdGlvbkRlbGF5TWF4ID0gdjtcbiAgICAgICAgICB0aGlzLmJhY2tvZmYgJiYgdGhpcy5iYWNrb2ZmLnNldE1heCh2KTtcbiAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogU2V0cyB0aGUgY29ubmVjdGlvbiB0aW1lb3V0LiBgZmFsc2VgIHRvIGRpc2FibGVcbiAgICAgICAgICpcbiAgICAgICAgICogQHJldHVybiB7TWFuYWdlcn0gc2VsZiBvciB2YWx1ZVxuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cblxuICAgICAgICBNYW5hZ2VyLnByb3RvdHlwZS50aW1lb3V0ID0gZnVuY3Rpb24gKHYpIHtcbiAgICAgICAgICBpZiAoIWFyZ3VtZW50cy5sZW5ndGgpIHJldHVybiB0aGlzLl90aW1lb3V0O1xuICAgICAgICAgIHRoaXMuX3RpbWVvdXQgPSB2O1xuICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBTdGFydHMgdHJ5aW5nIHRvIHJlY29ubmVjdCBpZiByZWNvbm5lY3Rpb24gaXMgZW5hYmxlZCBhbmQgd2UgaGF2ZSBub3RcbiAgICAgICAgICogc3RhcnRlZCByZWNvbm5lY3RpbmcgeWV0XG4gICAgICAgICAqXG4gICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgKi9cblxuICAgICAgICBNYW5hZ2VyLnByb3RvdHlwZS5tYXliZVJlY29ubmVjdE9uT3BlbiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAvLyBPbmx5IHRyeSB0byByZWNvbm5lY3QgaWYgaXQncyB0aGUgZmlyc3QgdGltZSB3ZSdyZSBjb25uZWN0aW5nXG4gICAgICAgICAgaWYgKCF0aGlzLnJlY29ubmVjdGluZyAmJiB0aGlzLl9yZWNvbm5lY3Rpb24gJiYgdGhpcy5iYWNrb2ZmLmF0dGVtcHRzID09PSAwKSB7XG4gICAgICAgICAgICAvLyBrZWVwcyByZWNvbm5lY3Rpb24gZnJvbSBmaXJpbmcgdHdpY2UgZm9yIHRoZSBzYW1lIHJlY29ubmVjdGlvbiBsb29wXG4gICAgICAgICAgICB0aGlzLnJlY29ubmVjdCgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogU2V0cyB0aGUgY3VycmVudCB0cmFuc3BvcnQgYHNvY2tldGAuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7RnVuY3Rpb259IG9wdGlvbmFsLCBjYWxsYmFja1xuICAgICAgICAgKiBAcmV0dXJuIHtNYW5hZ2VyfSBzZWxmXG4gICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAqL1xuXG4gICAgICAgIE1hbmFnZXIucHJvdG90eXBlLm9wZW4gPSBNYW5hZ2VyLnByb3RvdHlwZS5jb25uZWN0ID0gZnVuY3Rpb24gKGZuKSB7XG4gICAgICAgICAgZGVidWcoJ3JlYWR5U3RhdGUgJXMnLCB0aGlzLnJlYWR5U3RhdGUpO1xuICAgICAgICAgIGlmICh+dGhpcy5yZWFkeVN0YXRlLmluZGV4T2YoJ29wZW4nKSkgcmV0dXJuIHRoaXM7XG5cbiAgICAgICAgICBkZWJ1Zygnb3BlbmluZyAlcycsIHRoaXMudXJpKTtcbiAgICAgICAgICB0aGlzLmVuZ2luZSA9IGVpbyh0aGlzLnVyaSwgdGhpcy5vcHRzKTtcbiAgICAgICAgICB2YXIgc29ja2V0ID0gdGhpcy5lbmdpbmU7XG4gICAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICAgIHRoaXMucmVhZHlTdGF0ZSA9ICdvcGVuaW5nJztcbiAgICAgICAgICB0aGlzLnNraXBSZWNvbm5lY3QgPSBmYWxzZTtcblxuICAgICAgICAgIC8vIGVtaXQgYG9wZW5gXG4gICAgICAgICAgdmFyIG9wZW5TdWIgPSBvbihzb2NrZXQsICdvcGVuJywgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgc2VsZi5vbm9wZW4oKTtcbiAgICAgICAgICAgIGZuICYmIGZuKCk7XG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICAvLyBlbWl0IGBjb25uZWN0X2Vycm9yYFxuICAgICAgICAgIHZhciBlcnJvclN1YiA9IG9uKHNvY2tldCwgJ2Vycm9yJywgZnVuY3Rpb24gKGRhdGEpIHtcbiAgICAgICAgICAgIGRlYnVnKCdjb25uZWN0X2Vycm9yJyk7XG4gICAgICAgICAgICBzZWxmLmNsZWFudXAoKTtcbiAgICAgICAgICAgIHNlbGYucmVhZHlTdGF0ZSA9ICdjbG9zZWQnO1xuICAgICAgICAgICAgc2VsZi5lbWl0QWxsKCdjb25uZWN0X2Vycm9yJywgZGF0YSk7XG4gICAgICAgICAgICBpZiAoZm4pIHtcbiAgICAgICAgICAgICAgdmFyIGVyciA9IG5ldyBFcnJvcignQ29ubmVjdGlvbiBlcnJvcicpO1xuICAgICAgICAgICAgICBlcnIuZGF0YSA9IGRhdGE7XG4gICAgICAgICAgICAgIGZuKGVycik7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAvLyBPbmx5IGRvIHRoaXMgaWYgdGhlcmUgaXMgbm8gZm4gdG8gaGFuZGxlIHRoZSBlcnJvclxuICAgICAgICAgICAgICBzZWxmLm1heWJlUmVjb25uZWN0T25PcGVuKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICAvLyBlbWl0IGBjb25uZWN0X3RpbWVvdXRgXG4gICAgICAgICAgaWYgKGZhbHNlICE9PSB0aGlzLl90aW1lb3V0KSB7XG4gICAgICAgICAgICB2YXIgdGltZW91dCA9IHRoaXMuX3RpbWVvdXQ7XG4gICAgICAgICAgICBkZWJ1ZygnY29ubmVjdCBhdHRlbXB0IHdpbGwgdGltZW91dCBhZnRlciAlZCcsIHRpbWVvdXQpO1xuXG4gICAgICAgICAgICAvLyBzZXQgdGltZXJcbiAgICAgICAgICAgIHZhciB0aW1lciA9IHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICBkZWJ1ZygnY29ubmVjdCBhdHRlbXB0IHRpbWVkIG91dCBhZnRlciAlZCcsIHRpbWVvdXQpO1xuICAgICAgICAgICAgICBvcGVuU3ViLmRlc3Ryb3koKTtcbiAgICAgICAgICAgICAgc29ja2V0LmNsb3NlKCk7XG4gICAgICAgICAgICAgIHNvY2tldC5lbWl0KCdlcnJvcicsICd0aW1lb3V0Jyk7XG4gICAgICAgICAgICAgIHNlbGYuZW1pdEFsbCgnY29ubmVjdF90aW1lb3V0JywgdGltZW91dCk7XG4gICAgICAgICAgICB9LCB0aW1lb3V0KTtcblxuICAgICAgICAgICAgdGhpcy5zdWJzLnB1c2goe1xuICAgICAgICAgICAgICBkZXN0cm95OiBmdW5jdGlvbiBkZXN0cm95KCkge1xuICAgICAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aW1lcik7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHRoaXMuc3Vicy5wdXNoKG9wZW5TdWIpO1xuICAgICAgICAgIHRoaXMuc3Vicy5wdXNoKGVycm9yU3ViKTtcblxuICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDYWxsZWQgdXBvbiB0cmFuc3BvcnQgb3Blbi5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIE1hbmFnZXIucHJvdG90eXBlLm9ub3BlbiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBkZWJ1Zygnb3BlbicpO1xuXG4gICAgICAgICAgLy8gY2xlYXIgb2xkIHN1YnNcbiAgICAgICAgICB0aGlzLmNsZWFudXAoKTtcblxuICAgICAgICAgIC8vIG1hcmsgYXMgb3BlblxuICAgICAgICAgIHRoaXMucmVhZHlTdGF0ZSA9ICdvcGVuJztcbiAgICAgICAgICB0aGlzLmVtaXQoJ29wZW4nKTtcblxuICAgICAgICAgIC8vIGFkZCBuZXcgc3Vic1xuICAgICAgICAgIHZhciBzb2NrZXQgPSB0aGlzLmVuZ2luZTtcbiAgICAgICAgICB0aGlzLnN1YnMucHVzaChvbihzb2NrZXQsICdkYXRhJywgYmluZCh0aGlzLCAnb25kYXRhJykpKTtcbiAgICAgICAgICB0aGlzLnN1YnMucHVzaChvbihzb2NrZXQsICdwaW5nJywgYmluZCh0aGlzLCAnb25waW5nJykpKTtcbiAgICAgICAgICB0aGlzLnN1YnMucHVzaChvbihzb2NrZXQsICdwb25nJywgYmluZCh0aGlzLCAnb25wb25nJykpKTtcbiAgICAgICAgICB0aGlzLnN1YnMucHVzaChvbihzb2NrZXQsICdlcnJvcicsIGJpbmQodGhpcywgJ29uZXJyb3InKSkpO1xuICAgICAgICAgIHRoaXMuc3Vicy5wdXNoKG9uKHNvY2tldCwgJ2Nsb3NlJywgYmluZCh0aGlzLCAnb25jbG9zZScpKSk7XG4gICAgICAgICAgdGhpcy5zdWJzLnB1c2gob24odGhpcy5kZWNvZGVyLCAnZGVjb2RlZCcsIGJpbmQodGhpcywgJ29uZGVjb2RlZCcpKSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENhbGxlZCB1cG9uIGEgcGluZy5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIE1hbmFnZXIucHJvdG90eXBlLm9ucGluZyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICB0aGlzLmxhc3RQaW5nID0gbmV3IERhdGUoKTtcbiAgICAgICAgICB0aGlzLmVtaXRBbGwoJ3BpbmcnKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ2FsbGVkIHVwb24gYSBwYWNrZXQuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgKi9cblxuICAgICAgICBNYW5hZ2VyLnByb3RvdHlwZS5vbnBvbmcgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgdGhpcy5lbWl0QWxsKCdwb25nJywgbmV3IERhdGUoKSAtIHRoaXMubGFzdFBpbmcpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDYWxsZWQgd2l0aCBkYXRhLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICovXG5cbiAgICAgICAgTWFuYWdlci5wcm90b3R5cGUub25kYXRhID0gZnVuY3Rpb24gKGRhdGEpIHtcbiAgICAgICAgICB0aGlzLmRlY29kZXIuYWRkKGRhdGEpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDYWxsZWQgd2hlbiBwYXJzZXIgZnVsbHkgZGVjb2RlcyBhIHBhY2tldC5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIE1hbmFnZXIucHJvdG90eXBlLm9uZGVjb2RlZCA9IGZ1bmN0aW9uIChwYWNrZXQpIHtcbiAgICAgICAgICB0aGlzLmVtaXQoJ3BhY2tldCcsIHBhY2tldCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENhbGxlZCB1cG9uIHNvY2tldCBlcnJvci5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIE1hbmFnZXIucHJvdG90eXBlLm9uZXJyb3IgPSBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICAgICAgZGVidWcoJ2Vycm9yJywgZXJyKTtcbiAgICAgICAgICB0aGlzLmVtaXRBbGwoJ2Vycm9yJywgZXJyKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIG5ldyBzb2NrZXQgZm9yIHRoZSBnaXZlbiBgbnNwYC5cbiAgICAgICAgICpcbiAgICAgICAgICogQHJldHVybiB7U29ja2V0fVxuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cblxuICAgICAgICBNYW5hZ2VyLnByb3RvdHlwZS5zb2NrZXQgPSBmdW5jdGlvbiAobnNwKSB7XG4gICAgICAgICAgdmFyIHNvY2tldCA9IHRoaXMubnNwc1tuc3BdO1xuICAgICAgICAgIGlmICghc29ja2V0KSB7XG4gICAgICAgICAgICBzb2NrZXQgPSBuZXcgU29ja2V0KHRoaXMsIG5zcCk7XG4gICAgICAgICAgICB0aGlzLm5zcHNbbnNwXSA9IHNvY2tldDtcbiAgICAgICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgICAgIHNvY2tldC5vbignY29ubmVjdGluZycsIG9uQ29ubmVjdGluZyk7XG4gICAgICAgICAgICBzb2NrZXQub24oJ2Nvbm5lY3QnLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgIHNvY2tldC5pZCA9IHNlbGYuZW5naW5lLmlkO1xuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIGlmICh0aGlzLmF1dG9Db25uZWN0KSB7XG4gICAgICAgICAgICAgIC8vIG1hbnVhbGx5IGNhbGwgaGVyZSBzaW5jZSBjb25uZWN0aW5nIGV2bmV0IGlzIGZpcmVkIGJlZm9yZSBsaXN0ZW5pbmdcbiAgICAgICAgICAgICAgb25Db25uZWN0aW5nKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgZnVuY3Rpb24gb25Db25uZWN0aW5nKCkge1xuICAgICAgICAgICAgaWYgKCEgfmluZGV4T2Yoc2VsZi5jb25uZWN0aW5nLCBzb2NrZXQpKSB7XG4gICAgICAgICAgICAgIHNlbGYuY29ubmVjdGluZy5wdXNoKHNvY2tldCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgcmV0dXJuIHNvY2tldDtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ2FsbGVkIHVwb24gYSBzb2NrZXQgY2xvc2UuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7U29ja2V0fSBzb2NrZXRcbiAgICAgICAgICovXG5cbiAgICAgICAgTWFuYWdlci5wcm90b3R5cGUuZGVzdHJveSA9IGZ1bmN0aW9uIChzb2NrZXQpIHtcbiAgICAgICAgICB2YXIgaW5kZXggPSBpbmRleE9mKHRoaXMuY29ubmVjdGluZywgc29ja2V0KTtcbiAgICAgICAgICBpZiAofmluZGV4KSB0aGlzLmNvbm5lY3Rpbmcuc3BsaWNlKGluZGV4LCAxKTtcbiAgICAgICAgICBpZiAodGhpcy5jb25uZWN0aW5nLmxlbmd0aCkgcmV0dXJuO1xuXG4gICAgICAgICAgdGhpcy5jbG9zZSgpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBXcml0ZXMgYSBwYWNrZXQuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBwYWNrZXRcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIE1hbmFnZXIucHJvdG90eXBlLnBhY2tldCA9IGZ1bmN0aW9uIChwYWNrZXQpIHtcbiAgICAgICAgICBkZWJ1Zygnd3JpdGluZyBwYWNrZXQgJWonLCBwYWNrZXQpO1xuICAgICAgICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgICAgICAgIGlmICghc2VsZi5lbmNvZGluZykge1xuICAgICAgICAgICAgLy8gZW5jb2RlLCB0aGVuIHdyaXRlIHRvIGVuZ2luZSB3aXRoIHJlc3VsdFxuICAgICAgICAgICAgc2VsZi5lbmNvZGluZyA9IHRydWU7XG4gICAgICAgICAgICB0aGlzLmVuY29kZXIuZW5jb2RlKHBhY2tldCwgZnVuY3Rpb24gKGVuY29kZWRQYWNrZXRzKSB7XG4gICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgZW5jb2RlZFBhY2tldHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICBzZWxmLmVuZ2luZS53cml0ZShlbmNvZGVkUGFja2V0c1tpXSwgcGFja2V0Lm9wdGlvbnMpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHNlbGYuZW5jb2RpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgc2VsZi5wcm9jZXNzUGFja2V0UXVldWUoKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBhZGQgcGFja2V0IHRvIHRoZSBxdWV1ZVxuICAgICAgICAgICAgc2VsZi5wYWNrZXRCdWZmZXIucHVzaChwYWNrZXQpO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogSWYgcGFja2V0IGJ1ZmZlciBpcyBub24tZW1wdHksIGJlZ2lucyBlbmNvZGluZyB0aGVcbiAgICAgICAgICogbmV4dCBwYWNrZXQgaW4gbGluZS5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIE1hbmFnZXIucHJvdG90eXBlLnByb2Nlc3NQYWNrZXRRdWV1ZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBpZiAodGhpcy5wYWNrZXRCdWZmZXIubGVuZ3RoID4gMCAmJiAhdGhpcy5lbmNvZGluZykge1xuICAgICAgICAgICAgdmFyIHBhY2sgPSB0aGlzLnBhY2tldEJ1ZmZlci5zaGlmdCgpO1xuICAgICAgICAgICAgdGhpcy5wYWNrZXQocGFjayk7XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDbGVhbiB1cCB0cmFuc3BvcnQgc3Vic2NyaXB0aW9ucyBhbmQgcGFja2V0IGJ1ZmZlci5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIE1hbmFnZXIucHJvdG90eXBlLmNsZWFudXAgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgZGVidWcoJ2NsZWFudXAnKTtcblxuICAgICAgICAgIHZhciBzdWI7XG4gICAgICAgICAgd2hpbGUgKHN1YiA9IHRoaXMuc3Vicy5zaGlmdCgpKSBzdWIuZGVzdHJveSgpO1xuXG4gICAgICAgICAgdGhpcy5wYWNrZXRCdWZmZXIgPSBbXTtcbiAgICAgICAgICB0aGlzLmVuY29kaW5nID0gZmFsc2U7XG4gICAgICAgICAgdGhpcy5sYXN0UGluZyA9IG51bGw7XG5cbiAgICAgICAgICB0aGlzLmRlY29kZXIuZGVzdHJveSgpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDbG9zZSB0aGUgY3VycmVudCBzb2NrZXQuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgKi9cblxuICAgICAgICBNYW5hZ2VyLnByb3RvdHlwZS5jbG9zZSA9IE1hbmFnZXIucHJvdG90eXBlLmRpc2Nvbm5lY3QgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgZGVidWcoJ2Rpc2Nvbm5lY3QnKTtcbiAgICAgICAgICB0aGlzLnNraXBSZWNvbm5lY3QgPSB0cnVlO1xuICAgICAgICAgIHRoaXMucmVjb25uZWN0aW5nID0gZmFsc2U7XG4gICAgICAgICAgaWYgKCdvcGVuaW5nJyA9PSB0aGlzLnJlYWR5U3RhdGUpIHtcbiAgICAgICAgICAgIC8vIGBvbmNsb3NlYCB3aWxsIG5vdCBmaXJlIGJlY2F1c2VcbiAgICAgICAgICAgIC8vIGFuIG9wZW4gZXZlbnQgbmV2ZXIgaGFwcGVuZWRcbiAgICAgICAgICAgIHRoaXMuY2xlYW51cCgpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLmJhY2tvZmYucmVzZXQoKTtcbiAgICAgICAgICB0aGlzLnJlYWR5U3RhdGUgPSAnY2xvc2VkJztcbiAgICAgICAgICBpZiAodGhpcy5lbmdpbmUpIHRoaXMuZW5naW5lLmNsb3NlKCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENhbGxlZCB1cG9uIGVuZ2luZSBjbG9zZS5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIE1hbmFnZXIucHJvdG90eXBlLm9uY2xvc2UgPSBmdW5jdGlvbiAocmVhc29uKSB7XG4gICAgICAgICAgZGVidWcoJ29uY2xvc2UnKTtcblxuICAgICAgICAgIHRoaXMuY2xlYW51cCgpO1xuICAgICAgICAgIHRoaXMuYmFja29mZi5yZXNldCgpO1xuICAgICAgICAgIHRoaXMucmVhZHlTdGF0ZSA9ICdjbG9zZWQnO1xuICAgICAgICAgIHRoaXMuZW1pdCgnY2xvc2UnLCByZWFzb24pO1xuXG4gICAgICAgICAgaWYgKHRoaXMuX3JlY29ubmVjdGlvbiAmJiAhdGhpcy5za2lwUmVjb25uZWN0KSB7XG4gICAgICAgICAgICB0aGlzLnJlY29ubmVjdCgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQXR0ZW1wdCBhIHJlY29ubmVjdGlvbi5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIE1hbmFnZXIucHJvdG90eXBlLnJlY29ubmVjdCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBpZiAodGhpcy5yZWNvbm5lY3RpbmcgfHwgdGhpcy5za2lwUmVjb25uZWN0KSByZXR1cm4gdGhpcztcblxuICAgICAgICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgICAgICAgIGlmICh0aGlzLmJhY2tvZmYuYXR0ZW1wdHMgPj0gdGhpcy5fcmVjb25uZWN0aW9uQXR0ZW1wdHMpIHtcbiAgICAgICAgICAgIGRlYnVnKCdyZWNvbm5lY3QgZmFpbGVkJyk7XG4gICAgICAgICAgICB0aGlzLmJhY2tvZmYucmVzZXQoKTtcbiAgICAgICAgICAgIHRoaXMuZW1pdEFsbCgncmVjb25uZWN0X2ZhaWxlZCcpO1xuICAgICAgICAgICAgdGhpcy5yZWNvbm5lY3RpbmcgPSBmYWxzZTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdmFyIGRlbGF5ID0gdGhpcy5iYWNrb2ZmLmR1cmF0aW9uKCk7XG4gICAgICAgICAgICBkZWJ1Zygnd2lsbCB3YWl0ICVkbXMgYmVmb3JlIHJlY29ubmVjdCBhdHRlbXB0JywgZGVsYXkpO1xuXG4gICAgICAgICAgICB0aGlzLnJlY29ubmVjdGluZyA9IHRydWU7XG4gICAgICAgICAgICB2YXIgdGltZXIgPSBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgaWYgKHNlbGYuc2tpcFJlY29ubmVjdCkgcmV0dXJuO1xuXG4gICAgICAgICAgICAgIGRlYnVnKCdhdHRlbXB0aW5nIHJlY29ubmVjdCcpO1xuICAgICAgICAgICAgICBzZWxmLmVtaXRBbGwoJ3JlY29ubmVjdF9hdHRlbXB0Jywgc2VsZi5iYWNrb2ZmLmF0dGVtcHRzKTtcbiAgICAgICAgICAgICAgc2VsZi5lbWl0QWxsKCdyZWNvbm5lY3RpbmcnLCBzZWxmLmJhY2tvZmYuYXR0ZW1wdHMpO1xuXG4gICAgICAgICAgICAgIC8vIGNoZWNrIGFnYWluIGZvciB0aGUgY2FzZSBzb2NrZXQgY2xvc2VkIGluIGFib3ZlIGV2ZW50c1xuICAgICAgICAgICAgICBpZiAoc2VsZi5za2lwUmVjb25uZWN0KSByZXR1cm47XG5cbiAgICAgICAgICAgICAgc2VsZi5vcGVuKGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgICAgICAgICAgICBpZiAoZXJyKSB7XG4gICAgICAgICAgICAgICAgICBkZWJ1ZygncmVjb25uZWN0IGF0dGVtcHQgZXJyb3InKTtcbiAgICAgICAgICAgICAgICAgIHNlbGYucmVjb25uZWN0aW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICBzZWxmLnJlY29ubmVjdCgpO1xuICAgICAgICAgICAgICAgICAgc2VsZi5lbWl0QWxsKCdyZWNvbm5lY3RfZXJyb3InLCBlcnIuZGF0YSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIGRlYnVnKCdyZWNvbm5lY3Qgc3VjY2VzcycpO1xuICAgICAgICAgICAgICAgICAgc2VsZi5vbnJlY29ubmVjdCgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9LCBkZWxheSk7XG5cbiAgICAgICAgICAgIHRoaXMuc3Vicy5wdXNoKHtcbiAgICAgICAgICAgICAgZGVzdHJveTogZnVuY3Rpb24gZGVzdHJveSgpIHtcbiAgICAgICAgICAgICAgICBjbGVhclRpbWVvdXQodGltZXIpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENhbGxlZCB1cG9uIHN1Y2Nlc3NmdWwgcmVjb25uZWN0LlxuICAgICAgICAgKlxuICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICovXG5cbiAgICAgICAgTWFuYWdlci5wcm90b3R5cGUub25yZWNvbm5lY3QgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgdmFyIGF0dGVtcHQgPSB0aGlzLmJhY2tvZmYuYXR0ZW1wdHM7XG4gICAgICAgICAgdGhpcy5yZWNvbm5lY3RpbmcgPSBmYWxzZTtcbiAgICAgICAgICB0aGlzLmJhY2tvZmYucmVzZXQoKTtcbiAgICAgICAgICB0aGlzLnVwZGF0ZVNvY2tldElkcygpO1xuICAgICAgICAgIHRoaXMuZW1pdEFsbCgncmVjb25uZWN0JywgYXR0ZW1wdCk7XG4gICAgICAgIH07XG4gICAgICB9LCB7IFwiLi9vblwiOiAzMywgXCIuL3NvY2tldFwiOiAzNCwgXCJiYWNrbzJcIjogMzYsIFwiY29tcG9uZW50LWJpbmRcIjogMzcsIFwiY29tcG9uZW50LWVtaXR0ZXJcIjogMzgsIFwiZGVidWdcIjogMzksIFwiZW5naW5lLmlvLWNsaWVudFwiOiAxLCBcImluZGV4b2ZcIjogNDIsIFwic29ja2V0LmlvLXBhcnNlclwiOiA0NyB9XSwgMzM6IFtmdW5jdGlvbiAoX2RlcmVxXywgbW9kdWxlLCBleHBvcnRzKSB7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIE1vZHVsZSBleHBvcnRzLlxuICAgICAgICAgKi9cblxuICAgICAgICBtb2R1bGUuZXhwb3J0cyA9IG9uO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBIZWxwZXIgZm9yIHN1YnNjcmlwdGlvbnMuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0fEV2ZW50RW1pdHRlcn0gb2JqIHdpdGggYEVtaXR0ZXJgIG1peGluIG9yIGBFdmVudEVtaXR0ZXJgXG4gICAgICAgICAqIEBwYXJhbSB7U3RyaW5nfSBldmVudCBuYW1lXG4gICAgICAgICAqIEBwYXJhbSB7RnVuY3Rpb259IGNhbGxiYWNrXG4gICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAqL1xuXG4gICAgICAgIGZ1bmN0aW9uIG9uKG9iaiwgZXYsIGZuKSB7XG4gICAgICAgICAgb2JqLm9uKGV2LCBmbik7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGRlc3Ryb3k6IGZ1bmN0aW9uIGRlc3Ryb3koKSB7XG4gICAgICAgICAgICAgIG9iai5yZW1vdmVMaXN0ZW5lcihldiwgZm4pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgIH0sIHt9XSwgMzQ6IFtmdW5jdGlvbiAoX2RlcmVxXywgbW9kdWxlLCBleHBvcnRzKSB7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIE1vZHVsZSBkZXBlbmRlbmNpZXMuXG4gICAgICAgICAqL1xuXG4gICAgICAgIHZhciBwYXJzZXIgPSBfZGVyZXFfKCdzb2NrZXQuaW8tcGFyc2VyJyk7XG4gICAgICAgIHZhciBFbWl0dGVyID0gX2RlcmVxXygnY29tcG9uZW50LWVtaXR0ZXInKTtcbiAgICAgICAgdmFyIHRvQXJyYXkgPSBfZGVyZXFfKCd0by1hcnJheScpO1xuICAgICAgICB2YXIgb24gPSBfZGVyZXFfKCcuL29uJyk7XG4gICAgICAgIHZhciBiaW5kID0gX2RlcmVxXygnY29tcG9uZW50LWJpbmQnKTtcbiAgICAgICAgdmFyIGRlYnVnID0gX2RlcmVxXygnZGVidWcnKSgnc29ja2V0LmlvLWNsaWVudDpzb2NrZXQnKTtcbiAgICAgICAgdmFyIGhhc0JpbiA9IF9kZXJlcV8oJ2hhcy1iaW5hcnknKTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogTW9kdWxlIGV4cG9ydHMuXG4gICAgICAgICAqL1xuXG4gICAgICAgIG1vZHVsZS5leHBvcnRzID0gZXhwb3J0cyA9IFNvY2tldDtcblxuICAgICAgICAvKipcbiAgICAgICAgICogSW50ZXJuYWwgZXZlbnRzIChibGFja2xpc3RlZCkuXG4gICAgICAgICAqIFRoZXNlIGV2ZW50cyBjYW4ndCBiZSBlbWl0dGVkIGJ5IHRoZSB1c2VyLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICovXG5cbiAgICAgICAgdmFyIGV2ZW50cyA9IHtcbiAgICAgICAgICBjb25uZWN0OiAxLFxuICAgICAgICAgIGNvbm5lY3RfZXJyb3I6IDEsXG4gICAgICAgICAgY29ubmVjdF90aW1lb3V0OiAxLFxuICAgICAgICAgIGNvbm5lY3Rpbmc6IDEsXG4gICAgICAgICAgZGlzY29ubmVjdDogMSxcbiAgICAgICAgICBlcnJvcjogMSxcbiAgICAgICAgICByZWNvbm5lY3Q6IDEsXG4gICAgICAgICAgcmVjb25uZWN0X2F0dGVtcHQ6IDEsXG4gICAgICAgICAgcmVjb25uZWN0X2ZhaWxlZDogMSxcbiAgICAgICAgICByZWNvbm5lY3RfZXJyb3I6IDEsXG4gICAgICAgICAgcmVjb25uZWN0aW5nOiAxLFxuICAgICAgICAgIHBpbmc6IDEsXG4gICAgICAgICAgcG9uZzogMVxuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBTaG9ydGN1dCB0byBgRW1pdHRlciNlbWl0YC5cbiAgICAgICAgICovXG5cbiAgICAgICAgdmFyIGVtaXQgPSBFbWl0dGVyLnByb3RvdHlwZS5lbWl0O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBgU29ja2V0YCBjb25zdHJ1Y3Rvci5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgZnVuY3Rpb24gU29ja2V0KGlvLCBuc3ApIHtcbiAgICAgICAgICB0aGlzLmlvID0gaW87XG4gICAgICAgICAgdGhpcy5uc3AgPSBuc3A7XG4gICAgICAgICAgdGhpcy5qc29uID0gdGhpczsgLy8gY29tcGF0XG4gICAgICAgICAgdGhpcy5pZHMgPSAwO1xuICAgICAgICAgIHRoaXMuYWNrcyA9IHt9O1xuICAgICAgICAgIHRoaXMucmVjZWl2ZUJ1ZmZlciA9IFtdO1xuICAgICAgICAgIHRoaXMuc2VuZEJ1ZmZlciA9IFtdO1xuICAgICAgICAgIHRoaXMuY29ubmVjdGVkID0gZmFsc2U7XG4gICAgICAgICAgdGhpcy5kaXNjb25uZWN0ZWQgPSB0cnVlO1xuICAgICAgICAgIGlmICh0aGlzLmlvLmF1dG9Db25uZWN0KSB0aGlzLm9wZW4oKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBNaXggaW4gYEVtaXR0ZXJgLlxuICAgICAgICAgKi9cblxuICAgICAgICBFbWl0dGVyKFNvY2tldC5wcm90b3R5cGUpO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBTdWJzY3JpYmUgdG8gb3BlbiwgY2xvc2UgYW5kIHBhY2tldCBldmVudHNcbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIFNvY2tldC5wcm90b3R5cGUuc3ViRXZlbnRzID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIGlmICh0aGlzLnN1YnMpIHJldHVybjtcblxuICAgICAgICAgIHZhciBpbyA9IHRoaXMuaW87XG4gICAgICAgICAgdGhpcy5zdWJzID0gW29uKGlvLCAnb3BlbicsIGJpbmQodGhpcywgJ29ub3BlbicpKSwgb24oaW8sICdwYWNrZXQnLCBiaW5kKHRoaXMsICdvbnBhY2tldCcpKSwgb24oaW8sICdjbG9zZScsIGJpbmQodGhpcywgJ29uY2xvc2UnKSldO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBcIk9wZW5zXCIgdGhlIHNvY2tldC5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgU29ja2V0LnByb3RvdHlwZS5vcGVuID0gU29ja2V0LnByb3RvdHlwZS5jb25uZWN0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIGlmICh0aGlzLmNvbm5lY3RlZCkgcmV0dXJuIHRoaXM7XG5cbiAgICAgICAgICB0aGlzLnN1YkV2ZW50cygpO1xuICAgICAgICAgIHRoaXMuaW8ub3BlbigpOyAvLyBlbnN1cmUgb3BlblxuICAgICAgICAgIGlmICgnb3BlbicgPT0gdGhpcy5pby5yZWFkeVN0YXRlKSB0aGlzLm9ub3BlbigpO1xuICAgICAgICAgIHRoaXMuZW1pdCgnY29ubmVjdGluZycpO1xuICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBTZW5kcyBhIGBtZXNzYWdlYCBldmVudC5cbiAgICAgICAgICpcbiAgICAgICAgICogQHJldHVybiB7U29ja2V0fSBzZWxmXG4gICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAqL1xuXG4gICAgICAgIFNvY2tldC5wcm90b3R5cGUuc2VuZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICB2YXIgYXJncyA9IHRvQXJyYXkoYXJndW1lbnRzKTtcbiAgICAgICAgICBhcmdzLnVuc2hpZnQoJ21lc3NhZ2UnKTtcbiAgICAgICAgICB0aGlzLmVtaXQuYXBwbHkodGhpcywgYXJncyk7XG4gICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIE92ZXJyaWRlIGBlbWl0YC5cbiAgICAgICAgICogSWYgdGhlIGV2ZW50IGlzIGluIGBldmVudHNgLCBpdCdzIGVtaXR0ZWQgbm9ybWFsbHkuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7U3RyaW5nfSBldmVudCBuYW1lXG4gICAgICAgICAqIEByZXR1cm4ge1NvY2tldH0gc2VsZlxuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cblxuICAgICAgICBTb2NrZXQucHJvdG90eXBlLmVtaXQgPSBmdW5jdGlvbiAoZXYpIHtcbiAgICAgICAgICBpZiAoZXZlbnRzLmhhc093blByb3BlcnR5KGV2KSkge1xuICAgICAgICAgICAgZW1pdC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgdmFyIGFyZ3MgPSB0b0FycmF5KGFyZ3VtZW50cyk7XG4gICAgICAgICAgdmFyIHBhcnNlclR5cGUgPSBwYXJzZXIuRVZFTlQ7IC8vIGRlZmF1bHRcbiAgICAgICAgICBpZiAoaGFzQmluKGFyZ3MpKSB7XG4gICAgICAgICAgICBwYXJzZXJUeXBlID0gcGFyc2VyLkJJTkFSWV9FVkVOVDtcbiAgICAgICAgICB9IC8vIGJpbmFyeVxuICAgICAgICAgIHZhciBwYWNrZXQgPSB7IHR5cGU6IHBhcnNlclR5cGUsIGRhdGE6IGFyZ3MgfTtcblxuICAgICAgICAgIHBhY2tldC5vcHRpb25zID0ge307XG4gICAgICAgICAgcGFja2V0Lm9wdGlvbnMuY29tcHJlc3MgPSAhdGhpcy5mbGFncyB8fCBmYWxzZSAhPT0gdGhpcy5mbGFncy5jb21wcmVzcztcblxuICAgICAgICAgIC8vIGV2ZW50IGFjayBjYWxsYmFja1xuICAgICAgICAgIGlmICgnZnVuY3Rpb24nID09IHR5cGVvZiBhcmdzW2FyZ3MubGVuZ3RoIC0gMV0pIHtcbiAgICAgICAgICAgIGRlYnVnKCdlbWl0dGluZyBwYWNrZXQgd2l0aCBhY2sgaWQgJWQnLCB0aGlzLmlkcyk7XG4gICAgICAgICAgICB0aGlzLmFja3NbdGhpcy5pZHNdID0gYXJncy5wb3AoKTtcbiAgICAgICAgICAgIHBhY2tldC5pZCA9IHRoaXMuaWRzKys7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKHRoaXMuY29ubmVjdGVkKSB7XG4gICAgICAgICAgICB0aGlzLnBhY2tldChwYWNrZXQpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnNlbmRCdWZmZXIucHVzaChwYWNrZXQpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGRlbGV0ZSB0aGlzLmZsYWdzO1xuXG4gICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFNlbmRzIGEgcGFja2V0LlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ge09iamVjdH0gcGFja2V0XG4gICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgKi9cblxuICAgICAgICBTb2NrZXQucHJvdG90eXBlLnBhY2tldCA9IGZ1bmN0aW9uIChwYWNrZXQpIHtcbiAgICAgICAgICBwYWNrZXQubnNwID0gdGhpcy5uc3A7XG4gICAgICAgICAgdGhpcy5pby5wYWNrZXQocGFja2V0KTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ2FsbGVkIHVwb24gZW5naW5lIGBvcGVuYC5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIFNvY2tldC5wcm90b3R5cGUub25vcGVuID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIGRlYnVnKCd0cmFuc3BvcnQgaXMgb3BlbiAtIGNvbm5lY3RpbmcnKTtcblxuICAgICAgICAgIC8vIHdyaXRlIGNvbm5lY3QgcGFja2V0IGlmIG5lY2Vzc2FyeVxuICAgICAgICAgIGlmICgnLycgIT0gdGhpcy5uc3ApIHtcbiAgICAgICAgICAgIHRoaXMucGFja2V0KHsgdHlwZTogcGFyc2VyLkNPTk5FQ1QgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDYWxsZWQgdXBvbiBlbmdpbmUgYGNsb3NlYC5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtTdHJpbmd9IHJlYXNvblxuICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICovXG5cbiAgICAgICAgU29ja2V0LnByb3RvdHlwZS5vbmNsb3NlID0gZnVuY3Rpb24gKHJlYXNvbikge1xuICAgICAgICAgIGRlYnVnKCdjbG9zZSAoJXMpJywgcmVhc29uKTtcbiAgICAgICAgICB0aGlzLmNvbm5lY3RlZCA9IGZhbHNlO1xuICAgICAgICAgIHRoaXMuZGlzY29ubmVjdGVkID0gdHJ1ZTtcbiAgICAgICAgICBkZWxldGUgdGhpcy5pZDtcbiAgICAgICAgICB0aGlzLmVtaXQoJ2Rpc2Nvbm5lY3QnLCByZWFzb24pO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDYWxsZWQgd2l0aCBzb2NrZXQgcGFja2V0LlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ge09iamVjdH0gcGFja2V0XG4gICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgKi9cblxuICAgICAgICBTb2NrZXQucHJvdG90eXBlLm9ucGFja2V0ID0gZnVuY3Rpb24gKHBhY2tldCkge1xuICAgICAgICAgIGlmIChwYWNrZXQubnNwICE9IHRoaXMubnNwKSByZXR1cm47XG5cbiAgICAgICAgICBzd2l0Y2ggKHBhY2tldC50eXBlKSB7XG4gICAgICAgICAgICBjYXNlIHBhcnNlci5DT05ORUNUOlxuICAgICAgICAgICAgICB0aGlzLm9uY29ubmVjdCgpO1xuICAgICAgICAgICAgICBicmVhaztcblxuICAgICAgICAgICAgY2FzZSBwYXJzZXIuRVZFTlQ6XG4gICAgICAgICAgICAgIHRoaXMub25ldmVudChwYWNrZXQpO1xuICAgICAgICAgICAgICBicmVhaztcblxuICAgICAgICAgICAgY2FzZSBwYXJzZXIuQklOQVJZX0VWRU5UOlxuICAgICAgICAgICAgICB0aGlzLm9uZXZlbnQocGFja2V0KTtcbiAgICAgICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgICAgIGNhc2UgcGFyc2VyLkFDSzpcbiAgICAgICAgICAgICAgdGhpcy5vbmFjayhwYWNrZXQpO1xuICAgICAgICAgICAgICBicmVhaztcblxuICAgICAgICAgICAgY2FzZSBwYXJzZXIuQklOQVJZX0FDSzpcbiAgICAgICAgICAgICAgdGhpcy5vbmFjayhwYWNrZXQpO1xuICAgICAgICAgICAgICBicmVhaztcblxuICAgICAgICAgICAgY2FzZSBwYXJzZXIuRElTQ09OTkVDVDpcbiAgICAgICAgICAgICAgdGhpcy5vbmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgICAgIGNhc2UgcGFyc2VyLkVSUk9SOlxuICAgICAgICAgICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgcGFja2V0LmRhdGEpO1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENhbGxlZCB1cG9uIGEgc2VydmVyIGV2ZW50LlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ge09iamVjdH0gcGFja2V0XG4gICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgKi9cblxuICAgICAgICBTb2NrZXQucHJvdG90eXBlLm9uZXZlbnQgPSBmdW5jdGlvbiAocGFja2V0KSB7XG4gICAgICAgICAgdmFyIGFyZ3MgPSBwYWNrZXQuZGF0YSB8fCBbXTtcbiAgICAgICAgICBkZWJ1ZygnZW1pdHRpbmcgZXZlbnQgJWonLCBhcmdzKTtcblxuICAgICAgICAgIGlmIChudWxsICE9IHBhY2tldC5pZCkge1xuICAgICAgICAgICAgZGVidWcoJ2F0dGFjaGluZyBhY2sgY2FsbGJhY2sgdG8gZXZlbnQnKTtcbiAgICAgICAgICAgIGFyZ3MucHVzaCh0aGlzLmFjayhwYWNrZXQuaWQpKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAodGhpcy5jb25uZWN0ZWQpIHtcbiAgICAgICAgICAgIGVtaXQuYXBwbHkodGhpcywgYXJncyk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMucmVjZWl2ZUJ1ZmZlci5wdXNoKGFyZ3MpO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogUHJvZHVjZXMgYW4gYWNrIGNhbGxiYWNrIHRvIGVtaXQgd2l0aCBhbiBldmVudC5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIFNvY2tldC5wcm90b3R5cGUuYWNrID0gZnVuY3Rpb24gKGlkKSB7XG4gICAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICAgIHZhciBzZW50ID0gZmFsc2U7XG4gICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIC8vIHByZXZlbnQgZG91YmxlIGNhbGxiYWNrc1xuICAgICAgICAgICAgaWYgKHNlbnQpIHJldHVybjtcbiAgICAgICAgICAgIHNlbnQgPSB0cnVlO1xuICAgICAgICAgICAgdmFyIGFyZ3MgPSB0b0FycmF5KGFyZ3VtZW50cyk7XG4gICAgICAgICAgICBkZWJ1Zygnc2VuZGluZyBhY2sgJWonLCBhcmdzKTtcblxuICAgICAgICAgICAgdmFyIHR5cGUgPSBoYXNCaW4oYXJncykgPyBwYXJzZXIuQklOQVJZX0FDSyA6IHBhcnNlci5BQ0s7XG4gICAgICAgICAgICBzZWxmLnBhY2tldCh7XG4gICAgICAgICAgICAgIHR5cGU6IHR5cGUsXG4gICAgICAgICAgICAgIGlkOiBpZCxcbiAgICAgICAgICAgICAgZGF0YTogYXJnc1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ2FsbGVkIHVwb24gYSBzZXJ2ZXIgYWNrbm93bGVnZW1lbnQuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBwYWNrZXRcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIFNvY2tldC5wcm90b3R5cGUub25hY2sgPSBmdW5jdGlvbiAocGFja2V0KSB7XG4gICAgICAgICAgdmFyIGFjayA9IHRoaXMuYWNrc1twYWNrZXQuaWRdO1xuICAgICAgICAgIGlmICgnZnVuY3Rpb24nID09IHR5cGVvZiBhY2spIHtcbiAgICAgICAgICAgIGRlYnVnKCdjYWxsaW5nIGFjayAlcyB3aXRoICVqJywgcGFja2V0LmlkLCBwYWNrZXQuZGF0YSk7XG4gICAgICAgICAgICBhY2suYXBwbHkodGhpcywgcGFja2V0LmRhdGEpO1xuICAgICAgICAgICAgZGVsZXRlIHRoaXMuYWNrc1twYWNrZXQuaWRdO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBkZWJ1ZygnYmFkIGFjayAlcycsIHBhY2tldC5pZCk7XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDYWxsZWQgdXBvbiBzZXJ2ZXIgY29ubmVjdC5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIFNvY2tldC5wcm90b3R5cGUub25jb25uZWN0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHRoaXMuY29ubmVjdGVkID0gdHJ1ZTtcbiAgICAgICAgICB0aGlzLmRpc2Nvbm5lY3RlZCA9IGZhbHNlO1xuICAgICAgICAgIHRoaXMuZW1pdCgnY29ubmVjdCcpO1xuICAgICAgICAgIHRoaXMuZW1pdEJ1ZmZlcmVkKCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEVtaXQgYnVmZmVyZWQgZXZlbnRzIChyZWNlaXZlZCBhbmQgZW1pdHRlZCkuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgKi9cblxuICAgICAgICBTb2NrZXQucHJvdG90eXBlLmVtaXRCdWZmZXJlZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICB2YXIgaTtcbiAgICAgICAgICBmb3IgKGkgPSAwOyBpIDwgdGhpcy5yZWNlaXZlQnVmZmVyLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBlbWl0LmFwcGx5KHRoaXMsIHRoaXMucmVjZWl2ZUJ1ZmZlcltpXSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRoaXMucmVjZWl2ZUJ1ZmZlciA9IFtdO1xuXG4gICAgICAgICAgZm9yIChpID0gMDsgaSA8IHRoaXMuc2VuZEJ1ZmZlci5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgdGhpcy5wYWNrZXQodGhpcy5zZW5kQnVmZmVyW2ldKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhpcy5zZW5kQnVmZmVyID0gW107XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENhbGxlZCB1cG9uIHNlcnZlciBkaXNjb25uZWN0LlxuICAgICAgICAgKlxuICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICovXG5cbiAgICAgICAgU29ja2V0LnByb3RvdHlwZS5vbmRpc2Nvbm5lY3QgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgZGVidWcoJ3NlcnZlciBkaXNjb25uZWN0ICglcyknLCB0aGlzLm5zcCk7XG4gICAgICAgICAgdGhpcy5kZXN0cm95KCk7XG4gICAgICAgICAgdGhpcy5vbmNsb3NlKCdpbyBzZXJ2ZXIgZGlzY29ubmVjdCcpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDYWxsZWQgdXBvbiBmb3JjZWQgY2xpZW50L3NlcnZlciBzaWRlIGRpc2Nvbm5lY3Rpb25zLFxuICAgICAgICAgKiB0aGlzIG1ldGhvZCBlbnN1cmVzIHRoZSBtYW5hZ2VyIHN0b3BzIHRyYWNraW5nIHVzIGFuZFxuICAgICAgICAgKiB0aGF0IHJlY29ubmVjdGlvbnMgZG9uJ3QgZ2V0IHRyaWdnZXJlZCBmb3IgdGhpcy5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwcml2YXRlLlxuICAgICAgICAgKi9cblxuICAgICAgICBTb2NrZXQucHJvdG90eXBlLmRlc3Ryb3kgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgaWYgKHRoaXMuc3Vicykge1xuICAgICAgICAgICAgLy8gY2xlYW4gc3Vic2NyaXB0aW9ucyB0byBhdm9pZCByZWNvbm5lY3Rpb25zXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMuc3Vicy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICB0aGlzLnN1YnNbaV0uZGVzdHJveSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5zdWJzID0gbnVsbDtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICB0aGlzLmlvLmRlc3Ryb3kodGhpcyk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERpc2Nvbm5lY3RzIHRoZSBzb2NrZXQgbWFudWFsbHkuXG4gICAgICAgICAqXG4gICAgICAgICAqIEByZXR1cm4ge1NvY2tldH0gc2VsZlxuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cblxuICAgICAgICBTb2NrZXQucHJvdG90eXBlLmNsb3NlID0gU29ja2V0LnByb3RvdHlwZS5kaXNjb25uZWN0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIGlmICh0aGlzLmNvbm5lY3RlZCkge1xuICAgICAgICAgICAgZGVidWcoJ3BlcmZvcm1pbmcgZGlzY29ubmVjdCAoJXMpJywgdGhpcy5uc3ApO1xuICAgICAgICAgICAgdGhpcy5wYWNrZXQoeyB0eXBlOiBwYXJzZXIuRElTQ09OTkVDVCB9KTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyByZW1vdmUgc29ja2V0IGZyb20gcG9vbFxuICAgICAgICAgIHRoaXMuZGVzdHJveSgpO1xuXG4gICAgICAgICAgaWYgKHRoaXMuY29ubmVjdGVkKSB7XG4gICAgICAgICAgICAvLyBmaXJlIGV2ZW50c1xuICAgICAgICAgICAgdGhpcy5vbmNsb3NlKCdpbyBjbGllbnQgZGlzY29ubmVjdCcpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogU2V0cyB0aGUgY29tcHJlc3MgZmxhZy5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtCb29sZWFufSBpZiBgdHJ1ZWAsIGNvbXByZXNzZXMgdGhlIHNlbmRpbmcgZGF0YVxuICAgICAgICAgKiBAcmV0dXJuIHtTb2NrZXR9IHNlbGZcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgU29ja2V0LnByb3RvdHlwZS5jb21wcmVzcyA9IGZ1bmN0aW9uIChjb21wcmVzcykge1xuICAgICAgICAgIHRoaXMuZmxhZ3MgPSB0aGlzLmZsYWdzIHx8IHt9O1xuICAgICAgICAgIHRoaXMuZmxhZ3MuY29tcHJlc3MgPSBjb21wcmVzcztcbiAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfTtcbiAgICAgIH0sIHsgXCIuL29uXCI6IDMzLCBcImNvbXBvbmVudC1iaW5kXCI6IDM3LCBcImNvbXBvbmVudC1lbWl0dGVyXCI6IDM4LCBcImRlYnVnXCI6IDM5LCBcImhhcy1iaW5hcnlcIjogNDEsIFwic29ja2V0LmlvLXBhcnNlclwiOiA0NywgXCJ0by1hcnJheVwiOiA1MSB9XSwgMzU6IFtmdW5jdGlvbiAoX2RlcmVxXywgbW9kdWxlLCBleHBvcnRzKSB7XG4gICAgICAgIChmdW5jdGlvbiAoZ2xvYmFsKSB7XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBNb2R1bGUgZGVwZW5kZW5jaWVzLlxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgdmFyIHBhcnNldXJpID0gX2RlcmVxXygncGFyc2V1cmknKTtcbiAgICAgICAgICB2YXIgZGVidWcgPSBfZGVyZXFfKCdkZWJ1ZycpKCdzb2NrZXQuaW8tY2xpZW50OnVybCcpO1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogTW9kdWxlIGV4cG9ydHMuXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBtb2R1bGUuZXhwb3J0cyA9IHVybDtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIFVSTCBwYXJzZXIuXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAcGFyYW0ge1N0cmluZ30gdXJsXG4gICAgICAgICAgICogQHBhcmFtIHtPYmplY3R9IEFuIG9iamVjdCBtZWFudCB0byBtaW1pYyB3aW5kb3cubG9jYXRpb24uXG4gICAgICAgICAgICogICAgICAgICAgICAgICAgIERlZmF1bHRzIHRvIHdpbmRvdy5sb2NhdGlvbi5cbiAgICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgZnVuY3Rpb24gdXJsKHVyaSwgbG9jKSB7XG4gICAgICAgICAgICB2YXIgb2JqID0gdXJpO1xuXG4gICAgICAgICAgICAvLyBkZWZhdWx0IHRvIHdpbmRvdy5sb2NhdGlvblxuICAgICAgICAgICAgdmFyIGxvYyA9IGxvYyB8fCBnbG9iYWwubG9jYXRpb247XG4gICAgICAgICAgICBpZiAobnVsbCA9PSB1cmkpIHVyaSA9IGxvYy5wcm90b2NvbCArICcvLycgKyBsb2MuaG9zdDtcblxuICAgICAgICAgICAgLy8gcmVsYXRpdmUgcGF0aCBzdXBwb3J0XG4gICAgICAgICAgICBpZiAoJ3N0cmluZycgPT0gdHlwZW9mIHVyaSkge1xuICAgICAgICAgICAgICBpZiAoJy8nID09IHVyaS5jaGFyQXQoMCkpIHtcbiAgICAgICAgICAgICAgICBpZiAoJy8nID09IHVyaS5jaGFyQXQoMSkpIHtcbiAgICAgICAgICAgICAgICAgIHVyaSA9IGxvYy5wcm90b2NvbCArIHVyaTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgdXJpID0gbG9jLmhvc3QgKyB1cmk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgaWYgKCEvXihodHRwcz98d3NzPyk6XFwvXFwvLy50ZXN0KHVyaSkpIHtcbiAgICAgICAgICAgICAgICBkZWJ1ZygncHJvdG9jb2wtbGVzcyB1cmwgJXMnLCB1cmkpO1xuICAgICAgICAgICAgICAgIGlmICgndW5kZWZpbmVkJyAhPSB0eXBlb2YgbG9jKSB7XG4gICAgICAgICAgICAgICAgICB1cmkgPSBsb2MucHJvdG9jb2wgKyAnLy8nICsgdXJpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICB1cmkgPSAnaHR0cHM6Ly8nICsgdXJpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIC8vIHBhcnNlXG4gICAgICAgICAgICAgIGRlYnVnKCdwYXJzZSAlcycsIHVyaSk7XG4gICAgICAgICAgICAgIG9iaiA9IHBhcnNldXJpKHVyaSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIG1ha2Ugc3VyZSB3ZSB0cmVhdCBgbG9jYWxob3N0OjgwYCBhbmQgYGxvY2FsaG9zdGAgZXF1YWxseVxuICAgICAgICAgICAgaWYgKCFvYmoucG9ydCkge1xuICAgICAgICAgICAgICBpZiAoL14oaHR0cHx3cykkLy50ZXN0KG9iai5wcm90b2NvbCkpIHtcbiAgICAgICAgICAgICAgICBvYmoucG9ydCA9ICc4MCc7XG4gICAgICAgICAgICAgIH0gZWxzZSBpZiAoL14oaHR0cHx3cylzJC8udGVzdChvYmoucHJvdG9jb2wpKSB7XG4gICAgICAgICAgICAgICAgb2JqLnBvcnQgPSAnNDQzJztcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBvYmoucGF0aCA9IG9iai5wYXRoIHx8ICcvJztcblxuICAgICAgICAgICAgdmFyIGlwdjYgPSBvYmouaG9zdC5pbmRleE9mKCc6JykgIT09IC0xO1xuICAgICAgICAgICAgdmFyIGhvc3QgPSBpcHY2ID8gJ1snICsgb2JqLmhvc3QgKyAnXScgOiBvYmouaG9zdDtcblxuICAgICAgICAgICAgLy8gZGVmaW5lIHVuaXF1ZSBpZFxuICAgICAgICAgICAgb2JqLmlkID0gb2JqLnByb3RvY29sICsgJzovLycgKyBob3N0ICsgJzonICsgb2JqLnBvcnQ7XG4gICAgICAgICAgICAvLyBkZWZpbmUgaHJlZlxuICAgICAgICAgICAgb2JqLmhyZWYgPSBvYmoucHJvdG9jb2wgKyAnOi8vJyArIGhvc3QgKyAobG9jICYmIGxvYy5wb3J0ID09IG9iai5wb3J0ID8gJycgOiAnOicgKyBvYmoucG9ydCk7XG5cbiAgICAgICAgICAgIHJldHVybiBvYmo7XG4gICAgICAgICAgfVxuICAgICAgICB9KS5jYWxsKHRoaXMsIHR5cGVvZiBzZWxmICE9PSBcInVuZGVmaW5lZFwiID8gc2VsZiA6IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgPyB3aW5kb3cgOiB0eXBlb2YgZ2xvYmFsICE9PSBcInVuZGVmaW5lZFwiID8gZ2xvYmFsIDoge30pO1xuICAgICAgfSwgeyBcImRlYnVnXCI6IDM5LCBcInBhcnNldXJpXCI6IDQ1IH1dLCAzNjogW2Z1bmN0aW9uIChfZGVyZXFfLCBtb2R1bGUsIGV4cG9ydHMpIHtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRXhwb3NlIGBCYWNrb2ZmYC5cbiAgICAgICAgICovXG5cbiAgICAgICAgbW9kdWxlLmV4cG9ydHMgPSBCYWNrb2ZmO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBJbml0aWFsaXplIGJhY2tvZmYgdGltZXIgd2l0aCBgb3B0c2AuXG4gICAgICAgICAqXG4gICAgICAgICAqIC0gYG1pbmAgaW5pdGlhbCB0aW1lb3V0IGluIG1pbGxpc2Vjb25kcyBbMTAwXVxuICAgICAgICAgKiAtIGBtYXhgIG1heCB0aW1lb3V0IFsxMDAwMF1cbiAgICAgICAgICogLSBgaml0dGVyYCBbMF1cbiAgICAgICAgICogLSBgZmFjdG9yYCBbMl1cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3R9IG9wdHNcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgZnVuY3Rpb24gQmFja29mZihvcHRzKSB7XG4gICAgICAgICAgb3B0cyA9IG9wdHMgfHwge307XG4gICAgICAgICAgdGhpcy5tcyA9IG9wdHMubWluIHx8IDEwMDtcbiAgICAgICAgICB0aGlzLm1heCA9IG9wdHMubWF4IHx8IDEwMDAwO1xuICAgICAgICAgIHRoaXMuZmFjdG9yID0gb3B0cy5mYWN0b3IgfHwgMjtcbiAgICAgICAgICB0aGlzLmppdHRlciA9IG9wdHMuaml0dGVyID4gMCAmJiBvcHRzLmppdHRlciA8PSAxID8gb3B0cy5qaXR0ZXIgOiAwO1xuICAgICAgICAgIHRoaXMuYXR0ZW1wdHMgPSAwO1xuICAgICAgICB9XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFJldHVybiB0aGUgYmFja29mZiBkdXJhdGlvbi5cbiAgICAgICAgICpcbiAgICAgICAgICogQHJldHVybiB7TnVtYmVyfVxuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cblxuICAgICAgICBCYWNrb2ZmLnByb3RvdHlwZS5kdXJhdGlvbiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICB2YXIgbXMgPSB0aGlzLm1zICogTWF0aC5wb3codGhpcy5mYWN0b3IsIHRoaXMuYXR0ZW1wdHMrKyk7XG4gICAgICAgICAgaWYgKHRoaXMuaml0dGVyKSB7XG4gICAgICAgICAgICB2YXIgcmFuZCA9IE1hdGgucmFuZG9tKCk7XG4gICAgICAgICAgICB2YXIgZGV2aWF0aW9uID0gTWF0aC5mbG9vcihyYW5kICogdGhpcy5qaXR0ZXIgKiBtcyk7XG4gICAgICAgICAgICBtcyA9IChNYXRoLmZsb29yKHJhbmQgKiAxMCkgJiAxKSA9PSAwID8gbXMgLSBkZXZpYXRpb24gOiBtcyArIGRldmlhdGlvbjtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIE1hdGgubWluKG1zLCB0aGlzLm1heCkgfCAwO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBSZXNldCB0aGUgbnVtYmVyIG9mIGF0dGVtcHRzLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cblxuICAgICAgICBCYWNrb2ZmLnByb3RvdHlwZS5yZXNldCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICB0aGlzLmF0dGVtcHRzID0gMDtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogU2V0IHRoZSBtaW5pbXVtIGR1cmF0aW9uXG4gICAgICAgICAqXG4gICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAqL1xuXG4gICAgICAgIEJhY2tvZmYucHJvdG90eXBlLnNldE1pbiA9IGZ1bmN0aW9uIChtaW4pIHtcbiAgICAgICAgICB0aGlzLm1zID0gbWluO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBTZXQgdGhlIG1heGltdW0gZHVyYXRpb25cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgQmFja29mZi5wcm90b3R5cGUuc2V0TWF4ID0gZnVuY3Rpb24gKG1heCkge1xuICAgICAgICAgIHRoaXMubWF4ID0gbWF4O1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBTZXQgdGhlIGppdHRlclxuICAgICAgICAgKlxuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cblxuICAgICAgICBCYWNrb2ZmLnByb3RvdHlwZS5zZXRKaXR0ZXIgPSBmdW5jdGlvbiAoaml0dGVyKSB7XG4gICAgICAgICAgdGhpcy5qaXR0ZXIgPSBqaXR0ZXI7XG4gICAgICAgIH07XG4gICAgICB9LCB7fV0sIDM3OiBbZnVuY3Rpb24gKF9kZXJlcV8sIG1vZHVsZSwgZXhwb3J0cykge1xuICAgICAgICAvKipcbiAgICAgICAgICogU2xpY2UgcmVmZXJlbmNlLlxuICAgICAgICAgKi9cblxuICAgICAgICB2YXIgc2xpY2UgPSBbXS5zbGljZTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQmluZCBgb2JqYCB0byBgZm5gLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ge09iamVjdH0gb2JqXG4gICAgICAgICAqIEBwYXJhbSB7RnVuY3Rpb258U3RyaW5nfSBmbiBvciBzdHJpbmdcbiAgICAgICAgICogQHJldHVybiB7RnVuY3Rpb259XG4gICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAqL1xuXG4gICAgICAgIG1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKG9iaiwgZm4pIHtcbiAgICAgICAgICBpZiAoJ3N0cmluZycgPT0gdHlwZW9mIGZuKSBmbiA9IG9ialtmbl07XG4gICAgICAgICAgaWYgKCdmdW5jdGlvbicgIT0gdHlwZW9mIGZuKSB0aHJvdyBuZXcgRXJyb3IoJ2JpbmQoKSByZXF1aXJlcyBhIGZ1bmN0aW9uJyk7XG4gICAgICAgICAgdmFyIGFyZ3MgPSBzbGljZS5jYWxsKGFyZ3VtZW50cywgMik7XG4gICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiBmbi5hcHBseShvYmosIGFyZ3MuY29uY2F0KHNsaWNlLmNhbGwoYXJndW1lbnRzKSkpO1xuICAgICAgICAgIH07XG4gICAgICAgIH07XG4gICAgICB9LCB7fV0sIDM4OiBbZnVuY3Rpb24gKF9kZXJlcV8sIG1vZHVsZSwgZXhwb3J0cykge1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFeHBvc2UgYEVtaXR0ZXJgLlxuICAgICAgICAgKi9cblxuICAgICAgICBtb2R1bGUuZXhwb3J0cyA9IEVtaXR0ZXI7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEluaXRpYWxpemUgYSBuZXcgYEVtaXR0ZXJgLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cblxuICAgICAgICBmdW5jdGlvbiBFbWl0dGVyKG9iaikge1xuICAgICAgICAgIGlmIChvYmopIHJldHVybiBtaXhpbihvYmopO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBNaXhpbiB0aGUgZW1pdHRlciBwcm9wZXJ0aWVzLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ge09iamVjdH0gb2JqXG4gICAgICAgICAqIEByZXR1cm4ge09iamVjdH1cbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIGZ1bmN0aW9uIG1peGluKG9iaikge1xuICAgICAgICAgIGZvciAodmFyIGtleSBpbiBFbWl0dGVyLnByb3RvdHlwZSkge1xuICAgICAgICAgICAgb2JqW2tleV0gPSBFbWl0dGVyLnByb3RvdHlwZVtrZXldO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gb2JqO1xuICAgICAgICB9XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIExpc3RlbiBvbiB0aGUgZ2l2ZW4gYGV2ZW50YCB3aXRoIGBmbmAuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7U3RyaW5nfSBldmVudFxuICAgICAgICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBmblxuICAgICAgICAgKiBAcmV0dXJuIHtFbWl0dGVyfVxuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cblxuICAgICAgICBFbWl0dGVyLnByb3RvdHlwZS5vbiA9IEVtaXR0ZXIucHJvdG90eXBlLmFkZEV2ZW50TGlzdGVuZXIgPSBmdW5jdGlvbiAoZXZlbnQsIGZuKSB7XG4gICAgICAgICAgdGhpcy5fY2FsbGJhY2tzID0gdGhpcy5fY2FsbGJhY2tzIHx8IHt9O1xuICAgICAgICAgICh0aGlzLl9jYWxsYmFja3NbJyQnICsgZXZlbnRdID0gdGhpcy5fY2FsbGJhY2tzWyckJyArIGV2ZW50XSB8fCBbXSkucHVzaChmbik7XG4gICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEFkZHMgYW4gYGV2ZW50YCBsaXN0ZW5lciB0aGF0IHdpbGwgYmUgaW52b2tlZCBhIHNpbmdsZVxuICAgICAgICAgKiB0aW1lIHRoZW4gYXV0b21hdGljYWxseSByZW1vdmVkLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ge1N0cmluZ30gZXZlbnRcbiAgICAgICAgICogQHBhcmFtIHtGdW5jdGlvbn0gZm5cbiAgICAgICAgICogQHJldHVybiB7RW1pdHRlcn1cbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgRW1pdHRlci5wcm90b3R5cGUub25jZSA9IGZ1bmN0aW9uIChldmVudCwgZm4pIHtcbiAgICAgICAgICBmdW5jdGlvbiBvbigpIHtcbiAgICAgICAgICAgIHRoaXMub2ZmKGV2ZW50LCBvbik7XG4gICAgICAgICAgICBmbi5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIG9uLmZuID0gZm47XG4gICAgICAgICAgdGhpcy5vbihldmVudCwgb24pO1xuICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBSZW1vdmUgdGhlIGdpdmVuIGNhbGxiYWNrIGZvciBgZXZlbnRgIG9yIGFsbFxuICAgICAgICAgKiByZWdpc3RlcmVkIGNhbGxiYWNrcy5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtTdHJpbmd9IGV2ZW50XG4gICAgICAgICAqIEBwYXJhbSB7RnVuY3Rpb259IGZuXG4gICAgICAgICAqIEByZXR1cm4ge0VtaXR0ZXJ9XG4gICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAqL1xuXG4gICAgICAgIEVtaXR0ZXIucHJvdG90eXBlLm9mZiA9IEVtaXR0ZXIucHJvdG90eXBlLnJlbW92ZUxpc3RlbmVyID0gRW1pdHRlci5wcm90b3R5cGUucmVtb3ZlQWxsTGlzdGVuZXJzID0gRW1pdHRlci5wcm90b3R5cGUucmVtb3ZlRXZlbnRMaXN0ZW5lciA9IGZ1bmN0aW9uIChldmVudCwgZm4pIHtcbiAgICAgICAgICB0aGlzLl9jYWxsYmFja3MgPSB0aGlzLl9jYWxsYmFja3MgfHwge307XG5cbiAgICAgICAgICAvLyBhbGxcbiAgICAgICAgICBpZiAoMCA9PSBhcmd1bWVudHMubGVuZ3RoKSB7XG4gICAgICAgICAgICB0aGlzLl9jYWxsYmFja3MgPSB7fTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC8vIHNwZWNpZmljIGV2ZW50XG4gICAgICAgICAgdmFyIGNhbGxiYWNrcyA9IHRoaXMuX2NhbGxiYWNrc1snJCcgKyBldmVudF07XG4gICAgICAgICAgaWYgKCFjYWxsYmFja3MpIHJldHVybiB0aGlzO1xuXG4gICAgICAgICAgLy8gcmVtb3ZlIGFsbCBoYW5kbGVyc1xuICAgICAgICAgIGlmICgxID09IGFyZ3VtZW50cy5sZW5ndGgpIHtcbiAgICAgICAgICAgIGRlbGV0ZSB0aGlzLl9jYWxsYmFja3NbJyQnICsgZXZlbnRdO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLy8gcmVtb3ZlIHNwZWNpZmljIGhhbmRsZXJcbiAgICAgICAgICB2YXIgY2I7XG4gICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBjYWxsYmFja3MubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGNiID0gY2FsbGJhY2tzW2ldO1xuICAgICAgICAgICAgaWYgKGNiID09PSBmbiB8fCBjYi5mbiA9PT0gZm4pIHtcbiAgICAgICAgICAgICAgY2FsbGJhY2tzLnNwbGljZShpLCAxKTtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbWl0IGBldmVudGAgd2l0aCB0aGUgZ2l2ZW4gYXJncy5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtTdHJpbmd9IGV2ZW50XG4gICAgICAgICAqIEBwYXJhbSB7TWl4ZWR9IC4uLlxuICAgICAgICAgKiBAcmV0dXJuIHtFbWl0dGVyfVxuICAgICAgICAgKi9cblxuICAgICAgICBFbWl0dGVyLnByb3RvdHlwZS5lbWl0ID0gZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgICAgICAgdGhpcy5fY2FsbGJhY2tzID0gdGhpcy5fY2FsbGJhY2tzIHx8IHt9O1xuICAgICAgICAgIHZhciBhcmdzID0gW10uc2xpY2UuY2FsbChhcmd1bWVudHMsIDEpLFxuICAgICAgICAgICAgICBjYWxsYmFja3MgPSB0aGlzLl9jYWxsYmFja3NbJyQnICsgZXZlbnRdO1xuXG4gICAgICAgICAgaWYgKGNhbGxiYWNrcykge1xuICAgICAgICAgICAgY2FsbGJhY2tzID0gY2FsbGJhY2tzLnNsaWNlKDApO1xuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDAsIGxlbiA9IGNhbGxiYWNrcy5sZW5ndGg7IGkgPCBsZW47ICsraSkge1xuICAgICAgICAgICAgICBjYWxsYmFja3NbaV0uYXBwbHkodGhpcywgYXJncyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFJldHVybiBhcnJheSBvZiBjYWxsYmFja3MgZm9yIGBldmVudGAuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7U3RyaW5nfSBldmVudFxuICAgICAgICAgKiBAcmV0dXJuIHtBcnJheX1cbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgRW1pdHRlci5wcm90b3R5cGUubGlzdGVuZXJzID0gZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgICAgICAgdGhpcy5fY2FsbGJhY2tzID0gdGhpcy5fY2FsbGJhY2tzIHx8IHt9O1xuICAgICAgICAgIHJldHVybiB0aGlzLl9jYWxsYmFja3NbJyQnICsgZXZlbnRdIHx8IFtdO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDaGVjayBpZiB0aGlzIGVtaXR0ZXIgaGFzIGBldmVudGAgaGFuZGxlcnMuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7U3RyaW5nfSBldmVudFxuICAgICAgICAgKiBAcmV0dXJuIHtCb29sZWFufVxuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cblxuICAgICAgICBFbWl0dGVyLnByb3RvdHlwZS5oYXNMaXN0ZW5lcnMgPSBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgICByZXR1cm4gISF0aGlzLmxpc3RlbmVycyhldmVudCkubGVuZ3RoO1xuICAgICAgICB9O1xuICAgICAgfSwge31dLCAzOTogW2Z1bmN0aW9uIChfZGVyZXFfLCBtb2R1bGUsIGV4cG9ydHMpIHtcbiAgICAgICAgYXJndW1lbnRzWzRdWzE3XVswXS5hcHBseShleHBvcnRzLCBhcmd1bWVudHMpO1xuICAgICAgfSwgeyBcIi4vZGVidWdcIjogNDAsIFwiZHVwXCI6IDE3IH1dLCA0MDogW2Z1bmN0aW9uIChfZGVyZXFfLCBtb2R1bGUsIGV4cG9ydHMpIHtcbiAgICAgICAgYXJndW1lbnRzWzRdWzE4XVswXS5hcHBseShleHBvcnRzLCBhcmd1bWVudHMpO1xuICAgICAgfSwgeyBcImR1cFwiOiAxOCwgXCJtc1wiOiA0NCB9XSwgNDE6IFtmdW5jdGlvbiAoX2RlcmVxXywgbW9kdWxlLCBleHBvcnRzKSB7XG4gICAgICAgIChmdW5jdGlvbiAoZ2xvYmFsKSB7XG5cbiAgICAgICAgICAvKlxuICAgICAgICAgICAqIE1vZHVsZSByZXF1aXJlbWVudHMuXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICB2YXIgaXNBcnJheSA9IF9kZXJlcV8oJ2lzYXJyYXknKTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIE1vZHVsZSBleHBvcnRzLlxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgbW9kdWxlLmV4cG9ydHMgPSBoYXNCaW5hcnk7XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBDaGVja3MgZm9yIGJpbmFyeSBkYXRhLlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogUmlnaHQgbm93IG9ubHkgQnVmZmVyIGFuZCBBcnJheUJ1ZmZlciBhcmUgc3VwcG9ydGVkLi5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBhbnl0aGluZ1xuICAgICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBmdW5jdGlvbiBoYXNCaW5hcnkoZGF0YSkge1xuXG4gICAgICAgICAgICBmdW5jdGlvbiBfaGFzQmluYXJ5KG9iaikge1xuICAgICAgICAgICAgICBpZiAoIW9iaikgcmV0dXJuIGZhbHNlO1xuXG4gICAgICAgICAgICAgIGlmIChnbG9iYWwuQnVmZmVyICYmIGdsb2JhbC5CdWZmZXIuaXNCdWZmZXIgJiYgZ2xvYmFsLkJ1ZmZlci5pc0J1ZmZlcihvYmopIHx8IGdsb2JhbC5BcnJheUJ1ZmZlciAmJiBvYmogaW5zdGFuY2VvZiBBcnJheUJ1ZmZlciB8fCBnbG9iYWwuQmxvYiAmJiBvYmogaW5zdGFuY2VvZiBCbG9iIHx8IGdsb2JhbC5GaWxlICYmIG9iaiBpbnN0YW5jZW9mIEZpbGUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIGlmIChpc0FycmF5KG9iaikpIHtcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IG9iai5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgaWYgKF9oYXNCaW5hcnkob2JqW2ldKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0gZWxzZSBpZiAob2JqICYmICdvYmplY3QnID09IHR5cGVvZiBvYmopIHtcbiAgICAgICAgICAgICAgICAvLyBzZWU6IGh0dHBzOi8vZ2l0aHViLmNvbS9BdXRvbWF0dGljL2hhcy1iaW5hcnkvcHVsbC80XG4gICAgICAgICAgICAgICAgaWYgKG9iai50b0pTT04gJiYgJ2Z1bmN0aW9uJyA9PSB0eXBlb2Ygb2JqLnRvSlNPTikge1xuICAgICAgICAgICAgICAgICAgb2JqID0gb2JqLnRvSlNPTigpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGZvciAodmFyIGtleSBpbiBvYmopIHtcbiAgICAgICAgICAgICAgICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBrZXkpICYmIF9oYXNCaW5hcnkob2JqW2tleV0pKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIF9oYXNCaW5hcnkoZGF0YSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KS5jYWxsKHRoaXMsIHR5cGVvZiBzZWxmICE9PSBcInVuZGVmaW5lZFwiID8gc2VsZiA6IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgPyB3aW5kb3cgOiB0eXBlb2YgZ2xvYmFsICE9PSBcInVuZGVmaW5lZFwiID8gZ2xvYmFsIDoge30pO1xuICAgICAgfSwgeyBcImlzYXJyYXlcIjogNDMgfV0sIDQyOiBbZnVuY3Rpb24gKF9kZXJlcV8sIG1vZHVsZSwgZXhwb3J0cykge1xuICAgICAgICBhcmd1bWVudHNbNF1bMjNdWzBdLmFwcGx5KGV4cG9ydHMsIGFyZ3VtZW50cyk7XG4gICAgICB9LCB7IFwiZHVwXCI6IDIzIH1dLCA0MzogW2Z1bmN0aW9uIChfZGVyZXFfLCBtb2R1bGUsIGV4cG9ydHMpIHtcbiAgICAgICAgYXJndW1lbnRzWzRdWzI0XVswXS5hcHBseShleHBvcnRzLCBhcmd1bWVudHMpO1xuICAgICAgfSwgeyBcImR1cFwiOiAyNCB9XSwgNDQ6IFtmdW5jdGlvbiAoX2RlcmVxXywgbW9kdWxlLCBleHBvcnRzKSB7XG4gICAgICAgIGFyZ3VtZW50c1s0XVsyNV1bMF0uYXBwbHkoZXhwb3J0cywgYXJndW1lbnRzKTtcbiAgICAgIH0sIHsgXCJkdXBcIjogMjUgfV0sIDQ1OiBbZnVuY3Rpb24gKF9kZXJlcV8sIG1vZHVsZSwgZXhwb3J0cykge1xuICAgICAgICBhcmd1bWVudHNbNF1bMjhdWzBdLmFwcGx5KGV4cG9ydHMsIGFyZ3VtZW50cyk7XG4gICAgICB9LCB7IFwiZHVwXCI6IDI4IH1dLCA0NjogW2Z1bmN0aW9uIChfZGVyZXFfLCBtb2R1bGUsIGV4cG9ydHMpIHtcbiAgICAgICAgKGZ1bmN0aW9uIChnbG9iYWwpIHtcbiAgICAgICAgICAvKmdsb2JhbCBCbG9iLEZpbGUqL1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogTW9kdWxlIHJlcXVpcmVtZW50c1xuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgdmFyIGlzQXJyYXkgPSBfZGVyZXFfKCdpc2FycmF5Jyk7XG4gICAgICAgICAgdmFyIGlzQnVmID0gX2RlcmVxXygnLi9pcy1idWZmZXInKTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIFJlcGxhY2VzIGV2ZXJ5IEJ1ZmZlciB8IEFycmF5QnVmZmVyIGluIHBhY2tldCB3aXRoIGEgbnVtYmVyZWQgcGxhY2Vob2xkZXIuXG4gICAgICAgICAgICogQW55dGhpbmcgd2l0aCBibG9icyBvciBmaWxlcyBzaG91bGQgYmUgZmVkIHRocm91Z2ggcmVtb3ZlQmxvYnMgYmVmb3JlIGNvbWluZ1xuICAgICAgICAgICAqIGhlcmUuXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBAcGFyYW0ge09iamVjdH0gcGFja2V0IC0gc29ja2V0LmlvIGV2ZW50IHBhY2tldFxuICAgICAgICAgICAqIEByZXR1cm4ge09iamVjdH0gd2l0aCBkZWNvbnN0cnVjdGVkIHBhY2tldCBhbmQgbGlzdCBvZiBidWZmZXJzXG4gICAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIGV4cG9ydHMuZGVjb25zdHJ1Y3RQYWNrZXQgPSBmdW5jdGlvbiAocGFja2V0KSB7XG4gICAgICAgICAgICB2YXIgYnVmZmVycyA9IFtdO1xuICAgICAgICAgICAgdmFyIHBhY2tldERhdGEgPSBwYWNrZXQuZGF0YTtcblxuICAgICAgICAgICAgZnVuY3Rpb24gX2RlY29uc3RydWN0UGFja2V0KGRhdGEpIHtcbiAgICAgICAgICAgICAgaWYgKCFkYXRhKSByZXR1cm4gZGF0YTtcblxuICAgICAgICAgICAgICBpZiAoaXNCdWYoZGF0YSkpIHtcbiAgICAgICAgICAgICAgICB2YXIgcGxhY2Vob2xkZXIgPSB7IF9wbGFjZWhvbGRlcjogdHJ1ZSwgbnVtOiBidWZmZXJzLmxlbmd0aCB9O1xuICAgICAgICAgICAgICAgIGJ1ZmZlcnMucHVzaChkYXRhKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gcGxhY2Vob2xkZXI7XG4gICAgICAgICAgICAgIH0gZWxzZSBpZiAoaXNBcnJheShkYXRhKSkge1xuICAgICAgICAgICAgICAgIHZhciBuZXdEYXRhID0gbmV3IEFycmF5KGRhdGEubGVuZ3RoKTtcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgIG5ld0RhdGFbaV0gPSBfZGVjb25zdHJ1Y3RQYWNrZXQoZGF0YVtpXSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBuZXdEYXRhO1xuICAgICAgICAgICAgICB9IGVsc2UgaWYgKCdvYmplY3QnID09IHR5cGVvZiBkYXRhICYmICEoZGF0YSBpbnN0YW5jZW9mIERhdGUpKSB7XG4gICAgICAgICAgICAgICAgdmFyIG5ld0RhdGEgPSB7fTtcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBrZXkgaW4gZGF0YSkge1xuICAgICAgICAgICAgICAgICAgbmV3RGF0YVtrZXldID0gX2RlY29uc3RydWN0UGFja2V0KGRhdGFba2V5XSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBuZXdEYXRhO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB2YXIgcGFjayA9IHBhY2tldDtcbiAgICAgICAgICAgIHBhY2suZGF0YSA9IF9kZWNvbnN0cnVjdFBhY2tldChwYWNrZXREYXRhKTtcbiAgICAgICAgICAgIHBhY2suYXR0YWNobWVudHMgPSBidWZmZXJzLmxlbmd0aDsgLy8gbnVtYmVyIG9mIGJpbmFyeSAnYXR0YWNobWVudHMnXG4gICAgICAgICAgICByZXR1cm4geyBwYWNrZXQ6IHBhY2ssIGJ1ZmZlcnM6IGJ1ZmZlcnMgfTtcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogUmVjb25zdHJ1Y3RzIGEgYmluYXJ5IHBhY2tldCBmcm9tIGl0cyBwbGFjZWhvbGRlciBwYWNrZXQgYW5kIGJ1ZmZlcnNcbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBwYWNrZXQgLSBldmVudCBwYWNrZXQgd2l0aCBwbGFjZWhvbGRlcnNcbiAgICAgICAgICAgKiBAcGFyYW0ge0FycmF5fSBidWZmZXJzIC0gYmluYXJ5IGJ1ZmZlcnMgdG8gcHV0IGluIHBsYWNlaG9sZGVyIHBvc2l0aW9uc1xuICAgICAgICAgICAqIEByZXR1cm4ge09iamVjdH0gcmVjb25zdHJ1Y3RlZCBwYWNrZXRcbiAgICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgZXhwb3J0cy5yZWNvbnN0cnVjdFBhY2tldCA9IGZ1bmN0aW9uIChwYWNrZXQsIGJ1ZmZlcnMpIHtcbiAgICAgICAgICAgIHZhciBjdXJQbGFjZUhvbGRlciA9IDA7XG5cbiAgICAgICAgICAgIGZ1bmN0aW9uIF9yZWNvbnN0cnVjdFBhY2tldChkYXRhKSB7XG4gICAgICAgICAgICAgIGlmIChkYXRhICYmIGRhdGEuX3BsYWNlaG9sZGVyKSB7XG4gICAgICAgICAgICAgICAgdmFyIGJ1ZiA9IGJ1ZmZlcnNbZGF0YS5udW1dOyAvLyBhcHByb3ByaWF0ZSBidWZmZXIgKHNob3VsZCBiZSBuYXR1cmFsIG9yZGVyIGFueXdheSlcbiAgICAgICAgICAgICAgICByZXR1cm4gYnVmO1xuICAgICAgICAgICAgICB9IGVsc2UgaWYgKGlzQXJyYXkoZGF0YSkpIHtcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgIGRhdGFbaV0gPSBfcmVjb25zdHJ1Y3RQYWNrZXQoZGF0YVtpXSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgICAgICAgICB9IGVsc2UgaWYgKGRhdGEgJiYgJ29iamVjdCcgPT0gdHlwZW9mIGRhdGEpIHtcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBrZXkgaW4gZGF0YSkge1xuICAgICAgICAgICAgICAgICAgZGF0YVtrZXldID0gX3JlY29uc3RydWN0UGFja2V0KGRhdGFba2V5XSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBwYWNrZXQuZGF0YSA9IF9yZWNvbnN0cnVjdFBhY2tldChwYWNrZXQuZGF0YSk7XG4gICAgICAgICAgICBwYWNrZXQuYXR0YWNobWVudHMgPSB1bmRlZmluZWQ7IC8vIG5vIGxvbmdlciB1c2VmdWxcbiAgICAgICAgICAgIHJldHVybiBwYWNrZXQ7XG4gICAgICAgICAgfTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIEFzeW5jaHJvbm91c2x5IHJlbW92ZXMgQmxvYnMgb3IgRmlsZXMgZnJvbSBkYXRhIHZpYVxuICAgICAgICAgICAqIEZpbGVSZWFkZXIncyByZWFkQXNBcnJheUJ1ZmZlciBtZXRob2QuIFVzZWQgYmVmb3JlIGVuY29kaW5nXG4gICAgICAgICAgICogZGF0YSBhcyBtc2dwYWNrLiBDYWxscyBjYWxsYmFjayB3aXRoIHRoZSBibG9ibGVzcyBkYXRhLlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogQHBhcmFtIHtPYmplY3R9IGRhdGFcbiAgICAgICAgICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYWxsYmFja1xuICAgICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgICAqL1xuXG4gICAgICAgICAgZXhwb3J0cy5yZW1vdmVCbG9icyA9IGZ1bmN0aW9uIChkYXRhLCBjYWxsYmFjaykge1xuICAgICAgICAgICAgZnVuY3Rpb24gX3JlbW92ZUJsb2JzKG9iaiwgY3VyS2V5LCBjb250YWluaW5nT2JqZWN0KSB7XG4gICAgICAgICAgICAgIGlmICghb2JqKSByZXR1cm4gb2JqO1xuXG4gICAgICAgICAgICAgIC8vIGNvbnZlcnQgYW55IGJsb2JcbiAgICAgICAgICAgICAgaWYgKGdsb2JhbC5CbG9iICYmIG9iaiBpbnN0YW5jZW9mIEJsb2IgfHwgZ2xvYmFsLkZpbGUgJiYgb2JqIGluc3RhbmNlb2YgRmlsZSkge1xuICAgICAgICAgICAgICAgIHBlbmRpbmdCbG9icysrO1xuXG4gICAgICAgICAgICAgICAgLy8gYXN5bmMgZmlsZXJlYWRlclxuICAgICAgICAgICAgICAgIHZhciBmaWxlUmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcbiAgICAgICAgICAgICAgICBmaWxlUmVhZGVyLm9ubG9hZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgIC8vIHRoaXMucmVzdWx0ID09IGFycmF5YnVmZmVyXG4gICAgICAgICAgICAgICAgICBpZiAoY29udGFpbmluZ09iamVjdCkge1xuICAgICAgICAgICAgICAgICAgICBjb250YWluaW5nT2JqZWN0W2N1cktleV0gPSB0aGlzLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGJsb2JsZXNzRGF0YSA9IHRoaXMucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAvLyBpZiBub3RoaW5nIHBlbmRpbmcgaXRzIGNhbGxiYWNrIHRpbWVcbiAgICAgICAgICAgICAgICAgIGlmICghIC0tcGVuZGluZ0Jsb2JzKSB7XG4gICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrKGJsb2JsZXNzRGF0YSk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgIGZpbGVSZWFkZXIucmVhZEFzQXJyYXlCdWZmZXIob2JqKTsgLy8gYmxvYiAtPiBhcnJheWJ1ZmZlclxuICAgICAgICAgICAgICB9IGVsc2UgaWYgKGlzQXJyYXkob2JqKSkge1xuICAgICAgICAgICAgICAgICAgLy8gaGFuZGxlIGFycmF5XG4gICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IG9iai5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICBfcmVtb3ZlQmxvYnMob2JqW2ldLCBpLCBvYmopO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAob2JqICYmICdvYmplY3QnID09IHR5cGVvZiBvYmogJiYgIWlzQnVmKG9iaikpIHtcbiAgICAgICAgICAgICAgICAgIC8vIGFuZCBvYmplY3RcbiAgICAgICAgICAgICAgICAgIGZvciAodmFyIGtleSBpbiBvYmopIHtcbiAgICAgICAgICAgICAgICAgICAgX3JlbW92ZUJsb2JzKG9ialtrZXldLCBrZXksIG9iaik7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB2YXIgcGVuZGluZ0Jsb2JzID0gMDtcbiAgICAgICAgICAgIHZhciBibG9ibGVzc0RhdGEgPSBkYXRhO1xuICAgICAgICAgICAgX3JlbW92ZUJsb2JzKGJsb2JsZXNzRGF0YSk7XG4gICAgICAgICAgICBpZiAoIXBlbmRpbmdCbG9icykge1xuICAgICAgICAgICAgICBjYWxsYmFjayhibG9ibGVzc0RhdGEpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH07XG4gICAgICAgIH0pLmNhbGwodGhpcywgdHlwZW9mIHNlbGYgIT09IFwidW5kZWZpbmVkXCIgPyBzZWxmIDogdHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiA/IHdpbmRvdyA6IHR5cGVvZiBnbG9iYWwgIT09IFwidW5kZWZpbmVkXCIgPyBnbG9iYWwgOiB7fSk7XG4gICAgICB9LCB7IFwiLi9pcy1idWZmZXJcIjogNDgsIFwiaXNhcnJheVwiOiA0MyB9XSwgNDc6IFtmdW5jdGlvbiAoX2RlcmVxXywgbW9kdWxlLCBleHBvcnRzKSB7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIE1vZHVsZSBkZXBlbmRlbmNpZXMuXG4gICAgICAgICAqL1xuXG4gICAgICAgIHZhciBkZWJ1ZyA9IF9kZXJlcV8oJ2RlYnVnJykoJ3NvY2tldC5pby1wYXJzZXInKTtcbiAgICAgICAgdmFyIGpzb24gPSBfZGVyZXFfKCdqc29uMycpO1xuICAgICAgICB2YXIgaXNBcnJheSA9IF9kZXJlcV8oJ2lzYXJyYXknKTtcbiAgICAgICAgdmFyIEVtaXR0ZXIgPSBfZGVyZXFfKCdjb21wb25lbnQtZW1pdHRlcicpO1xuICAgICAgICB2YXIgYmluYXJ5ID0gX2RlcmVxXygnLi9iaW5hcnknKTtcbiAgICAgICAgdmFyIGlzQnVmID0gX2RlcmVxXygnLi9pcy1idWZmZXInKTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogUHJvdG9jb2wgdmVyc2lvbi5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgZXhwb3J0cy5wcm90b2NvbCA9IDQ7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFBhY2tldCB0eXBlcy5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgZXhwb3J0cy50eXBlcyA9IFsnQ09OTkVDVCcsICdESVNDT05ORUNUJywgJ0VWRU5UJywgJ0JJTkFSWV9FVkVOVCcsICdBQ0snLCAnQklOQVJZX0FDSycsICdFUlJPUiddO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBQYWNrZXQgdHlwZSBgY29ubmVjdGAuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAqL1xuXG4gICAgICAgIGV4cG9ydHMuQ09OTkVDVCA9IDA7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFBhY2tldCB0eXBlIGBkaXNjb25uZWN0YC5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgZXhwb3J0cy5ESVNDT05ORUNUID0gMTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogUGFja2V0IHR5cGUgYGV2ZW50YC5cbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgZXhwb3J0cy5FVkVOVCA9IDI7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFBhY2tldCB0eXBlIGBhY2tgLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cblxuICAgICAgICBleHBvcnRzLkFDSyA9IDM7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFBhY2tldCB0eXBlIGBlcnJvcmAuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAqL1xuXG4gICAgICAgIGV4cG9ydHMuRVJST1IgPSA0O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBQYWNrZXQgdHlwZSAnYmluYXJ5IGV2ZW50J1xuICAgICAgICAgKlxuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cblxuICAgICAgICBleHBvcnRzLkJJTkFSWV9FVkVOVCA9IDU7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFBhY2tldCB0eXBlIGBiaW5hcnkgYWNrYC4gRm9yIGFja3Mgd2l0aCBiaW5hcnkgYXJndW1lbnRzLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cblxuICAgICAgICBleHBvcnRzLkJJTkFSWV9BQ0sgPSA2O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVyIGNvbnN0cnVjdG9yLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cblxuICAgICAgICBleHBvcnRzLkVuY29kZXIgPSBFbmNvZGVyO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBEZWNvZGVyIGNvbnN0cnVjdG9yLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cblxuICAgICAgICBleHBvcnRzLkRlY29kZXIgPSBEZWNvZGVyO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBBIHNvY2tldC5pbyBFbmNvZGVyIGluc3RhbmNlXG4gICAgICAgICAqXG4gICAgICAgICAqIEBhcGkgcHVibGljXG4gICAgICAgICAqL1xuXG4gICAgICAgIGZ1bmN0aW9uIEVuY29kZXIoKSB7fVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGUgYSBwYWNrZXQgYXMgYSBzaW5nbGUgc3RyaW5nIGlmIG5vbi1iaW5hcnksIG9yIGFzIGFcbiAgICAgICAgICogYnVmZmVyIHNlcXVlbmNlLCBkZXBlbmRpbmcgb24gcGFja2V0IHR5cGUuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBvYmogLSBwYWNrZXQgb2JqZWN0XG4gICAgICAgICAqIEBwYXJhbSB7RnVuY3Rpb259IGNhbGxiYWNrIC0gZnVuY3Rpb24gdG8gaGFuZGxlIGVuY29kaW5ncyAobGlrZWx5IGVuZ2luZS53cml0ZSlcbiAgICAgICAgICogQHJldHVybiBDYWxscyBjYWxsYmFjayB3aXRoIEFycmF5IG9mIGVuY29kaW5nc1xuICAgICAgICAgKiBAYXBpIHB1YmxpY1xuICAgICAgICAgKi9cblxuICAgICAgICBFbmNvZGVyLnByb3RvdHlwZS5lbmNvZGUgPSBmdW5jdGlvbiAob2JqLCBjYWxsYmFjaykge1xuICAgICAgICAgIGRlYnVnKCdlbmNvZGluZyBwYWNrZXQgJWonLCBvYmopO1xuXG4gICAgICAgICAgaWYgKGV4cG9ydHMuQklOQVJZX0VWRU5UID09IG9iai50eXBlIHx8IGV4cG9ydHMuQklOQVJZX0FDSyA9PSBvYmoudHlwZSkge1xuICAgICAgICAgICAgZW5jb2RlQXNCaW5hcnkob2JqLCBjYWxsYmFjayk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHZhciBlbmNvZGluZyA9IGVuY29kZUFzU3RyaW5nKG9iaik7XG4gICAgICAgICAgICBjYWxsYmFjayhbZW5jb2RpbmddKTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEVuY29kZSBwYWNrZXQgYXMgc3RyaW5nLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ge09iamVjdH0gcGFja2V0XG4gICAgICAgICAqIEByZXR1cm4ge1N0cmluZ30gZW5jb2RlZFxuICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICovXG5cbiAgICAgICAgZnVuY3Rpb24gZW5jb2RlQXNTdHJpbmcob2JqKSB7XG4gICAgICAgICAgdmFyIHN0ciA9ICcnO1xuICAgICAgICAgIHZhciBuc3AgPSBmYWxzZTtcblxuICAgICAgICAgIC8vIGZpcnN0IGlzIHR5cGVcbiAgICAgICAgICBzdHIgKz0gb2JqLnR5cGU7XG5cbiAgICAgICAgICAvLyBhdHRhY2htZW50cyBpZiB3ZSBoYXZlIHRoZW1cbiAgICAgICAgICBpZiAoZXhwb3J0cy5CSU5BUllfRVZFTlQgPT0gb2JqLnR5cGUgfHwgZXhwb3J0cy5CSU5BUllfQUNLID09IG9iai50eXBlKSB7XG4gICAgICAgICAgICBzdHIgKz0gb2JqLmF0dGFjaG1lbnRzO1xuICAgICAgICAgICAgc3RyICs9ICctJztcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBpZiB3ZSBoYXZlIGEgbmFtZXNwYWNlIG90aGVyIHRoYW4gYC9gXG4gICAgICAgICAgLy8gd2UgYXBwZW5kIGl0IGZvbGxvd2VkIGJ5IGEgY29tbWEgYCxgXG4gICAgICAgICAgaWYgKG9iai5uc3AgJiYgJy8nICE9IG9iai5uc3ApIHtcbiAgICAgICAgICAgIG5zcCA9IHRydWU7XG4gICAgICAgICAgICBzdHIgKz0gb2JqLm5zcDtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBpbW1lZGlhdGVseSBmb2xsb3dlZCBieSB0aGUgaWRcbiAgICAgICAgICBpZiAobnVsbCAhPSBvYmouaWQpIHtcbiAgICAgICAgICAgIGlmIChuc3ApIHtcbiAgICAgICAgICAgICAgc3RyICs9ICcsJztcbiAgICAgICAgICAgICAgbnNwID0gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzdHIgKz0gb2JqLmlkO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC8vIGpzb24gZGF0YVxuICAgICAgICAgIGlmIChudWxsICE9IG9iai5kYXRhKSB7XG4gICAgICAgICAgICBpZiAobnNwKSBzdHIgKz0gJywnO1xuICAgICAgICAgICAgc3RyICs9IGpzb24uc3RyaW5naWZ5KG9iai5kYXRhKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBkZWJ1ZygnZW5jb2RlZCAlaiBhcyAlcycsIG9iaiwgc3RyKTtcbiAgICAgICAgICByZXR1cm4gc3RyO1xuICAgICAgICB9XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEVuY29kZSBwYWNrZXQgYXMgJ2J1ZmZlciBzZXF1ZW5jZScgYnkgcmVtb3ZpbmcgYmxvYnMsIGFuZFxuICAgICAgICAgKiBkZWNvbnN0cnVjdGluZyBwYWNrZXQgaW50byBvYmplY3Qgd2l0aCBwbGFjZWhvbGRlcnMgYW5kXG4gICAgICAgICAqIGEgbGlzdCBvZiBidWZmZXJzLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ge09iamVjdH0gcGFja2V0XG4gICAgICAgICAqIEByZXR1cm4ge0J1ZmZlcn0gZW5jb2RlZFxuICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICovXG5cbiAgICAgICAgZnVuY3Rpb24gZW5jb2RlQXNCaW5hcnkob2JqLCBjYWxsYmFjaykge1xuXG4gICAgICAgICAgZnVuY3Rpb24gd3JpdGVFbmNvZGluZyhibG9ibGVzc0RhdGEpIHtcbiAgICAgICAgICAgIHZhciBkZWNvbnN0cnVjdGlvbiA9IGJpbmFyeS5kZWNvbnN0cnVjdFBhY2tldChibG9ibGVzc0RhdGEpO1xuICAgICAgICAgICAgdmFyIHBhY2sgPSBlbmNvZGVBc1N0cmluZyhkZWNvbnN0cnVjdGlvbi5wYWNrZXQpO1xuICAgICAgICAgICAgdmFyIGJ1ZmZlcnMgPSBkZWNvbnN0cnVjdGlvbi5idWZmZXJzO1xuXG4gICAgICAgICAgICBidWZmZXJzLnVuc2hpZnQocGFjayk7IC8vIGFkZCBwYWNrZXQgaW5mbyB0byBiZWdpbm5pbmcgb2YgZGF0YSBsaXN0XG4gICAgICAgICAgICBjYWxsYmFjayhidWZmZXJzKTsgLy8gd3JpdGUgYWxsIHRoZSBidWZmZXJzXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgYmluYXJ5LnJlbW92ZUJsb2JzKG9iaiwgd3JpdGVFbmNvZGluZyk7XG4gICAgICAgIH1cblxuICAgICAgICAvKipcbiAgICAgICAgICogQSBzb2NrZXQuaW8gRGVjb2RlciBpbnN0YW5jZVxuICAgICAgICAgKlxuICAgICAgICAgKiBAcmV0dXJuIHtPYmplY3R9IGRlY29kZXJcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgZnVuY3Rpb24gRGVjb2RlcigpIHtcbiAgICAgICAgICB0aGlzLnJlY29uc3RydWN0b3IgPSBudWxsO1xuICAgICAgICB9XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIE1peCBpbiBgRW1pdHRlcmAgd2l0aCBEZWNvZGVyLlxuICAgICAgICAgKi9cblxuICAgICAgICBFbWl0dGVyKERlY29kZXIucHJvdG90eXBlKTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRGVjb2RlcyBhbiBlY29kZWQgcGFja2V0IHN0cmluZyBpbnRvIHBhY2tldCBKU09OLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ge1N0cmluZ30gb2JqIC0gZW5jb2RlZCBwYWNrZXRcbiAgICAgICAgICogQHJldHVybiB7T2JqZWN0fSBwYWNrZXRcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgRGVjb2Rlci5wcm90b3R5cGUuYWRkID0gZnVuY3Rpb24gKG9iaikge1xuICAgICAgICAgIHZhciBwYWNrZXQ7XG4gICAgICAgICAgaWYgKCdzdHJpbmcnID09IHR5cGVvZiBvYmopIHtcbiAgICAgICAgICAgIHBhY2tldCA9IGRlY29kZVN0cmluZyhvYmopO1xuICAgICAgICAgICAgaWYgKGV4cG9ydHMuQklOQVJZX0VWRU5UID09IHBhY2tldC50eXBlIHx8IGV4cG9ydHMuQklOQVJZX0FDSyA9PSBwYWNrZXQudHlwZSkge1xuICAgICAgICAgICAgICAvLyBiaW5hcnkgcGFja2V0J3MganNvblxuICAgICAgICAgICAgICB0aGlzLnJlY29uc3RydWN0b3IgPSBuZXcgQmluYXJ5UmVjb25zdHJ1Y3RvcihwYWNrZXQpO1xuXG4gICAgICAgICAgICAgIC8vIG5vIGF0dGFjaG1lbnRzLCBsYWJlbGVkIGJpbmFyeSBidXQgbm8gYmluYXJ5IGRhdGEgdG8gZm9sbG93XG4gICAgICAgICAgICAgIGlmICh0aGlzLnJlY29uc3RydWN0b3IucmVjb25QYWNrLmF0dGFjaG1lbnRzID09PSAwKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5lbWl0KCdkZWNvZGVkJywgcGFja2V0KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgLy8gbm9uLWJpbmFyeSBmdWxsIHBhY2tldFxuICAgICAgICAgICAgICB0aGlzLmVtaXQoJ2RlY29kZWQnLCBwYWNrZXQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gZWxzZSBpZiAoaXNCdWYob2JqKSB8fCBvYmouYmFzZTY0KSB7XG4gICAgICAgICAgICAvLyByYXcgYmluYXJ5IGRhdGFcbiAgICAgICAgICAgIGlmICghdGhpcy5yZWNvbnN0cnVjdG9yKSB7XG4gICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignZ290IGJpbmFyeSBkYXRhIHdoZW4gbm90IHJlY29uc3RydWN0aW5nIGEgcGFja2V0Jyk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBwYWNrZXQgPSB0aGlzLnJlY29uc3RydWN0b3IudGFrZUJpbmFyeURhdGEob2JqKTtcbiAgICAgICAgICAgICAgaWYgKHBhY2tldCkge1xuICAgICAgICAgICAgICAgIC8vIHJlY2VpdmVkIGZpbmFsIGJ1ZmZlclxuICAgICAgICAgICAgICAgIHRoaXMucmVjb25zdHJ1Y3RvciA9IG51bGw7XG4gICAgICAgICAgICAgICAgdGhpcy5lbWl0KCdkZWNvZGVkJywgcGFja2V0KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1Vua25vd24gdHlwZTogJyArIG9iaik7XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBEZWNvZGUgYSBwYWNrZXQgU3RyaW5nIChKU09OIGRhdGEpXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7U3RyaW5nfSBzdHJcbiAgICAgICAgICogQHJldHVybiB7T2JqZWN0fSBwYWNrZXRcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIGZ1bmN0aW9uIGRlY29kZVN0cmluZyhzdHIpIHtcbiAgICAgICAgICB2YXIgcCA9IHt9O1xuICAgICAgICAgIHZhciBpID0gMDtcblxuICAgICAgICAgIC8vIGxvb2sgdXAgdHlwZVxuICAgICAgICAgIHAudHlwZSA9IE51bWJlcihzdHIuY2hhckF0KDApKTtcbiAgICAgICAgICBpZiAobnVsbCA9PSBleHBvcnRzLnR5cGVzW3AudHlwZV0pIHJldHVybiBlcnJvcigpO1xuXG4gICAgICAgICAgLy8gbG9vayB1cCBhdHRhY2htZW50cyBpZiB0eXBlIGJpbmFyeVxuICAgICAgICAgIGlmIChleHBvcnRzLkJJTkFSWV9FVkVOVCA9PSBwLnR5cGUgfHwgZXhwb3J0cy5CSU5BUllfQUNLID09IHAudHlwZSkge1xuICAgICAgICAgICAgdmFyIGJ1ZiA9ICcnO1xuICAgICAgICAgICAgd2hpbGUgKHN0ci5jaGFyQXQoKytpKSAhPSAnLScpIHtcbiAgICAgICAgICAgICAgYnVmICs9IHN0ci5jaGFyQXQoaSk7XG4gICAgICAgICAgICAgIGlmIChpID09IHN0ci5sZW5ndGgpIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGJ1ZiAhPSBOdW1iZXIoYnVmKSB8fCBzdHIuY2hhckF0KGkpICE9ICctJykge1xuICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0lsbGVnYWwgYXR0YWNobWVudHMnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHAuYXR0YWNobWVudHMgPSBOdW1iZXIoYnVmKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBsb29rIHVwIG5hbWVzcGFjZSAoaWYgYW55KVxuICAgICAgICAgIGlmICgnLycgPT0gc3RyLmNoYXJBdChpICsgMSkpIHtcbiAgICAgICAgICAgIHAubnNwID0gJyc7XG4gICAgICAgICAgICB3aGlsZSAoKytpKSB7XG4gICAgICAgICAgICAgIHZhciBjID0gc3RyLmNoYXJBdChpKTtcbiAgICAgICAgICAgICAgaWYgKCcsJyA9PSBjKSBicmVhaztcbiAgICAgICAgICAgICAgcC5uc3AgKz0gYztcbiAgICAgICAgICAgICAgaWYgKGkgPT0gc3RyLmxlbmd0aCkgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHAubnNwID0gJy8nO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC8vIGxvb2sgdXAgaWRcbiAgICAgICAgICB2YXIgbmV4dCA9IHN0ci5jaGFyQXQoaSArIDEpO1xuICAgICAgICAgIGlmICgnJyAhPT0gbmV4dCAmJiBOdW1iZXIobmV4dCkgPT0gbmV4dCkge1xuICAgICAgICAgICAgcC5pZCA9ICcnO1xuICAgICAgICAgICAgd2hpbGUgKCsraSkge1xuICAgICAgICAgICAgICB2YXIgYyA9IHN0ci5jaGFyQXQoaSk7XG4gICAgICAgICAgICAgIGlmIChudWxsID09IGMgfHwgTnVtYmVyKGMpICE9IGMpIHtcbiAgICAgICAgICAgICAgICAtLWk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgcC5pZCArPSBzdHIuY2hhckF0KGkpO1xuICAgICAgICAgICAgICBpZiAoaSA9PSBzdHIubGVuZ3RoKSBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHAuaWQgPSBOdW1iZXIocC5pZCk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLy8gbG9vayB1cCBqc29uIGRhdGFcbiAgICAgICAgICBpZiAoc3RyLmNoYXJBdCgrK2kpKSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICBwLmRhdGEgPSBqc29uLnBhcnNlKHN0ci5zdWJzdHIoaSkpO1xuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICByZXR1cm4gZXJyb3IoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICBkZWJ1ZygnZGVjb2RlZCAlcyBhcyAlaicsIHN0ciwgcCk7XG4gICAgICAgICAgcmV0dXJuIHA7XG4gICAgICAgIH1cblxuICAgICAgICAvKipcbiAgICAgICAgICogRGVhbGxvY2F0ZXMgYSBwYXJzZXIncyByZXNvdXJjZXNcbiAgICAgICAgICpcbiAgICAgICAgICogQGFwaSBwdWJsaWNcbiAgICAgICAgICovXG5cbiAgICAgICAgRGVjb2Rlci5wcm90b3R5cGUuZGVzdHJveSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBpZiAodGhpcy5yZWNvbnN0cnVjdG9yKSB7XG4gICAgICAgICAgICB0aGlzLnJlY29uc3RydWN0b3IuZmluaXNoZWRSZWNvbnN0cnVjdGlvbigpO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQSBtYW5hZ2VyIG9mIGEgYmluYXJ5IGV2ZW50J3MgJ2J1ZmZlciBzZXF1ZW5jZScuIFNob3VsZFxuICAgICAgICAgKiBiZSBjb25zdHJ1Y3RlZCB3aGVuZXZlciBhIHBhY2tldCBvZiB0eXBlIEJJTkFSWV9FVkVOVCBpc1xuICAgICAgICAgKiBkZWNvZGVkLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ge09iamVjdH0gcGFja2V0XG4gICAgICAgICAqIEByZXR1cm4ge0JpbmFyeVJlY29uc3RydWN0b3J9IGluaXRpYWxpemVkIHJlY29uc3RydWN0b3JcbiAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAqL1xuXG4gICAgICAgIGZ1bmN0aW9uIEJpbmFyeVJlY29uc3RydWN0b3IocGFja2V0KSB7XG4gICAgICAgICAgdGhpcy5yZWNvblBhY2sgPSBwYWNrZXQ7XG4gICAgICAgICAgdGhpcy5idWZmZXJzID0gW107XG4gICAgICAgIH1cblxuICAgICAgICAvKipcbiAgICAgICAgICogTWV0aG9kIHRvIGJlIGNhbGxlZCB3aGVuIGJpbmFyeSBkYXRhIHJlY2VpdmVkIGZyb20gY29ubmVjdGlvblxuICAgICAgICAgKiBhZnRlciBhIEJJTkFSWV9FVkVOVCBwYWNrZXQuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7QnVmZmVyIHwgQXJyYXlCdWZmZXJ9IGJpbkRhdGEgLSB0aGUgcmF3IGJpbmFyeSBkYXRhIHJlY2VpdmVkXG4gICAgICAgICAqIEByZXR1cm4ge251bGwgfCBPYmplY3R9IHJldHVybnMgbnVsbCBpZiBtb3JlIGJpbmFyeSBkYXRhIGlzIGV4cGVjdGVkIG9yXG4gICAgICAgICAqICAgYSByZWNvbnN0cnVjdGVkIHBhY2tldCBvYmplY3QgaWYgYWxsIGJ1ZmZlcnMgaGF2ZSBiZWVuIHJlY2VpdmVkLlxuICAgICAgICAgKiBAYXBpIHByaXZhdGVcbiAgICAgICAgICovXG5cbiAgICAgICAgQmluYXJ5UmVjb25zdHJ1Y3Rvci5wcm90b3R5cGUudGFrZUJpbmFyeURhdGEgPSBmdW5jdGlvbiAoYmluRGF0YSkge1xuICAgICAgICAgIHRoaXMuYnVmZmVycy5wdXNoKGJpbkRhdGEpO1xuICAgICAgICAgIGlmICh0aGlzLmJ1ZmZlcnMubGVuZ3RoID09IHRoaXMucmVjb25QYWNrLmF0dGFjaG1lbnRzKSB7XG4gICAgICAgICAgICAvLyBkb25lIHdpdGggYnVmZmVyIGxpc3RcbiAgICAgICAgICAgIHZhciBwYWNrZXQgPSBiaW5hcnkucmVjb25zdHJ1Y3RQYWNrZXQodGhpcy5yZWNvblBhY2ssIHRoaXMuYnVmZmVycyk7XG4gICAgICAgICAgICB0aGlzLmZpbmlzaGVkUmVjb25zdHJ1Y3Rpb24oKTtcbiAgICAgICAgICAgIHJldHVybiBwYWNrZXQ7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDbGVhbnMgdXAgYmluYXJ5IHBhY2tldCByZWNvbnN0cnVjdGlvbiB2YXJpYWJsZXMuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBhcGkgcHJpdmF0ZVxuICAgICAgICAgKi9cblxuICAgICAgICBCaW5hcnlSZWNvbnN0cnVjdG9yLnByb3RvdHlwZS5maW5pc2hlZFJlY29uc3RydWN0aW9uID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHRoaXMucmVjb25QYWNrID0gbnVsbDtcbiAgICAgICAgICB0aGlzLmJ1ZmZlcnMgPSBbXTtcbiAgICAgICAgfTtcblxuICAgICAgICBmdW5jdGlvbiBlcnJvcihkYXRhKSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHR5cGU6IGV4cG9ydHMuRVJST1IsXG4gICAgICAgICAgICBkYXRhOiAncGFyc2VyIGVycm9yJ1xuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgIH0sIHsgXCIuL2JpbmFyeVwiOiA0NiwgXCIuL2lzLWJ1ZmZlclwiOiA0OCwgXCJjb21wb25lbnQtZW1pdHRlclwiOiA0OSwgXCJkZWJ1Z1wiOiAzOSwgXCJpc2FycmF5XCI6IDQzLCBcImpzb24zXCI6IDUwIH1dLCA0ODogW2Z1bmN0aW9uIChfZGVyZXFfLCBtb2R1bGUsIGV4cG9ydHMpIHtcbiAgICAgICAgKGZ1bmN0aW9uIChnbG9iYWwpIHtcblxuICAgICAgICAgIG1vZHVsZS5leHBvcnRzID0gaXNCdWY7XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBSZXR1cm5zIHRydWUgaWYgb2JqIGlzIGEgYnVmZmVyIG9yIGFuIGFycmF5YnVmZmVyLlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogQGFwaSBwcml2YXRlXG4gICAgICAgICAgICovXG5cbiAgICAgICAgICBmdW5jdGlvbiBpc0J1ZihvYmopIHtcbiAgICAgICAgICAgIHJldHVybiBnbG9iYWwuQnVmZmVyICYmIGdsb2JhbC5CdWZmZXIuaXNCdWZmZXIob2JqKSB8fCBnbG9iYWwuQXJyYXlCdWZmZXIgJiYgb2JqIGluc3RhbmNlb2YgQXJyYXlCdWZmZXI7XG4gICAgICAgICAgfVxuICAgICAgICB9KS5jYWxsKHRoaXMsIHR5cGVvZiBzZWxmICE9PSBcInVuZGVmaW5lZFwiID8gc2VsZiA6IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgPyB3aW5kb3cgOiB0eXBlb2YgZ2xvYmFsICE9PSBcInVuZGVmaW5lZFwiID8gZ2xvYmFsIDoge30pO1xuICAgICAgfSwge31dLCA0OTogW2Z1bmN0aW9uIChfZGVyZXFfLCBtb2R1bGUsIGV4cG9ydHMpIHtcbiAgICAgICAgYXJndW1lbnRzWzRdWzE1XVswXS5hcHBseShleHBvcnRzLCBhcmd1bWVudHMpO1xuICAgICAgfSwgeyBcImR1cFwiOiAxNSB9XSwgNTA6IFtmdW5jdGlvbiAoX2RlcmVxXywgbW9kdWxlLCBleHBvcnRzKSB7XG4gICAgICAgIChmdW5jdGlvbiAoZ2xvYmFsKSB7XG4gICAgICAgICAgLyohIEpTT04gdjMuMy4yIHwgaHR0cDovL2Jlc3RpZWpzLmdpdGh1Yi5pby9qc29uMyB8IENvcHlyaWdodCAyMDEyLTIwMTQsIEtpdCBDYW1icmlkZ2UgfCBodHRwOi8va2l0Lm1pdC1saWNlbnNlLm9yZyAqL1xuICAgICAgICAgIDsoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgLy8gRGV0ZWN0IHRoZSBgZGVmaW5lYCBmdW5jdGlvbiBleHBvc2VkIGJ5IGFzeW5jaHJvbm91cyBtb2R1bGUgbG9hZGVycy4gVGhlXG4gICAgICAgICAgICAvLyBzdHJpY3QgYGRlZmluZWAgY2hlY2sgaXMgbmVjZXNzYXJ5IGZvciBjb21wYXRpYmlsaXR5IHdpdGggYHIuanNgLlxuICAgICAgICAgICAgdmFyIGlzTG9hZGVyID0gdHlwZW9mIGRlZmluZSA9PT0gXCJmdW5jdGlvblwiICYmIGRlZmluZS5hbWQ7XG5cbiAgICAgICAgICAgIC8vIEEgc2V0IG9mIHR5cGVzIHVzZWQgdG8gZGlzdGluZ3Vpc2ggb2JqZWN0cyBmcm9tIHByaW1pdGl2ZXMuXG4gICAgICAgICAgICB2YXIgb2JqZWN0VHlwZXMgPSB7XG4gICAgICAgICAgICAgIFwiZnVuY3Rpb25cIjogdHJ1ZSxcbiAgICAgICAgICAgICAgXCJvYmplY3RcIjogdHJ1ZVxuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgLy8gRGV0ZWN0IHRoZSBgZXhwb3J0c2Agb2JqZWN0IGV4cG9zZWQgYnkgQ29tbW9uSlMgaW1wbGVtZW50YXRpb25zLlxuICAgICAgICAgICAgdmFyIGZyZWVFeHBvcnRzID0gb2JqZWN0VHlwZXNbdHlwZW9mIGV4cG9ydHNdICYmIGV4cG9ydHMgJiYgIWV4cG9ydHMubm9kZVR5cGUgJiYgZXhwb3J0cztcblxuICAgICAgICAgICAgLy8gVXNlIHRoZSBgZ2xvYmFsYCBvYmplY3QgZXhwb3NlZCBieSBOb2RlIChpbmNsdWRpbmcgQnJvd3NlcmlmeSB2aWFcbiAgICAgICAgICAgIC8vIGBpbnNlcnQtbW9kdWxlLWdsb2JhbHNgKSwgTmFyd2hhbCwgYW5kIFJpbmdvIGFzIHRoZSBkZWZhdWx0IGNvbnRleHQsXG4gICAgICAgICAgICAvLyBhbmQgdGhlIGB3aW5kb3dgIG9iamVjdCBpbiBicm93c2Vycy4gUmhpbm8gZXhwb3J0cyBhIGBnbG9iYWxgIGZ1bmN0aW9uXG4gICAgICAgICAgICAvLyBpbnN0ZWFkLlxuICAgICAgICAgICAgdmFyIHJvb3QgPSBvYmplY3RUeXBlc1t0eXBlb2Ygd2luZG93XSAmJiB3aW5kb3cgfHwgdGhpcyxcbiAgICAgICAgICAgICAgICBmcmVlR2xvYmFsID0gZnJlZUV4cG9ydHMgJiYgb2JqZWN0VHlwZXNbdHlwZW9mIG1vZHVsZV0gJiYgbW9kdWxlICYmICFtb2R1bGUubm9kZVR5cGUgJiYgdHlwZW9mIGdsb2JhbCA9PSBcIm9iamVjdFwiICYmIGdsb2JhbDtcblxuICAgICAgICAgICAgaWYgKGZyZWVHbG9iYWwgJiYgKGZyZWVHbG9iYWxbXCJnbG9iYWxcIl0gPT09IGZyZWVHbG9iYWwgfHwgZnJlZUdsb2JhbFtcIndpbmRvd1wiXSA9PT0gZnJlZUdsb2JhbCB8fCBmcmVlR2xvYmFsW1wic2VsZlwiXSA9PT0gZnJlZUdsb2JhbCkpIHtcbiAgICAgICAgICAgICAgcm9vdCA9IGZyZWVHbG9iYWw7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIFB1YmxpYzogSW5pdGlhbGl6ZXMgSlNPTiAzIHVzaW5nIHRoZSBnaXZlbiBgY29udGV4dGAgb2JqZWN0LCBhdHRhY2hpbmcgdGhlXG4gICAgICAgICAgICAvLyBgc3RyaW5naWZ5YCBhbmQgYHBhcnNlYCBmdW5jdGlvbnMgdG8gdGhlIHNwZWNpZmllZCBgZXhwb3J0c2Agb2JqZWN0LlxuICAgICAgICAgICAgZnVuY3Rpb24gcnVuSW5Db250ZXh0KGNvbnRleHQsIGV4cG9ydHMpIHtcbiAgICAgICAgICAgICAgY29udGV4dCB8fCAoY29udGV4dCA9IHJvb3RbXCJPYmplY3RcIl0oKSk7XG4gICAgICAgICAgICAgIGV4cG9ydHMgfHwgKGV4cG9ydHMgPSByb290W1wiT2JqZWN0XCJdKCkpO1xuXG4gICAgICAgICAgICAgIC8vIE5hdGl2ZSBjb25zdHJ1Y3RvciBhbGlhc2VzLlxuICAgICAgICAgICAgICB2YXIgTnVtYmVyID0gY29udGV4dFtcIk51bWJlclwiXSB8fCByb290W1wiTnVtYmVyXCJdLFxuICAgICAgICAgICAgICAgICAgU3RyaW5nID0gY29udGV4dFtcIlN0cmluZ1wiXSB8fCByb290W1wiU3RyaW5nXCJdLFxuICAgICAgICAgICAgICAgICAgT2JqZWN0ID0gY29udGV4dFtcIk9iamVjdFwiXSB8fCByb290W1wiT2JqZWN0XCJdLFxuICAgICAgICAgICAgICAgICAgRGF0ZSA9IGNvbnRleHRbXCJEYXRlXCJdIHx8IHJvb3RbXCJEYXRlXCJdLFxuICAgICAgICAgICAgICAgICAgU3ludGF4RXJyb3IgPSBjb250ZXh0W1wiU3ludGF4RXJyb3JcIl0gfHwgcm9vdFtcIlN5bnRheEVycm9yXCJdLFxuICAgICAgICAgICAgICAgICAgVHlwZUVycm9yID0gY29udGV4dFtcIlR5cGVFcnJvclwiXSB8fCByb290W1wiVHlwZUVycm9yXCJdLFxuICAgICAgICAgICAgICAgICAgTWF0aCA9IGNvbnRleHRbXCJNYXRoXCJdIHx8IHJvb3RbXCJNYXRoXCJdLFxuICAgICAgICAgICAgICAgICAgbmF0aXZlSlNPTiA9IGNvbnRleHRbXCJKU09OXCJdIHx8IHJvb3RbXCJKU09OXCJdO1xuXG4gICAgICAgICAgICAgIC8vIERlbGVnYXRlIHRvIHRoZSBuYXRpdmUgYHN0cmluZ2lmeWAgYW5kIGBwYXJzZWAgaW1wbGVtZW50YXRpb25zLlxuICAgICAgICAgICAgICBpZiAodHlwZW9mIG5hdGl2ZUpTT04gPT0gXCJvYmplY3RcIiAmJiBuYXRpdmVKU09OKSB7XG4gICAgICAgICAgICAgICAgZXhwb3J0cy5zdHJpbmdpZnkgPSBuYXRpdmVKU09OLnN0cmluZ2lmeTtcbiAgICAgICAgICAgICAgICBleHBvcnRzLnBhcnNlID0gbmF0aXZlSlNPTi5wYXJzZTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIC8vIENvbnZlbmllbmNlIGFsaWFzZXMuXG4gICAgICAgICAgICAgIHZhciBvYmplY3RQcm90byA9IE9iamVjdC5wcm90b3R5cGUsXG4gICAgICAgICAgICAgICAgICBnZXRDbGFzcyA9IG9iamVjdFByb3RvLnRvU3RyaW5nLFxuICAgICAgICAgICAgICAgICAgaXNQcm9wZXJ0eSxcbiAgICAgICAgICAgICAgICAgIGZvckVhY2gsXG4gICAgICAgICAgICAgICAgICB1bmRlZjtcblxuICAgICAgICAgICAgICAvLyBUZXN0IHRoZSBgRGF0ZSNnZXRVVEMqYCBtZXRob2RzLiBCYXNlZCBvbiB3b3JrIGJ5IEBZYWZmbGUuXG4gICAgICAgICAgICAgIHZhciBpc0V4dGVuZGVkID0gbmV3IERhdGUoLTM1MDk4MjczMzQ1NzMyOTIpO1xuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIC8vIFRoZSBgZ2V0VVRDRnVsbFllYXJgLCBgTW9udGhgLCBhbmQgYERhdGVgIG1ldGhvZHMgcmV0dXJuIG5vbnNlbnNpY2FsXG4gICAgICAgICAgICAgICAgLy8gcmVzdWx0cyBmb3IgY2VydGFpbiBkYXRlcyBpbiBPcGVyYSA+PSAxMC41My5cbiAgICAgICAgICAgICAgICBpc0V4dGVuZGVkID0gaXNFeHRlbmRlZC5nZXRVVENGdWxsWWVhcigpID09IC0xMDkyNTIgJiYgaXNFeHRlbmRlZC5nZXRVVENNb250aCgpID09PSAwICYmIGlzRXh0ZW5kZWQuZ2V0VVRDRGF0ZSgpID09PSAxICYmXG4gICAgICAgICAgICAgICAgLy8gU2FmYXJpIDwgMi4wLjIgc3RvcmVzIHRoZSBpbnRlcm5hbCBtaWxsaXNlY29uZCB0aW1lIHZhbHVlIGNvcnJlY3RseSxcbiAgICAgICAgICAgICAgICAvLyBidXQgY2xpcHMgdGhlIHZhbHVlcyByZXR1cm5lZCBieSB0aGUgZGF0ZSBtZXRob2RzIHRvIHRoZSByYW5nZSBvZlxuICAgICAgICAgICAgICAgIC8vIHNpZ25lZCAzMi1iaXQgaW50ZWdlcnMgKFstMiAqKiAzMSwgMiAqKiAzMSAtIDFdKS5cbiAgICAgICAgICAgICAgICBpc0V4dGVuZGVkLmdldFVUQ0hvdXJzKCkgPT0gMTAgJiYgaXNFeHRlbmRlZC5nZXRVVENNaW51dGVzKCkgPT0gMzcgJiYgaXNFeHRlbmRlZC5nZXRVVENTZWNvbmRzKCkgPT0gNiAmJiBpc0V4dGVuZGVkLmdldFVUQ01pbGxpc2Vjb25kcygpID09IDcwODtcbiAgICAgICAgICAgICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7fVxuXG4gICAgICAgICAgICAgIC8vIEludGVybmFsOiBEZXRlcm1pbmVzIHdoZXRoZXIgdGhlIG5hdGl2ZSBgSlNPTi5zdHJpbmdpZnlgIGFuZCBgcGFyc2VgXG4gICAgICAgICAgICAgIC8vIGltcGxlbWVudGF0aW9ucyBhcmUgc3BlYy1jb21wbGlhbnQuIEJhc2VkIG9uIHdvcmsgYnkgS2VuIFNueWRlci5cbiAgICAgICAgICAgICAgZnVuY3Rpb24gaGFzKG5hbWUpIHtcbiAgICAgICAgICAgICAgICBpZiAoaGFzW25hbWVdICE9PSB1bmRlZikge1xuICAgICAgICAgICAgICAgICAgLy8gUmV0dXJuIGNhY2hlZCBmZWF0dXJlIHRlc3QgcmVzdWx0LlxuICAgICAgICAgICAgICAgICAgcmV0dXJuIGhhc1tuYW1lXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdmFyIGlzU3VwcG9ydGVkO1xuICAgICAgICAgICAgICAgIGlmIChuYW1lID09IFwiYnVnLXN0cmluZy1jaGFyLWluZGV4XCIpIHtcbiAgICAgICAgICAgICAgICAgIC8vIElFIDw9IDcgZG9lc24ndCBzdXBwb3J0IGFjY2Vzc2luZyBzdHJpbmcgY2hhcmFjdGVycyB1c2luZyBzcXVhcmVcbiAgICAgICAgICAgICAgICAgIC8vIGJyYWNrZXQgbm90YXRpb24uIElFIDggb25seSBzdXBwb3J0cyB0aGlzIGZvciBwcmltaXRpdmVzLlxuICAgICAgICAgICAgICAgICAgaXNTdXBwb3J0ZWQgPSBcImFcIlswXSAhPSBcImFcIjtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKG5hbWUgPT0gXCJqc29uXCIpIHtcbiAgICAgICAgICAgICAgICAgIC8vIEluZGljYXRlcyB3aGV0aGVyIGJvdGggYEpTT04uc3RyaW5naWZ5YCBhbmQgYEpTT04ucGFyc2VgIGFyZVxuICAgICAgICAgICAgICAgICAgLy8gc3VwcG9ydGVkLlxuICAgICAgICAgICAgICAgICAgaXNTdXBwb3J0ZWQgPSBoYXMoXCJqc29uLXN0cmluZ2lmeVwiKSAmJiBoYXMoXCJqc29uLXBhcnNlXCIpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICB2YXIgdmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgc2VyaWFsaXplZCA9IFwie1xcXCJhXFxcIjpbMSx0cnVlLGZhbHNlLG51bGwsXFxcIlxcXFx1MDAwMFxcXFxiXFxcXG5cXFxcZlxcXFxyXFxcXHRcXFwiXX1cIjtcbiAgICAgICAgICAgICAgICAgIC8vIFRlc3QgYEpTT04uc3RyaW5naWZ5YC5cbiAgICAgICAgICAgICAgICAgIGlmIChuYW1lID09IFwianNvbi1zdHJpbmdpZnlcIikge1xuICAgICAgICAgICAgICAgICAgICB2YXIgc3RyaW5naWZ5ID0gZXhwb3J0cy5zdHJpbmdpZnksXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJpbmdpZnlTdXBwb3J0ZWQgPSB0eXBlb2Ygc3RyaW5naWZ5ID09IFwiZnVuY3Rpb25cIiAmJiBpc0V4dGVuZGVkO1xuICAgICAgICAgICAgICAgICAgICBpZiAoc3RyaW5naWZ5U3VwcG9ydGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgLy8gQSB0ZXN0IGZ1bmN0aW9uIG9iamVjdCB3aXRoIGEgY3VzdG9tIGB0b0pTT05gIG1ldGhvZC5cbiAgICAgICAgICAgICAgICAgICAgICAodmFsdWUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gMTtcbiAgICAgICAgICAgICAgICAgICAgICB9KS50b0pTT04gPSB2YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc3RyaW5naWZ5U3VwcG9ydGVkID1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIEZpcmVmb3ggMy4xYjEgYW5kIGIyIHNlcmlhbGl6ZSBzdHJpbmcsIG51bWJlciwgYW5kIGJvb2xlYW5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHByaW1pdGl2ZXMgYXMgb2JqZWN0IGxpdGVyYWxzLlxuICAgICAgICAgICAgICAgICAgICAgICAgc3RyaW5naWZ5KDApID09PSBcIjBcIiAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gRkYgMy4xYjEsIGIyLCBhbmQgSlNPTiAyIHNlcmlhbGl6ZSB3cmFwcGVkIHByaW1pdGl2ZXMgYXMgb2JqZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBsaXRlcmFscy5cbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cmluZ2lmeShuZXcgTnVtYmVyKCkpID09PSBcIjBcIiAmJiBzdHJpbmdpZnkobmV3IFN0cmluZygpKSA9PSAnXCJcIicgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIEZGIDMuMWIxLCAyIHRocm93IGFuIGVycm9yIGlmIHRoZSB2YWx1ZSBpcyBgbnVsbGAsIGB1bmRlZmluZWRgLCBvclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZG9lcyBub3QgZGVmaW5lIGEgY2Fub25pY2FsIEpTT04gcmVwcmVzZW50YXRpb24gKHRoaXMgYXBwbGllcyB0b1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gb2JqZWN0cyB3aXRoIGB0b0pTT05gIHByb3BlcnRpZXMgYXMgd2VsbCwgKnVubGVzcyogdGhleSBhcmUgbmVzdGVkXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB3aXRoaW4gYW4gb2JqZWN0IG9yIGFycmF5KS5cbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cmluZ2lmeShnZXRDbGFzcykgPT09IHVuZGVmICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBJRSA4IHNlcmlhbGl6ZXMgYHVuZGVmaW5lZGAgYXMgYFwidW5kZWZpbmVkXCJgLiBTYWZhcmkgPD0gNS4xLjcgYW5kXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBGRiAzLjFiMyBwYXNzIHRoaXMgdGVzdC5cbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cmluZ2lmeSh1bmRlZikgPT09IHVuZGVmICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBTYWZhcmkgPD0gNS4xLjcgYW5kIEZGIDMuMWIzIHRocm93IGBFcnJvcmBzIGFuZCBgVHlwZUVycm9yYHMsXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyByZXNwZWN0aXZlbHksIGlmIHRoZSB2YWx1ZSBpcyBvbWl0dGVkIGVudGlyZWx5LlxuICAgICAgICAgICAgICAgICAgICAgICAgc3RyaW5naWZ5KCkgPT09IHVuZGVmICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBGRiAzLjFiMSwgMiB0aHJvdyBhbiBlcnJvciBpZiB0aGUgZ2l2ZW4gdmFsdWUgaXMgbm90IGEgbnVtYmVyLFxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gc3RyaW5nLCBhcnJheSwgb2JqZWN0LCBCb29sZWFuLCBvciBgbnVsbGAgbGl0ZXJhbC4gVGhpcyBhcHBsaWVzIHRvXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBvYmplY3RzIHdpdGggY3VzdG9tIGB0b0pTT05gIG1ldGhvZHMgYXMgd2VsbCwgdW5sZXNzIHRoZXkgYXJlIG5lc3RlZFxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gaW5zaWRlIG9iamVjdCBvciBhcnJheSBsaXRlcmFscy4gWVVJIDMuMC4wYjEgaWdub3JlcyBjdXN0b20gYHRvSlNPTmBcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIG1ldGhvZHMgZW50aXJlbHkuXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJpbmdpZnkodmFsdWUpID09PSBcIjFcIiAmJiBzdHJpbmdpZnkoW3ZhbHVlXSkgPT0gXCJbMV1cIiAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gUHJvdG90eXBlIDw9IDEuNi4xIHNlcmlhbGl6ZXMgYFt1bmRlZmluZWRdYCBhcyBgXCJbXVwiYCBpbnN0ZWFkIG9mXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBgXCJbbnVsbF1cImAuXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJpbmdpZnkoW3VuZGVmXSkgPT0gXCJbbnVsbF1cIiAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gWVVJIDMuMC4wYjEgZmFpbHMgdG8gc2VyaWFsaXplIGBudWxsYCBsaXRlcmFscy5cbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cmluZ2lmeShudWxsKSA9PSBcIm51bGxcIiAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gRkYgMy4xYjEsIDIgaGFsdHMgc2VyaWFsaXphdGlvbiBpZiBhbiBhcnJheSBjb250YWlucyBhIGZ1bmN0aW9uOlxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gYFsxLCB0cnVlLCBnZXRDbGFzcywgMV1gIHNlcmlhbGl6ZXMgYXMgXCJbMSx0cnVlLF0sXCIuIEZGIDMuMWIzXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBlbGlkZXMgbm9uLUpTT04gdmFsdWVzIGZyb20gb2JqZWN0cyBhbmQgYXJyYXlzLCB1bmxlc3MgdGhleVxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGVmaW5lIGN1c3RvbSBgdG9KU09OYCBtZXRob2RzLlxuICAgICAgICAgICAgICAgICAgICAgICAgc3RyaW5naWZ5KFt1bmRlZiwgZ2V0Q2xhc3MsIG51bGxdKSA9PSBcIltudWxsLG51bGwsbnVsbF1cIiAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gU2ltcGxlIHNlcmlhbGl6YXRpb24gdGVzdC4gRkYgMy4xYjEgdXNlcyBVbmljb2RlIGVzY2FwZSBzZXF1ZW5jZXNcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHdoZXJlIGNoYXJhY3RlciBlc2NhcGUgY29kZXMgYXJlIGV4cGVjdGVkIChlLmcuLCBgXFxiYCA9PiBgXFx1MDAwOGApLlxuICAgICAgICAgICAgICAgICAgICAgICAgc3RyaW5naWZ5KHsgXCJhXCI6IFt2YWx1ZSwgdHJ1ZSwgZmFsc2UsIG51bGwsIFwiXFx4MDBcXGJcXG5cXGZcXHJcXHRcIl0gfSkgPT0gc2VyaWFsaXplZCAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gRkYgMy4xYjEgYW5kIGIyIGlnbm9yZSB0aGUgYGZpbHRlcmAgYW5kIGB3aWR0aGAgYXJndW1lbnRzLlxuICAgICAgICAgICAgICAgICAgICAgICAgc3RyaW5naWZ5KG51bGwsIHZhbHVlKSA9PT0gXCIxXCIgJiYgc3RyaW5naWZ5KFsxLCAyXSwgbnVsbCwgMSkgPT0gXCJbXFxuIDEsXFxuIDJcXG5dXCIgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIEpTT04gMiwgUHJvdG90eXBlIDw9IDEuNywgYW5kIG9sZGVyIFdlYktpdCBidWlsZHMgaW5jb3JyZWN0bHlcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHNlcmlhbGl6ZSBleHRlbmRlZCB5ZWFycy5cbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cmluZ2lmeShuZXcgRGF0ZSgtOC42NGUxNSkpID09ICdcIi0yNzE4MjEtMDQtMjBUMDA6MDA6MDAuMDAwWlwiJyAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gVGhlIG1pbGxpc2Vjb25kcyBhcmUgb3B0aW9uYWwgaW4gRVMgNSwgYnV0IHJlcXVpcmVkIGluIDUuMS5cbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cmluZ2lmeShuZXcgRGF0ZSg4LjY0ZTE1KSkgPT0gJ1wiKzI3NTc2MC0wOS0xM1QwMDowMDowMC4wMDBaXCInICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBGaXJlZm94IDw9IDExLjAgaW5jb3JyZWN0bHkgc2VyaWFsaXplcyB5ZWFycyBwcmlvciB0byAwIGFzIG5lZ2F0aXZlXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBmb3VyLWRpZ2l0IHllYXJzIGluc3RlYWQgb2Ygc2l4LWRpZ2l0IHllYXJzLiBDcmVkaXRzOiBAWWFmZmxlLlxuICAgICAgICAgICAgICAgICAgICAgICAgc3RyaW5naWZ5KG5ldyBEYXRlKC02MjE5ODc1NTJlNSkpID09ICdcIi0wMDAwMDEtMDEtMDFUMDA6MDA6MDAuMDAwWlwiJyAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gU2FmYXJpIDw9IDUuMS41IGFuZCBPcGVyYSA+PSAxMC41MyBpbmNvcnJlY3RseSBzZXJpYWxpemUgbWlsbGlzZWNvbmRcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbHVlcyBsZXNzIHRoYW4gMTAwMC4gQ3JlZGl0czogQFlhZmZsZS5cbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cmluZ2lmeShuZXcgRGF0ZSgtMSkpID09ICdcIjE5NjktMTItMzFUMjM6NTk6NTkuOTk5WlwiJztcbiAgICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cmluZ2lmeVN1cHBvcnRlZCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpc1N1cHBvcnRlZCA9IHN0cmluZ2lmeVN1cHBvcnRlZDtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIC8vIFRlc3QgYEpTT04ucGFyc2VgLlxuICAgICAgICAgICAgICAgICAgaWYgKG5hbWUgPT0gXCJqc29uLXBhcnNlXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHBhcnNlID0gZXhwb3J0cy5wYXJzZTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBwYXJzZSA9PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gRkYgMy4xYjEsIGIyIHdpbGwgdGhyb3cgYW4gZXhjZXB0aW9uIGlmIGEgYmFyZSBsaXRlcmFsIGlzIHByb3ZpZGVkLlxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gQ29uZm9ybWluZyBpbXBsZW1lbnRhdGlvbnMgc2hvdWxkIGFsc28gY29lcmNlIHRoZSBpbml0aWFsIGFyZ3VtZW50IHRvXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBhIHN0cmluZyBwcmlvciB0byBwYXJzaW5nLlxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHBhcnNlKFwiMFwiKSA9PT0gMCAmJiAhcGFyc2UoZmFsc2UpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFNpbXBsZSBwYXJzaW5nIHRlc3QuXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlID0gcGFyc2Uoc2VyaWFsaXplZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwYXJzZVN1cHBvcnRlZCA9IHZhbHVlW1wiYVwiXS5sZW5ndGggPT0gNSAmJiB2YWx1ZVtcImFcIl1bMF0gPT09IDE7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwYXJzZVN1cHBvcnRlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBTYWZhcmkgPD0gNS4xLjIgYW5kIEZGIDMuMWIxIGFsbG93IHVuZXNjYXBlZCB0YWJzIGluIHN0cmluZ3MuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJzZVN1cHBvcnRlZCA9ICFwYXJzZSgnXCJcXHRcIicpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocGFyc2VTdXBwb3J0ZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEZGIDQuMCBhbmQgNC4wLjEgYWxsb3cgbGVhZGluZyBgK2Agc2lnbnMgYW5kIGxlYWRpbmdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGVjaW1hbCBwb2ludHMuIEZGIDQuMCwgNC4wLjEsIGFuZCBJRSA5LTEwIGFsc28gYWxsb3dcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY2VydGFpbiBvY3RhbCBsaXRlcmFscy5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VTdXBwb3J0ZWQgPSBwYXJzZShcIjAxXCIpICE9PSAxO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocGFyc2VTdXBwb3J0ZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEZGIDQuMCwgNC4wLjEsIGFuZCBSaGlubyAxLjdSMy1SNCBhbGxvdyB0cmFpbGluZyBkZWNpbWFsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHBvaW50cy4gVGhlc2UgZW52aXJvbm1lbnRzLCBhbG9uZyB3aXRoIEZGIDMuMWIxIGFuZCAyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBhbHNvIGFsbG93IHRyYWlsaW5nIGNvbW1hcyBpbiBKU09OIG9iamVjdHMgYW5kIGFycmF5cy5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VTdXBwb3J0ZWQgPSBwYXJzZShcIjEuXCIpICE9PSAxO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VTdXBwb3J0ZWQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaXNTdXBwb3J0ZWQgPSBwYXJzZVN1cHBvcnRlZDtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIGhhc1tuYW1lXSA9ICEhaXNTdXBwb3J0ZWQ7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICBpZiAoIWhhcyhcImpzb25cIikpIHtcbiAgICAgICAgICAgICAgICAvLyBDb21tb24gYFtbQ2xhc3NdXWAgbmFtZSBhbGlhc2VzLlxuICAgICAgICAgICAgICAgIHZhciBmdW5jdGlvbkNsYXNzID0gXCJbb2JqZWN0IEZ1bmN0aW9uXVwiLFxuICAgICAgICAgICAgICAgICAgICBkYXRlQ2xhc3MgPSBcIltvYmplY3QgRGF0ZV1cIixcbiAgICAgICAgICAgICAgICAgICAgbnVtYmVyQ2xhc3MgPSBcIltvYmplY3QgTnVtYmVyXVwiLFxuICAgICAgICAgICAgICAgICAgICBzdHJpbmdDbGFzcyA9IFwiW29iamVjdCBTdHJpbmddXCIsXG4gICAgICAgICAgICAgICAgICAgIGFycmF5Q2xhc3MgPSBcIltvYmplY3QgQXJyYXldXCIsXG4gICAgICAgICAgICAgICAgICAgIGJvb2xlYW5DbGFzcyA9IFwiW29iamVjdCBCb29sZWFuXVwiO1xuXG4gICAgICAgICAgICAgICAgLy8gRGV0ZWN0IGluY29tcGxldGUgc3VwcG9ydCBmb3IgYWNjZXNzaW5nIHN0cmluZyBjaGFyYWN0ZXJzIGJ5IGluZGV4LlxuICAgICAgICAgICAgICAgIHZhciBjaGFySW5kZXhCdWdneSA9IGhhcyhcImJ1Zy1zdHJpbmctY2hhci1pbmRleFwiKTtcblxuICAgICAgICAgICAgICAgIC8vIERlZmluZSBhZGRpdGlvbmFsIHV0aWxpdHkgbWV0aG9kcyBpZiB0aGUgYERhdGVgIG1ldGhvZHMgYXJlIGJ1Z2d5LlxuICAgICAgICAgICAgICAgIGlmICghaXNFeHRlbmRlZCkge1xuICAgICAgICAgICAgICAgICAgdmFyIGZsb29yID0gTWF0aC5mbG9vcjtcbiAgICAgICAgICAgICAgICAgIC8vIEEgbWFwcGluZyBiZXR3ZWVuIHRoZSBtb250aHMgb2YgdGhlIHllYXIgYW5kIHRoZSBudW1iZXIgb2YgZGF5cyBiZXR3ZWVuXG4gICAgICAgICAgICAgICAgICAvLyBKYW51YXJ5IDFzdCBhbmQgdGhlIGZpcnN0IG9mIHRoZSByZXNwZWN0aXZlIG1vbnRoLlxuICAgICAgICAgICAgICAgICAgdmFyIE1vbnRocyA9IFswLCAzMSwgNTksIDkwLCAxMjAsIDE1MSwgMTgxLCAyMTIsIDI0MywgMjczLCAzMDQsIDMzNF07XG4gICAgICAgICAgICAgICAgICAvLyBJbnRlcm5hbDogQ2FsY3VsYXRlcyB0aGUgbnVtYmVyIG9mIGRheXMgYmV0d2VlbiB0aGUgVW5peCBlcG9jaCBhbmQgdGhlXG4gICAgICAgICAgICAgICAgICAvLyBmaXJzdCBkYXkgb2YgdGhlIGdpdmVuIG1vbnRoLlxuICAgICAgICAgICAgICAgICAgdmFyIGdldERheSA9IGZ1bmN0aW9uIGdldERheSh5ZWFyLCBtb250aCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gTW9udGhzW21vbnRoXSArIDM2NSAqICh5ZWFyIC0gMTk3MCkgKyBmbG9vcigoeWVhciAtIDE5NjkgKyAobW9udGggPSArKG1vbnRoID4gMSkpKSAvIDQpIC0gZmxvb3IoKHllYXIgLSAxOTAxICsgbW9udGgpIC8gMTAwKSArIGZsb29yKCh5ZWFyIC0gMTYwMSArIG1vbnRoKSAvIDQwMCk7XG4gICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vIEludGVybmFsOiBEZXRlcm1pbmVzIGlmIGEgcHJvcGVydHkgaXMgYSBkaXJlY3QgcHJvcGVydHkgb2YgdGhlIGdpdmVuXG4gICAgICAgICAgICAgICAgLy8gb2JqZWN0LiBEZWxlZ2F0ZXMgdG8gdGhlIG5hdGl2ZSBgT2JqZWN0I2hhc093blByb3BlcnR5YCBtZXRob2QuXG4gICAgICAgICAgICAgICAgaWYgKCEoaXNQcm9wZXJ0eSA9IG9iamVjdFByb3RvLmhhc093blByb3BlcnR5KSkge1xuICAgICAgICAgICAgICAgICAgaXNQcm9wZXJ0eSA9IGZ1bmN0aW9uIChwcm9wZXJ0eSkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgbWVtYmVycyA9IHt9LFxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3RydWN0b3I7XG4gICAgICAgICAgICAgICAgICAgIGlmICgobWVtYmVycy5fX3Byb3RvX18gPSBudWxsLCBtZW1iZXJzLl9fcHJvdG9fXyA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAvLyBUaGUgKnByb3RvKiBwcm9wZXJ0eSBjYW5ub3QgYmUgc2V0IG11bHRpcGxlIHRpbWVzIGluIHJlY2VudFxuICAgICAgICAgICAgICAgICAgICAgIC8vIHZlcnNpb25zIG9mIEZpcmVmb3ggYW5kIFNlYU1vbmtleS5cbiAgICAgICAgICAgICAgICAgICAgICBcInRvU3RyaW5nXCI6IDFcbiAgICAgICAgICAgICAgICAgICAgfSwgbWVtYmVycykudG9TdHJpbmcgIT0gZ2V0Q2xhc3MpIHtcbiAgICAgICAgICAgICAgICAgICAgICAvLyBTYWZhcmkgPD0gMi4wLjMgZG9lc24ndCBpbXBsZW1lbnQgYE9iamVjdCNoYXNPd25Qcm9wZXJ0eWAsIGJ1dFxuICAgICAgICAgICAgICAgICAgICAgIC8vIHN1cHBvcnRzIHRoZSBtdXRhYmxlICpwcm90byogcHJvcGVydHkuXG4gICAgICAgICAgICAgICAgICAgICAgaXNQcm9wZXJ0eSA9IGZ1bmN0aW9uIChwcm9wZXJ0eSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gQ2FwdHVyZSBhbmQgYnJlYWsgdGhlIG9iamVjdCdzIHByb3RvdHlwZSBjaGFpbiAoc2VlIHNlY3Rpb24gOC42LjJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIG9mIHRoZSBFUyA1LjEgc3BlYykuIFRoZSBwYXJlbnRoZXNpemVkIGV4cHJlc3Npb24gcHJldmVudHMgYW5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHVuc2FmZSB0cmFuc2Zvcm1hdGlvbiBieSB0aGUgQ2xvc3VyZSBDb21waWxlci5cbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBvcmlnaW5hbCA9IHRoaXMuX19wcm90b19fLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdCA9IChwcm9wZXJ0eSBpbiAodGhpcy5fX3Byb3RvX18gPSBudWxsLCB0aGlzKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBSZXN0b3JlIHRoZSBvcmlnaW5hbCBwcm90b3R5cGUgY2hhaW4uXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9fcHJvdG9fXyA9IG9yaWdpbmFsO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgIC8vIENhcHR1cmUgYSByZWZlcmVuY2UgdG8gdGhlIHRvcC1sZXZlbCBgT2JqZWN0YCBjb25zdHJ1Y3Rvci5cbiAgICAgICAgICAgICAgICAgICAgICBjb25zdHJ1Y3RvciA9IG1lbWJlcnMuY29uc3RydWN0b3I7XG4gICAgICAgICAgICAgICAgICAgICAgLy8gVXNlIHRoZSBgY29uc3RydWN0b3JgIHByb3BlcnR5IHRvIHNpbXVsYXRlIGBPYmplY3QjaGFzT3duUHJvcGVydHlgIGluXG4gICAgICAgICAgICAgICAgICAgICAgLy8gb3RoZXIgZW52aXJvbm1lbnRzLlxuICAgICAgICAgICAgICAgICAgICAgIGlzUHJvcGVydHkgPSBmdW5jdGlvbiAocHJvcGVydHkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwYXJlbnQgPSAodGhpcy5jb25zdHJ1Y3RvciB8fCBjb25zdHJ1Y3RvcikucHJvdG90eXBlO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHByb3BlcnR5IGluIHRoaXMgJiYgIShwcm9wZXJ0eSBpbiBwYXJlbnQgJiYgdGhpc1twcm9wZXJ0eV0gPT09IHBhcmVudFtwcm9wZXJ0eV0pO1xuICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgbWVtYmVycyA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpc1Byb3BlcnR5LmNhbGwodGhpcywgcHJvcGVydHkpO1xuICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAvLyBJbnRlcm5hbDogTm9ybWFsaXplcyB0aGUgYGZvci4uLmluYCBpdGVyYXRpb24gYWxnb3JpdGhtIGFjcm9zc1xuICAgICAgICAgICAgICAgIC8vIGVudmlyb25tZW50cy4gRWFjaCBlbnVtZXJhdGVkIGtleSBpcyB5aWVsZGVkIHRvIGEgYGNhbGxiYWNrYCBmdW5jdGlvbi5cbiAgICAgICAgICAgICAgICBmb3JFYWNoID0gZnVuY3Rpb24gKG9iamVjdCwgY2FsbGJhY2spIHtcbiAgICAgICAgICAgICAgICAgIHZhciBzaXplID0gMCxcbiAgICAgICAgICAgICAgICAgICAgICBQcm9wZXJ0aWVzLFxuICAgICAgICAgICAgICAgICAgICAgIG1lbWJlcnMsXG4gICAgICAgICAgICAgICAgICAgICAgcHJvcGVydHk7XG5cbiAgICAgICAgICAgICAgICAgIC8vIFRlc3RzIGZvciBidWdzIGluIHRoZSBjdXJyZW50IGVudmlyb25tZW50J3MgYGZvci4uLmluYCBhbGdvcml0aG0uIFRoZVxuICAgICAgICAgICAgICAgICAgLy8gYHZhbHVlT2ZgIHByb3BlcnR5IGluaGVyaXRzIHRoZSBub24tZW51bWVyYWJsZSBmbGFnIGZyb21cbiAgICAgICAgICAgICAgICAgIC8vIGBPYmplY3QucHJvdG90eXBlYCBpbiBvbGRlciB2ZXJzaW9ucyBvZiBJRSwgTmV0c2NhcGUsIGFuZCBNb3ppbGxhLlxuICAgICAgICAgICAgICAgICAgKFByb3BlcnRpZXMgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMudmFsdWVPZiA9IDA7XG4gICAgICAgICAgICAgICAgICB9KS5wcm90b3R5cGUudmFsdWVPZiA9IDA7XG5cbiAgICAgICAgICAgICAgICAgIC8vIEl0ZXJhdGUgb3ZlciBhIG5ldyBpbnN0YW5jZSBvZiB0aGUgYFByb3BlcnRpZXNgIGNsYXNzLlxuICAgICAgICAgICAgICAgICAgbWVtYmVycyA9IG5ldyBQcm9wZXJ0aWVzKCk7XG4gICAgICAgICAgICAgICAgICBmb3IgKHByb3BlcnR5IGluIG1lbWJlcnMpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gSWdub3JlIGFsbCBwcm9wZXJ0aWVzIGluaGVyaXRlZCBmcm9tIGBPYmplY3QucHJvdG90eXBlYC5cbiAgICAgICAgICAgICAgICAgICAgaWYgKGlzUHJvcGVydHkuY2FsbChtZW1iZXJzLCBwcm9wZXJ0eSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICBzaXplKys7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIFByb3BlcnRpZXMgPSBtZW1iZXJzID0gbnVsbDtcblxuICAgICAgICAgICAgICAgICAgLy8gTm9ybWFsaXplIHRoZSBpdGVyYXRpb24gYWxnb3JpdGhtLlxuICAgICAgICAgICAgICAgICAgaWYgKCFzaXplKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIEEgbGlzdCBvZiBub24tZW51bWVyYWJsZSBwcm9wZXJ0aWVzIGluaGVyaXRlZCBmcm9tIGBPYmplY3QucHJvdG90eXBlYC5cbiAgICAgICAgICAgICAgICAgICAgbWVtYmVycyA9IFtcInZhbHVlT2ZcIiwgXCJ0b1N0cmluZ1wiLCBcInRvTG9jYWxlU3RyaW5nXCIsIFwicHJvcGVydHlJc0VudW1lcmFibGVcIiwgXCJpc1Byb3RvdHlwZU9mXCIsIFwiaGFzT3duUHJvcGVydHlcIiwgXCJjb25zdHJ1Y3RvclwiXTtcbiAgICAgICAgICAgICAgICAgICAgLy8gSUUgPD0gOCwgTW96aWxsYSAxLjAsIGFuZCBOZXRzY2FwZSA2LjIgaWdub3JlIHNoYWRvd2VkIG5vbi1lbnVtZXJhYmxlXG4gICAgICAgICAgICAgICAgICAgIC8vIHByb3BlcnRpZXMuXG4gICAgICAgICAgICAgICAgICAgIGZvckVhY2ggPSBmdW5jdGlvbiAob2JqZWN0LCBjYWxsYmFjaykge1xuICAgICAgICAgICAgICAgICAgICAgIHZhciBpc0Z1bmN0aW9uID0gZ2V0Q2xhc3MuY2FsbChvYmplY3QpID09IGZ1bmN0aW9uQ2xhc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHByb3BlcnR5LFxuICAgICAgICAgICAgICAgICAgICAgICAgICBsZW5ndGg7XG4gICAgICAgICAgICAgICAgICAgICAgdmFyIGhhc1Byb3BlcnR5ID0gIWlzRnVuY3Rpb24gJiYgdHlwZW9mIG9iamVjdC5jb25zdHJ1Y3RvciAhPSBcImZ1bmN0aW9uXCIgJiYgb2JqZWN0VHlwZXNbdHlwZW9mIG9iamVjdC5oYXNPd25Qcm9wZXJ0eV0gJiYgb2JqZWN0Lmhhc093blByb3BlcnR5IHx8IGlzUHJvcGVydHk7XG4gICAgICAgICAgICAgICAgICAgICAgZm9yIChwcm9wZXJ0eSBpbiBvYmplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIEdlY2tvIDw9IDEuMCBlbnVtZXJhdGVzIHRoZSBgcHJvdG90eXBlYCBwcm9wZXJ0eSBvZiBmdW5jdGlvbnMgdW5kZXJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNlcnRhaW4gY29uZGl0aW9uczsgSUUgZG9lcyBub3QuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIShpc0Z1bmN0aW9uICYmIHByb3BlcnR5ID09IFwicHJvdG90eXBlXCIpICYmIGhhc1Byb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2socHJvcGVydHkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAvLyBNYW51YWxseSBpbnZva2UgdGhlIGNhbGxiYWNrIGZvciBlYWNoIG5vbi1lbnVtZXJhYmxlIHByb3BlcnR5LlxuICAgICAgICAgICAgICAgICAgICAgIGZvciAobGVuZ3RoID0gbWVtYmVycy5sZW5ndGg7IHByb3BlcnR5ID0gbWVtYmVyc1stLWxlbmd0aF07IGhhc1Byb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSkgJiYgY2FsbGJhY2socHJvcGVydHkpKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoc2l6ZSA9PSAyKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIFNhZmFyaSA8PSAyLjAuNCBlbnVtZXJhdGVzIHNoYWRvd2VkIHByb3BlcnRpZXMgdHdpY2UuXG4gICAgICAgICAgICAgICAgICAgIGZvckVhY2ggPSBmdW5jdGlvbiAob2JqZWN0LCBjYWxsYmFjaykge1xuICAgICAgICAgICAgICAgICAgICAgIC8vIENyZWF0ZSBhIHNldCBvZiBpdGVyYXRlZCBwcm9wZXJ0aWVzLlxuICAgICAgICAgICAgICAgICAgICAgIHZhciBtZW1iZXJzID0ge30sXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlzRnVuY3Rpb24gPSBnZXRDbGFzcy5jYWxsKG9iamVjdCkgPT0gZnVuY3Rpb25DbGFzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcGVydHk7XG4gICAgICAgICAgICAgICAgICAgICAgZm9yIChwcm9wZXJ0eSBpbiBvYmplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFN0b3JlIGVhY2ggcHJvcGVydHkgbmFtZSB0byBwcmV2ZW50IGRvdWJsZSBlbnVtZXJhdGlvbi4gVGhlXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBgcHJvdG90eXBlYCBwcm9wZXJ0eSBvZiBmdW5jdGlvbnMgaXMgbm90IGVudW1lcmF0ZWQgZHVlIHRvIGNyb3NzLVxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZW52aXJvbm1lbnQgaW5jb25zaXN0ZW5jaWVzLlxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCEoaXNGdW5jdGlvbiAmJiBwcm9wZXJ0eSA9PSBcInByb3RvdHlwZVwiKSAmJiAhaXNQcm9wZXJ0eS5jYWxsKG1lbWJlcnMsIHByb3BlcnR5KSAmJiAobWVtYmVyc1twcm9wZXJ0eV0gPSAxKSAmJiBpc1Byb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2socHJvcGVydHkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIE5vIGJ1Z3MgZGV0ZWN0ZWQ7IHVzZSB0aGUgc3RhbmRhcmQgYGZvci4uLmluYCBhbGdvcml0aG0uXG4gICAgICAgICAgICAgICAgICAgIGZvckVhY2ggPSBmdW5jdGlvbiAob2JqZWN0LCBjYWxsYmFjaykge1xuICAgICAgICAgICAgICAgICAgICAgIHZhciBpc0Z1bmN0aW9uID0gZ2V0Q2xhc3MuY2FsbChvYmplY3QpID09IGZ1bmN0aW9uQ2xhc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHByb3BlcnR5LFxuICAgICAgICAgICAgICAgICAgICAgICAgICBpc0NvbnN0cnVjdG9yO1xuICAgICAgICAgICAgICAgICAgICAgIGZvciAocHJvcGVydHkgaW4gb2JqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIShpc0Z1bmN0aW9uICYmIHByb3BlcnR5ID09IFwicHJvdG90eXBlXCIpICYmIGlzUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KSAmJiAhKGlzQ29uc3RydWN0b3IgPSBwcm9wZXJ0eSA9PT0gXCJjb25zdHJ1Y3RvclwiKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBjYWxsYmFjayhwcm9wZXJ0eSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIC8vIE1hbnVhbGx5IGludm9rZSB0aGUgY2FsbGJhY2sgZm9yIHRoZSBgY29uc3RydWN0b3JgIHByb3BlcnR5IGR1ZSB0b1xuICAgICAgICAgICAgICAgICAgICAgIC8vIGNyb3NzLWVudmlyb25tZW50IGluY29uc2lzdGVuY2llcy5cbiAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNDb25zdHJ1Y3RvciB8fCBpc1Byb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSA9IFwiY29uc3RydWN0b3JcIikpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrKHByb3BlcnR5KTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICByZXR1cm4gZm9yRWFjaChvYmplY3QsIGNhbGxiYWNrKTtcbiAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgLy8gUHVibGljOiBTZXJpYWxpemVzIGEgSmF2YVNjcmlwdCBgdmFsdWVgIGFzIGEgSlNPTiBzdHJpbmcuIFRoZSBvcHRpb25hbFxuICAgICAgICAgICAgICAgIC8vIGBmaWx0ZXJgIGFyZ3VtZW50IG1heSBzcGVjaWZ5IGVpdGhlciBhIGZ1bmN0aW9uIHRoYXQgYWx0ZXJzIGhvdyBvYmplY3QgYW5kXG4gICAgICAgICAgICAgICAgLy8gYXJyYXkgbWVtYmVycyBhcmUgc2VyaWFsaXplZCwgb3IgYW4gYXJyYXkgb2Ygc3RyaW5ncyBhbmQgbnVtYmVycyB0aGF0XG4gICAgICAgICAgICAgICAgLy8gaW5kaWNhdGVzIHdoaWNoIHByb3BlcnRpZXMgc2hvdWxkIGJlIHNlcmlhbGl6ZWQuIFRoZSBvcHRpb25hbCBgd2lkdGhgXG4gICAgICAgICAgICAgICAgLy8gYXJndW1lbnQgbWF5IGJlIGVpdGhlciBhIHN0cmluZyBvciBudW1iZXIgdGhhdCBzcGVjaWZpZXMgdGhlIGluZGVudGF0aW9uXG4gICAgICAgICAgICAgICAgLy8gbGV2ZWwgb2YgdGhlIG91dHB1dC5cbiAgICAgICAgICAgICAgICBpZiAoIWhhcyhcImpzb24tc3RyaW5naWZ5XCIpKSB7XG4gICAgICAgICAgICAgICAgICAvLyBJbnRlcm5hbDogQSBtYXAgb2YgY29udHJvbCBjaGFyYWN0ZXJzIGFuZCB0aGVpciBlc2NhcGVkIGVxdWl2YWxlbnRzLlxuICAgICAgICAgICAgICAgICAgdmFyIEVzY2FwZXMgPSB7XG4gICAgICAgICAgICAgICAgICAgIDkyOiBcIlxcXFxcXFxcXCIsXG4gICAgICAgICAgICAgICAgICAgIDM0OiAnXFxcXFwiJyxcbiAgICAgICAgICAgICAgICAgICAgODogXCJcXFxcYlwiLFxuICAgICAgICAgICAgICAgICAgICAxMjogXCJcXFxcZlwiLFxuICAgICAgICAgICAgICAgICAgICAxMDogXCJcXFxcblwiLFxuICAgICAgICAgICAgICAgICAgICAxMzogXCJcXFxcclwiLFxuICAgICAgICAgICAgICAgICAgICA5OiBcIlxcXFx0XCJcbiAgICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAgIC8vIEludGVybmFsOiBDb252ZXJ0cyBgdmFsdWVgIGludG8gYSB6ZXJvLXBhZGRlZCBzdHJpbmcgc3VjaCB0aGF0IGl0c1xuICAgICAgICAgICAgICAgICAgLy8gbGVuZ3RoIGlzIGF0IGxlYXN0IGVxdWFsIHRvIGB3aWR0aGAuIFRoZSBgd2lkdGhgIG11c3QgYmUgPD0gNi5cbiAgICAgICAgICAgICAgICAgIHZhciBsZWFkaW5nWmVyb2VzID0gXCIwMDAwMDBcIjtcbiAgICAgICAgICAgICAgICAgIHZhciB0b1BhZGRlZFN0cmluZyA9IGZ1bmN0aW9uIHRvUGFkZGVkU3RyaW5nKHdpZHRoLCB2YWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICAvLyBUaGUgYHx8IDBgIGV4cHJlc3Npb24gaXMgbmVjZXNzYXJ5IHRvIHdvcmsgYXJvdW5kIGEgYnVnIGluXG4gICAgICAgICAgICAgICAgICAgIC8vIE9wZXJhIDw9IDcuNTR1MiB3aGVyZSBgMCA9PSAtMGAsIGJ1dCBgU3RyaW5nKC0wKSAhPT0gXCIwXCJgLlxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKGxlYWRpbmdaZXJvZXMgKyAodmFsdWUgfHwgMCkpLnNsaWNlKC13aWR0aCk7XG4gICAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgICAvLyBJbnRlcm5hbDogRG91YmxlLXF1b3RlcyBhIHN0cmluZyBgdmFsdWVgLCByZXBsYWNpbmcgYWxsIEFTQ0lJIGNvbnRyb2xcbiAgICAgICAgICAgICAgICAgIC8vIGNoYXJhY3RlcnMgKGNoYXJhY3RlcnMgd2l0aCBjb2RlIHVuaXQgdmFsdWVzIGJldHdlZW4gMCBhbmQgMzEpIHdpdGhcbiAgICAgICAgICAgICAgICAgIC8vIHRoZWlyIGVzY2FwZWQgZXF1aXZhbGVudHMuIFRoaXMgaXMgYW4gaW1wbGVtZW50YXRpb24gb2YgdGhlXG4gICAgICAgICAgICAgICAgICAvLyBgUXVvdGUodmFsdWUpYCBvcGVyYXRpb24gZGVmaW5lZCBpbiBFUyA1LjEgc2VjdGlvbiAxNS4xMi4zLlxuICAgICAgICAgICAgICAgICAgdmFyIHVuaWNvZGVQcmVmaXggPSBcIlxcXFx1MDBcIjtcbiAgICAgICAgICAgICAgICAgIHZhciBxdW90ZSA9IGZ1bmN0aW9uIHF1b3RlKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciByZXN1bHQgPSAnXCInLFxuICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXggPSAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgbGVuZ3RoID0gdmFsdWUubGVuZ3RoLFxuICAgICAgICAgICAgICAgICAgICAgICAgdXNlQ2hhckluZGV4ID0gIWNoYXJJbmRleEJ1Z2d5IHx8IGxlbmd0aCA+IDEwO1xuICAgICAgICAgICAgICAgICAgICB2YXIgc3ltYm9scyA9IHVzZUNoYXJJbmRleCAmJiAoY2hhckluZGV4QnVnZ3kgPyB2YWx1ZS5zcGxpdChcIlwiKSA6IHZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgZm9yICg7IGluZGV4IDwgbGVuZ3RoOyBpbmRleCsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgdmFyIGNoYXJDb2RlID0gdmFsdWUuY2hhckNvZGVBdChpbmRleCk7XG4gICAgICAgICAgICAgICAgICAgICAgLy8gSWYgdGhlIGNoYXJhY3RlciBpcyBhIGNvbnRyb2wgY2hhcmFjdGVyLCBhcHBlbmQgaXRzIFVuaWNvZGUgb3JcbiAgICAgICAgICAgICAgICAgICAgICAvLyBzaG9ydGhhbmQgZXNjYXBlIHNlcXVlbmNlOyBvdGhlcndpc2UsIGFwcGVuZCB0aGUgY2hhcmFjdGVyIGFzLWlzLlxuICAgICAgICAgICAgICAgICAgICAgIHN3aXRjaCAoY2hhckNvZGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgODpjYXNlIDk6Y2FzZSAxMDpjYXNlIDEyOmNhc2UgMTM6Y2FzZSAzNDpjYXNlIDkyOlxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQgKz0gRXNjYXBlc1tjaGFyQ29kZV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNoYXJDb2RlIDwgMzIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQgKz0gdW5pY29kZVByZWZpeCArIHRvUGFkZGVkU3RyaW5nKDIsIGNoYXJDb2RlLnRvU3RyaW5nKDE2KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0ICs9IHVzZUNoYXJJbmRleCA/IHN5bWJvbHNbaW5kZXhdIDogdmFsdWUuY2hhckF0KGluZGV4KTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdCArICdcIic7XG4gICAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgICAvLyBJbnRlcm5hbDogUmVjdXJzaXZlbHkgc2VyaWFsaXplcyBhbiBvYmplY3QuIEltcGxlbWVudHMgdGhlXG4gICAgICAgICAgICAgICAgICAvLyBgU3RyKGtleSwgaG9sZGVyKWAsIGBKTyh2YWx1ZSlgLCBhbmQgYEpBKHZhbHVlKWAgb3BlcmF0aW9ucy5cbiAgICAgICAgICAgICAgICAgIHZhciBzZXJpYWxpemUgPSBmdW5jdGlvbiBzZXJpYWxpemUocHJvcGVydHksIG9iamVjdCwgY2FsbGJhY2ssIHByb3BlcnRpZXMsIHdoaXRlc3BhY2UsIGluZGVudGF0aW9uLCBzdGFjaykge1xuICAgICAgICAgICAgICAgICAgICB2YXIgdmFsdWUsIGNsYXNzTmFtZSwgeWVhciwgbW9udGgsIGRhdGUsIHRpbWUsIGhvdXJzLCBtaW51dGVzLCBzZWNvbmRzLCBtaWxsaXNlY29uZHMsIHJlc3VsdHMsIGVsZW1lbnQsIGluZGV4LCBsZW5ndGgsIHByZWZpeCwgcmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgIC8vIE5lY2Vzc2FyeSBmb3IgaG9zdCBvYmplY3Qgc3VwcG9ydC5cbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZSA9IG9iamVjdFtwcm9wZXJ0eV07XG4gICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge31cbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSA9PSBcIm9iamVjdFwiICYmIHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lID0gZ2V0Q2xhc3MuY2FsbCh2YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGNsYXNzTmFtZSA9PSBkYXRlQ2xhc3MgJiYgIWlzUHJvcGVydHkuY2FsbCh2YWx1ZSwgXCJ0b0pTT05cIikpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWx1ZSA+IC0xIC8gMCAmJiB2YWx1ZSA8IDEgLyAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8vIERhdGVzIGFyZSBzZXJpYWxpemVkIGFjY29yZGluZyB0byB0aGUgYERhdGUjdG9KU09OYCBtZXRob2RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gc3BlY2lmaWVkIGluIEVTIDUuMSBzZWN0aW9uIDE1LjkuNS40NC4gU2VlIHNlY3Rpb24gMTUuOS4xLjE1XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGZvciB0aGUgSVNPIDg2MDEgZGF0ZSB0aW1lIHN0cmluZyBmb3JtYXQuXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChnZXREYXkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBNYW51YWxseSBjb21wdXRlIHRoZSB5ZWFyLCBtb250aCwgZGF0ZSwgaG91cnMsIG1pbnV0ZXMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gc2Vjb25kcywgYW5kIG1pbGxpc2Vjb25kcyBpZiB0aGUgYGdldFVUQypgIG1ldGhvZHMgYXJlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gYnVnZ3kuIEFkYXB0ZWQgZnJvbSBAWWFmZmxlJ3MgYGRhdGUtc2hpbWAgcHJvamVjdC5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRlID0gZmxvb3IodmFsdWUgLyA4NjRlNSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh5ZWFyID0gZmxvb3IoZGF0ZSAvIDM2NS4yNDI1KSArIDE5NzAgLSAxOyBnZXREYXkoeWVhciArIDEsIDApIDw9IGRhdGU7IHllYXIrKyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChtb250aCA9IGZsb29yKChkYXRlIC0gZ2V0RGF5KHllYXIsIDApKSAvIDMwLjQyKTsgZ2V0RGF5KHllYXIsIG1vbnRoICsgMSkgPD0gZGF0ZTsgbW9udGgrKyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0ZSA9IDEgKyBkYXRlIC0gZ2V0RGF5KHllYXIsIG1vbnRoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBUaGUgYHRpbWVgIHZhbHVlIHNwZWNpZmllcyB0aGUgdGltZSB3aXRoaW4gdGhlIGRheSAoc2VlIEVTXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gNS4xIHNlY3Rpb24gMTUuOS4xLjIpLiBUaGUgZm9ybXVsYSBgKEEgJSBCICsgQikgJSBCYCBpcyB1c2VkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdG8gY29tcHV0ZSBgQSBtb2R1bG8gQmAsIGFzIHRoZSBgJWAgb3BlcmF0b3IgZG9lcyBub3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb3JyZXNwb25kIHRvIHRoZSBgbW9kdWxvYCBvcGVyYXRpb24gZm9yIG5lZ2F0aXZlIG51bWJlcnMuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGltZSA9ICh2YWx1ZSAlIDg2NGU1ICsgODY0ZTUpICUgODY0ZTU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gVGhlIGhvdXJzLCBtaW51dGVzLCBzZWNvbmRzLCBhbmQgbWlsbGlzZWNvbmRzIGFyZSBvYnRhaW5lZCBieVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRlY29tcG9zaW5nIHRoZSB0aW1lIHdpdGhpbiB0aGUgZGF5LiBTZWUgc2VjdGlvbiAxNS45LjEuMTAuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaG91cnMgPSBmbG9vcih0aW1lIC8gMzZlNSkgJSAyNDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW51dGVzID0gZmxvb3IodGltZSAvIDZlNCkgJSA2MDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWNvbmRzID0gZmxvb3IodGltZSAvIDFlMykgJSA2MDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaWxsaXNlY29uZHMgPSB0aW1lICUgMWUzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHllYXIgPSB2YWx1ZS5nZXRVVENGdWxsWWVhcigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vbnRoID0gdmFsdWUuZ2V0VVRDTW9udGgoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRlID0gdmFsdWUuZ2V0VVRDRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhvdXJzID0gdmFsdWUuZ2V0VVRDSG91cnMoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW51dGVzID0gdmFsdWUuZ2V0VVRDTWludXRlcygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlY29uZHMgPSB2YWx1ZS5nZXRVVENTZWNvbmRzKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWlsbGlzZWNvbmRzID0gdmFsdWUuZ2V0VVRDTWlsbGlzZWNvbmRzKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gU2VyaWFsaXplIGV4dGVuZGVkIHllYXJzIGNvcnJlY3RseS5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWUgPSAoeWVhciA8PSAwIHx8IHllYXIgPj0gMWU0ID8gKHllYXIgPCAwID8gXCItXCIgOiBcIitcIikgKyB0b1BhZGRlZFN0cmluZyg2LCB5ZWFyIDwgMCA/IC15ZWFyIDogeWVhcikgOiB0b1BhZGRlZFN0cmluZyg0LCB5ZWFyKSkgKyBcIi1cIiArIHRvUGFkZGVkU3RyaW5nKDIsIG1vbnRoICsgMSkgKyBcIi1cIiArIHRvUGFkZGVkU3RyaW5nKDIsIGRhdGUpICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gTW9udGhzLCBkYXRlcywgaG91cnMsIG1pbnV0ZXMsIGFuZCBzZWNvbmRzIHNob3VsZCBoYXZlIHR3b1xuICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkaWdpdHM7IG1pbGxpc2Vjb25kcyBzaG91bGQgaGF2ZSB0aHJlZS5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJUXCIgKyB0b1BhZGRlZFN0cmluZygyLCBob3VycykgKyBcIjpcIiArIHRvUGFkZGVkU3RyaW5nKDIsIG1pbnV0ZXMpICsgXCI6XCIgKyB0b1BhZGRlZFN0cmluZygyLCBzZWNvbmRzKSArXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE1pbGxpc2Vjb25kcyBhcmUgb3B0aW9uYWwgaW4gRVMgNS4wLCBidXQgcmVxdWlyZWQgaW4gNS4xLlxuICAgICAgICAgICAgICAgICAgICAgICAgICBcIi5cIiArIHRvUGFkZGVkU3RyaW5nKDMsIG1pbGxpc2Vjb25kcykgKyBcIlpcIjtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiB2YWx1ZS50b0pTT04gPT0gXCJmdW5jdGlvblwiICYmIChjbGFzc05hbWUgIT0gbnVtYmVyQ2xhc3MgJiYgY2xhc3NOYW1lICE9IHN0cmluZ0NsYXNzICYmIGNsYXNzTmFtZSAhPSBhcnJheUNsYXNzIHx8IGlzUHJvcGVydHkuY2FsbCh2YWx1ZSwgXCJ0b0pTT05cIikpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBQcm90b3R5cGUgPD0gMS42LjEgYWRkcyBub24tc3RhbmRhcmQgYHRvSlNPTmAgbWV0aG9kcyB0byB0aGVcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGBOdW1iZXJgLCBgU3RyaW5nYCwgYERhdGVgLCBhbmQgYEFycmF5YCBwcm90b3R5cGVzLiBKU09OIDNcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGlnbm9yZXMgYWxsIGB0b0pTT05gIG1ldGhvZHMgb24gdGhlc2Ugb2JqZWN0cyB1bmxlc3MgdGhleSBhcmVcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRlZmluZWQgZGlyZWN0bHkgb24gYW4gaW5zdGFuY2UuXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZSA9IHZhbHVlLnRvSlNPTihwcm9wZXJ0eSk7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChjYWxsYmFjaykge1xuICAgICAgICAgICAgICAgICAgICAgIC8vIElmIGEgcmVwbGFjZW1lbnQgZnVuY3Rpb24gd2FzIHByb3ZpZGVkLCBjYWxsIGl0IHRvIG9idGFpbiB0aGUgdmFsdWVcbiAgICAgICAgICAgICAgICAgICAgICAvLyBmb3Igc2VyaWFsaXphdGlvbi5cbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZSA9IGNhbGxiYWNrLmNhbGwob2JqZWN0LCBwcm9wZXJ0eSwgdmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmICh2YWx1ZSA9PT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcIm51bGxcIjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWUgPSBnZXRDbGFzcy5jYWxsKHZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNsYXNzTmFtZSA9PSBib29sZWFuQ2xhc3MpIHtcbiAgICAgICAgICAgICAgICAgICAgICAvLyBCb29sZWFucyBhcmUgcmVwcmVzZW50ZWQgbGl0ZXJhbGx5LlxuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcIlwiICsgdmFsdWU7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoY2xhc3NOYW1lID09IG51bWJlckNsYXNzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgLy8gSlNPTiBudW1iZXJzIG11c3QgYmUgZmluaXRlLiBgSW5maW5pdHlgIGFuZCBgTmFOYCBhcmUgc2VyaWFsaXplZCBhc1xuICAgICAgICAgICAgICAgICAgICAgIC8vIGBcIm51bGxcImAuXG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlID4gLTEgLyAwICYmIHZhbHVlIDwgMSAvIDAgPyBcIlwiICsgdmFsdWUgOiBcIm51bGxcIjtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChjbGFzc05hbWUgPT0gc3RyaW5nQ2xhc3MpIHtcbiAgICAgICAgICAgICAgICAgICAgICAvLyBTdHJpbmdzIGFyZSBkb3VibGUtcXVvdGVkIGFuZCBlc2NhcGVkLlxuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBxdW90ZShcIlwiICsgdmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIC8vIFJlY3Vyc2l2ZWx5IHNlcmlhbGl6ZSBvYmplY3RzIGFuZCBhcnJheXMuXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT0gXCJvYmplY3RcIikge1xuICAgICAgICAgICAgICAgICAgICAgIC8vIENoZWNrIGZvciBjeWNsaWMgc3RydWN0dXJlcy4gVGhpcyBpcyBhIGxpbmVhciBzZWFyY2g7IHBlcmZvcm1hbmNlXG4gICAgICAgICAgICAgICAgICAgICAgLy8gaXMgaW52ZXJzZWx5IHByb3BvcnRpb25hbCB0byB0aGUgbnVtYmVyIG9mIHVuaXF1ZSBuZXN0ZWQgb2JqZWN0cy5cbiAgICAgICAgICAgICAgICAgICAgICBmb3IgKGxlbmd0aCA9IHN0YWNrLmxlbmd0aDsgbGVuZ3RoLS07KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoc3RhY2tbbGVuZ3RoXSA9PT0gdmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQ3ljbGljIHN0cnVjdHVyZXMgY2Fubm90IGJlIHNlcmlhbGl6ZWQgYnkgYEpTT04uc3RyaW5naWZ5YC5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgVHlwZUVycm9yKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIC8vIEFkZCB0aGUgb2JqZWN0IHRvIHRoZSBzdGFjayBvZiB0cmF2ZXJzZWQgb2JqZWN0cy5cbiAgICAgICAgICAgICAgICAgICAgICBzdGFjay5wdXNoKHZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICByZXN1bHRzID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgLy8gU2F2ZSB0aGUgY3VycmVudCBpbmRlbnRhdGlvbiBsZXZlbCBhbmQgaW5kZW50IG9uZSBhZGRpdGlvbmFsIGxldmVsLlxuICAgICAgICAgICAgICAgICAgICAgIHByZWZpeCA9IGluZGVudGF0aW9uO1xuICAgICAgICAgICAgICAgICAgICAgIGluZGVudGF0aW9uICs9IHdoaXRlc3BhY2U7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGNsYXNzTmFtZSA9PSBhcnJheUNsYXNzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBSZWN1cnNpdmVseSBzZXJpYWxpemUgYXJyYXkgZWxlbWVudHMuXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGluZGV4ID0gMCwgbGVuZ3RoID0gdmFsdWUubGVuZ3RoOyBpbmRleCA8IGxlbmd0aDsgaW5kZXgrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50ID0gc2VyaWFsaXplKGluZGV4LCB2YWx1ZSwgY2FsbGJhY2ssIHByb3BlcnRpZXMsIHdoaXRlc3BhY2UsIGluZGVudGF0aW9uLCBzdGFjayk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdHMucHVzaChlbGVtZW50ID09PSB1bmRlZiA/IFwibnVsbFwiIDogZWxlbWVudCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSByZXN1bHRzLmxlbmd0aCA/IHdoaXRlc3BhY2UgPyBcIltcXG5cIiArIGluZGVudGF0aW9uICsgcmVzdWx0cy5qb2luKFwiLFxcblwiICsgaW5kZW50YXRpb24pICsgXCJcXG5cIiArIHByZWZpeCArIFwiXVwiIDogXCJbXCIgKyByZXN1bHRzLmpvaW4oXCIsXCIpICsgXCJdXCIgOiBcIltdXCI7XG4gICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFJlY3Vyc2l2ZWx5IHNlcmlhbGl6ZSBvYmplY3QgbWVtYmVycy4gTWVtYmVycyBhcmUgc2VsZWN0ZWQgZnJvbVxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZWl0aGVyIGEgdXNlci1zcGVjaWZpZWQgbGlzdCBvZiBwcm9wZXJ0eSBuYW1lcywgb3IgdGhlIG9iamVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gaXRzZWxmLlxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yRWFjaChwcm9wZXJ0aWVzIHx8IHZhbHVlLCBmdW5jdGlvbiAocHJvcGVydHkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGVsZW1lbnQgPSBzZXJpYWxpemUocHJvcGVydHksIHZhbHVlLCBjYWxsYmFjaywgcHJvcGVydGllcywgd2hpdGVzcGFjZSwgaW5kZW50YXRpb24sIHN0YWNrKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVsZW1lbnQgIT09IHVuZGVmKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQWNjb3JkaW5nIHRvIEVTIDUuMSBzZWN0aW9uIDE1LjEyLjM6IFwiSWYgYGdhcGAge3doaXRlc3BhY2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gaXMgbm90IHRoZSBlbXB0eSBzdHJpbmcsIGxldCBgbWVtYmVyYCB7cXVvdGUocHJvcGVydHkpICsgXCI6XCJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gYmUgdGhlIGNvbmNhdGVuYXRpb24gb2YgYG1lbWJlcmAgYW5kIHRoZSBgc3BhY2VgIGNoYXJhY3Rlci5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFRoZSBcImBzcGFjZWAgY2hhcmFjdGVyXCIgcmVmZXJzIHRvIHRoZSBsaXRlcmFsIHNwYWNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY2hhcmFjdGVyLCBub3QgdGhlIGBzcGFjZWAge3dpZHRofSBhcmd1bWVudCBwcm92aWRlZCB0b1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGBKU09OLnN0cmluZ2lmeWAuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0cy5wdXNoKHF1b3RlKHByb3BlcnR5KSArIFwiOlwiICsgKHdoaXRlc3BhY2UgPyBcIiBcIiA6IFwiXCIpICsgZWxlbWVudCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gcmVzdWx0cy5sZW5ndGggPyB3aGl0ZXNwYWNlID8gXCJ7XFxuXCIgKyBpbmRlbnRhdGlvbiArIHJlc3VsdHMuam9pbihcIixcXG5cIiArIGluZGVudGF0aW9uKSArIFwiXFxuXCIgKyBwcmVmaXggKyBcIn1cIiA6IFwie1wiICsgcmVzdWx0cy5qb2luKFwiLFwiKSArIFwifVwiIDogXCJ7fVwiO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAvLyBSZW1vdmUgdGhlIG9iamVjdCBmcm9tIHRoZSB0cmF2ZXJzZWQgb2JqZWN0IHN0YWNrLlxuICAgICAgICAgICAgICAgICAgICAgIHN0YWNrLnBvcCgpO1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAgIC8vIFB1YmxpYzogYEpTT04uc3RyaW5naWZ5YC4gU2VlIEVTIDUuMSBzZWN0aW9uIDE1LjEyLjMuXG4gICAgICAgICAgICAgICAgICBleHBvcnRzLnN0cmluZ2lmeSA9IGZ1bmN0aW9uIChzb3VyY2UsIGZpbHRlciwgd2lkdGgpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHdoaXRlc3BhY2UsIGNhbGxiYWNrLCBwcm9wZXJ0aWVzLCBjbGFzc05hbWU7XG4gICAgICAgICAgICAgICAgICAgIGlmIChvYmplY3RUeXBlc1t0eXBlb2YgZmlsdGVyXSAmJiBmaWx0ZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoKGNsYXNzTmFtZSA9IGdldENsYXNzLmNhbGwoZmlsdGVyKSkgPT0gZnVuY3Rpb25DbGFzcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2sgPSBmaWx0ZXI7XG4gICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChjbGFzc05hbWUgPT0gYXJyYXlDbGFzcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gQ29udmVydCB0aGUgcHJvcGVydHkgbmFtZXMgYXJyYXkgaW50byBhIG1ha2VzaGlmdCBzZXQuXG4gICAgICAgICAgICAgICAgICAgICAgICBwcm9wZXJ0aWVzID0ge307XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpbmRleCA9IDAsIGxlbmd0aCA9IGZpbHRlci5sZW5ndGgsIHZhbHVlOyBpbmRleCA8IGxlbmd0aDsgdmFsdWUgPSBmaWx0ZXJbaW5kZXgrK10sIChjbGFzc05hbWUgPSBnZXRDbGFzcy5jYWxsKHZhbHVlKSwgY2xhc3NOYW1lID09IHN0cmluZ0NsYXNzIHx8IGNsYXNzTmFtZSA9PSBudW1iZXJDbGFzcykgJiYgKHByb3BlcnRpZXNbdmFsdWVdID0gMSkpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAod2lkdGgpIHtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoKGNsYXNzTmFtZSA9IGdldENsYXNzLmNhbGwod2lkdGgpKSA9PSBudW1iZXJDbGFzcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gQ29udmVydCB0aGUgYHdpZHRoYCB0byBhbiBpbnRlZ2VyIGFuZCBjcmVhdGUgYSBzdHJpbmcgY29udGFpbmluZ1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gYHdpZHRoYCBudW1iZXIgb2Ygc3BhY2UgY2hhcmFjdGVycy5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICgod2lkdGggLT0gd2lkdGggJSAxKSA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh3aGl0ZXNwYWNlID0gXCJcIiwgd2lkdGggPiAxMCAmJiAod2lkdGggPSAxMCk7IHdoaXRlc3BhY2UubGVuZ3RoIDwgd2lkdGg7IHdoaXRlc3BhY2UgKz0gXCIgXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoY2xhc3NOYW1lID09IHN0cmluZ0NsYXNzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB3aGl0ZXNwYWNlID0gd2lkdGgubGVuZ3RoIDw9IDEwID8gd2lkdGggOiB3aWR0aC5zbGljZSgwLCAxMCk7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIC8vIE9wZXJhIDw9IDcuNTR1MiBkaXNjYXJkcyB0aGUgdmFsdWVzIGFzc29jaWF0ZWQgd2l0aCBlbXB0eSBzdHJpbmcga2V5c1xuICAgICAgICAgICAgICAgICAgICAvLyAoYFwiXCJgKSBvbmx5IGlmIHRoZXkgYXJlIHVzZWQgZGlyZWN0bHkgd2l0aGluIGFuIG9iamVjdCBtZW1iZXIgbGlzdFxuICAgICAgICAgICAgICAgICAgICAvLyAoZS5nLiwgYCEoXCJcIiBpbiB7IFwiXCI6IDF9KWApLlxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gc2VyaWFsaXplKFwiXCIsICh2YWx1ZSA9IHt9LCB2YWx1ZVtcIlwiXSA9IHNvdXJjZSwgdmFsdWUpLCBjYWxsYmFjaywgcHJvcGVydGllcywgd2hpdGVzcGFjZSwgXCJcIiwgW10pO1xuICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAvLyBQdWJsaWM6IFBhcnNlcyBhIEpTT04gc291cmNlIHN0cmluZy5cbiAgICAgICAgICAgICAgICBpZiAoIWhhcyhcImpzb24tcGFyc2VcIikpIHtcbiAgICAgICAgICAgICAgICAgIHZhciBmcm9tQ2hhckNvZGUgPSBTdHJpbmcuZnJvbUNoYXJDb2RlO1xuXG4gICAgICAgICAgICAgICAgICAvLyBJbnRlcm5hbDogQSBtYXAgb2YgZXNjYXBlZCBjb250cm9sIGNoYXJhY3RlcnMgYW5kIHRoZWlyIHVuZXNjYXBlZFxuICAgICAgICAgICAgICAgICAgLy8gZXF1aXZhbGVudHMuXG4gICAgICAgICAgICAgICAgICB2YXIgVW5lc2NhcGVzID0ge1xuICAgICAgICAgICAgICAgICAgICA5MjogXCJcXFxcXCIsXG4gICAgICAgICAgICAgICAgICAgIDM0OiAnXCInLFxuICAgICAgICAgICAgICAgICAgICA0NzogXCIvXCIsXG4gICAgICAgICAgICAgICAgICAgIDk4OiBcIlxcYlwiLFxuICAgICAgICAgICAgICAgICAgICAxMTY6IFwiXFx0XCIsXG4gICAgICAgICAgICAgICAgICAgIDExMDogXCJcXG5cIixcbiAgICAgICAgICAgICAgICAgICAgMTAyOiBcIlxcZlwiLFxuICAgICAgICAgICAgICAgICAgICAxMTQ6IFwiXFxyXCJcbiAgICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAgIC8vIEludGVybmFsOiBTdG9yZXMgdGhlIHBhcnNlciBzdGF0ZS5cbiAgICAgICAgICAgICAgICAgIHZhciBJbmRleCwgU291cmNlO1xuXG4gICAgICAgICAgICAgICAgICAvLyBJbnRlcm5hbDogUmVzZXRzIHRoZSBwYXJzZXIgc3RhdGUgYW5kIHRocm93cyBhIGBTeW50YXhFcnJvcmAuXG4gICAgICAgICAgICAgICAgICB2YXIgYWJvcnQgPSBmdW5jdGlvbiBhYm9ydCgpIHtcbiAgICAgICAgICAgICAgICAgICAgSW5kZXggPSBTb3VyY2UgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBTeW50YXhFcnJvcigpO1xuICAgICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgICAgLy8gSW50ZXJuYWw6IFJldHVybnMgdGhlIG5leHQgdG9rZW4sIG9yIGBcIiRcImAgaWYgdGhlIHBhcnNlciBoYXMgcmVhY2hlZFxuICAgICAgICAgICAgICAgICAgLy8gdGhlIGVuZCBvZiB0aGUgc291cmNlIHN0cmluZy4gQSB0b2tlbiBtYXkgYmUgYSBzdHJpbmcsIG51bWJlciwgYG51bGxgXG4gICAgICAgICAgICAgICAgICAvLyBsaXRlcmFsLCBvciBCb29sZWFuIGxpdGVyYWwuXG4gICAgICAgICAgICAgICAgICB2YXIgbGV4ID0gZnVuY3Rpb24gbGV4KCkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgc291cmNlID0gU291cmNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgbGVuZ3RoID0gc291cmNlLmxlbmd0aCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgYmVnaW4sXG4gICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbixcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzU2lnbmVkLFxuICAgICAgICAgICAgICAgICAgICAgICAgY2hhckNvZGU7XG4gICAgICAgICAgICAgICAgICAgIHdoaWxlIChJbmRleCA8IGxlbmd0aCkge1xuICAgICAgICAgICAgICAgICAgICAgIGNoYXJDb2RlID0gc291cmNlLmNoYXJDb2RlQXQoSW5kZXgpO1xuICAgICAgICAgICAgICAgICAgICAgIHN3aXRjaCAoY2hhckNvZGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgOTpjYXNlIDEwOmNhc2UgMTM6Y2FzZSAzMjpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gU2tpcCB3aGl0ZXNwYWNlIHRva2VucywgaW5jbHVkaW5nIHRhYnMsIGNhcnJpYWdlIHJldHVybnMsIGxpbmVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZmVlZHMsIGFuZCBzcGFjZSBjaGFyYWN0ZXJzLlxuICAgICAgICAgICAgICAgICAgICAgICAgICBJbmRleCsrO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMTIzOmNhc2UgMTI1OmNhc2UgOTE6Y2FzZSA5MzpjYXNlIDU4OmNhc2UgNDQ6XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFBhcnNlIGEgcHVuY3R1YXRvciB0b2tlbiAoYHtgLCBgfWAsIGBbYCwgYF1gLCBgOmAsIG9yIGAsYCkgYXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdGhlIGN1cnJlbnQgcG9zaXRpb24uXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlID0gY2hhckluZGV4QnVnZ3kgPyBzb3VyY2UuY2hhckF0KEluZGV4KSA6IHNvdXJjZVtJbmRleF07XG4gICAgICAgICAgICAgICAgICAgICAgICAgIEluZGV4Kys7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMzQ6XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGBcImAgZGVsaW1pdHMgYSBKU09OIHN0cmluZzsgYWR2YW5jZSB0byB0aGUgbmV4dCBjaGFyYWN0ZXIgYW5kXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGJlZ2luIHBhcnNpbmcgdGhlIHN0cmluZy4gU3RyaW5nIHRva2VucyBhcmUgcHJlZml4ZWQgd2l0aCB0aGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gc2VudGluZWwgYEBgIGNoYXJhY3RlciB0byBkaXN0aW5ndWlzaCB0aGVtIGZyb20gcHVuY3R1YXRvcnMgYW5kXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGVuZC1vZi1zdHJpbmcgdG9rZW5zLlxuICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhbHVlID0gXCJAXCIsIEluZGV4Kys7IEluZGV4IDwgbGVuZ3RoOykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoYXJDb2RlID0gc291cmNlLmNoYXJDb2RlQXQoSW5kZXgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjaGFyQ29kZSA8IDMyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBVbmVzY2FwZWQgQVNDSUkgY29udHJvbCBjaGFyYWN0ZXJzICh0aG9zZSB3aXRoIGEgY29kZSB1bml0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBsZXNzIHRoYW4gdGhlIHNwYWNlIGNoYXJhY3RlcikgYXJlIG5vdCBwZXJtaXR0ZWQuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhYm9ydCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoY2hhckNvZGUgPT0gOTIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEEgcmV2ZXJzZSBzb2xpZHVzIChgXFxgKSBtYXJrcyB0aGUgYmVnaW5uaW5nIG9mIGFuIGVzY2FwZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnRyb2wgY2hhcmFjdGVyIChpbmNsdWRpbmcgYFwiYCwgYFxcYCwgYW5kIGAvYCkgb3IgVW5pY29kZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZXNjYXBlIHNlcXVlbmNlLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hhckNvZGUgPSBzb3VyY2UuY2hhckNvZGVBdCgrK0luZGV4KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN3aXRjaCAoY2hhckNvZGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSA5MjpjYXNlIDM0OmNhc2UgNDc6Y2FzZSA5ODpjYXNlIDExNjpjYXNlIDExMDpjYXNlIDEwMjpjYXNlIDExNDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBSZXZpdmUgZXNjYXBlZCBjb250cm9sIGNoYXJhY3RlcnMuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWUgKz0gVW5lc2NhcGVzW2NoYXJDb2RlXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBJbmRleCsrO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIDExNzpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBgXFx1YCBtYXJrcyB0aGUgYmVnaW5uaW5nIG9mIGEgVW5pY29kZSBlc2NhcGUgc2VxdWVuY2UuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQWR2YW5jZSB0byB0aGUgZmlyc3QgY2hhcmFjdGVyIGFuZCB2YWxpZGF0ZSB0aGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBmb3VyLWRpZ2l0IGNvZGUgcG9pbnQuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmVnaW4gPSArK0luZGV4O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAocG9zaXRpb24gPSBJbmRleCArIDQ7IEluZGV4IDwgcG9zaXRpb247IEluZGV4KyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoYXJDb2RlID0gc291cmNlLmNoYXJDb2RlQXQoSW5kZXgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQSB2YWxpZCBzZXF1ZW5jZSBjb21wcmlzZXMgZm91ciBoZXhkaWdpdHMgKGNhc2UtXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBpbnNlbnNpdGl2ZSkgdGhhdCBmb3JtIGEgc2luZ2xlIGhleGFkZWNpbWFsIHZhbHVlLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCEoY2hhckNvZGUgPj0gNDggJiYgY2hhckNvZGUgPD0gNTcgfHwgY2hhckNvZGUgPj0gOTcgJiYgY2hhckNvZGUgPD0gMTAyIHx8IGNoYXJDb2RlID49IDY1ICYmIGNoYXJDb2RlIDw9IDcwKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBJbnZhbGlkIFVuaWNvZGUgZXNjYXBlIHNlcXVlbmNlLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhYm9ydCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBSZXZpdmUgdGhlIGVzY2FwZWQgY2hhcmFjdGVyLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlICs9IGZyb21DaGFyQ29kZShcIjB4XCIgKyBzb3VyY2Uuc2xpY2UoYmVnaW4sIEluZGV4KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gSW52YWxpZCBlc2NhcGUgc2VxdWVuY2UuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWJvcnQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNoYXJDb2RlID09IDM0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEFuIHVuZXNjYXBlZCBkb3VibGUtcXVvdGUgY2hhcmFjdGVyIG1hcmtzIHRoZSBlbmQgb2YgdGhlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHN0cmluZy5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGFyQ29kZSA9IHNvdXJjZS5jaGFyQ29kZUF0KEluZGV4KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJlZ2luID0gSW5kZXg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBPcHRpbWl6ZSBmb3IgdGhlIGNvbW1vbiBjYXNlIHdoZXJlIGEgc3RyaW5nIGlzIHZhbGlkLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd2hpbGUgKGNoYXJDb2RlID49IDMyICYmIGNoYXJDb2RlICE9IDkyICYmIGNoYXJDb2RlICE9IDM0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoYXJDb2RlID0gc291cmNlLmNoYXJDb2RlQXQoKytJbmRleCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBBcHBlbmQgdGhlIHN0cmluZyBhcy1pcy5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlICs9IHNvdXJjZS5zbGljZShiZWdpbiwgSW5kZXgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoc291cmNlLmNoYXJDb2RlQXQoSW5kZXgpID09IDM0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQWR2YW5jZSB0byB0aGUgbmV4dCBjaGFyYWN0ZXIgYW5kIHJldHVybiB0aGUgcmV2aXZlZCBzdHJpbmcuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgSW5kZXgrKztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gVW50ZXJtaW5hdGVkIHN0cmluZy5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWJvcnQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFBhcnNlIG51bWJlcnMgYW5kIGxpdGVyYWxzLlxuICAgICAgICAgICAgICAgICAgICAgICAgICBiZWdpbiA9IEluZGV4O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBBZHZhbmNlIHBhc3QgdGhlIG5lZ2F0aXZlIHNpZ24sIGlmIG9uZSBpcyBzcGVjaWZpZWQuXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjaGFyQ29kZSA9PSA0NSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzU2lnbmVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGFyQ29kZSA9IHNvdXJjZS5jaGFyQ29kZUF0KCsrSW5kZXgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFBhcnNlIGFuIGludGVnZXIgb3IgZmxvYXRpbmctcG9pbnQgdmFsdWUuXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjaGFyQ29kZSA+PSA0OCAmJiBjaGFyQ29kZSA8PSA1Nykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIExlYWRpbmcgemVyb2VzIGFyZSBpbnRlcnByZXRlZCBhcyBvY3RhbCBsaXRlcmFscy5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoY2hhckNvZGUgPT0gNDggJiYgKGNoYXJDb2RlID0gc291cmNlLmNoYXJDb2RlQXQoSW5kZXggKyAxKSwgY2hhckNvZGUgPj0gNDggJiYgY2hhckNvZGUgPD0gNTcpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBJbGxlZ2FsIG9jdGFsIGxpdGVyYWwuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhYm9ydCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc1NpZ25lZCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFBhcnNlIHRoZSBpbnRlZ2VyIGNvbXBvbmVudC5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKDsgSW5kZXggPCBsZW5ndGggJiYgKGNoYXJDb2RlID0gc291cmNlLmNoYXJDb2RlQXQoSW5kZXgpLCBjaGFyQ29kZSA+PSA0OCAmJiBjaGFyQ29kZSA8PSA1Nyk7IEluZGV4KyspO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEZsb2F0cyBjYW5ub3QgY29udGFpbiBhIGxlYWRpbmcgZGVjaW1hbCBwb2ludDsgaG93ZXZlciwgdGhpc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNhc2UgaXMgYWxyZWFkeSBhY2NvdW50ZWQgZm9yIGJ5IHRoZSBwYXJzZXIuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNvdXJjZS5jaGFyQ29kZUF0KEluZGV4KSA9PSA0Nikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb24gPSArK0luZGV4O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gUGFyc2UgdGhlIGRlY2ltYWwgY29tcG9uZW50LlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICg7IHBvc2l0aW9uIDwgbGVuZ3RoICYmIChjaGFyQ29kZSA9IHNvdXJjZS5jaGFyQ29kZUF0KHBvc2l0aW9uKSwgY2hhckNvZGUgPj0gNDggJiYgY2hhckNvZGUgPD0gNTcpOyBwb3NpdGlvbisrKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwb3NpdGlvbiA9PSBJbmRleCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBJbGxlZ2FsIHRyYWlsaW5nIGRlY2ltYWwuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFib3J0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBJbmRleCA9IHBvc2l0aW9uO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBQYXJzZSBleHBvbmVudHMuIFRoZSBgZWAgZGVub3RpbmcgdGhlIGV4cG9uZW50IGlzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY2FzZS1pbnNlbnNpdGl2ZS5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGFyQ29kZSA9IHNvdXJjZS5jaGFyQ29kZUF0KEluZGV4KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoY2hhckNvZGUgPT0gMTAxIHx8IGNoYXJDb2RlID09IDY5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGFyQ29kZSA9IHNvdXJjZS5jaGFyQ29kZUF0KCsrSW5kZXgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gU2tpcCBwYXN0IHRoZSBzaWduIGZvbGxvd2luZyB0aGUgZXhwb25lbnQsIGlmIG9uZSBpc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gc3BlY2lmaWVkLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNoYXJDb2RlID09IDQzIHx8IGNoYXJDb2RlID09IDQ1KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEluZGV4Kys7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBQYXJzZSB0aGUgZXhwb25lbnRpYWwgY29tcG9uZW50LlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChwb3NpdGlvbiA9IEluZGV4OyBwb3NpdGlvbiA8IGxlbmd0aCAmJiAoY2hhckNvZGUgPSBzb3VyY2UuY2hhckNvZGVBdChwb3NpdGlvbiksIGNoYXJDb2RlID49IDQ4ICYmIGNoYXJDb2RlIDw9IDU3KTsgcG9zaXRpb24rKyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocG9zaXRpb24gPT0gSW5kZXgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gSWxsZWdhbCBlbXB0eSBleHBvbmVudC5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWJvcnQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEluZGV4ID0gcG9zaXRpb247XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIENvZXJjZSB0aGUgcGFyc2VkIHZhbHVlIHRvIGEgSmF2YVNjcmlwdCBudW1iZXIuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuICtzb3VyY2Uuc2xpY2UoYmVnaW4sIEluZGV4KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBBIG5lZ2F0aXZlIHNpZ24gbWF5IG9ubHkgcHJlY2VkZSBudW1iZXJzLlxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNTaWduZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhYm9ydCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGB0cnVlYCwgYGZhbHNlYCwgYW5kIGBudWxsYCBsaXRlcmFscy5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNvdXJjZS5zbGljZShJbmRleCwgSW5kZXggKyA0KSA9PSBcInRydWVcIikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEluZGV4ICs9IDQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoc291cmNlLnNsaWNlKEluZGV4LCBJbmRleCArIDUpID09IFwiZmFsc2VcIikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEluZGV4ICs9IDU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHNvdXJjZS5zbGljZShJbmRleCwgSW5kZXggKyA0KSA9PSBcIm51bGxcIikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEluZGV4ICs9IDQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gVW5yZWNvZ25pemVkIHRva2VuLlxuICAgICAgICAgICAgICAgICAgICAgICAgICBhYm9ydCgpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAvLyBSZXR1cm4gdGhlIHNlbnRpbmVsIGAkYCBjaGFyYWN0ZXIgaWYgdGhlIHBhcnNlciBoYXMgcmVhY2hlZCB0aGUgZW5kXG4gICAgICAgICAgICAgICAgICAgIC8vIG9mIHRoZSBzb3VyY2Ugc3RyaW5nLlxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCIkXCI7XG4gICAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgICAvLyBJbnRlcm5hbDogUGFyc2VzIGEgSlNPTiBgdmFsdWVgIHRva2VuLlxuICAgICAgICAgICAgICAgICAgdmFyIGdldCA9IGZ1bmN0aW9uIGdldCh2YWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgcmVzdWx0cywgaGFzTWVtYmVycztcbiAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlID09IFwiJFwiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgLy8gVW5leHBlY3RlZCBlbmQgb2YgaW5wdXQuXG4gICAgICAgICAgICAgICAgICAgICAgYWJvcnQoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHZhbHVlID09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoKGNoYXJJbmRleEJ1Z2d5ID8gdmFsdWUuY2hhckF0KDApIDogdmFsdWVbMF0pID09IFwiQFwiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBSZW1vdmUgdGhlIHNlbnRpbmVsIGBAYCBjaGFyYWN0ZXIuXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdmFsdWUuc2xpY2UoMSk7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIC8vIFBhcnNlIG9iamVjdCBhbmQgYXJyYXkgbGl0ZXJhbHMuXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlID09IFwiW1wiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBQYXJzZXMgYSBKU09OIGFycmF5LCByZXR1cm5pbmcgYSBuZXcgSmF2YVNjcmlwdCBhcnJheS5cbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdHMgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoOzsgaGFzTWVtYmVycyB8fCAoaGFzTWVtYmVycyA9IHRydWUpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlID0gbGV4KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEEgY2xvc2luZyBzcXVhcmUgYnJhY2tldCBtYXJrcyB0aGUgZW5kIG9mIHRoZSBhcnJheSBsaXRlcmFsLlxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsdWUgPT0gXCJdXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBJZiB0aGUgYXJyYXkgbGl0ZXJhbCBjb250YWlucyBlbGVtZW50cywgdGhlIGN1cnJlbnQgdG9rZW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gc2hvdWxkIGJlIGEgY29tbWEgc2VwYXJhdGluZyB0aGUgcHJldmlvdXMgZWxlbWVudCBmcm9tIHRoZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBuZXh0LlxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaGFzTWVtYmVycykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWx1ZSA9PSBcIixcIikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWUgPSBsZXgoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWx1ZSA9PSBcIl1cIikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBVbmV4cGVjdGVkIHRyYWlsaW5nIGAsYCBpbiBhcnJheSBsaXRlcmFsLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhYm9ydCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBBIGAsYCBtdXN0IHNlcGFyYXRlIGVhY2ggYXJyYXkgZWxlbWVudC5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFib3J0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEVsaXNpb25zIGFuZCBsZWFkaW5nIGNvbW1hcyBhcmUgbm90IHBlcm1pdHRlZC5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlID09IFwiLFwiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWJvcnQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRzLnB1c2goZ2V0KHZhbHVlKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0cztcbiAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHZhbHVlID09IFwie1wiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBQYXJzZXMgYSBKU09OIG9iamVjdCwgcmV0dXJuaW5nIGEgbmV3IEphdmFTY3JpcHQgb2JqZWN0LlxuICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0cyA9IHt9O1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yICg7OyBoYXNNZW1iZXJzIHx8IChoYXNNZW1iZXJzID0gdHJ1ZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWUgPSBsZXgoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQSBjbG9zaW5nIGN1cmx5IGJyYWNlIG1hcmtzIHRoZSBlbmQgb2YgdGhlIG9iamVjdCBsaXRlcmFsLlxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsdWUgPT0gXCJ9XCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBJZiB0aGUgb2JqZWN0IGxpdGVyYWwgY29udGFpbnMgbWVtYmVycywgdGhlIGN1cnJlbnQgdG9rZW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gc2hvdWxkIGJlIGEgY29tbWEgc2VwYXJhdG9yLlxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaGFzTWVtYmVycykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWx1ZSA9PSBcIixcIikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWUgPSBsZXgoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWx1ZSA9PSBcIn1cIikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBVbmV4cGVjdGVkIHRyYWlsaW5nIGAsYCBpbiBvYmplY3QgbGl0ZXJhbC5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWJvcnQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQSBgLGAgbXVzdCBzZXBhcmF0ZSBlYWNoIG9iamVjdCBtZW1iZXIuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhYm9ydCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBMZWFkaW5nIGNvbW1hcyBhcmUgbm90IHBlcm1pdHRlZCwgb2JqZWN0IHByb3BlcnR5IG5hbWVzIG11c3QgYmVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZG91YmxlLXF1b3RlZCBzdHJpbmdzLCBhbmQgYSBgOmAgbXVzdCBzZXBhcmF0ZSBlYWNoIHByb3BlcnR5XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8vIG5hbWUgYW5kIHZhbHVlLlxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsdWUgPT0gXCIsXCIgfHwgdHlwZW9mIHZhbHVlICE9IFwic3RyaW5nXCIgfHwgKGNoYXJJbmRleEJ1Z2d5ID8gdmFsdWUuY2hhckF0KDApIDogdmFsdWVbMF0pICE9IFwiQFwiIHx8IGxleCgpICE9IFwiOlwiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWJvcnQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRzW3ZhbHVlLnNsaWNlKDEpXSA9IGdldChsZXgoKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0cztcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgLy8gVW5leHBlY3RlZCB0b2tlbiBlbmNvdW50ZXJlZC5cbiAgICAgICAgICAgICAgICAgICAgICBhYm9ydCgpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAgIC8vIEludGVybmFsOiBVcGRhdGVzIGEgdHJhdmVyc2VkIG9iamVjdCBtZW1iZXIuXG4gICAgICAgICAgICAgICAgICB2YXIgdXBkYXRlID0gZnVuY3Rpb24gdXBkYXRlKHNvdXJjZSwgcHJvcGVydHksIGNhbGxiYWNrKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBlbGVtZW50ID0gd2Fsayhzb3VyY2UsIHByb3BlcnR5LCBjYWxsYmFjayk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChlbGVtZW50ID09PSB1bmRlZikge1xuICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZSBzb3VyY2VbcHJvcGVydHldO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgIHNvdXJjZVtwcm9wZXJ0eV0gPSBlbGVtZW50O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgICAvLyBJbnRlcm5hbDogUmVjdXJzaXZlbHkgdHJhdmVyc2VzIGEgcGFyc2VkIEpTT04gb2JqZWN0LCBpbnZva2luZyB0aGVcbiAgICAgICAgICAgICAgICAgIC8vIGBjYWxsYmFja2AgZnVuY3Rpb24gZm9yIGVhY2ggdmFsdWUuIFRoaXMgaXMgYW4gaW1wbGVtZW50YXRpb24gb2YgdGhlXG4gICAgICAgICAgICAgICAgICAvLyBgV2Fsayhob2xkZXIsIG5hbWUpYCBvcGVyYXRpb24gZGVmaW5lZCBpbiBFUyA1LjEgc2VjdGlvbiAxNS4xMi4yLlxuICAgICAgICAgICAgICAgICAgdmFyIHdhbGsgPSBmdW5jdGlvbiB3YWxrKHNvdXJjZSwgcHJvcGVydHksIGNhbGxiYWNrKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciB2YWx1ZSA9IHNvdXJjZVtwcm9wZXJ0eV0sXG4gICAgICAgICAgICAgICAgICAgICAgICBsZW5ndGg7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT0gXCJvYmplY3RcIiAmJiB2YWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICAgIC8vIGBmb3JFYWNoYCBjYW4ndCBiZSB1c2VkIHRvIHRyYXZlcnNlIGFuIGFycmF5IGluIE9wZXJhIDw9IDguNTRcbiAgICAgICAgICAgICAgICAgICAgICAvLyBiZWNhdXNlIGl0cyBgT2JqZWN0I2hhc093blByb3BlcnR5YCBpbXBsZW1lbnRhdGlvbiByZXR1cm5zIGBmYWxzZWBcbiAgICAgICAgICAgICAgICAgICAgICAvLyBmb3IgYXJyYXkgaW5kaWNlcyAoZS5nLiwgYCFbMSwgMiwgM10uaGFzT3duUHJvcGVydHkoXCIwXCIpYCkuXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGdldENsYXNzLmNhbGwodmFsdWUpID09IGFycmF5Q2xhc3MpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAobGVuZ3RoID0gdmFsdWUubGVuZ3RoOyBsZW5ndGgtLTspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlKHZhbHVlLCBsZW5ndGgsIGNhbGxiYWNrKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yRWFjaCh2YWx1ZSwgZnVuY3Rpb24gKHByb3BlcnR5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZSh2YWx1ZSwgcHJvcGVydHksIGNhbGxiYWNrKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gY2FsbGJhY2suY2FsbChzb3VyY2UsIHByb3BlcnR5LCB2YWx1ZSk7XG4gICAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgICAvLyBQdWJsaWM6IGBKU09OLnBhcnNlYC4gU2VlIEVTIDUuMSBzZWN0aW9uIDE1LjEyLjIuXG4gICAgICAgICAgICAgICAgICBleHBvcnRzLnBhcnNlID0gZnVuY3Rpb24gKHNvdXJjZSwgY2FsbGJhY2spIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlc3VsdCwgdmFsdWU7XG4gICAgICAgICAgICAgICAgICAgIEluZGV4ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgU291cmNlID0gXCJcIiArIHNvdXJjZTtcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gZ2V0KGxleCgpKTtcbiAgICAgICAgICAgICAgICAgICAgLy8gSWYgYSBKU09OIHN0cmluZyBjb250YWlucyBtdWx0aXBsZSB0b2tlbnMsIGl0IGlzIGludmFsaWQuXG4gICAgICAgICAgICAgICAgICAgIGlmIChsZXgoKSAhPSBcIiRcIikge1xuICAgICAgICAgICAgICAgICAgICAgIGFib3J0KCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgLy8gUmVzZXQgdGhlIHBhcnNlciBzdGF0ZS5cbiAgICAgICAgICAgICAgICAgICAgSW5kZXggPSBTb3VyY2UgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gY2FsbGJhY2sgJiYgZ2V0Q2xhc3MuY2FsbChjYWxsYmFjaykgPT0gZnVuY3Rpb25DbGFzcyA/IHdhbGsoKHZhbHVlID0ge30sIHZhbHVlW1wiXCJdID0gcmVzdWx0LCB2YWx1ZSksIFwiXCIsIGNhbGxiYWNrKSA6IHJlc3VsdDtcbiAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgZXhwb3J0c1tcInJ1bkluQ29udGV4dFwiXSA9IHJ1bkluQ29udGV4dDtcbiAgICAgICAgICAgICAgcmV0dXJuIGV4cG9ydHM7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChmcmVlRXhwb3J0cyAmJiAhaXNMb2FkZXIpIHtcbiAgICAgICAgICAgICAgLy8gRXhwb3J0IGZvciBDb21tb25KUyBlbnZpcm9ubWVudHMuXG4gICAgICAgICAgICAgIHJ1bkluQ29udGV4dChyb290LCBmcmVlRXhwb3J0cyk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAvLyBFeHBvcnQgZm9yIHdlYiBicm93c2VycyBhbmQgSmF2YVNjcmlwdCBlbmdpbmVzLlxuICAgICAgICAgICAgICB2YXIgbmF0aXZlSlNPTiA9IHJvb3QuSlNPTixcbiAgICAgICAgICAgICAgICAgIHByZXZpb3VzSlNPTiA9IHJvb3RbXCJKU09OM1wiXSxcbiAgICAgICAgICAgICAgICAgIGlzUmVzdG9yZWQgPSBmYWxzZTtcblxuICAgICAgICAgICAgICB2YXIgSlNPTjMgPSBydW5JbkNvbnRleHQocm9vdCwgcm9vdFtcIkpTT04zXCJdID0ge1xuICAgICAgICAgICAgICAgIC8vIFB1YmxpYzogUmVzdG9yZXMgdGhlIG9yaWdpbmFsIHZhbHVlIG9mIHRoZSBnbG9iYWwgYEpTT05gIG9iamVjdCBhbmRcbiAgICAgICAgICAgICAgICAvLyByZXR1cm5zIGEgcmVmZXJlbmNlIHRvIHRoZSBgSlNPTjNgIG9iamVjdC5cbiAgICAgICAgICAgICAgICBcIm5vQ29uZmxpY3RcIjogZnVuY3Rpb24gbm9Db25mbGljdCgpIHtcbiAgICAgICAgICAgICAgICAgIGlmICghaXNSZXN0b3JlZCkge1xuICAgICAgICAgICAgICAgICAgICBpc1Jlc3RvcmVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgcm9vdC5KU09OID0gbmF0aXZlSlNPTjtcbiAgICAgICAgICAgICAgICAgICAgcm9vdFtcIkpTT04zXCJdID0gcHJldmlvdXNKU09OO1xuICAgICAgICAgICAgICAgICAgICBuYXRpdmVKU09OID0gcHJldmlvdXNKU09OID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIHJldHVybiBKU09OMztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgIHJvb3QuSlNPTiA9IHtcbiAgICAgICAgICAgICAgICBcInBhcnNlXCI6IEpTT04zLnBhcnNlLFxuICAgICAgICAgICAgICAgIFwic3RyaW5naWZ5XCI6IEpTT04zLnN0cmluZ2lmeVxuICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBFeHBvcnQgZm9yIGFzeW5jaHJvbm91cyBtb2R1bGUgbG9hZGVycy5cbiAgICAgICAgICAgIGlmIChpc0xvYWRlcikge1xuICAgICAgICAgICAgICBkZWZpbmUoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBKU09OMztcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSkuY2FsbCh0aGlzKTtcbiAgICAgICAgfSkuY2FsbCh0aGlzLCB0eXBlb2Ygc2VsZiAhPT0gXCJ1bmRlZmluZWRcIiA/IHNlbGYgOiB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiID8gd2luZG93IDogdHlwZW9mIGdsb2JhbCAhPT0gXCJ1bmRlZmluZWRcIiA/IGdsb2JhbCA6IHt9KTtcbiAgICAgIH0sIHt9XSwgNTE6IFtmdW5jdGlvbiAoX2RlcmVxXywgbW9kdWxlLCBleHBvcnRzKSB7XG4gICAgICAgIG1vZHVsZS5leHBvcnRzID0gdG9BcnJheTtcblxuICAgICAgICBmdW5jdGlvbiB0b0FycmF5KGxpc3QsIGluZGV4KSB7XG4gICAgICAgICAgdmFyIGFycmF5ID0gW107XG5cbiAgICAgICAgICBpbmRleCA9IGluZGV4IHx8IDA7XG5cbiAgICAgICAgICBmb3IgKHZhciBpID0gaW5kZXggfHwgMDsgaSA8IGxpc3QubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGFycmF5W2kgLSBpbmRleF0gPSBsaXN0W2ldO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHJldHVybiBhcnJheTtcbiAgICAgICAgfVxuICAgICAgfSwge31dIH0sIHt9LCBbMzFdKSgzMSk7XG4gIH0pO1xufVxuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnNjQyMDdid1Q1bEtEYTNIQm9QVTZIejAnLCAndGFua1NjcmlwdCcpO1xuLy8gU2NyaXB0L0dhbWVzY3JpcHQvdGFua1NjcmlwdC5qc1xuXG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgbGJuYW1lOiB7XG4gICAgICAgICAgICB0eXBlOiBjYy5MYWJlbCxcbiAgICAgICAgICAgIFwiZGVmYXVsdFwiOiBudWxsXG4gICAgICAgIH0sXG4gICAgICAgIGJvZHl0YW5rOiB7XG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGxcbiAgICAgICAgfSxcbiAgICAgICAgZ3VudGFuazoge1xuICAgICAgICAgICAgdHlwZTogY2MuTm9kZSxcbiAgICAgICAgICAgIFwiZGVmYXVsdFwiOiBudWxsXG4gICAgICAgIH0sXG5cbiAgICAgICAgbGJzY29yZToge1xuICAgICAgICAgICAgdHlwZTogY2MuTGFiZWwsXG4gICAgICAgICAgICBcImRlZmF1bHRcIjogbnVsbFxuICAgICAgICB9XG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICB0aGlzLmxibmFtZS5zdHJpbmcgPSBcIlwiO1xuICAgICAgICB0aGlzLmRpck12ID0gMDtcbiAgICAgICAgdGhpcy5zcGVlZE1vdmUgPSAwO1xuICAgICAgICB0aGlzLm5leHRGcmFtZU1vdmUgPSAwO1xuXG4gICAgICAgIHRoaXMuYW1tbyA9IDA7XG4gICAgICAgIHRoaXMuaHAgPSAwO1xuICAgICAgICB0aGlzLmxldmVsID0gMDtcblxuICAgICAgICB0aGlzLmNvdW50X3VwZGF0ZVJ1biA9IDA7XG5cbiAgICAgICAgdGhpcy5uZWVkVXBkYXRlTmFtZSA9IHRydWU7XG5cbiAgICAgICAgdmFyIGZsYWdOb2RlID0gdGhpcy5ub2RlLmNoaWxkcmVuWzFdO1xuICAgICAgICBmbGFnTm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgLy92YXIgc3BfYm9keT10aGlzLm5vZGUuY2hpbGRyZW5bMF07XG4gICAgICAgIC8vdmFyIHNwcml0ZV9ib2R5PXNwX2JvZHkuZ2V0Q29tcG9uZW50KFwiY2MuU3ByaXRlXCIpO1xuICAgICAgICAvL3Nwcml0ZV9ib2R5LnNwcml0ZUZyYW1lPXRoaXMuc3BBbGxDaGFyYWN0ZXIuZ2V0U3ByaXRlRnJhbWUoXCJUYW5rQ29sb3ItdDVfYlwiKTtcbiAgICB9LFxuICAgIC8vW3tcInhcIjpcIi02MS41MFwiLFwieVwiOlwiLTUyLjAwXCIsXCJpZFwiOlwiNDhcIixcInJcIjpcIjAuMDBcIixcImxldmVsXCI6XCIxXCIsXCJzY29yZVwiOlwiMFwiLFwiaHBcIjpcIjgwXCIsXCJhbW1vXCI6XCIxNDBcIixcInNwXCI6XCI1MFwiLFwiZ1JcIjpcIjE4MFwifV0sXCJlXCI6W119XG5cbiAgICB1cGRhdGVGcmFtZTogZnVuY3Rpb24gdXBkYXRlRnJhbWUob2JqX2luZm8pIHtcbiAgICAgICAgdmFyIHhfcCA9IE51bWJlcihvYmpfaW5mby54KTtcbiAgICAgICAgdmFyIHlfcCA9IE51bWJlcihvYmpfaW5mby55KTtcbiAgICAgICAgdGhpcy5ub2RlLmlzQWN0aXZlU0MgPSB0cnVlO1xuICAgICAgICB0aGlzLm5vZGUuc2V0UG9zaXRpb24oY2MucCh4X3AsIHlfcCkpO1xuXG4gICAgICAgIHRoaXMuYm9keXRhbmsucm90YXRpb24gPSBOdW1iZXIob2JqX2luZm8ucik7XG5cbiAgICAgICAgdmFyIGd1blIgPSBOdW1iZXIob2JqX2luZm8uZ1IpO1xuICAgICAgICBpZiAoZ3VuUiA+IDE4MCkge1xuICAgICAgICAgICAgZ3VuUiA9IGd1blIgLSAzNjA7XG4gICAgICAgIH1cbiAgICAgICAgZ3VuUiA9IC1ndW5SO1xuICAgICAgICAvL2NvbnNvbGUubG9nKFwib2JqX2luZm8uZGlyTVY6ICVzXCIsb2JqX2luZm8uZGlyKTtcbiAgICAgICAgdGhpcy5kaXJNdiA9IHBhcnNlSW50KG9ial9pbmZvLmRpcik7XG4gICAgICAgIHRoaXMuc3BlZWRNb3ZlID0gcGFyc2VJbnQob2JqX2luZm8uc3ApO1xuXG4gICAgICAgIHRoaXMubmV4dEZyYW1lTW92ZSA9IDA7XG5cbiAgICAgICAgdGhpcy5PcG9zID0gY2MucCh4X3AsIHlfcCk7XG4gICAgICAgIHRoaXMubWluX3ggPSB4X3AgLSAxMjtcbiAgICAgICAgdGhpcy5tYXhfeCA9IHhfcCArIDEyO1xuICAgICAgICB0aGlzLm1pbl95ID0geV9wIC0gMTI7XG4gICAgICAgIHRoaXMubWF4X3kgPSB5X3AgKyAxMjtcblxuICAgICAgICAvL3RoaXMuc2NvcmU9b2JqX2luZm8uc2NvcmU7XG4gICAgICAgIC8vdGhpcy5hbW1vPXBhcnNlSW50KG9ial9pbmZvLmFtbW8pO1xuICAgICAgICAvL3RoaXMuaHA9cGFyc2VJbnQob2JqX2luZm8uaHApO1xuXG4gICAgICAgIHZhciB0bXBMZXZlbCA9IHBhcnNlSW50KG9ial9pbmZvLmxldmVsKTtcbiAgICAgICAgaWYgKHRtcExldmVsICE9IHRoaXMubGV2ZWwpIHtcbiAgICAgICAgICAgIHRoaXMubGV2ZWwgPSB0bXBMZXZlbDtcbiAgICAgICAgICAgIHZhciBwYXJyZW50Tm9kZSA9IHRoaXMubm9kZS5wYXJlbnQ7XG4gICAgICAgICAgICB2YXIgbWFwU2NyaXB0ID0gcGFycmVudE5vZGUuZ2V0Q29tcG9uZW50KFwiR2FtZU1hcFwiKTtcblxuICAgICAgICAgICAgdmFyIHNwX2JvZHkgPSB0aGlzLm5vZGUuY2hpbGRyZW5bMF07XG4gICAgICAgICAgICB2YXIgc3ByaXRlX2JvZHkgPSBzcF9ib2R5LmdldENvbXBvbmVudChcImNjLlNwcml0ZVwiKTtcbiAgICAgICAgICAgIHNwcml0ZV9ib2R5LnNwcml0ZUZyYW1lID0gbWFwU2NyaXB0LnRhbmtBdGxhcy5nZXRTcHJpdGVGcmFtZShcIlRhbmtDb2xvci10XCIgKyB0aGlzLmNvbG9ySUQgKyBcIl9iXCIpO1xuICAgICAgICAgICAgLy90aGlzLmNvdW50X3VwZGF0ZVJ1bisrO1xuICAgICAgICAgICAgdmFyIHRtbF9sdl9ndW4gPSAxO1xuICAgICAgICAgICAgaWYgKHRoaXMubGV2ZWwgPj0gMTAgJiYgdGhpcy5sZXZlbCA8IDM1KSB7XG4gICAgICAgICAgICAgICAgdG1sX2x2X2d1biA9IDI7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHRoaXMubGV2ZWwgPj0gMzUgJiYgdGhpcy5sZXZlbCA8IDc5KSB7XG4gICAgICAgICAgICAgICAgdG1sX2x2X2d1biA9IDM7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHRoaXMubGV2ZWwgPj0gNzkpIHtcbiAgICAgICAgICAgICAgICB0bWxfbHZfZ3VuID0gNDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh0aGlzLmxldmVsR3VuICE9IHRtbF9sdl9ndW4pIHtcbiAgICAgICAgICAgICAgICB0aGlzLmxldmVsR3VuID0gdG1sX2x2X2d1bjtcbiAgICAgICAgICAgICAgICB2YXIgc3BfZ3VuID0gdGhpcy5ub2RlLmNoaWxkcmVuWzNdO1xuICAgICAgICAgICAgICAgIHZhciBzcHJpdGVfZ3VuID0gc3BfZ3VuLmdldENvbXBvbmVudChcImNjLlNwcml0ZVwiKTtcbiAgICAgICAgICAgICAgICAvL3RoaXMuY291bnRfdXBkYXRlUnVuKys7XG4gICAgICAgICAgICAgICAgc3ByaXRlX2d1bi5zcHJpdGVGcmFtZSA9IG1hcFNjcmlwdC50YW5rQXRsYXMuZ2V0U3ByaXRlRnJhbWUoXCJUYW5rQ29sb3ItdFwiICsgdGhpcy5jb2xvcklEICsgXCJfbFwiICsgdGhpcy5sZXZlbEd1bik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICB2YXIgdG1wX2hwID0gcGFyc2VJbnQob2JqX2luZm8uaHApO1xuICAgICAgICBpZiAodG1wX2hwICE9IHRoaXMuaHApIHtcbiAgICAgICAgICAgIHRoaXMuaHAgPSB0bXBfaHA7XG4gICAgICAgICAgICB2YXIgbm9kZXByID0gdGhpcy5ub2RlLmNoaWxkcmVuWzJdO1xuICAgICAgICAgICAgdmFyIG5vZGVwcnNjID0gbm9kZXByLmNoaWxkcmVuWzBdO1xuICAgICAgICAgICAgdmFyIG1heEhQID0gODAgKyAodGhpcy5sZXZlbCAtIDEpICogMTU7XG4gICAgICAgICAgICB2YXIgWHNjID0gdGhpcy5ocCAvIG1heEhQO1xuICAgICAgICAgICAgaWYgKFhzYyA+IDEpIHtcbiAgICAgICAgICAgICAgICBYc2MgPSAxO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChYc2MgPCAwKSB7XG4gICAgICAgICAgICAgICAgWHNjID0gMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG5vZGVwcnNjLnNjYWxlWCA9IFhzYztcbiAgICAgICAgICAgIC8vdGhpcy5jb3VudF91cGRhdGVSdW4rKztcbiAgICAgICAgfVxuXG4gICAgICAgIHZhciBuYW1lID0gb2JqX2luZm8ubmFtZTtcbiAgICAgICAgaWYgKG5hbWUubGVuZ3RoID49IDEgJiYgdGhpcy5uZWVkVXBkYXRlTmFtZSkge1xuICAgICAgICAgICAgdGhpcy5jb3VudF91cGRhdGVSdW4rKztcblxuICAgICAgICAgICAgdGhpcy5uZWVkVXBkYXRlTmFtZSA9IGZhbHNlO1xuXG4gICAgICAgICAgICB2YXIgbm9kZXNjb3JlID0gdGhpcy5ub2RlLmNoaWxkcmVuWzVdO1xuICAgICAgICAgICAgdmFyIGxic2NvcmUgPSBub2Rlc2NvcmUuZ2V0Q29tcG9uZW50KFwiY2MuTGFiZWxcIik7XG4gICAgICAgICAgICBsYnNjb3JlLnN0cmluZyA9IG5hbWU7XG5cbiAgICAgICAgICAgIHZhciBjY29kZSA9IG9ial9pbmZvLmNvZGU7XG4gICAgICAgICAgICBpZiAoY2NvZGUubGVuZ3RoID09IDIgfHwgdHJ1ZSkge1xuICAgICAgICAgICAgICAgIHZhciBmbGFnTm9kZSA9IHRoaXMubm9kZS5jaGlsZHJlblsxXTtcbiAgICAgICAgICAgICAgICBmbGFnTm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHZhciBmbGFnU3ByaXRlID0gZmxhZ05vZGUuZ2V0Q29tcG9uZW50KFwiY2MuU3ByaXRlXCIpO1xuICAgICAgICAgICAgICAgIHZhciBwYXJyZW50Tm9kZSA9IHRoaXMubm9kZS5wYXJlbnQ7XG4gICAgICAgICAgICAgICAgdmFyIG1hcFNjcmlwdCA9IHBhcnJlbnROb2RlLmdldENvbXBvbmVudChcIkdhbWVNYXBcIik7XG4gICAgICAgICAgICAgICAgZmxhZ1Nwcml0ZS5zcHJpdGVGcmFtZSA9IG1hcFNjcmlwdC5mbGFnc0FsYXMuZ2V0U3ByaXRlRnJhbWUoXCJmbGFnLVwiICsgY2NvZGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgdmFyIG5vZGVuYW1lID0gdGhpcy5ub2RlLmNoaWxkcmVuWzRdO1xuICAgICAgICB2YXIgbGJSZWQgPSBub2RlbmFtZS5nZXRDb21wb25lbnQoXCJjYy5MYWJlbFwiKTtcbiAgICAgICAgbGJSZWQuc3RyaW5nID0gb2JqX2luZm8uc2NvcmU7XG4gICAgICAgIC8vdmFyIG5vZGVzY29yZT10aGlzLm5vZGUuY2hpbGRyZW5bNV07XG4gICAgICAgIC8vdmFyIGxic2NvcmU9bm9kZXNjb3JlLmdldENvbXBvbmVudChcImNjLkxhYmVsXCIpO1xuICAgICAgICAvL2xic2NvcmUuc3RyaW5nPVxuXG4gICAgICAgIHRoaXMuZ3VudGFuay5yb3RhdGlvbiA9IGd1blI7XG4gICAgICAgIC8vdGhpcy5sYm5hbWUuc3RyaW5nPVwiR3Vlc3RYWFhYXCI7XG4gICAgfVxuXG59KTtcblxuY2MuX1JGcG9wKCk7Il19
