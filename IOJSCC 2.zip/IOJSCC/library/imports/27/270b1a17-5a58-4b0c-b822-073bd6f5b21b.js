cc.Class({
    "extends": cc.Component,

    properties: {
        lbCountAmmo: cc.Label,
        lbCountHp: cc.Label,
        lbLevel: cc.Label,
        lbSpeed: cc.Label,
        prAmmo: cc.Node,
        prHP: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {}

});