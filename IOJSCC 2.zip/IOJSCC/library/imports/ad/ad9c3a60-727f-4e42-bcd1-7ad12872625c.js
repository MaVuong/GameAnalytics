cc.Class({
    "extends": cc.Component,

    properties: {
        spBullet: cc.Node,
        msTexture: cc.Texture2D,
        spX1: cc.Node,
        spX2: cc.Node,
        frameAlts: cc.SpriteAtlas,
        partTest: cc.ParticleSystem,
        tankEffect: cc.Prefab,
        homeMap: cc.Node
        //sp_particle:cc.Node
    },
    start: function start() {
        cc.log("node_add:start");
    },

    // use this for initialization
    onLoad: function onLoad() {
        var xcolcolor = new cc.Color(255, 255, 0);

        cc.log("node_add:onLoad");

        //this.spX1.setLocalZOrder(3);
        // this.spX2.setGlobalZOrder(2);

        // this.spX2.globalZOrder=-1;
        // this.spX2.color=new cc.Color(255,255,0);

        //var action1=cc.MoveBy(10,cc.p(500,0));
        //this.homeMap.runAction(action1);

        // cc.log("node_add:name= %s",node_add.name);

        // this.node_fire=new cc.Node("nodeParticleSystem");
        // this.ms=this.node_fire.addComponent(cc.ParticleSystem);
        // this.ms.file="";

        // this.node.addChild(this.node_fire);

        //cc.log("this.sp_particle.name: %s count allchild:",this.sp_particle.name,this.node.children.length);
        //cc.director.getScheduler().schedule(function() { this.testMovexx(); }, this, 0.1, !this._isRunning);
        // this.testMovexx();
    },

    testMovexx: function testMovexx(dt) {
        var tankNodeEff = cc.instantiate(this.tankEffect);
        tankNodeEff.x = 50;
        tankNodeEff.y = 180;

        var script_eff = tankNodeEff.getComponent("TankEffectScript");
        script_eff.runEffect(this.frameAlts, 3);
        this.node.addChild(tankNodeEff);

        //this.homeMap.addChild(tankNode);

        ////console.log("partTest: %s",this.partTest.group);
        //if (this.partTest.positionType==1){
        //    this.partTest.positionType=0;
        //}else{
        //    this.partTest.positionType=1;
        //}
        //
        //console.log("tankNode.children: "+this.homeMap.children.length);

        //var nodex=tankNode.children[9];
        //nodex.positionType=1;
        //nodex=tankNode.children[10];
        //nodex.positionType=1;
    },

    actionCheckEffect: function actionCheckEffect() {
        this.unscheduleAllCallbacks();
        // cc.log("this.node.children.length: %s",this.node.children.length);
        // cc.log("this.sp_particle.name: %s",this.sp_particle.name);
        // if (cc.isValid(sp_particle)) {
        //     cc.log("is activate");
        // }else{
        //     cc.log("is Remove ");
        // }
    },

    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {
        //this.homeMap.x=this.homeMap.x+2;

    }
});