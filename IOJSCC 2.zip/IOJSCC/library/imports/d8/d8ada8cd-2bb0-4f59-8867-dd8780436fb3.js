cc.Class({
    "extends": cc.Component,

    properties: {
        lb_button_control: cc.Label,
        lb_button_sound: cc.Label
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.addTouchListenEvent();
    },
    addTouchListenEvent: function addTouchListenEvent() {

        this.touchListen = cc.eventManager.addListener({ event: cc.EventListener.TOUCH_ONE_BY_ONE, swallowTouches: true,
            onTouchBegan: (function (touch, event) {
                console.log("alksdasdhaskd-----asd-s-s-s-s-s-s-s-s--s");
                return true;
            }).bind(this)

        }, this.node);

        this.loadLastSetting();
    },
    loadLastSetting: function loadLastSetting() {
        var eff_disable = false;
        var disableSound = cc.sys.localStorage.getItem("disableEffect");
        if (disableSound != null) {
            if (typeof disableSound === "undefined") {
                console.log("AAAA begin eff");
                eff_disable = false;
            } else {

                eff_disable = JSON.parse(disableSound);
            }
        }
        this.lb_button_sound.string = eff_disable ? "Off" : "On";

        var boole_swipe = false;
        var enable_swipe = cc.sys.localStorage.getItem("enable_swipe");
        if (enable_swipe != null) {
            if (typeof enable_swipe === "undefined") {
                enable_swipe = false;
            } else {
                boole_swipe = JSON.parse(enable_swipe);
            }
        }
        this.lb_button_control.string = !boole_swipe ? "Swipe" : "Button";
    },
    actionClose: function actionClose() {
        this.node.destroy();
    },
    actionChangeControl: function actionChangeControl() {
        var boole_swipe = false;
        var enable_swipe = cc.sys.localStorage.getItem("enable_swipe");
        if (enable_swipe != null) {
            if (typeof enable_swipe === "undefined") {
                enable_swipe = false;
            } else {
                boole_swipe = JSON.parse(enable_swipe);
            }
        }
        boole_swipe = !JSON.parse(boole_swipe);
        cc.sys.localStorage.setItem("enable_swipe", boole_swipe + "");
        this.lb_button_control.string = !boole_swipe ? "Swipe" : "Button";
    },

    actionOnOffAudio: function actionOnOffAudio() {
        var eff_disable = false;
        var disableSound = cc.sys.localStorage.getItem("disableEffect");
        cc.log("-------: ", disableSound);
        if (disableSound != null) {
            if (typeof disableSound === "undefined") {
                eff_disable = false;
            } else {
                eff_disable = JSON.parse(disableSound);
            }
        }
        eff_disable = !JSON.parse(eff_disable);
        cc.sys.localStorage.setItem("disableEffect", eff_disable + "");
        this.lb_button_sound.string = eff_disable ? "Off" : "On";
    }
});