cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    initDisplay: function initDisplay(tmp_info) {
        var x_p = Number(tmp_info.x);
        var y_p = Number(tmp_info.y);
        this.node.setPosition(cc.p(x_p, y_p));
        var ww = Number(tmp_info.w);
        var hh = Number(tmp_info.h);
        this.node.scaleX = ww / 100;
        this.node.scaleY = hh / 100;

        this.Opos = cc.p(x_p, y_p);
        this.min_x = x_p - ww / 2;
        this.max_x = x_p + ww / 2;

        this.min_y = y_p - hh / 2;
        this.max_y = y_p + hh / 2;
    }

});