cc.Class({
    "extends": cc.Component,

    properties: {},

    onLoad: function onLoad() {
        this.node.opacity = 190;
        var childx_effect = this.node.children[0];
        var ac1 = cc.fadeTo(cc.random0To1() * 3 + 0.5, 0); // tham so dau tien la duration , time so thu 2 la opacity
        var ac2 = cc.fadeTo(cc.random0To1() * 2 + 0.5, 255); // tham so dau tien la duration , time so thu 2 la opacity

        this.repeat = cc.repeatForever(cc.sequence(ac1, ac2));

        childx_effect.runAction(this.repeat);
    },
    beginClean: function beginClean() {
        var childx_effect = this.node.children[0];
        childx_effect.stopAllActions();
    },
    updateDisplay: function updateDisplay(tmp_info) {
        var x_p = Number(tmp_info.x);
        var y_p = Number(tmp_info.y);

        this.node.setPosition(cc.p(x_p, y_p));
        this.node.isActiveSC = true;
    }

});