var CoutryServer = { IM: "tankeu", HR: "tankeu", GW: "tankeu", IN: "tankasia", KE: "tankeu", LA: "tankasia", IO: "tankasia", HT: "tank", GY: "tank", LB: "tankasia", KG: "tankasia", HU: "tankeu", LC: "tank", IQ: "tankasia", KH: "tankasia", JM: "tank", IR: "tankasia", KI: "tankasia", IS: "tankeu", MA: "tankeu", JO: "tankasia", IT: "tankeu", JP: "tankasia", MC: "tankeu", KM: "tankeu", MD: "tankeu", LI: "tankeu", KN: "tank", ME: "tankeu", NA: "tankeu", MF: "tank", LK: "tankasia", KP: "tankasia", MG: "tankeu", NC: "tankasia", MH: "tankasia", KR: "tankasia", NE: "tankeu", NF: "tankasia", MK: "tankeu", NG: "tankeu", ML: "tankeu", MM: "tankasia", LR: "tankeu", NI: "tank", KW: "tankasia", MN: "tankasia", LS: "tankeu", PA: "tank", MO: "tankasia", LT: "tankeu", KY: "tank", MP: "tankasia", LU: "tankeu", NL: "tankeu", KZ: "tankasia", MQ: "tank", LV: "tankeu", MR: "tankeu", PE: "tank", MS: "tank", QA: "tankasia", NO: "tankeu", PF: "tankasia", MT: "tankeu", LY: "tankeu", NP: "tankasia", PG: "tankasia", MU: "tankeu", PH: "tankasia", MV: "tankasia", OM: "tankasia", NR: "tankasia", MW: "tankeu", MX: "tank", PK: "tankasia", MY: "tankasia", NU: "tankasia", PL: "tankeu", MZ: "tankeu", PM: "tank", PN: "tankasia", RE: "tankeu", SA: "tankasia", SB: "tankasia", NZ: "tankasia", SC: "tankeu", SD: "tankeu", PR: "tank", SE: "tankeu", PS: "tankasia", PT: "tankeu", SG: "tankasia", TC: "tank", SH: "tankeu", TD: "tankeu", SI: "tankeu", PW: "tankasia", SJ: "tankeu", UA: "tankeu", RO: "tankeu", TF: "tankeu", SK: "tankeu", PY: "tank", TG: "tankeu", SL: "tankeu", TH: "tankasia", SM: "tankeu", SN: "tankeu", RS: "tankeu", TJ: "tankasia", VA: "tankeu", SO: "tankeu", TK: "tankasia", UG: "tankeu", RU: "tankeu", TL: "tankasia", VC: "tank", TM: "tankasia", SR: "tank", RW: "tankeu", TN: "tankeu", VE: "tank", SS: "tankeu", TO: "tankasia", ST: "tankeu", VG: "tank", SV: "tank", UM: "tankasia", TR: "tankasia", VI: "tank", SX: "tank", WF: "tankasia", TT: "tank", SY: "tankasia", SZ: "tankeu", TV: "tankasia", TW: "tankasia", VN: "tankasia", US: "tank", TZ: "tankeu", YE: "tankasia", ZA: "tankeu", XK: "tankeu", UY: "tank", VU: "tankasia", UZ: "tankasia", WS: "tankasia", ZM: "tankeu", AD: "tankeu", YT: "tankeu", AE: "tankasia", BA: "tankeu", AF: "tankasia", BB: "tank", AG: "tank", BD: "tankasia", AI: "tank", BE: "tankeu", CA: "tank", BF: "tankeu", BG: "tankeu", ZW: "tankeu", AL: "tankeu", CC: "tankasia", BH: "tankasia", AM: "tankasia", CD: "tankeu", BI: "tankeu", BJ: "tankeu", AO: "tankeu", CF: "tankeu", CG: "tankeu", BL: "tank", AQ: "tankeu", CH: "tankeu", BM: "tank", AR: "tank", CI: "tankeu", BN: "tankasia", DE: "tankeu", AS: "tankasia", BO: "tank", AT: "tankeu", CK: "tankasia", AU: "tankasia", CL: "tank", EC: "tank", BQ: "tank", CM: "tankeu", BR: "tank", AW: "tank", CN: "tankasia", EE: "tankeu", BS: "tank", DJ: "tankeu", AX: "tankeu", CO: "tank", BT: "tankasia", DK: "tankeu", EG: "tankeu", AZ: "tankasia", EH: "tankeu", BV: "tankeu", DM: "tank", CR: "tank", BW: "tankeu", GA: "tankeu", DO: "tank", BY: "tankeu", GB: "tankeu", CU: "tank", BZ: "tank", CV: "tankeu", GD: "tank", FI: "tankeu", CW: "tank", GE: "tankasia", FJ: "tankasia", CX: "tankasia", GF: "tank", FK: "tank", CY: "tankeu", GG: "tankeu", CZ: "tankeu", GH: "tankeu", FM: "tankasia", ER: "tankeu", GI: "tankeu", ES: "tankeu", FO: "tankeu", ET: "tankeu", GL: "tank", DZ: "tankeu", GM: "tankeu", ID: "tankasia", FR: "tankeu", GN: "tankeu", IE: "tankeu", HK: "tankasia", GP: "tank", GQ: "tankeu", HM: "tankeu", GR: "tankeu", HN: "tank", JE: "tankeu", GS: "tankeu", GT: "tank", GU: "tankasia", IL: "tankasia" };
var Utils = {
    log: function log(msgobject) {
        console.log("-GAMEIOLIVE-:%s", msgobject);
    },

    getServer: function getServer() {
        var contrycode = cc.sys.localStorage.getItem("country");

        if (typeof contrycode === "undefined") {
            contrycode = "US";
        }
        if (contrycode == null) {
            contrycode = "US";
        }
        if (contrycode.length != 2) {
            contrycode = "US";
        }
        contrycode = contrycode.toUpperCase();

        var subdomain = CoutryServer[contrycode];
        if (typeof subdomain === "undefined") {
            subdomain = "tank";
        }
        if (subdomain == null) {
            subdomain = "tank";
        }

        var domain = "http://" + subdomain + ".gameio.live:2020";
        console.log("contrycode: %s  / %s", contrycode, domain);
        return domain;
    },

    distance2Pos: function distance2Pos(p1, p2) {
        var dtx = p1.x - p2.x;
        var dty = p1.y - p2.y;
        return Math.sqrt(Math.pow(dtx, 2) + Math.pow(dty, 2));
    },
    loadUserInfo: function loadUserInfo() {
        var strRT = '{"platform":10,"version":1.1,"usr":"UserName","code":"vn"}'; // theo quy ước thì 9 là iOS,10 là web mobile, 11 là android

        var contrycode = cc.sys.localStorage.getItem("country");
        if (contrycode != null) {
            if (typeof contrycode === "undefined") {
                cc.log("error load contry code");
                strRT = strRT.replace("vn", "us");
            } else {
                strRT = strRT.replace("vn", contrycode);
            }
        }
        strRT = strRT.replace("UserName", Utils.playerName);
        cc.log("strRT: %s", strRT);
        return strRT;
    },
    deCode: function deCode(keyCode) {
        var end = keyCode.length * 0.6;
        var begin = keyCode.length * 0.1;
        var newkey = keyCode.substring(begin, end);
        return newkey;
    },

    decodePackTank: function decodePackTank(objectEndcode) {
        var psend = objectEndcode.p;
        var x_tmp = psend / 100000.0;
        var xp = x_tmp / 10.0;
        xp = xp - 2000;
        var y_tmp = psend % 100000;
        var yp = y_tmp / 10.0;
        yp = yp - 2000;

        var e_g_r_d = objectEndcode.r;
        var dir = 0;
        if (e_g_r_d >= 1000000) {
            dir = parseInt(e_g_r_d / 1000000);
            e_g_r_d = e_g_r_d - dir * 1000000;
        }
        var tank_angle = e_g_r_d / 1000;
        var gun_angle = e_g_r_d % 1000;

        var e_x = objectEndcode.e;
        var hp = parseInt(e_x / 10000.0);
        var ammo = e_x % 10000;

        var level_score = objectEndcode.s;
        var level_s = level_score / 1000000.0;
        var score_s = level_score % 1000000;

        var t_ID = objectEndcode.i;
        var spped = objectEndcode.m;

        var tankName = "";
        var nameserver = objectEndcode.n;
        if (typeof nameserver === "undefined") {
            tankName = "";
        } else {
            tankName = objectEndcode.n;
        }

        var ccode = objectEndcode.c;
        if (typeof ccode === "undefined") {
            ccode = "vn";
        } else {
            ccode = objectEndcode.c;
        }

        var objectDecode = {
            x: xp,
            y: yp,
            id: t_ID,
            r: tank_angle,
            level: level_s,
            score: score_s,
            hp: hp,
            dir: dir,
            ammo: ammo,
            sp: spped,
            name: tankName,
            gR: gun_angle,
            code: ccode
        };
        return objectDecode;
    },

    decodePackObs: function decodePackObs(objectEndcode) {
        var psend = objectEndcode.p;
        var x_tmp = psend / 100000.0;
        var xp = x_tmp / 10.0;
        xp = xp - 2000;
        var y_tmp = psend % 100000;
        var yp = y_tmp / 10.0;
        yp = yp - 2000;

        var numinfo = objectEndcode.o;
        var idObj = parseInt(numinfo / 1000000.0);

        var sodu = numinfo % 1000000;
        var wd = sodu / 1000;
        var hd = sodu % 1000;

        var objDecode = {
            x: xp,
            y: yp,
            w: wd,
            h: hd,
            id: idObj
        };
        return objDecode;
    },

    decodePackBullet: function decodePackBullet(objectEndcode) {
        var psend = objectEndcode.p;
        var x_tmp = psend / 100000.0;
        var xp = x_tmp / 10.0;
        xp = xp - 2000;
        var y_tmp = psend % 100000;
        var yp = y_tmp / 10.0;
        yp = yp - 2000;

        var number_info = objectEndcode.i;
        var bullet_angle = parseInt(number_info / 100000);
        var bullet_id = number_info % 100000;

        var objDecode = {
            x: xp,
            y: yp,
            ag: bullet_angle,
            id: bullet_id
        };
        return objDecode;
    },

    decodePackExplosion: function decodePackExplosion(objectEndcode) {
        var psend = objectEndcode.p;
        var x_tmp = psend / 100000.0;
        var xp = x_tmp / 10.0;
        xp = xp - 2000;
        var y_tmp = psend % 100000;
        var yp = y_tmp / 10.0;
        yp = yp - 2000;

        var tid = objectEndcode.t;

        var objDecode = {
            x: xp,
            y: yp,
            tid: tid,
            stt: objectEndcode.e,
            tank_angle: 0,
            gun_angle: 0
        };
        return objDecode;
    },

    decodePackItem: function decodePackItem(objectEndcode) {
        var psend = objectEndcode.p;
        var x_tmp = psend / 100000.0;
        var xp = x_tmp / 10.0;
        xp = xp - 2000;
        var y_tmp = psend % 100000;
        var yp = y_tmp / 10.0;
        yp = yp - 2000;

        var numberinfo = objectEndcode.i;
        var iditem = numberinfo % 100000;
        var typeitem = parseInt(numberinfo / 100000);
        var objDecode = {
            id: iditem,
            x: xp,
            y: yp,
            type: typeitem
        };
        return objDecode;
    }

};
module.exports = Utils;