cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // COCOS-CREATOR LA ENGINE KHON NAN NHAT, EFFECT RENDER STATIC THEO SCREEN :| BO TAY

    onLoad: function onLoad() {
        this.schudleFixPosition();
    },
    setFixedPosition: function setFixedPosition() {
        this.rX = this.node.parent.x;
        this.rY = this.node.parent.y;
    },
    schudleFixPosition: function schudleFixPosition() {
        this.schedule(function (dt) {
            //var dtx=this.node.parent.x-this.rX;
            //var dty=this.node.parent.y-this.rY;
            //this.rX=this.node.parent.x;
            //this.rY=this.node.parent.y;
            //
            //this.node.x=this.node.x+dtx/2;
            //this.node.y=this.node.y+dty/2;
        }, 0.002);
    }
});