var Utils = require('../LIB/Utils');
cc.Class({
    "extends": cc.Component,

    properties: {
        hubcontrol: cc.Node,
        bt0: cc.Node,
        bt1: cc.Node,
        bt2: cc.Node,
        bt3: cc.Node,
        bt4: cc.Node

    },

    // use this for initialization
    onLoad: function onLoad() {
        //this.addTouchListenEvent();

        if (cc.sys.isBrowser || Utils.enableSwipe) {
            this.node.active = false;
        } else {
            var size = cc.director.getVisibleSize();

            var yclose = -225;
            var y_explain = -145;

            var xclose = -size.width / 2 + 113;
            var x_explain = -size.width / 2 + 200;

            this.closePos = cc.p(xclose, yclose);
            this.ex_pos = cc.p(x_explain, y_explain);

            this.PadDir = 1;

            this.closeAllButton();
            this.changeframe = true;
        }
    },
    onDisable: function onDisable() {
        this.mainscript = null;
    },
    updatePadDir: function updatePadDir() {

        var allchild = this.node.children;
        for (var ix = 0; ix < allchild.length; ix++) {
            var bt1 = allchild[ix];
            //bt1.setLocalZOrder(1);
        }
        if (this.PadDir == 1) {
            this.bt0.rotation = 180;
            // this.bt0=this.node.children[2];
            this.bt2.setLocalZOrder(3);
        }
        if (this.PadDir == 3) {
            this.bt0.rotation = 0;
            //this.bt0=this.node.children[3];
            this.bt3.setLocalZOrder(3);
        }
        if (this.PadDir == 4) {
            this.bt0.rotation = -90;
            //this.bt0=this.node.children[1];
            this.bt1.setLocalZOrder(3);
        }
        if (this.PadDir == 2) {
            this.bt0.rotation = 90;
            //this.bt0=this.node.children[4];
            this.bt4.setLocalZOrder(3);
        }
    },
    closeAllButton: function closeAllButton() {
        var allchild = this.node.children;
        for (var ix = 0; ix < allchild.length; ix++) {
            var bt1 = allchild[ix];
            bt1.x = 0;
            bt1.y = 0;
            if (ix == 0) {
                bt1.active = true;
            } else {
                bt1.active = false;
            }
        }

        this.node.setPosition(this.closePos);
        this.hubcontrol.active = true;
    },
    objectMovePos: function objectMovePos(obj_node, pos) {
        obj_node.stopAllActions();
        var actionmv = cc.moveTo(0.2, pos);
        obj_node.runAction(actionmv);
    },
    objectMoveCenter: function objectMoveCenter(obj_node, pos) {
        obj_node.stopAllActions();
        var actionmv = cc.moveTo(0.2, pos);
        obj_node.runAction(actionmv);
    },
    explainAllButton: function explainAllButton() {

        //var bt1=allchild[0];
        this.bt0.x = 0;
        this.bt0.y = 0;
        this.bt0.active = false;

        //bt1=allchild[1];
        this.bt1.active = true;
        this.objectMovePos(this.bt1, cc.p(0, -90));

        //bt1=allchild[2];
        this.bt2.active = true;
        this.objectMovePos(this.bt2, cc.p(90, 0));

        //bt1=allchild[3];
        this.bt3.active = true;
        this.objectMovePos(this.bt3, cc.p(-90, 0));

        //bt1=allchild[4];
        this.bt4.active = true;
        this.objectMovePos(this.bt4, cc.p(0, 90));

        this.node.stopAllActions();
        var actionmv = cc.moveTo(0.2, this.ex_pos);
        this.node.runAction(actionmv);
        //this.node.setPosition(this.ex_pos);
    },

    moveAndCloseAllButton: function moveAndCloseAllButton() {
        cc.log("asdas askkkkkkkkkkkdk");

        this.mainscript.updateMoveController(this.PadDir);
        var moveCenter = cc.callFunc(this.moveToCenter, this);
        var delaytime = cc.delayTime(0.15);
        var moveRootPos = cc.callFunc(this.moveToClosepos, this);
        var actionsc = cc.sequence(moveCenter, delaytime, moveRootPos);
        this.node.stopAllActions();
        this.node.runAction(actionsc);
    },
    moveToClosepos: function moveToClosepos(objsc) {
        var allchild = this.node.children;
        for (var ix = 0; ix < allchild.length; ix++) {
            var bt1 = allchild[ix];
            bt1.x = 0;
            bt1.y = 0;
            if (ix == 0) {
                bt1.active = true;
            } else {
                bt1.active = false;
            }
        }
        //this.bt0.active=true;
        //this.bt1.active=false;
        //this.bt2.active=false;
        //this.bt3.active=false;
        //this.bt4.active=false;
        // this.node.stopAllActions();
        var actionmv = cc.moveTo(0.18, this.closePos);
        this.node.runAction(actionmv);
    },
    moveToCenter: function moveToCenter(objsc) {
        cc.log("----------kkkkkk ");
        var allchild = this.node.children;

        // var bt1=allchild[0];
        // bt1.active = true;
        // bt1.opacity=0;
        this.updatePadDir();

        //var bt1=allchild[1];
        this.bt1.active = true;
        this.objectMoveCenter(this.bt1, cc.p(0, 0));

        //bt1=allchild[2];
        this.bt2.active = true;
        this.objectMoveCenter(this.bt2, cc.p(0, 0));

        //bt1=allchild[3];
        this.bt3.active = true;
        this.objectMoveCenter(this.bt3, cc.p(0, 0));

        //bt1=allchild[4];
        this.bt4.active = true;
        this.objectMoveCenter(this.bt4, cc.p(0, 0));
    },

    actionMoveUp: function actionMoveUp() {
        this.PadDir = 2;
        this.moveAndCloseAllButton();
        //this.closeAllButton();
    },
    actionMoveLeft: function actionMoveLeft() {
        this.PadDir = 3;
        this.moveAndCloseAllButton();
    },
    actionMoveRight: function actionMoveRight() {
        cc.log("move actionMoveRight");
        this.PadDir = 1;
        this.moveAndCloseAllButton();
    },
    actionMoveDown: function actionMoveDown() {
        cc.log("move actionMoveDown");
        this.PadDir = 4;
        this.moveAndCloseAllButton();
    },
    actionEX: function actionEX() {
        cc.log("move actionEX");
        var bt0 = this.node.children[0];
        if (this.changeframe) {
            this.changeframe = false;
            this.hubcontrol.removeFromParent(true);
            this.hubcontrol = null;
        }

        this.explainAllButton();
        //this.node.setPosition(this.ex_pos);
    }

});