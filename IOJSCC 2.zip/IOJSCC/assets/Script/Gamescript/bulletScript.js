cc.Class({
    extends: cc.Component,

    properties: {
        msTexture:cc.Texture2D
    },

    // use this for initialization
    onLoad: function () {
        // this.node_add_efect=new cc.Node("effect");
        // var ms=this.node_add_efect.addComponent(cc.MotionStreak);
        // ms.fadeTime=0.08;
        // ms.minSeg=0.2;
        // ms.stroke=5;
        // ms.texture=this.msTexture;
        // this.node.parent.addChild(this.node_add_efect);
        // this.angleMove=0;
        
        this.nextFrameMove=0;
        //this.effnode=this.node.children[0];
    },
    
    updateFrame:function(tmp_info){
        var x_p=Number(tmp_info.x);
        var y_p=Number(tmp_info.y);
        this.node.setPosition(cc.p(x_p,y_p));
        this.node.isActiveSC=true;

        this.angleMove=parseInt(tmp_info.ag);
        var t_r=this.angleMove;
        if(t_r>180){
            t_r=t_r-360;
        }
        t_r=-t_r;
        this.nextFrameMove=0;
        this.node.rotation=t_r;

        //this.updateEffectPosition();
    },
    
    
});
