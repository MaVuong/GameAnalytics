
var Utils = require('../LIB/Utils');
cc.Class({
    extends: cc.Component,

    properties: {
        hub_prefab:{
            type:cc.Prefab,
            default:null
        },
        lbStatus:{
            type:cc.Label,
            default:null
        },
        nodecontro:cc.Node,
        panelInfo:cc.Node,
        gameMap:{
            type:cc.Node,
            default:null
        },
        arrowNode:cc.Node,
        tinyPlayer:cc.Node,
        lbscore:cc.Label,
        testnodxx:{
            type:cc.Prefab,
            default:null
        },

        tinyMapGrapphic:cc.Graphics,
    },
    actionBackHome:function(){
        this.socket.disconnect();
        cc.director.loadScene("HomeScene");
    },

    ListenNativeHidden: function () {
        //game_on_hide
        if (cc.sys.isNative){
            var self=this;
            this.lstnr = cc.EventListenerCustom.create("game_on_hide",function(){
                self.socket.disconnect();
                cc.director.loadScene("HomeScene");
            });
            cc.eventManager.addListener(this.lstnr, this);
        }


    },


    // use this for initialization
    onLoad: function () {
        /** 
         * Cơ bản trong Engine cocos: cấp cao nhất và chứa tất cả các đối tượng trong game là scene, trong scene chứa các child như là Canvas, Node, Sprite ,Label,button.... etc 
         * các child này sẽ có các thuộc tính cơ bản từ Node như position,scale,rotation,Anchor point ...
         * Lớp Node là lớp base chứa các đối tượng ,Sprite,Label,Button... đều là kế thừa từ Node và có các thuộc tính của node, ngoài ra với mỗi đối tượng có thêm thuộc tính riêng của mình
         *  -Sprite là đối tượng được dùng để thiển thị 1 bức ảnh cơ chế để load 1 bức ảnh image_file->texture->spriteframe----->Sprite 
         *          trong đó Sprite chỉ hiển thị spriteFrame, ví dụ mình có thể tạo 1 Sprite hiển thị trên màn hình là 1 ảnh hình tròn màu đỏ, khi touch vào thì load 1 spriteFrame màu xanh 
         *          ,release thì load lại spriteFrame màu đỏ 
         * 
         * Bất cứ đối tượng UI nào trong game đều có thể tạo 1 script đề điều khiển đối tượng đó, ví dụ có 1 đối tượng là xe tank thì trong xe tank có thể tạo 1 hoặc nhiều script để điều khiển 
         * xe tank, tuy nhiên tạo nhiều script sẽ dễ dẫn đến xung đột khó bắt lỗi 
         *     từ đối tượng UI muốn gọi ra script của xe tank thì gọi bằng cách 
         *          var scriptObj=UI_Object.getComponent("ScriptName");--> bở vì 1 node có thể chứa nhiều script nên phải gọi thế này
         *     ngược lại từ 1 script muốn gọi lại đối tượng UI_Object thì chỉ cần gọi 
         *          var ui_obj=script_obj.node;---> một đối tượng script chỉ có thể điều khiển duy nhất 1 node 
         *     ở dòng code trên ui_obj có thể là Label, Button, Sprite... tuy nhiên thì class Node là cha và đại diện chung cho tất cả các đối tượng trên 
         * */
         
        
        /**
         *  Hàm Onload được gọi đầu tiên trong game xem thêm ở url :http://cocos2d-x.org/docs/api-ref/creator/v1.1.2/classes/TiledLayer.html#method_onLoad
         * 
         * 
         * */
        if (cc.sys.isNative){
            this.ListenNativeHidden();
        }

        var script_controller=this.nodecontro.getComponent("PadController");
        script_controller.mainscript=this;
        
        this.mapScript=this.gameMap.getComponent("GameMap");// lấy ra script của đối tượng gamemap
        
        this.panelInfoScript=this.panelInfo.getComponent("PanelUserInfo");
        
        
        this.actionListenKeyPress();//sử dụng cho việc nhấn phím để di chuyển xe tank web version

        //this.addTouchListenEvent();// sử dụng cho việc touch mobile version
        if(Utils.enableSwipe){
            this.arrowNode.active=false;
            this.addTouchAndSwipeEvent();
        }else{
            this.arrowNode.destroy();
            this.addTouchListenEvent();
        }

        
        this.timelog=0;
        this.actionLoadGameBegin();// connect đến server 

        //Utils.lastscore=103;
        this.AdsManager();

        this.testcountdraw=0;


    },
    AdsManager:function(){
        if(cc.sys.os==cc.sys.OS_IOS){
            jsb.reflection.callStaticMethod("BridgeIOS", "HiddenAdsBanerWithAnimation");
        }else if(cc.sys.os==cc.sys.OS_ANDROID){
            
        }else {// phien ban web 
            
        }
    },
    


    runUpdateHighScore:function(){

    },

    
    //called every frame, uncomment this function to activate update callback
    //update: function (dt) {
    //   this.timelog=this.timelog+dt;
    //   if(this.timelog>0.3){
    //       this.timelog=0;
    //       var logscreen="ID:"+this.mapScript.TANKID+" Tank:"+this.mapScript.t_add_tank+"  Obs:"+this.mapScript.t_add_obs+ "  Bullet:"+this.mapScript.t_add_bullet+ "  item:"+this.mapScript.t_add_items;
    //       logscreen=logscreen+" exp:"+this.mapScript.t_add_explosion;
    //       logscreen=logscreen+"\n"+this.mapScript.msglog+ "\n"+this.mapScript.otherMSG;
    //       this.lbStatus.string=logscreen;
    //   }
    //},
    
    
    onDisable: function(){
        var script_controller=this.nodecontro.getComponent("PadController");
        script_controller.mainscript=null;
        this.panelInfoScript=null;
        Utils.log("Game player is Unload");
        cc.eventManager.removeListener(this.touchListen);
        cc.eventManager.removeListener(this.keyEventListen);
        if (cc.sys.isNative){
            cc.eventManager.removeListener(this.lstnr);
        }

       // cc.eventManager.removeAllListeners();
    },
    
    updateMoveController:function(dir_move){
        cc.log("dir_move:%s",dir_move);
        var numberint=parseInt(dir_move);
        if(numberint>=1&&numberint<=4){
            this.socket.emit("changeDir",numberint);
        }
    },
    
    addTouchListenEvent:function(){

        this.touchListen=cc.eventManager.addListener({event: cc.EventListener.TOUCH_ONE_BY_ONE,swallowTouches: true,
            onTouchBegan: function(touch, event) {
                //cc.log("-----------asdasdasdasdkhkasjdbkajsdsakjdhaskdhaskjdhakjsdhask------------");

                //this.isFire=true;
                //this.beginPos = this.node.convertToNodeSpace(touch.getLocation());

                var pos = this.node.convertToNodeSpace(touch.getLocation());
                pos.x=pos.x-cc.winSize.width/2;
                pos.y=pos.y-cc.winSize.height/2;
                var vfire=cc.pNormalize(cc.v2(pos.x, pos.y));
                var angle=cc.pToAngle(vfire);
                angle=((angle*180)/3.14);
                if(angle<0){
                    angle=360+angle;
                }
                if(angle>360){// se khong bao gio xay ra truong hop nay vi cocos2d-js luon tra ve 1 goc tu -180,180
                    angle=angle-360;
                }
                //this.lbStatus.string="GOC false AAA="+angle;
                this.socket.emit("fireTarget",angle);


                return true;
            }.bind(this),


        }, this.node);
        
        
        
    },

    addTouchAndSwipeEvent:function(){

        this.touchListen=cc.eventManager.addListener({event: cc.EventListener.TOUCH_ONE_BY_ONE,swallowTouches: true,
            onTouchBegan: function(touch, event) {
                this.isFire=true;
                this.beginPos = this.node.convertToNodeSpace(touch.getLocation());
                return true;
            }.bind(this),


            onTouchMoved: function(touch, event) {
                //this.lbStatus.string="touch onTouchMoved";
            }.bind(this),

            onTouchEnded: function(touch, event) {

                var pos = this.node.convertToNodeSpace(touch.getLocation());
                var bukPos=this.beginPos;
                var distance=cc.pDistance(this.beginPos, pos);
                var stt_movedir=0;
                //this.lbStatus.string="touch distance:"+distance;
                if(distance>30){
                    this.isFire=false;
                    var dtPos=cc.v2(pos.x-this.beginPos.x, pos.y-this.beginPos.y);

                    var anglemv=cc.pToAngle(dtPos);
                    anglemv=((anglemv*180)/3.14);
                    if(anglemv<0){
                        anglemv=360+anglemv;
                    }
                    if(anglemv>360){// se khong bao gio xay ra truong hop nay vi cocos2d-js luon tra ve 1 goc tu -180,180 , nhưng cứ thêm 1 câu if cho chắc ăn
                        anglemv=anglemv-360;
                    }
                    if (anglemv<45||anglemv>315) {
                        stt_movedir=1;
                    }
                    if (anglemv>45&&anglemv<135) {
                        stt_movedir=2;
                    }
                    if (anglemv>135&&anglemv<225) {
                        stt_movedir=3;
                    }
                    if (anglemv<315&&anglemv>225) {
                        stt_movedir=4;
                    }
                    //this.lbStatus.string="tank angle="+anglemv;
                }

                if(this.isFire){
                    pos.x=pos.x-cc.winSize.width/2;
                    pos.y=pos.y-cc.winSize.height/2;
                    var vfire=cc.pNormalize(cc.v2(pos.x, pos.y));
                    var angle=cc.pToAngle(vfire);
                    angle=((angle*180)/3.14);
                    if(angle<0){
                        angle=360+angle;
                    }
                    if(angle>360){// se khong bao gio xay ra truong hop nay vi cocos2d-js luon tra ve 1 goc tu -180,180
                        angle=angle-360;
                    }

                    //this.lbStatus.string="GOC false AAA="+angle;
                    this.socket.emit("fireTarget",angle);
                }else{
                    if(stt_movedir>0&&stt_movedir<5){
                        pos.x=this.beginPos.x-cc.winSize.width/2;
                        pos.y=this.beginPos.y-cc.winSize.height/2;
                        this.arrowNode.active=true;
                        this.arrowNode.stopAllActions();
                        this.arrowNode.setPosition(pos);
                        this.arrowNode.scaleX=0.4;
                        this.arrowNode.opacity=120;
                        var actionSC=cc.scaleTo(0.3,0.8,0.7);

                        var xm=0;
                        var ym=0;
                        if(stt_movedir==1){
                            xm=300;
                            this.arrowNode.rotation=0;
                        }
                        if(stt_movedir==3){
                            xm=-300;
                            this.arrowNode.rotation=-180;
                        }
                        if(stt_movedir==2){
                            ym=300;
                            this.arrowNode.rotation=-90;
                        }
                        if(stt_movedir==4){
                            ym=-300;
                            this.arrowNode.rotation=90;
                        }
                        var actionMV=cc.moveBy(0.3,cc.p(xm,ym));
                        var actionop=cc.fadeTo(0.5,0);
                        this.arrowNode.runAction(cc.spawn(actionSC,actionMV,actionop));

                        this.socket.emit("changeDir",stt_movedir);
                    }

                }
            }.bind(this)


        }, this.node);

    },

    
    actionListenKeyPress:function(){
        var self = this;
        //add keyboard input listener to jump, turnLeft and turnRight
        this.keyEventListen=cc.eventManager.addListener({
            event: cc.EventListener.KEYBOARD,
            // set a flag when key pressed
            onKeyPressed: function(keyCode, event) {
                var movestt=0;
                if (keyCode==cc.KEY.d||keyCode==cc.KEY.right){movestt=1;}
                if (keyCode==cc.KEY.w||keyCode==cc.KEY.up){movestt=2;}
                if (keyCode==cc.KEY.a||keyCode==cc.KEY.left){movestt=3;}
                if (keyCode==cc.KEY.s||keyCode==cc.KEY.down){movestt=4;}

                // if(this.last_movestt==movestt){
                //     return;
                // }
                this.last_movestt=movestt;
                if(movestt>0&&movestt<5){
                    self.socket.emit("changeDir",movestt);
                }
            }
        }, self.node);
    },

    actionLoadGameBegin:function(){
        
        this.hub=cc.instantiate(this.hub_prefab);
        this.node.addChild(this.hub);
        
        var self=this;
        require('socket.io');
        var urlconnect=Utils.getServer();
        var config={
            'forceNew':true,
            'reconnection': false,
            'reconnectionDelay': 200,
            'reconnectionDelayMax' : 1000,
            'reconnectionAttempts': 1
        };
        this.socket = io.connect(urlconnect,config);// phiên bản js này hỗ trợ trực tiếp ipv6, ipv4
        console.log("-----DD-->url connect: %s",urlconnect);
        this.socket.on('connect', function(){
            Utils.log("ket noi thanh cong");
            var str_info=Utils.loadUserInfo();
            self.socket.emit("MyInfo",str_info);
            if(self.hub==null){
                return;
            }
            self.hub.destroy();
            self.hub=null;


        });

        this.socket.on('RequestValidate', function(message){
            var msgReceive=message;
            if(typeof(message)=="string"){
                msgReceive=JSON.parse(message);
            }
            self.mapScript.TANKID=parseInt(msgReceive.id);
            var keydecode=Utils.deCode(msgReceive.key);
            self.socket.emit("MyValidate",keydecode);
            ///cham mau trang nhap nhay lien tuc
            //var actionRP=cc.repeatForever(cc.blink(2, 3));
            //self.tinyPlayer.stopAllActions();
            //self.tinyPlayer.runAction(actionRP);
        });
        this.socket.on('UpdatePosition', function(message){
            var msgReceive=message;
            if(typeof(message)=="string"){
                msgReceive=JSON.parse(message);
            }
            self.mapScript.updateFrameStep(msgReceive);
            self.updateTinyMapGame();
        });

        this.socket.on('UpdateTankMap', function(message){

            var msgReceive=message;
            if(typeof(message)=="string"){
                msgReceive=JSON.parse(message);
            }
            self.updateTinyMap(msgReceive);
        });


        this.socket.on('BestPlayers',function(message){
            var msgReceive=message;
            if(typeof(message)=="string"){
                msgReceive=JSON.parse(message);
            }
            var l=msgReceive.length;
            var strHC="";
            for(var i=0;i<l;i++){
                var objsc=msgReceive[i];
                var stt=i+1;
                var linetmp="#"+stt+"  "+objsc.n+"    "+objsc.s;
                if(i==0){
                    strHC=linetmp;
                }else {
                    strHC=strHC+"\n"+linetmp;
                }

            }
            self.lbStatus.string=strHC;

        });


        this.socket.on('error', function(message){
            //cc.log("dddddddd----------eror:%s",message);
            Utils.messageconnect=message;
            cc.director.loadScene("HomeScene");
        });
        this.socket.on('disconnect', function(message){
           cc.director.loadScene("HomeScene");
        });
        
    },

    updateTinyMap:function(arrayTank){
        //this.testcountdraw=this.testcountdraw+1;
        //if(this.testcountdraw>3){
        //
        //    this.tinyMapGrapphic.clear();
        //}else{
        //    this.tinyMapGrapphic.rect(20,20,111,111);
        //    this.tinyMapGrapphic.fillColor = cc.Color.GREEN;
        //    this.tinyMapGrapphic.fill();
        //}
        //if(this.testcountdraw>5){
        //    this.testcountdraw=0;
        //}
        //
        //return;

        this.tinyMapGrapphic.clear();
        var len=arrayTank.length;
        var mypos={};
        mypos.x=this.mapScript.MYPLAYER.x;
        mypos.y=this.mapScript.MYPLAYER.y;

        for(var ax=0;ax<len;ax++){
            var pos=arrayTank[ax];

            var distanceMe=Utils.distance2Pos(mypos,pos);
            if(distanceMe>15){
                pos.x=70*(pos.x/1500);
                pos.y=50*(pos.y/1000);
                this.tinyMapGrapphic.rect(pos.x-1.5,pos.y-1.5,3,3);
                this.tinyMapGrapphic.fillColor=cc.Color.RED;
            }



        }
        this.tinyMapGrapphic.fill();

        mypos.x=70*(mypos.x/1500);
        mypos.y=50*(mypos.y/1000);
        this.tinyMapGrapphic.rect(mypos.x-1.5,mypos.y-1.5,3,3);
        this.tinyMapGrapphic.fillColor=cc.Color.GREEN;
        this.tinyMapGrapphic.fill();
    },

    updateTinyMapGame:function(){
        if(this.mapScript.MYPLAYER.isActiveSC){
            
            //var xpos=this.mapScript.MYPLAYER.x/1500;
            //var ypos=this.mapScript.MYPLAYER.y/1000;
            //this.tinyPlayer.x=xpos*70;
            //this.tinyPlayer.y=ypos*50;
            
            var obj_info=this.mapScript.MYPLAYER.activeInfo;
            
            var myLevel=obj_info.level;
            
            var myMaxAmmo=parseInt(140+(myLevel-1)*20);
            var myMaxHealth=parseInt(80+(myLevel-1)*15);

            var sc_ammo=parseInt(obj_info.ammo)/myMaxAmmo;
            if(sc_ammo>1){
                sc_ammo=1;
            }
            var sc_hp=parseInt(obj_info.hp)/myMaxHealth;
            if(sc_hp>1){
                sc_hp=1;
            }
            
            this.panelInfoScript.prAmmo.scaleX=sc_ammo;
            this.panelInfoScript.prHP.scaleX=sc_hp;


            this.panelInfoScript.lbCountAmmo.string=parseInt(obj_info.ammo)+"/"+myMaxAmmo;
            this.panelInfoScript.lbCountHp.string=parseInt(obj_info.hp)+"/"+myMaxHealth;
            this.panelInfoScript.lbLevel.string="LEVEL:"+parseInt(myLevel);
            this.lbscore.string=obj_info.score;
            Utils.myscore=obj_info.score;
            this.panelInfoScript.lbSpeed.string="Speed:"+Number(obj_info.sp).toFixed(1);
        }
    },
   
});
