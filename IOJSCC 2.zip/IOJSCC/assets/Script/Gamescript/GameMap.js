var Utils = require('../LIB/Utils');
cc.Class({
    extends: cc.Component,

    properties: {
        t_prefab:{
            type:cc.Prefab,
            default:null
        },
        obs_prefab:{
            type:cc.Prefab,
            default:null
        },
        bullet_prefab:{
            type:cc.Prefab,
            default:null
        },
        item_ammo_prefab:{
            type:cc.Prefab,
            default:null
        },
        item_health_prefab:{
            type:cc.Prefab,
            default:null
        },
        
        tankAtlas:cc.SpriteAtlas,
        flagsAlas:cc.SpriteAtlas,
        explosionAtlas:cc.SpriteAtlas,


        fire_audio: {
            default: null,
            url: cc.AudioClip
        },
        hit2: {
            default: null,
            url: cc.AudioClip
        },
        hit_tank: {
            default: null,
            url: cc.AudioClip
        },
        tank_no: {
            default: null,
            url: cc.AudioClip
        },

        eff_hit_wall:cc.Prefab,
        eff_hit_tank:cc.Prefab,
        eff_gun_fire:cc.Prefab,
        eff_tank_explosion:cc.Prefab
    },

    // use this for initialization
    onLoad: function () {
        // khai bao dang dictionary key-value, mục đích là chỉ chứa các script điều khiển việc hiển thị các đối tượng trong node mapgame
        this.dictObs={};// obj_type=1;
        this.dictTanks={};// obj_type=2;
        this.dictBullets={};// obj_type=3;
        this.dictItems={};// obj_type=3;
        
        this.MYPLAYER=null;
        this.t_add_tank=0;
        this.t_add_bullet=0;
        this.t_add_obs=0;
        this.t_add_items=0;
        this.t_add_explosion=0;
        
        this.isOver=false;
        this.frame=0;

        this.estimateMoveTank();

    },
    
    /**
     * trong hàm updateFrameStep thì đầu tiên gọi điến hàm beginUpdateFrame, kết thúc gọi đến hàm endUpdateFrame
     * Mục đích là để kiểm tra những đối tượng nào mà trên server không còn trả về nữa thì destroy nó đi như là 
     *  (ra ngoài view màn hình(tank,items,obs), bị nổ(tank) ,hoặc hết time-life (items,bullet) )
     * 
     * 
     * 
     * */
     
    updateFrameStep:function(msgObj){
        this.frame++;
        //----------TANK ----
        this.beginUpdate(this.dictTanks);
        var arr_tank=msgObj.t;
        this.managerTank(arr_tank);
        this.finishUpdate(this.dictTanks);
        
        this.updateMapPosition();
        
        
        //----------OBS ----

        var arr_obs=msgObj.o;
        if (!(typeof(arr_obs)==="undefined")){
            this.beginUpdate(this.dictObs);
            this.managerObs(arr_obs);
            this.finishUpdate(this.dictObs);
        }

        

        //----------BULLET ----
        this.beginUpdate(this.dictBullets);
        var arr_bullet=msgObj.b;
        this.managerBullet(arr_bullet);
        this.finishUpdate(this.dictBullets);


        
        
        //----------ITEM ----

        var arr_items=msgObj.i;
        if(!(typeof(arr_items)==="undefined")){
            this.beginUpdate(this.dictItems);
            this.managerItems(arr_items);
            this.finishUpdate(this.dictItems);
        }

        
        
        //----------Explorsion ----
        var arr_ex=msgObj.e;
        this.managerExplosion(arr_ex);
        
        
        
        
        
        this.loadMSGTest();
    },
    
    beginUpdate:function(dictUpdate){
        for(var ikey in dictUpdate){
            var tmp_script=dictUpdate[ikey];
            tmp_script.node.isActiveSC=false;
        }

        
    },
    
    finishUpdate:function(dictUpdate){
        var arrDelete=[];
        for(var ikey in dictUpdate){
            var tmp_script=dictUpdate[ikey];
            if(tmp_script.node.isActiveSC){
                continue;
            }
            if (cc.isValid(tmp_script.node)) {
                arrDelete.push(tmp_script.node);
            }
            
        }
        
        for (var deleteid = 0,maxlengt=arrDelete.length; deleteid <maxlengt; deleteid++) {
            var node_tmp=arrDelete[deleteid];
            var type_of_dict=node_tmp.obj_type;
            
            if(type_of_dict==1){
                delete this.dictObs[node_tmp.gid];
            }
            if(type_of_dict==2){
                delete this.dictTanks[node_tmp.gid];
            }
            if(type_of_dict==3){
                // var script_bullet_delete=this.dictBullets[node_tmp.gid];
                // script_bullet_delete.clearBulletEffect();
                delete this.dictBullets[node_tmp.gid];
            }
            if(type_of_dict==4){
                var script_item_delete=this.dictItems[node_tmp.gid];
                script_item_delete.beginClean();
                delete this.dictItems[node_tmp.gid];
            }
            node_tmp.removeFromParent(true);
            //node_tmp.destroy();
        }
        
    },
    
    loadMSGTest:function(){
        // doan nay chi de test object meomory
        this.c_tank_script=Object.keys(this.dictTanks).length;
        this.c_obs_script=Object.keys(this.dictObs).length;
        this.c_item_script=Object.keys(this.dictItems).length;
        this.c_bullet_script=Object.keys(this.dictBullets).length;
        var tong=this.c_tank_script+this.c_obs_script+this.c_item_script+this.c_bullet_script;
        this.c_all_node=this.node.children.length-1;// tru di 1 lan tiledMapBG
        if(tong==this.c_all_node){
            this.msglog="count all object: "+tong;
        }else{
            this.msglog="------>error: "+tong+"|"+this.c_all_node+"   info "+"t="+this.c_tank_script+ " obs="+ this.c_obs_script + " item="+ this.c_item_script + " bullet="+ this.c_bullet_script ;
        }
    },
    

    
    managerExplosion:function(arr_Ex){

        for(var i_e=0,i_e_m=arr_Ex.length;i_e<i_e_m;i_e++){
            var e_info=Utils.decodePackExplosion(arr_Ex[i_e]);
            var status=e_info.stt;
            status=status-0;

            var x_p=Number(e_info.x);
            var y_p=Number(e_info.y);
            //Utils.log("status:"+status);
            this.t_add_explosion++;
            if(status==1||status==2){//dan ban trung tuong
                var tmpnode=null;
                if(status==2){//dan va cham xe tank
                    tmpnode=cc.instantiate(this.eff_hit_tank);//hit2
                    if(!Utils.turnOffAudio) {
                        var vl = 0.8;
                        var pos1 = {};
                        pos1.x = this.MYPLAYER.x;
                        pos1.y = this.MYPLAYER.y;
                        var distance=Utils.distance2Pos(pos1,cc.p(x_p,y_p));
                        vl=1.0-distance/450.0;

                        if (vl>0.8) {
                            vl=0.8;
                        }
                        if (vl<0.1) {
                            vl=0.1;
                        }
                        vl=vl*0.3;

                        if(cc.sys.os==cc.sys.OS_IOS) {
                            jsb.reflection.callStaticMethod("BridgeIOS", "PlayEffect:volume:","hittank.mp3",vl+"");
                        }else{
                            cc.audioEngine.playEffect(this.hit_tank, false,vl);
                        }
                    }
                }else{
                    tmpnode=cc.instantiate(this.eff_hit_wall);//hit_tank
                    if(!Utils.turnOffAudio){
                        var vl=0.8;
                        var pos1={};
                        pos1.x=this.MYPLAYER.x;
                        pos1.y=this.MYPLAYER.y;
                        var distance=Utils.distance2Pos(pos1,cc.p(x_p,y_p));
                        vl=(1.0-distance/300.0)*0.9;
                        //NSLog(@"disance 11111: %f --- %f",disance,vl);
                        if (vl>0.8) {
                            vl=0.8;
                        }
                        if (vl<0.1) {
                            vl=0.1;
                        }
                        if(cc.sys.os==cc.sys.OS_IOS) {
                            jsb.reflection.callStaticMethod("BridgeIOS", "PlayEffect:volume:","hit2.mp3",vl+"");
                        }else{
                            cc.audioEngine.playEffect(this.hit2, false,vl);
                        }

                    }

                }
                if(tmpnode==null){
                    continue;
                }
                tmpnode.setPosition(cc.p(x_p,y_p));
                tmpnode.setLocalZOrder(8);
                var paricle=tmpnode.getComponent('cc.ParticleSystem');
                tmpnode.positionType=cc.ParticleSystem.PositionType.RELATIVE;
                paricle.positionType=cc.ParticleSystem.PositionType.RELATIVE;
                //var scriptEffect=tmpnode.getComponent("EffectScript");

                this.node.addChild(tmpnode);
                //scriptEffect.setFixedPosition();

            }

            if(status>=3&&status<=6){//dan ban ra tu nong sung
                var tmp_effect_gun=cc.instantiate(this.eff_gun_fire);
                tmp_effect_gun.setPosition(cc.p(78,2));
                tmp_effect_gun.scale=2;
                tmp_effect_gun.setLocalZOrder(-3);// khong hieu sao -1,-2 lai khong duoc , bo tay 
                var scriptnode=this.dictTanks[e_info.tid];
                if(typeof(scriptnode)==="undefined"){
                    continue;
                }
                if(typeof(scriptnode.node)==="undefined"){
                    continue;
                }
                var guntank=scriptnode.guntank;
                scriptnode.guntank.addChild(tmp_effect_gun);
                //console.log("scriptnode.guntank: %s",scriptnode.guntank.children.length);
                // effect audio
                if(!Utils.turnOffAudio){
                    var vl=0.8;
                    var pos1={};
                    pos1.x=this.MYPLAYER.x;
                    pos1.y=this.MYPLAYER.y;
                    var distance=Utils.distance2Pos(pos1,cc.p(x_p,y_p));

                    var vl=(1-distance/300.0)*0.8;
                    //NSLog(@"disance 3----6: %f --- %f",disance,vl);
                    if (vl>0.9) {
                        vl=0.9;
                    }
                    if (vl<0.1) {
                        vl=0.1;
                    }

                    if(cc.sys.os==cc.sys.OS_IOS) {
                        jsb.reflection.callStaticMethod("BridgeIOS", "PlayEffect:volume:","fire.mp3",vl+"");
                    }else{
                        cc.audioEngine.playEffect(this.fire_audio, false,vl);
                    }
                }


            }
            if(status===0){//xe tank no
                //if(this.isOver){
                //    return;
                //}
                var tid=parseInt(e_info.tid);
                tid=Math.abs(tid);
                tid=tid%10;
                console.log("run explorsion: %s",tid);
                var tankNodeEff=cc.instantiate(this.eff_tank_explosion);
                var script_eff=tankNodeEff.getComponent("TankEffectScript");
                script_eff.runEffect(this.explosionAtlas,tid);
                tankNodeEff.setPosition(cc.p(x_p,y_p));
                tankNodeEff.scale=0.5;
                this.node.addChild(tankNodeEff);
                console.log("status ==0"+" e_info.tid="+e_info.tid);
                // audio effect
                if(!Utils.turnOffAudio){
                    var volume=0.8;
                    tid=parseInt(e_info.tid);
                    if(tid==this.TANKID){
                        volume=0.8;
                    }else{
                        var pos1={};
                        pos1.x=this.MYPLAYER.x;
                        pos1.y=this.MYPLAYER.y;
                        var distance=Utils.distance2Pos(pos1,cc.p(x_p,y_p));
                        volume=1-distance/300.0;
                        if (volume>0.6) {
                            volume=0.6;
                        }
                        if (volume<0.1) {
                            volume=0.1;
                        }
                    }
                    volume=volume*0.5;

                    if(cc.sys.os==cc.sys.OS_IOS) {
                        jsb.reflection.callStaticMethod("BridgeIOS", "PlayEffect:volume:","tankno.mp3",volume+"");
                    }else{
                        cc.audioEngine.playEffect(this.tank_no, false,volume);
                    }
                }
            }
        }


    },
    
    
    
    
    managerTank:function(arr_tank){
         for(var i_t=0,i_t_m=arr_tank.length;i_t<i_t_m;i_t++){
            var obj_info=Utils.decodePackTank(arr_tank[i_t]);
            var tank_script=this.dictTanks[obj_info.id];
            var tankNumberID=parseInt(obj_info.id)
            //Utils.log("--->tank_tmp:"+tank_tmp);
            if ( typeof(tank_script) ==="undefined" ){// check bang null khong co tac dung :( 
                //Utils.log("add new tank game");
                var tank_node=cc.instantiate(this.t_prefab);
                if(this.TANKID===tankNumberID){
                    this.MYPLAYER=tank_node;
                }
                var colorID=Math.abs(tankNumberID%10);
                if(colorID<0){
                    colorID=6;
                }else if (colorID>9){
                    colorID=7;
                }

                tank_node.obj_type=2;
                tank_node.gid=obj_info.id;
                tank_node.scale=0.25;
                tank_node.setLocalZOrder(5); 
                
                tank_script=tank_node.getComponent("tankScript");
                tank_script.gid=obj_info.id;
                tank_script.colorID=colorID;
                tank_script.level=0;
                tank_script.levelGun=0;

                this.node.addChild(tank_node);
                this.dictTanks[tank_script.gid]=tank_script;
                
                this.t_add_tank++;
            }
            tank_script.updateFrame(obj_info);
            if(this.TANKID===tankNumberID){
                this.MYPLAYER.activeInfo=obj_info;
            }
        }
        if(!this.MYPLAYER.isActiveSC){
            this.isOver=true;
        }
    },
    
    
    managerObs:function(arr_obs){
        for(var i_o=0,j_o_m=arr_obs.length;i_o<j_o_m;i_o++){
            var tmp_info= Utils.decodePackObs(arr_obs[i_o]);
            
            var obs_script=this.dictObs[tmp_info.id];
            if( typeof(obs_script) ==="undefined" ){
               // Utils.log("Add new Obstacles");
                var tmp_Obs=cc.instantiate(this.obs_prefab);
                tmp_Obs.obj_type=1;
                tmp_Obs.gid=tmp_info.id;
                tmp_Obs.setLocalZOrder(2);
                
                obs_script=tmp_Obs.getComponent("obsScript");
                obs_script.gid=tmp_info.id;
                obs_script.initDisplay(tmp_info);
                this.node.addChild(tmp_Obs);
                
                this.dictObs[obs_script.gid]=obs_script;
                
                this.t_add_obs++;
            }
            obs_script.node.isActiveSC=true;
        }
    },
    
    
    managerBullet:function(arr_bullet){
        for(var i_b=0,j_b_m=arr_bullet.length;i_b<j_b_m;i_b++){
            var tmp_info=Utils.decodePackBullet(arr_bullet[i_b]);
            var bullet_script=this.dictBullets[tmp_info.id];
            if( typeof(bullet_script) ==="undefined" ){
               // Utils.log("Add new Bullet");
                this.t_add_bullet++;
                var tmp_Bullet=cc.instantiate(this.bullet_prefab);
                tmp_Bullet.obj_type=3;
                tmp_Bullet.gid=tmp_info.id;
                tmp_Bullet.setLocalZOrder(1);
                
                bullet_script=tmp_Bullet.getComponent("bulletScript");
                bullet_script.gid=tmp_info.id;

                this.node.addChild(tmp_Bullet);
                
                this.dictBullets[bullet_script.gid]=bullet_script;
                

            }
            bullet_script.updateFrame(tmp_info);
        }
    },
    
    
    managerItems:function(arr_items){
        for(var i_i=0,j_i_m=arr_items.length;i_i<j_i_m;i_i++){
            var tmp_info=Utils.decodePackItem(arr_items[i_i]);
            var item_script=this.dictItems[tmp_info.id];
            if( typeof(item_script) ==="undefined" ){
                //Utils.log("Add new item");
                var tmp_Item;
                if(tmp_info.type==1){
                    tmp_Item=cc.instantiate(this.item_ammo_prefab); 
                }else{
                    tmp_Item=cc.instantiate(this.item_health_prefab);
                }
                tmp_Item.obj_type=4;
                tmp_Item.gid=tmp_info.id;
                tmp_Item.setLocalZOrder(1);
                
                item_script=tmp_Item.getComponent("itemScript");
                item_script.gid=tmp_info.id;

                this.node.addChild(tmp_Item);
                
                this.dictItems[item_script.gid]=item_script;
                
                this.t_add_items++;
            }
            item_script.updateDisplay(tmp_info);
        }
    },
    
    updateMapPosition:function(){
        if(this.isOver){
            this.otherMSG="this.isOver";
            return;
        }
        if(this.MYPLAYER===null){
            this.otherMSG="MYPLAYER===null";
            return;
        }
        if(this.TANKID==this.MYPLAYER.gid){
            var x_pos=-(this.MYPLAYER.x);
            var y_pos=-(this.MYPLAYER.y);
            //this.node.setPosition(cc.p(x_pos,y_pos));
            this.node.x=x_pos*2;// nhan 2 boi vi map game scale =2
            this.node.y=y_pos*2;
            this.otherMSG="";
        }else{
            this.otherMSG="this.TANKID="+this.TANKID+" | MYPLAYER.gid: "+MYPLAYER.gid;
        }
    },
    
    
    estimateMoveTank:function(){
        /**
        *server mac dinh luon push ve la 80/1000 
        * dt_move=speed*0.08
        * 
        */
        /**
         * GIẢI THÍCH :
         * Hàm này chỉ là làm mượt chuyển động của xe tank và giảm bớt việc ở backend cứ 40/1000s là 25 lần 1s thì giờ
         * chỉ cần là 1s push về 12 lần thôi , nếu comment lại hàm này và không chạy  cũng không sao như trông nó rất giật game
         *
         * 1.Cách cũ là livestream vị trí của các Object trong game
         *      Tức là ví dụ ở frame1 xe tank ở vị trí 1, sau đó ở frame2 lại set vị trí cho xe tank ở vị trí P2..
         *      Cách này realtime và luôn nhưng nhược điểm là cần từ backend push data về liên tục
         * 2.Cách mới là tính toán đường đi tương đối của xe tank và cứ 0.08s lại đồng bộ với server 1 lần
         *      Ví dụ ở frame1 xe tank đang ở vị trí là A1 và hướng đi của tank là đến vị trí A2 ở frame sau vậy mình tạo
         *      ra 1 chuyển động cứ 0.001s lại cho xe tank nhích 1 đoạn tới vị trí của A2( vận tốc đã biết rồi) , và đên
         *      frame2 bất kể xe tank đã nhích đến hay đi quá vị trí so với frame2 trả về thì cũng set position cho tank
         *      ở vị trí frame2 trả về anh xem ở hàm managerTank
         *
         *
         *      -Cách làm tương tự như vậy đối với viên đạn ,tuy nhiên với viên đạn sẽ có chút lỗi xảy ra là giữa đường
         *      viên đạn va vào chướng ngại vật hoặc va vào xe tank mà client vẫn chưa được cập nhật speed đạn là 400
         *      và time là 0.08 vậy sẽ có trường hợp đạn ở client vẫn cứ đi thẳng sai số với server là 400*0.08=32 px
         *      cái này client thấy rất rõ ràng
         *
         *      -Một lỗi nữa là trên trình duyệt web không hiểu sao lại lag , nếu không được thì backend chắc phải if ,else code
         *      để web vẫn push về là 0.04s 1 lần còn mobile là 0.08 và mobile sẽ giảm tải được dữ liệu đi về chỉ có 1kb/s
         *
               -còn một vấn đề ở backend là vì mỗi frame là mình check vị trí của viên đạn so với chướng ngại vật là theo
         *      mỗi frame , trước ít ảy ra sai số vì mỗi frame cách nhau 0.04s và đạn đi có 16px x, giờ time mỗi frame cách
         *      nhau lên đến 0.08 thì sai số tăng lên theo , nhưng cái này mình sửa được ở server và làm sau
         *
         *
         *
         */
//      chú ý là nếu timeout quá lớn thì return ngay hoặc di chuyển quá vị trí tính toán thì stop lại
//      1 : là vẫn nên làm chức năng tính toán va chạm ở client đối với đạn và tank 
        var self=this;
        this.countStep=0;
        var TIME_FRAME_SERVER=0.08;
        this.schedule(function(dt) {
            var checkCollision=false;
            if(self.countStep==0){
                checkCollision=true;
            }
            //console.log("CCCCCC----------------------AAAA--------------------AAA");
            for(var keyobj in self.dictTanks){
                var tankscript=self.dictTanks[keyobj];
                //console.log("tankscript.dirMv: "+tankscript.dirMv);
                var maxMove=tankscript.speedMove*TIME_FRAME_SERVER;
                if(tankscript.nextFrameMove>=maxMove){
                    continue;
                }

                var dt_move=tankscript.speedMove*dt;
                tankscript.nextFrameMove=tankscript.nextFrameMove+dt_move;
                var tmp_tank=tankscript.node;
                if(tankscript.dirMv>0&&tankscript.dirMv<5){
                    if(tankscript.dirMv==1){
                        tmp_tank.x=tmp_tank.x+dt_move;
                    }else if(tankscript.dirMv==2){
                        tmp_tank.y=tmp_tank.y+dt_move;
                    }else if(tankscript.dirMv==3){
                        tmp_tank.x=tmp_tank.x-dt_move;
                    }else if(tankscript.dirMv==4){
                        tmp_tank.y=tmp_tank.y-dt_move;
                    }else{
                        //console.log("AAAAAAA----------------------AAAA--------------------AAA");
                    }

                }
            }


            self.updateMapPosition();
            
            for(var key_b in self.dictBullets){
                var bullet_script=self.dictBullets[key_b];
                var dtMv=400*dt;
                var maxMove=400*TIME_FRAME_SERVER;
                if(bullet_script.nextFrameMove>=maxMove){
                    return;
                }
                
                
                
                
                bullet_script.nextFrameMove=bullet_script.nextFrameMove+dtMv;
                var convert_angle=bullet_script.angleMove*3.14592/180;
                var tmpPos=cc.p(bullet_script.node.x+dtMv*Math.cos(convert_angle), bullet_script.node.y+dtMv*Math.sin(convert_angle));

                if(checkCollision){
                    // neu co va cham xay ra thi , bullet co opacity=0 va limit position 
                    if(this.checkCollisionWithObstacble(tmpPos)){
                        bullet_script.node.opacity=0;
                    }
                    if(this.checkCollisionWithTank(tmpPos)){
                        bullet_script.node.opacity=0;
                    }
                }
                
                
                bullet_script.node.x=tmpPos.x;
                bullet_script.node.y=tmpPos.y;
            }
            

            self.countStep=self.countStep+1;
            if(self.countStep>=3){
                self.countStep=0;
            }
            
        },0.001);
    },
    onDisable: function(){
        this.unscheduleAllCallbacks();
    },
    
    
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {
        
        
       
    // },
    
    checkCollisionWithObstacble:function(obj_b){
        var isC=false;
        for(var keyobj in this.dictObs){
            var obs_sc=this.dictObs[keyobj];
            if((obj_b.x>obs_sc.min_x)&&(obj_b.x<obs_sc.max_x)&&(obj_b.y<obs_sc.max_y)&&(obj_b.y>obs_sc.min_y)){
                isC=true;
                break;
            }
        }
        if(obj_b.x>1475||obj_b.x<-1475||obj_b.y>975||obj_b.y<-975){
            isC=true;
        }

        return isC;
    },
    checkCollisionWithTank:function(obj_b){
        var isC=false;
        for(var keyobj in this.dictTanks){
            var obs_sc=this.dictTanks[keyobj];
            if((obj_b.x>obs_sc.min_x)&&(obj_b.x<obs_sc.max_x)&&(obj_b.y<obs_sc.max_y)&&(obj_b.y>obs_sc.min_y)){
                isC=true;
                break;
            }
        }
        return isC;
    },
});




















