cc.Class({
    extends: cc.Component,

    properties: {
        spAtlas:cc.SpriteAtlas
    },

    // use this for initialization
    onLoad: function () {

    },
    runEffect:function(spAtlas,id){

        var allchild=this.node.children;
        for(var ix=0;ix<=8;ix++){
            var childNode=allchild[ix];
            var sp=childNode.getComponent("cc.Sprite");
            sp.spriteFrame=spAtlas.getSpriteFrame("Ptank-"+id+"_tex"+ix);
            var time1=(0.3+Math.random()*0.7)*1.2;
            var angle=90+Math.random()*360;
            var rotateby=cc.rotateBy(time1,angle);

            var mvx=(0.5-Math.random())*300;
            var mvy=(0.5-Math.random())*300;

            var actionmove=cc.moveBy(time1,cc.p(mvx,mvy));
            var fade=cc.fadeTo(time1*0.3,0);
            var delay=cc.delayTime(time1+0.6);
            var sqaction=cc.sequence(delay,fade);
            childNode.runAction(cc.spawn(rotateby,actionmove,sqaction));
        }
    },

    start: function () {
        setTimeout(function () {
            this.node.destroy();
        }.bind(this), 1700);
    },

});
