var Utils = require('../LIB/Utils');
cc.Class({
    extends: cc.Component,

    properties: {
        nodeWeb:cc.Node,
        nodeMobile:cc.Node,
        txtUserName:cc.EditBox,
        hubloading:cc.Node,
        popSetting:cc.Prefab
    },

    loadFlagIpInfo:function(){
        if(this.IpInfo){
            return;
        }
        this.IpInfo=true;
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function ()
        {
            if (xhr.readyState == 4 && (xhr.status >= 200 && xhr.status < 400))
            {
                var response = xhr.responseText;

                var flag=JSON.parse(response).country;

                if(flag!=null){

                    if(flag.length>1||flag.length<4){
                        flag=flag.toLowerCase();
                        cc.sys.localStorage.setItem("country", flag);
                        console.log("ipinfo---->"+flag);
                    }

                }
            }
        };
        xhr.open("GET","http://ipinfo.io/json", true);
        xhr.send();
    },

    loadFlagIpAPI:function(){
        var xhr = new XMLHttpRequest();
        var self=this;
        xhr.onreadystatechange = function ()
        {
            if (xhr.readyState == 4 && (xhr.status >= 200 && xhr.status < 400))
            {
                var response = xhr.responseText;

                var flag=JSON.parse(response).countryCode;

                if(flag!=null){

                    if(flag.length>1||flag.length<4){
                        flag=flag.toLowerCase();
                        cc.sys.localStorage.setItem("country", flag);
                        console.log("IPAPI---->"+flag);
                    }else{
                        self.loadFlagIpInfo();
                    }

                }else{
                    self.loadFlagIpInfo();
                }

            }else{
                self.loadFlagIpInfo();
            }
        };
        xhr.onerror=function(){
            self.loadFlagIpInfo();
        };
        xhr.open("GET", "http://ip-api.com/json/", true);
        xhr.send();
    },



    // use this for initialization
    onLoad: function () {
        if(cc.sys.isNative){
         // this.lbOS.string="isNative-iOS+Android:"+cc.sys.os; 
            this.nodeWeb.active=false;
            this.nodeMobile.active=true;
        }else{
            this.nodeWeb.active=true;
            this.nodeMobile.active=false;
        }
        var strx=cc.sys.localStorage.getItem("usr");
        if(strx!=null){
            if(typeof (strx)==="undefined"){
                this.txtUserName.string="";
            }else{
                this.txtUserName.string=strx;
            }
        }
        this.IpInfo=false;
        this.AdsManager();
        this.loadFlagIpAPI();

        if (typeof (Utils.myscore)!="undefined"){
            var intscore=parseInt(Utils.myscore);
            if(intscore>0){
                var strintscore=intscore+"";
                if(cc.sys.os==cc.sys.OS_IOS) {
                    jsb.reflection.callStaticMethod("BridgeIOS", "submitScoreGameCenter:leaderBoarID:", strintscore, "com.gameio.tankhighscore");
                }
            }
        }



        Utils.turnOffAudio=false;
    },

    AdsManager:function(){
        if(cc.sys.os==cc.sys.OS_IOS){
            // hien thi quang cao
            jsb.reflection.callStaticMethod("BridgeIOS", "ShowAdsBanerWithAdnimation");

            jsb.reflection.callStaticMethod("BridgeIOS", "ShowFullScreen");

            // hien thi loi thong bao khi khong ket not duoc mang
            if (typeof (Utils.messageconnect)!="undefined"){
                var msg=Utils.messageconnect+"";
                if(msg.length>4){
                    jsb.reflection.callStaticMethod("BridgeIOS",
                        "callNativeUIWithTitle:andContent:",
                        "Message",
                        msg);
                    Utils.messageconnect="";
                }
            }


        }else if(cc.sys.os==cc.sys.OS_ANDROID){
            
        }else {// phien ban web 
            
        }
    },
    
    acRate:function(){
        /**
         *  NHỮNG API NÀY ĐƯỢC GỌI ĐI GỌI LẠI VÀ NÓ LÀ CƠ BẢN TẤT CẢ CÁC GAME ĐỀU CẦN CÓ NHƯ LÀ INAPP-PURCHASE,ADS,GAMECENTER,SHARE..., 
         *  NÊN SAU GAME NÀY MÌNH VIẾT NÓ THÀNH 1 CLASS RIÊNG ĐỂ DỄ TÁI SỬ DỤNG VÀ DỄ QUẢN LÝ, CÒN GIỜ CỨ VIẾT TẠM HẾT TRONG ĐÂY 
         * */
        var urlRateApp="";
        if(cc.sys.os==cc.sys.OS_IOS){
            urlRateApp="itms-apps://itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?id=1142249508&onlyLatestVersion=true&pageNumber=0&sortOrdering=1&type=Purple+Software";
            
        }else{// la android 
            urlRateApp="https://play.google.com/store/apps/details?id=pack_name";
        }
        cc.sys.openURL(urlRateApp);
    },
    acHighScore:function(){
        if(cc.sys.os==cc.sys.OS_IOS){
            jsb.reflection.callStaticMethod("BridgeIOS", "showHighScore");
        }

                                        
                                               
    },
    acSetting:function(){
        var popsetting=cc.instantiate(this.popSetting);
        this.node.addChild(popsetting);
    },
    acShare:function(){
        if(cc.sys.os==cc.sys.OS_IOS){
            jsb.reflection.callStaticMethod("BridgeIOS", "shareAppNative:","https://itunes.apple.com/app/id1142249508");
        }
    },

    actionOpenURL:function(){
        cc.sys.openURL("http://tank.gameio.net");
    },
    
    actionWebLoadAppstore:function(){
        cc.sys.openURL("https://itunes.apple.com/app/id1142249508");
    },
    actionWebLoadAppPlayStore:function(){
        cc.sys.openURL("https://itunes.apple.com/app/id1142249508");
    },
    
    acFacebookPage:function(){
        cc.sys.openURL("https://www.facebook.com/gameio.live");
    },
    acTwitterPage:function(){
        cc.sys.openURL("https://twitter.com/GameioL");
        
    },
    actionLoadGaamePlayer:function(){
        Utils.playerName=this.txtUserName.string.trim();
        cc.sys.localStorage.setItem("usr", Utils.playerName);
        this.loadConfigAudio();
        this.hubloading.opacity=255;
        cc.director.loadScene("GamePlay");
    },

    loadConfigAudio:function(){
        var eff_disable=false;
        var disableSound=cc.sys.localStorage.getItem("disableEffect");
        if(disableSound!=null){
            if(typeof (disableSound)==="undefined"){
                console.log("AAAA begin eff");
                eff_disable=false;
            }else{

                eff_disable=JSON.parse(disableSound);
            }
        }
        Utils.turnOffAudio=eff_disable;

        var boole_swipe=false;
        var enable_swipe=cc.sys.localStorage.getItem("enable_swipe");
        if(enable_swipe!=null){
            if(typeof (enable_swipe)==="undefined"){
                enable_swipe=false;
            }else{
                boole_swipe=JSON.parse(enable_swipe);
            }
        }
        Utils.enableSwipe=!boole_swipe;
    }
});
