cc.Class({
    extends: cc.Component,

    properties: {
        
    },

    onLoad: function () {
        cc.log("askdjakshdaksdhkasjdhakjsdhkajshdksajd0239182371892739172891");
    },
    
});
