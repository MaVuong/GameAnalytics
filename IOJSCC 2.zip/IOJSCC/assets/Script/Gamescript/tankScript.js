cc.Class({
    extends: cc.Component,

    properties: {
        lbname:{
            type:cc.Label,
            default:null
        },
        bodytank:{
            type:cc.Node,
            default:null
        },
        guntank:{
            type:cc.Node,
            default:null
        },


        lbscore:{
            type:cc.Label,
            default:null
        }
    },

    // use this for initialization
    onLoad: function () {
        this.lbname.string="";
        this.dirMv=0;
        this.speedMove=0;
        this.nextFrameMove=0;

        this.ammo=0;
        this.hp=0;
        this.level=0;

        this.count_updateRun=0;

        this.needUpdateName=true;

        var flagNode=this.node.children[1];
        flagNode.active=false;
        //var sp_body=this.node.children[0];
        //var sprite_body=sp_body.getComponent("cc.Sprite");
        //sprite_body.spriteFrame=this.spAllCharacter.getSpriteFrame("TankColor-t5_b");


    },
    //[{"x":"-61.50","y":"-52.00","id":"48","r":"0.00","level":"1","score":"0","hp":"80","ammo":"140","sp":"50","gR":"180"}],"e":[]}

    updateFrame:function(obj_info){
        var x_p=Number(obj_info.x);
        var y_p=Number(obj_info.y);
        this.node.isActiveSC=true;
        this.node.setPosition(cc.p(x_p,y_p));
        
        this.bodytank.rotation=Number(obj_info.r);
        
        var gunR=Number(obj_info.gR);
        if(gunR>180){
            gunR=gunR-360;
        }
        gunR=-gunR;
        //console.log("obj_info.dirMV: %s",obj_info.dir);
        this.dirMv=parseInt(obj_info.dir);
        this.speedMove=parseInt(obj_info.sp);
    
        this.nextFrameMove=0;


        this.Opos=cc.p(x_p,y_p);
        this.min_x=x_p-12;
        this.max_x=x_p+12;
        this.min_y=y_p-12;
        this.max_y=y_p+12;

        //this.score=obj_info.score;
        //this.ammo=parseInt(obj_info.ammo);
        //this.hp=parseInt(obj_info.hp);

        var tmpLevel=parseInt(obj_info.level);
        if(tmpLevel!=this.level){
            this.level=tmpLevel;
            var parrentNode=this.node.parent;
            var mapScript=parrentNode.getComponent("GameMap");

            var sp_body=this.node.children[0];
            var sprite_body=sp_body.getComponent("cc.Sprite");
            sprite_body.spriteFrame=mapScript.tankAtlas.getSpriteFrame("TankColor-t"+this.colorID+"_b");
            //this.count_updateRun++;
            var tml_lv_gun=1;
            if (this.level>=10&&this.level<35){
                tml_lv_gun=2;
            }else if(this.level>=35&&this.level<79){
                tml_lv_gun=3;
            }else if(this.level>=79){
                tml_lv_gun=4;
            }
            if (this.levelGun!=tml_lv_gun) {
                this.levelGun = tml_lv_gun;
                var sp_gun = this.node.children[3];
                var sprite_gun=sp_gun.getComponent("cc.Sprite");
                //this.count_updateRun++;
                sprite_gun.spriteFrame = mapScript.tankAtlas.getSpriteFrame("TankColor-t" + this.colorID + "_l" + this.levelGun);
            }
        }

        var tmp_hp=parseInt(obj_info.hp);
        if(tmp_hp!=this.hp){
            this.hp=tmp_hp;
            var nodepr=this.node.children[2];
            var nodeprsc=nodepr.children[0];
            var maxHP=80+(this.level-1)*15;
            var Xsc=this.hp/maxHP;
            if(Xsc>1){
                Xsc=1;
            }else if(Xsc<0){
                Xsc=0;
            }
            nodeprsc.scaleX=Xsc;
            //this.count_updateRun++;
        }

        var name=obj_info.name;
        if(name.length>=1&&this.needUpdateName){
            this.count_updateRun++;

            this.needUpdateName=false;


            var nodescore=this.node.children[5];
            var lbscore=nodescore.getComponent("cc.Label");
            lbscore.string=name


            var ccode=obj_info.code;
            if(ccode.length==2||true){
                var flagNode=this.node.children[1];
                flagNode.active=true;
                var flagSprite=flagNode.getComponent("cc.Sprite");
                var parrentNode=this.node.parent;
                var mapScript=parrentNode.getComponent("GameMap");
                flagSprite.spriteFrame=mapScript.flagsAlas.getSpriteFrame("flag-"+ccode);
            }




        }

        var nodename=this.node.children[4];
        var lbRed=nodename.getComponent("cc.Label");
        lbRed.string=obj_info.score;
        //var nodescore=this.node.children[5];
        //var lbscore=nodescore.getComponent("cc.Label");
        //lbscore.string=

        this.guntank.rotation=gunR;
        //this.lbname.string="GuestXXXX";

    },

});
