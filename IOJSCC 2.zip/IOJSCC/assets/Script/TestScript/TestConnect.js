cc.Class({
    extends: cc.Component,

    properties: {
       label_status:{
           type:cc.Label,
           default:null
       },
       
    },

    // use this for initialization
    onLoad: function () {

    },
    
    actionConnect: function(){
        var self=this;
        require('socket.io');
        this.socket = io.connect('localhost:2020');
        this.socket.on('connect', function(msgSend){
            cc.log("connection------>");
            self.label_status.string="ALKHKJHKD";
        });
     
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
